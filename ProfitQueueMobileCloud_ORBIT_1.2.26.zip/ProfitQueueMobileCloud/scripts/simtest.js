'use strict';

const assert=require('assert');
const Module=require('module');
// Load server.js without installing web-server dependencies; simulation only needs pure logic.
const originalLoad=Module._load;
Module._load=function(request,parent,isMain){
  if(request==='dotenv') return {config:()=>({})};
  if(request==='express'){
    const express=()=>({use:()=>{},disable:()=>{},set:()=>{},get:()=>{},post:()=>{}});
    express.json=()=>((_req,_res,next)=>next&&next());
    express.static=()=>((_req,_res,next)=>next&&next());
    return express;
  }
  if(request==='multer'){
    const multer=()=>({fields:()=>((_req,_res,next)=>next&&next())});
    multer.memoryStorage=()=>({});
    return multer;
  }
  return originalLoad.apply(this,arguments);
};
// Any accidental network call makes the simulation suite fail immediately.
global.fetch=async()=>{ throw new Error('SIMULATION_SUITE_NETWORK_CALL_BLOCKED'); };

const {marketToItem,reconcileIdentityWithLens,itemQueryCandidates,cloudflareResultText}=require('../server');
Module._load=originalLoad;

function q({matched=0,estimate=0,sample=matched,total=Math.max(sample,estimate),precision=.90,precisionLow=.78,uncertain=false,broadQuery=false}={}){
  const low=Math.max(0,estimate*.82),high=Math.max(low,estimate*1.18);
  return {matchedN:matched,estimate,sampleN:sample,total,precision,precisionLow,low,high,uncertain,broadQuery};
}
function priceRows({brand='Acme',model='Model X',family='widget',count=8,price=50,spread=.08,shipping=6,visual=false,prefix='sold'}={}){
  const rows=[];
  for(let i=0;i<count;i++){
    const wiggle=1+((((i*37)%11)-5)/5)*spread;
    const p=Math.max(1,price*wiggle);
    rows.push({
      itemId:`${prefix}-${i}`,
      title:`${brand} ${model} ${family} ${i+1}`.trim(),
      price:Number(p.toFixed(2)), shipping, landedPrice:Number((p+shipping).toFixed(2)),
      sold_date:'2026-09-01', searchPool:'exact', visualVerified:visual, visualConfidence:visual?.91:0,
      compClass:visual?'exact':'title_supported_exact'
    });
  }
  return rows;
}
function makeMarket({brand='Acme',model='Model X',family='widget',price=50,sold=12,active=10,useFamily=false,visual=false,soldAvailable=true,activeAvailable=true,dispersion=.08,shipping=6,activeUncertain=false,scarcity=false}={}){
  const exactSold=useFamily?Math.min(1,sold):sold;
  const exactActive=useFamily?Math.min(1,active):active;
  const familySold=useFamily?sold:Math.max(sold,exactSold);
  const familyActive=useFamily?active:Math.max(active,exactActive);
  const exactRows=priceRows({brand,model,family,count:Math.max(0,Math.min(24,exactSold||0)),price,spread:dispersion,shipping,visual,prefix:'exact'});
  const familyRows=priceRows({brand,model:useFamily?'Similar Style':model,family,count:Math.max(0,Math.min(80,familySold||0)),price,spread:dispersion,shipping,visual,prefix:'family'}).map(r=>({...r,searchPool:'family',compClass:visual?'family':'title_supported_family'}));
  const activeEstimate=scarcity?0:active;
  const familyActiveEstimate=scarcity?0:familyActive;
  return {
    query:`${brand} ${model}`,
    familyQuery:`${brand} ${family}`,
    soldSource:'SIM', providerMs:0,classifyMs:0,
    soldDataAvailable:soldAvailable, activeDataAvailable:activeAvailable,
    visualVerificationAvailable:visual,
    prices:exactRows.map(r=>r.price), familyPrices:familyRows.map(r=>r.price),
    soldExact:exactRows, soldFamilyVelocity:familyRows, soldFamily:familyRows,
    soldPre:[...exactRows,...familyRows],
    soldQ:q({matched:exactSold,estimate:sold,sample:Math.max(1,exactSold),total:Math.max(sold,exactSold),precision:.94,precisionLow:.82}),
    activeQ:q({matched:exactActive,estimate:activeEstimate,sample:Math.max(1,exactActive),total:scarcity?Math.max(1,exactActive):Math.max(active,exactActive),precision:.93,precisionLow:.80,uncertain:activeUncertain}),
    familySoldQ:q({matched:familySold,estimate:sold,sample:Math.max(2,Math.min(30,familySold)),total:Math.max(sold,familySold),precision:.92,precisionLow:.79}),
    familyActiveQ:q({matched:scarcity?0:familyActive,estimate:familyActiveEstimate,sample:scarcity?Math.max(1,Math.min(4,familyActive||1)):Math.max(1,Math.min(30,familyActive)),total:scarcity?Math.max(1,Math.min(4,familyActive||1)):Math.max(active,familyActive),precision:.91,precisionLow:.78,uncertain:activeUncertain}),
    familySoldCountLowerBound:false,soldCountLowerBound:false,
    visualSoldInspected:visual?Math.min(4,familySold):0, visualActiveInspected:visual?Math.min(4,familyActive):0,
    visualSoldExactInspected:visual?Math.min(4,exactSold):0, visualActiveExactInspected:visual?Math.min(4,exactActive):0,
    agreement:.94, activeMarketConfidence:.82, providerErrors:[],
    askingPriceMedian:price*1.15, activePriceLow:price*.8, activePriceHigh:price*1.4,
    demandProxy:'simulated', visibleActiveSoldUnits:0, activeListingsWithSales:0, activeWatchers:0
  };
}
function makeIdentity({brand='Acme',model='Model X',family='widget',confidence=.92,shipping=6,weight=.5,title=null}={}){
  return {
    title:title||`${brand} ${model} ${family}`,
    item_type:family,category:'Simulated',brand,model,condition:'used',identity_confidence:confidence,
    visible_text:[],identity_terms:[model],family_identity_terms:[],velocity_family:family,exclude_terms:[],query_candidates:[`${brand} ${model}`],
    shipping_estimate:shipping,supplies_estimate:1,labor_min:10,weight_estimate_lb:weight,weight_low_lb:weight*.8,weight_high_lb:weight*1.2,weight_confidence:.8
  };
}
function runScenario(spec){
  const identity=makeIdentity(spec);
  const market=makeMarket(spec);
  const settings={manualPrice:spec.cost??1,acquisitionMode:spec.bins?'bins':'normal',binsPricePerLb:spec.binsRate??1.69,minProfit:spec.minProfit??10,minResaleValue:spec.minResale??25,minSellThrough:spec.minStr??10,defaultFeesPct:15};
  const item=marketToItem(identity,market,settings);
  return {identity,market,item,settings};
}

let passed=0;
const failures=[];
function test(name,fn){
  try{fn();passed++;}
  catch(err){failures.push({name,error:err.message});}
}

// Named regressions taken from real ORBIT failure modes.
test('Bose family evidence keeps STR without visual classifier',()=>{
  const {item}=runScenario({brand:'Bose',model:'QuietControl 30',family:'wireless neckband headphones',price:55.53,sold:60,active:100,useFamily:true,visual:false,cost:1,shipping:6.55});
  assert.strictEqual(item.velocityVerified,true);
  assert(item.sellThrough90!==null && Math.abs(item.sellThrough90-60)<.2);
  assert(item.pricingAvailable && item.pricingVerified);
});
test('40 sold / 57 active family pool must not blank STR',()=>{
  const {item}=runScenario({brand:'Jabra',model:'Halo Smart',family:'wireless neckband headset',price:55.49,sold:40,active:57,useFamily:true,visual:false,cost:.338});
  assert.strictEqual(item.velocityVerified,true);
  assert(item.sellThrough90!==null);
  assert(Math.abs(item.sellThrough90-70.2)<1);
});
test('Wolverine cheap item with buyer-paid shipping gets positive max buy',()=>{
  const {item}=runScenario({brand:'Toy Biz',model:'Wolverine',family:'action figure',price:15.75,sold:95,active:85,useFamily:true,visual:false,cost:.169,shipping:6.55,minProfit:5});
  assert(item.maxBuyPrice>item.cost);
  assert(item.sellThrough90>100);
});
test('Kim Seybert family pricing survives thin exact pool',()=>{
  const {item}=runScenario({brand:'Kim Seybert',model:'Fall Leaves',family:'beaded table runner',price:140.76,sold:9,active:35,useFamily:true,visual:false,cost:1,shipping:9});
  assert(item.pricingAvailable);
  assert(item.averageSalePrice>100);
  assert(item.sellThrough90!==null);
});
test('zero active scarcity produces lower-bound STR',()=>{
  const {item}=runScenario({brand:'RareCo',model:'R1',family:'collectible',price:80,sold:8,active:0,useFamily:true,visual:false,cost:5,scarcity:true});
  assert.strictEqual(item.activeScarcitySignal,true);
  assert(item.sellThrough90>=800);
  assert.strictEqual(item.sellThroughLowerBound,true);
});
test('missing active provider does not fake STR',()=>{
  const {item}=runScenario({price:60,sold:12,active:8,useFamily:true,activeAvailable:false});
  assert.strictEqual(item.velocityVerified,false);
  assert.strictEqual(item.sellThrough90,null);
});
test('missing sold provider cannot verify pricing',()=>{
  const {item}=runScenario({price:60,sold:12,active:8,useFamily:true,soldAvailable:false});
  assert.strictEqual(item.pricingVerified,false);
});
test('very dispersed sold prices lower pricing confidence',()=>{
  const {item}=runScenario({price:60,sold:12,active:8,useFamily:true,dispersion:1.4});
  assert(item.pricingConfidenceLabel!=='High');
});
test('bins uses conservative high weight cost',()=>{
  const {item}=runScenario({price:65,sold:20,active:10,useFamily:false,bins:true,binsRate:1.69,weight:2});
  assert.strictEqual(item.acquisitionMode,'bins');
  assert(Math.abs(item.cost-(2*1.2*1.69))<.02);
});
test('active uncertainty blocks exact velocity readiness',()=>{
  const {item}=runScenario({price:65,sold:20,active:10,useFamily:false,activeUncertain:true});
  assert.strictEqual(item.velocityVerified,false);
});
test('specific wrong Jabra ID is corrected by Bose Lens consensus',()=>{
  const wrong={title:'Jabra Elite 25e Wireless Bluetooth Neckband Earphones',brand:'Jabra',model:'Elite 25e',item_type:'wireless neckband headphones',identity_confidence:.94,visible_text:[],identity_terms:['Elite 25e'],query_candidates:['Jabra Elite-25e'],condition:'used'};
  const lens=[{title:'Bose QuietControl 30 Wireless Headphones'},{title:'Bose QuietControl 30 QC30 Bluetooth Neckband Headphones'},{title:'Bose QuietControl 30 Black Wireless Headset'},{title:'Bose QuietControl 30 Wireless Noise Cancelling Headphones'}];
  const fixed=reconcileIdentityWithLens(wrong,lens);
  assert.strictEqual(String(fixed.brand).toLowerCase(),'bose');
  assert(/^bose/i.test(itemQueryCandidates(fixed)[0]||''));
});
test('Cloudflare response envelope parser handles Workers AI shape',()=>{
  const body={result:{response:'{"items":[{"title":"Bose QuietControl 30"}]}'},success:true};
  assert(/Bose/.test(cloudflareResultText(body)));
});

// 88 deterministic generated scenarios = 100 total. They exercise price, demand,
// exact/family velocity, visual/no-visual, acquisition costs, and confidence ranges.
for(let i=0;i<88;i++){
  test(`generated reseller scenario ${String(i+1).padStart(2,'0')}`,()=>{
    const useFamily=i%2===0;
    const visual=i%3===0;
    const price=12+(i%11)*9;
    const sold=4+(i%17)*3;
    const active=2+(i%13)*4;
    const cost=.5+(i%9)*2.25;
    const shipping=4.5+(i%5)*1.25;
    const {item}=runScenario({brand:`Brand${i%7}`,model:`M${100+i}`,family:['headphones','boots','camera','toy','shirt','bag','collectible'][i%7],price,sold,active,useFamily,visual,cost,shipping,confidence:.78+(i%5)*.04,minProfit:5+(i%4)*2});
    assert(Number.isFinite(item.averageSalePrice) && item.averageSalePrice>0,'price should be available');
    assert(item.pricingAvailable===true,'pricing should be available');
    assert(item.sellThrough90!==null,'STR should be present when both market sides exist');
    const expected=sold/active*100;
    assert(Math.abs(item.sellThrough90-expected)<1.2,`STR mismatch ${item.sellThrough90} vs ${expected}`);
    assert(Number.isFinite(item.maxBuyPrice) && item.maxBuyPrice>=0,'max buy must be finite/nonnegative');
    assert(item.soldDataAvailable===true && item.activeDataAvailable===true,'market availability should survive');
    if(!visual) assert(/title-supported evidence used/i.test(item.marketSource),'no-visual path should disclose title-supported evidence');
  });
}

if(failures.length){
  console.error(`ORBIT zero-credit simulation suite: ${passed}/100 passed, ${failures.length} failed`);
  failures.forEach(f=>console.error(`- ${f.name}: ${f.error}`));
  process.exit(1);
}
console.log(`ORBIT zero-credit simulation suite: ${passed}/100 passed — 0 network/API calls`);
