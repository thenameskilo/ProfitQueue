'use strict';

require('dotenv').config();
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const multer = require('multer');

const app = express();
const PORT = Number(process.env.PORT || 4173);
const HOST = process.env.HOST || '0.0.0.0';
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 14 * 1024 * 1024, files: 5 },
  fileFilter: (_req, file, cb) => cb(null, /^image\//.test(file.mimetype || ''))
});

// Keep local-development file:// access working; production uses same-origin HTTPS.
app.use((req,res,next)=>{
  const origin=String(req.headers.origin||'');
  const allowed=!origin || origin==='null' || /^https?:\/\/(?:localhost|127\.0\.0\.1)(?::\d+)?$/i.test(origin);
  if(allowed){
    res.setHeader('Access-Control-Allow-Origin',origin||'*');
    res.setHeader('Vary','Origin');
    res.setHeader('Access-Control-Allow-Methods','GET,POST,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers','Content-Type, X-ProfitQueue-Access');
  }
  if(req.method==='OPTIONS') return res.sendStatus(204);
  next();
});
app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use((req,res,next)=>{
  res.setHeader('X-Content-Type-Options','nosniff');
  res.setHeader('Referrer-Policy','same-origin');
  res.setHeader('Permissions-Policy','camera=(self)');
  if (req.path.startsWith('/api/')) res.setHeader('Cache-Control','no-store');
  next();
});
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public'), {
  maxAge: process.env.NODE_ENV==='production' ? '1h' : 0,
  setHeaders(res,file){ if(file.endsWith('index.html')||file.endsWith('sw.js')||file.endsWith('manifest.webmanifest')) res.setHeader('Cache-Control','no-cache'); }
}));

function cleanTextEnv(v='') { return String(v).trim(); }

const ENGINE_VERSION = '1.2.26-testlab-cloudflare-primary';
const GEMINI_MODEL = process.env.GEMINI_VISION_MODEL || 'gemini-3.5-flash';
const FAST_IDENTIFY_MODEL = process.env.GEMINI_IDENTIFY_FAST_MODEL || 'gemini-3.5-flash-lite';
const COMP_MODEL = process.env.GEMINI_COMP_MODEL || 'gemini-3.5-flash-lite';
const SERPAPI_KEY = process.env.SERPAPI_KEY || '';
const TRAWL_API_KEY = process.env.TRAWL_API_KEY || '';
const TRAWL_MAX_PAGES = Math.max(1, Math.min(6, Number(process.env.TRAWL_MAX_PAGES || 2)));
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || '';
const CLOUDFLARE_ACCOUNT_ID = cleanTextEnv(process.env.CLOUDFLARE_ACCOUNT_ID || '');
const CLOUDFLARE_API_TOKEN = cleanTextEnv(process.env.CLOUDFLARE_API_TOKEN || process.env.CLOUDFLARE_AUTH_TOKEN || '');
const CLOUDFLARE_VISION_MODEL = cleanTextEnv(process.env.CLOUDFLARE_VISION_MODEL || '@cf/google/gemma-4-26b-a4b-it');
const CLOUDFLARE_VISION_TIMEOUT_MS = Math.max(2500, Math.min(12000, Number(process.env.CLOUDFLARE_VISION_TIMEOUT_MS || 6000)));
const CLOUDFLARE_VISION_CONFIGURED = Boolean(CLOUDFLARE_ACCOUNT_ID && CLOUDFLARE_API_TOKEN);
const APP_ACCESS_CODE = cleanTextEnv(process.env.APP_ACCESS_CODE || '');
// Free-mode defaults: one sold page + one active page for one search formulation.
// This is about 2 SerpApi searches/item, so the 250-search free plan goes much further.
const MARKET_SAMPLE_PAGES = Math.max(1, Math.min(3, Number(process.env.MARKET_SAMPLE_PAGES || 1)));
const MARKET_QUERY_ATTEMPTS = Math.max(1, Math.min(3, Number(process.env.MARKET_QUERY_ATTEMPTS || 2)));
const VISUAL_COMP_MAX_SOLD = Math.max(3, Math.min(16, Number(process.env.VISUAL_COMP_MAX_SOLD || 4)));
const VISUAL_COMP_MAX_ACTIVE = Math.max(2, Math.min(12, Number(process.env.VISUAL_COMP_MAX_ACTIVE || 4)));
const COMP_IMAGE_TIMEOUT_MS = Math.max(1200, Math.min(7000, Number(process.env.COMP_IMAGE_TIMEOUT_MS || 1800)));
const COMP_CLASSIFY_TIMEOUT_MS = Math.max(3200, Math.min(9000, Number(process.env.COMP_CLASSIFY_TIMEOUT_MS || 5200)));
const COMP_IMAGE_MAX_BYTES = Math.max(250000, Math.min(4000000, Number(process.env.COMP_IMAGE_MAX_BYTES || 1200000)));
const IDENTIFY_FALLBACK_DELAY_MS = Math.max(1200, Math.min(5000, Number(process.env.IDENTIFY_FALLBACK_DELAY_MS || 2400)));
const IDENTIFY_MAX_IMAGES = Math.max(1, Math.min(5, Number(process.env.IDENTIFY_MAX_IMAGES || 3)));
const GEMINI_IMAGE_REQUEST_TIMEOUT_MS = Math.max(3200, Math.min(9000, Number(process.env.GEMINI_IMAGE_REQUEST_TIMEOUT_MS || 5200)));
const SERP_REQUEST_TIMEOUT_MS = Math.max(2800, Math.min(9000, Number(process.env.SERP_REQUEST_TIMEOUT_MS || 4800)));
const TRAWL_REQUEST_TIMEOUT_MS = Math.max(2800, Math.min(9000, Number(process.env.TRAWL_REQUEST_TIMEOUT_MS || 4800)));
const TRAWL_MAX_ATTEMPTS_FAST = Math.max(1, Math.min(3, Number(process.env.TRAWL_MAX_ATTEMPTS_FAST || 2)));
const LENS_UPLOAD_TIMEOUT_MS = Math.max(1800, Math.min(7000, Number(process.env.LENS_UPLOAD_TIMEOUT_MS || 3200)));
const LENS_SEARCH_TIMEOUT_MS = Math.max(1800, Math.min(7000, Number(process.env.LENS_SEARCH_TIMEOUT_MS || 3600)));
const LENS_CROSSCHECK_WAIT_MS = Math.max(800, Math.min(5000, Number(process.env.LENS_CROSSCHECK_WAIT_MS || 2600)));
const LENS_CROSSCHECK_MIN_SUPPORT = Math.max(2, Math.min(5, Number(process.env.LENS_CROSSCHECK_MIN_SUPPORT || 2)));

const SEARCH_CACHE = new Map();
const SEARCH_CACHE_TTL_MS = 45 * 60 * 1000;
const COMP_IMAGE_CACHE = new Map();
const COMP_IMAGE_CACHE_TTL_MS = 6 * 60 * 60 * 1000;
const ANALYSIS_CACHE = new Map();
const ANALYSIS_CACHE_TTL_MS = 15 * 60 * 1000;

// Trawl's free plan allows 2 requests/second. Keep every request in this process
// behind one queue so single, group, refinement, and repeated scans cannot burst
// above the provider limit. 650ms gives us headroom beyond the 500ms minimum.
const TRAWL_MIN_INTERVAL_MS = Math.max(550, Math.min(5000, Number(process.env.TRAWL_MIN_INTERVAL_MS || 650)));
const TRAWL_INFLIGHT = new Map();
let trawlQueueTail = Promise.resolve();
let trawlLastStartedAt = 0;
async function runTrawlQueued(task) {
  const previous = trawlQueueTail;
  let release;
  trawlQueueTail = new Promise(resolve => { release = resolve; });
  await previous;
  try {
    const waitMs = Math.max(0, TRAWL_MIN_INTERVAL_MS - (Date.now() - trawlLastStartedAt));
    if (waitMs > 0) await sleep(waitMs);
    trawlLastStartedAt = Date.now();
    return await task();
  } finally {
    release();
  }
}
function retryAfterMs(response) {
  const raw = cleanText(response?.headers?.get?.('retry-after') || '');
  if (!raw) return 0;
  const seconds = Number(raw);
  if (Number.isFinite(seconds) && seconds >= 0) return Math.ceil(seconds * 1000);
  const when = Date.parse(raw);
  return Number.isFinite(when) ? Math.max(0, when - Date.now()) : 0;
}

let soldProviderDegradedUntil = 0;
let soldProviderLastError = '';
const SOLD_PROVIDER_COOLDOWN_MS = 5 * 60 * 1000;
function cacheGet(key){ const v=SEARCH_CACHE.get(key); if(!v) return null; if(Date.now()-v.at>SEARCH_CACHE_TTL_MS){SEARCH_CACHE.delete(key);return null;} return v.data; }
function cacheSet(key,data){ SEARCH_CACHE.set(key,{at:Date.now(),data}); if(SEARCH_CACHE.size>250){ const first=SEARCH_CACHE.keys().next().value; SEARCH_CACHE.delete(first); } }
function analysisCacheGet(key){ const v=ANALYSIS_CACHE.get(key); if(!v) return null; if(Date.now()-v.at>ANALYSIS_CACHE_TTL_MS){ANALYSIS_CACHE.delete(key);return null;} return v.data; }
function analysisCacheSet(key,data){ ANALYSIS_CACHE.set(key,{at:Date.now(),data}); if(ANALYSIS_CACHE.size>100){ const first=ANALYSIS_CACHE.keys().next().value; ANALYSIS_CACHE.delete(first); } }
function stableJson(value){ if(Array.isArray(value)) return `[${value.map(stableJson).join(',')}]`; if(value&&typeof value==='object'){ return `{${Object.keys(value).sort().map(k=>JSON.stringify(k)+':'+stableJson(value[k])).join(',')}}`; } return JSON.stringify(value); }
function analysisFingerprint(uploaded, mode, barcode, settings){ const h=crypto.createHash('sha256'); h.update(String(mode||'single')); h.update('\0'+String(barcode||'')); h.update('\0'+stableJson(settings||{})); for(const f of uploaded){ h.update('\0'+String(f.mimetype||'')); h.update(f.buffer); } return h.digest('hex'); }

const STOP = new Set('a an and the of for with without to from by on in at is are was were this that these those vintage rare new used genuine authentic original oem nice great'.split(' '));
const ACCESSORY_WORDS = new Set('case cover manual instructions box packaging charger cable cord adapter replacement part parts shell skin mount stand holder remote strap bag pouch dock cradle battery lens cap'.split(' '));
const LOT_RE = /\b(lot of|bundle of|set of \d+|\d+[- ]?(?:pc|pcs|piece|pack)|pair of|lot\b|bundle\b)/i;
const PARTS_RE = /\b(for parts|parts only|not working|broken|repair|as[- ]?is)\b/i;
const OFFER_RE = /best offer accepted|offer accepted/i;

function cleanText(v='') {
  if (v == null) return '';
  const s = String(v).replace(/\s+/g, ' ').trim();
  return /^(?:null|undefined)$/i.test(s) ? '' : s;
}
function norm(v='') { return cleanText(v).toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim(); }
function tokens(v='') { return norm(v).split(' ').filter(t => t && !STOP.has(t) && t.length > 1); }
function clamp(n, a, b) { return Math.max(a, Math.min(b, n)); }
function uniq(arr) { return [...new Set(arr.filter(Boolean).map(cleanText))]; }
function sanitizeUserHints(v='') { return cleanText(v).slice(0,320); }
function userHintSearchQuery(v='') {
  const hint=sanitizeUserHints(v);
  if(!hint) return '';
  return marketQueryClean(hint
    .replace(/\b(?:brand|maker|model|style|style name|mpn|sku|upc|size|keywords?|item|product)\s*[:=\-]\s*/ig,' ')
    .replace(/[|;]+/g,' ')
    .replace(/\s+/g,' ')
  ).split(/\s+/).slice(0,16).join(' ').slice(0,140);
}
function mean(arr) {
  const a = arr.filter(Number.isFinite);
  return a.length ? a.reduce((s,v)=>s+v,0)/a.length : 0;
}
function median(arr) {
  const a = arr.filter(Number.isFinite).slice().sort((x,y)=>x-y);
  if (!a.length) return 0;
  const i = Math.floor(a.length/2);
  return a.length % 2 ? a[i] : (a[i-1]+a[i])/2;
}
function percentile(arr, p) {
  const a = arr.filter(Number.isFinite).slice().sort((x,y)=>x-y);
  if (!a.length) return 0;
  const x = (a.length - 1) * p;
  const lo = Math.floor(x), hi = Math.ceil(x);
  return lo === hi ? a[lo] : a[lo] + (a[hi]-a[lo])*(x-lo);
}
function trimmedMean(arr, trim=.10) {
  const a = arr.filter(Number.isFinite).slice().sort((x,y)=>x-y);
  if (!a.length) return 0;
  if (a.length < 10) return mean(a);
  const cut = Math.floor(a.length * trim);
  return mean(a.slice(cut, a.length-cut));
}
function robustPrices(values) {
  const vals = values.filter(v => Number.isFinite(v) && v > 0);
  if (vals.length < 5) return vals;
  const med = median(vals);
  const deviations = vals.map(v=>Math.abs(v-med));
  const mad = median(deviations);
  let filtered = vals;
  if (mad > 0) {
    // 3.5 modified-z cutoff. More stable than ordinary mean/SD for collectible outliers.
    filtered = vals.filter(v => (0.6745 * Math.abs(v-med) / mad) <= 3.5);
  }
  if (filtered.length < Math.max(4, Math.floor(vals.length*.6))) {
    const q1 = percentile(vals,.25), q3 = percentile(vals,.75), iqr = Math.max(.01,q3-q1);
    filtered = vals.filter(v => v >= Math.max(0,q1-1.5*iqr) && v <= q3+1.5*iqr);
  }
  return filtered.length >= 3 ? filtered : vals;
}
function parseMoney(v) {
  if (typeof v === 'number') return Number.isFinite(v) ? v : null;
  if (v && typeof v === 'object') {
    for (const k of ['extracted','extracted_value','value','amount','price']) {
      const n = parseMoney(v[k]); if (n != null) return n;
    }
    if (v.from || v.to) {
      const lo = parseMoney(v.from), hi = parseMoney(v.to);
      if (lo != null && hi != null) return (lo+hi)/2;
      return lo ?? hi;
    }
  }
  const s = String(v ?? '');
  if (/free shipping/i.test(s)) return 0;
  const m = s.replace(/,/g,'').match(/-?\d+(?:\.\d{1,2})?/);
  return m ? Number(m[0]) : null;
}
function safeJson(text) {
  let s = String(text || '').trim();
  s = s.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
  const first = s.indexOf('{'), last = s.lastIndexOf('}');
  if (first >= 0 && last > first) s = s.slice(first, last+1);
  return JSON.parse(s);
}

function geminiResponseText(payload) {
  const parts = payload?.candidates?.[0]?.content?.parts || [];
  return parts.map(p => typeof p?.text === 'string' ? p.text : '').join('').trim();
}

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
function uniqueModels(list=[]) {
  return [...new Set(list.map(v=>String(v||'').trim()).filter(Boolean))];
}
const VISION_FALLBACK_MODELS = uniqueModels([
  ...(process.env.GEMINI_VISION_FALLBACKS || '').split(','),
  'gemini-3.5-flash-lite',
  'gemini-3.1-flash-lite',
  'gemini-3.6-flash',
  'gemini-3.7-flash',
  'gemini-3.8-flash'
]);
const COMP_FALLBACK_MODELS = uniqueModels([
  ...(process.env.GEMINI_COMP_FALLBACKS || '').split(','),
  'gemini-3.5-flash-lite',
  'gemini-3.1-flash-lite',
  'gemini-3.5-flash',
  'gemini-3.6-flash'
]);

async function geminiGenerate({ model=GEMINI_MODEL, fallbackModels=[], prompt='', imageBuffer=null, imageMime='image/jpeg', parts=null, jsonMode=true }={}) {
  if (!GEMINI_API_KEY) throw new Error('GEMINI_API_KEY is not configured');
  let requestParts;
  if (Array.isArray(parts) && parts.length) {
    requestParts = parts;
  } else {
    requestParts = [{ text: String(prompt || '') }];
    if (imageBuffer) {
      requestParts.push({
        inline_data: {
          mime_type: imageMime || 'image/jpeg',
          data: imageBuffer.toString('base64')
        }
      });
    }
  }
  const hasImages = requestParts.some(p=>p && p.inline_data && p.inline_data.data);
  const body = {
    contents: [{ role: 'user', parts: requestParts }],
    generationConfig: jsonMode ? { response_mime_type: 'application/json', temperature: 0 } : { temperature: 0 }
  };
  const models = uniqueModels([model, ...fallbackModels]).slice(0, hasImages ? 2 : 3);
  let lastErr = null;

  for (let modelIndex=0; modelIndex<models.length; modelIndex++) {
    const candidateModel = models[modelIndex];
    for (let attempt=1; attempt<=1; attempt++) {
      const controller = new AbortController();
      const timer = setTimeout(()=>controller.abort(), hasImages ? GEMINI_IMAGE_REQUEST_TIMEOUT_MS : 9000);
      try {
        const response = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(candidateModel)}:generateContent`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'x-goog-api-key': GEMINI_API_KEY },
            body: JSON.stringify(body),
            signal: controller.signal
          }
        );
        const payload = await response.json().catch(() => ({}));
        if (!response.ok) {
          const msg = payload?.error?.message || `Gemini API HTTP ${response.status}`;
          const err = new Error(msg);
          err.status = response.status;
          err.code = payload?.error?.status || 'GEMINI_API_ERROR';
          throw err;
        }
        const text = geminiResponseText(payload);
        if (!text) {
          const reason = payload?.promptFeedback?.blockReason || payload?.candidates?.[0]?.finishReason || 'empty response';
          const err = new Error(`Gemini returned no text (${reason})`);
          err.status = 502;
          err.code = 'EMPTY_RESPONSE';
          throw err;
        }
        if (candidateModel !== model) console.warn(`Gemini fallback succeeded: ${model} -> ${candidateModel}`);
        return text;
      } catch (err) {
        if (err?.name==='AbortError') { const e=new Error('Gemini request timed out'); e.status=408; err=e; }
        lastErr = err;
        const status = Number(err?.status || 0);
        const transient = status === 408 || status === 429 || status >= 500;
        const unavailableModel = status === 404 || /no longer available|not found|unsupported model/i.test(String(err?.message||''));
        console.warn(`Gemini ${candidateModel} attempt ${attempt} failed: ${err.message}`);
        if (unavailableModel || transient) break;
        throw err;
      } finally { clearTimeout(timer); }
    }
  }
  const err = new Error(`Gemini capacity unavailable across ${models.length} supported model${models.length===1?'':'s'}: ${lastErr?.message || 'unknown error'}`);
  err.status = lastErr?.status || 503;
  err.code = lastErr?.code || 'GEMINI_FALLBACK_EXHAUSTED';
  throw err;
}

function cloudflareResultText(payload={}) {
  const result=payload?.result;
  if(typeof result==='string') return result;
  if(typeof result?.response==='string') return result.response;
  if(typeof result?.text==='string') return result.text;
  if(typeof result?.output_text==='string') return result.output_text;
  if(Array.isArray(result?.choices)) return result.choices.map(x=>x?.message?.content||x?.text||'').join('\n').trim();
  return '';
}

async function cloudflareVisionIdentify(prompt,image={}) {
  if(!CLOUDFLARE_VISION_CONFIGURED) throw new Error('Cloudflare Workers AI is not configured');
  if(!image?.buffer) throw new Error('Cloudflare vision requires an image');
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),CLOUDFLARE_VISION_TIMEOUT_MS);
  try {
    const modelPath=CLOUDFLARE_VISION_MODEL.startsWith('@cf/')?CLOUDFLARE_VISION_MODEL:`@cf/${CLOUDFLARE_VISION_MODEL}`;
    const url=`https://api.cloudflare.com/client/v4/accounts/${encodeURIComponent(CLOUDFLARE_ACCOUNT_ID)}/ai/run/${modelPath}`;
    const body={
      messages:[
        {role:'system',content:'Return only valid JSON. Do not wrap JSON in markdown.'},
        {role:'user',content:String(prompt||'Identify this resale item.')}
      ],
      image:`data:${image.mime||'image/jpeg'};base64,${image.buffer.toString('base64')}`,
      temperature:0,
      max_tokens:1400,
      chat_template_kwargs:{enable_thinking:false},
      options:{rejectIfBusy:true}
    };
    const response=await fetch(url,{method:'POST',headers:{Authorization:`Bearer ${CLOUDFLARE_API_TOKEN}`,'Content-Type':'application/json'},body:JSON.stringify(body),signal:controller.signal});
    const payload=await response.json().catch(()=>({}));
    if(!response.ok || payload?.success===false){
      const msg=(payload?.errors||[]).map(x=>x?.message).filter(Boolean).join('; ') || `Cloudflare Workers AI HTTP ${response.status}`;
      const err=new Error(msg); err.status=response.status; throw err;
    }
    const text=cloudflareResultText(payload);
    if(!text) throw new Error('Cloudflare Workers AI returned no text');
    const parsed=safeJson(text);
    if(!Array.isArray(parsed?.items)||!parsed.items.length) throw new Error('Cloudflare vision returned no identifiable items');
    return text;
  } catch(err) {
    if(err?.name==='AbortError') throw new Error('Cloudflare Workers AI vision timed out');
    throw err;
  } finally { clearTimeout(timer); }
}

async function identifyWithSoftFallback(parts) {
  // Identification latency is a SOFT budget, never a hard item failure. Start with the
  // lightweight vision model. If it is still pending after a short grace period, race a
  // stronger model in parallel and accept whichever VALID identification arrives first.
  // This avoids the 1.2.9 failure mode where a 6.5s timeout discarded the entire scan.
  const fastModel=FAST_IDENTIFY_MODEL;
  const strongModel=(GEMINI_MODEL && GEMINI_MODEL!==fastModel)?GEMINI_MODEL:'gemini-3.1-flash-lite';
  const runValidated=async model=>{
    const text=await geminiGenerate({model,fallbackModels:[],parts,jsonMode:true});
    const parsed=safeJson(text);
    if(!Array.isArray(parsed?.items)||!parsed.items.length) throw new Error(`${model} returned no identifiable items`);
    return text;
  };
  const fastPromise=runValidated(fastModel);
  let timer;
  const first=await Promise.race([
    fastPromise.then(value=>({kind:'value',value}),error=>({kind:'error',error})),
    new Promise(resolve=>{timer=setTimeout(()=>resolve({kind:'slow'}),IDENTIFY_FALLBACK_DELAY_MS);})
  ]);
  if(timer) clearTimeout(timer);
  if(first.kind==='value') return first.value;
  if(first.kind==='error') {
    console.warn(`Fast identification failed on ${fastModel}: ${first.error?.message||first.error}; trying ${strongModel}`);
    try { return await runValidated(strongModel); }
    catch (err) {
      console.warn(`Strong identification failed on ${strongModel}: ${err?.message||err}; trying emergency lite fallback`);
      return runValidated('gemini-3.1-flash-lite');
    }
  }
  console.warn(`Fast identification exceeded ${IDENTIFY_FALLBACK_DELAY_MS}ms soft budget; racing ${strongModel}`);
  const strongPromise=runValidated(strongModel);
  try {
    return await Promise.any([fastPromise,strongPromise]);
  } catch (aggregate) {
    const errors=Array.from(aggregate?.errors||[]);
    console.warn(`Parallel identification attempts failed: ${errors.map(e=>e?.message||e).join(' | ')}`);
    // Final emergency fallback only runs when both primary paths actually failed. It is rare,
    // and is preferable to returning an artificial "couldn't verify" caused only by latency.
    return runValidated('gemini-3.1-flash-lite');
  }
}

function parseDate(v) {
  if (!v) return null;
  const cleaned=cleanText(v).replace(/^(sold|ended|completed)\s*(on)?\s*/i,'');
  const d = new Date(cleaned);
  return Number.isFinite(d.getTime()) ? d : null;
}
function daysAgo(date, now=new Date()) {
  if (!(date instanceof Date) || !Number.isFinite(date.getTime())) return null;
  return Math.floor((now.getTime()-date.getTime()) / 86400000);
}
function itemIdFromResult(r) {
  if (r.product_id) return String(r.product_id);
  const link = String(r.link || '');
  const m = link.match(/\/itm\/(?:[^/]+\/)?(\d{9,15})/i);
  return m ? m[1] : null;
}
function dedupeRows(rows) {
  const seen = new Set();
  return rows.filter(r=>{
    const key = r.itemId || `${norm(r.title)}|${r.price}|${r.sold_date||''}`;
    if (seen.has(key)) return false;
    seen.add(key); return true;
  });
}
function wilson(successes, n, z=1.96) {
  if (!n) return {p:0,low:0,high:1};
  const p = clamp(successes/n,0,1), z2=z*z, den=1+z2/n;
  const center=(p+z2/(2*n))/den;
  const spread=(z*Math.sqrt((p*(1-p)+z2/(4*n))/n))/den;
  return {p,low:clamp(center-spread,0,1),high:clamp(center+spread,0,1)};
}

function conditionCompatible(target, text='') {
  const t=norm(text);
  if (!target || target==='unknown' || !t) return true;
  if (target==='for_parts') return PARTS_RE.test(t);
  if (PARTS_RE.test(t)) return false;
  if (target==='new') return /\bnew\b|sealed|new with tags|new in box/.test(t) && !/open box/.test(t);
  if (target==='open_box') return /open box|new other|unused/.test(t) || /\bnew\b/.test(t);
  if (target==='used') return !/brand new|new with|new in|sealed/.test(t);
  return true;
}

function marketQueryClean(v) {
  return cleanText(v)
    .replace(/["“”']/g, ' ')
    .replace(/[\/|]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

// eBay tokenizes whitespace aggressively. Models such as "XA 2" can turn into a
// very broad search (XA + the generic number 2) even though the real model is XA2.
// Generate compact/hyphen variants so the first market query uses the identifier
// sellers actually put in their titles.
function modelSearchVariants(value='') {
  const raw=marketQueryClean(value);
  if(!raw) return [];
  const parts=raw.split(/\s+/).filter(Boolean);
  const variants=[];
  if(parts.length===2 && /^[A-Za-z]{1,5}$/.test(parts[0]) && /^\d[A-Za-z0-9]{0,8}$/.test(parts[1])) {
    const compact=`${parts[0]}${parts[1]}`;
    const hyphen=`${parts[0]}-${parts[1]}`;
    // Short single-digit suffixes are normally written compact (XA2, R5, X2).
    if(parts[1].length===1) variants.push(compact,hyphen);
    else variants.push(hyphen,compact);
  } else if(parts.length>=2) {
    const a=parts[parts.length-2], b=parts[parts.length-1];
    if(/^[A-Za-z]{1,3}$/.test(a) && /^\d{1,3}$/.test(b)) {
      variants.push([...parts.slice(0,-2),`${a}${b}`].join(' '));
    }
  }
  variants.push(raw);
  return uniq(variants);
}

function usableModelIdentity(item={}) {
  const model=marketQueryClean(item.model||'');
  const brand=marketQueryClean(item.brand||'');
  if(!model) return '';
  if(brand && norm(model)===norm(brand)) return '';
  return model;
}

function itemQueryCandidates(item) {
  const brand = marketQueryClean(item.brand), model = usableModelIdentity(item), mpn = marketQueryClean(item.mpn);
  const modelVariants=modelSearchVariants(model);
  const type = marketQueryClean(item.item_type || '');
  const velocityFamily = canonicalVelocityFamily(item);
  const title = marketQueryClean(item.title || '');
  const barcode = marketQueryClean(item.barcode || '');
  const userHintQuery=userHintSearchQuery(item.user_hints||'');
  const supplied = Array.isArray(item.query_candidates) ? item.query_candidates.map(marketQueryClean).filter(Boolean) : [];
  const identityTerms = Array.isArray(item.identity_terms) ? item.identity_terms.map(marketQueryClean).filter(Boolean) : [];
  const familyTerms = familyAnchorTerms(item);
  const conciseTitle = title.split(/\s+/).slice(0,8).join(' ');
  const brandNorm=norm(brand);
  const suppliedSpecific=supplied.filter(q=>{
    const nq=norm(q), qt=tokens(q);
    if(!nq) return false;
    if(brandNorm && nq===brandNorm) return false;
    return qt.length>=2 || qt.some(t=>/\d/.test(t));
  });
  const suppliedBroad=supplied.filter(q=>!suppliedSpecific.includes(q));
  const titleWithoutColor=title.replace(/\b(?:black|white|grey|gray|brown|tan|beige|red|blue|green|navy|orange|yellow|purple|pink)\b/ig,' ').replace(/\s+/g,' ').trim();
  const hardIdentity=hasHardIdentity(item);
  const familyQuery=[brand, ...familyTerms.slice(0,2), type].filter(Boolean).join(' ');
  const brandType=[brand,type].filter(Boolean).join(' ');
  const brandVelocity=[brand,velocityFamily].filter(Boolean).join(' ');

  // One-pass search strategy:
  // - With a real model/identifier, lead with the exact identity.
  // - Without a hard model, lead with brand + product type. The visual verifier then
  //   splits that ONE result pool into exact-design rows for pricing and closely related
  //   same-brand styles for velocity. This avoids 2-3 sequential market attempts for
  //   apparel/home-goods items whose "model" is really just a seller-written style name.
  const exactFirst=[
    userHintQuery,
    barcode,
    ...modelVariants.map(v=>[brand,v].filter(Boolean).join(' ')),
    [brand, mpn, model].filter(Boolean).join(' '),
    [brand, mpn].filter(Boolean).join(' ')
  ];
  const discoveryFirst=[userHintQuery,brandVelocity,familyQuery,brandType,conciseTitle,titleWithoutColor];
  const fallback=[
    [brand, ...identityTerms.slice(0,3)].filter(Boolean).join(' '),
    ...suppliedSpecific,
    titleWithoutColor,
    conciseTitle,
    brandVelocity,
    familyQuery,
    brandType,
    ...suppliedBroad,
    brand
  ];
  return uniq([...(hardIdentity?exactFirst:discoveryFirst),...fallback].map(marketQueryClean))
    .filter(q => q.length >= 3).slice(0, 8);
}


function ensureBrandInTitle(item={}) {
  const brand=marketQueryClean(item.brand||'');
  const title=cleanText(item.title||item.item_type||'Unidentified item');
  if(!brand) return {...item,title};
  if(norm(title).includes(norm(brand))) return {...item,title};
  return {...item,title:cleanText(`${brand} ${title}`)};
}

function genericIdentityNeedsRescue(item={}) {
  const brand=marketQueryClean(item.brand||'');
  const mpn=marketQueryClean(item.mpn||'');
  const barcode=marketQueryClean(item.barcode||'');
  // A missing brand is itself worth rescuing. The fast model sometimes invents a generic
  // style/model phrase while missing a visible logo that Lens or the stronger model can recover.
  if(brand) return false;
  if((mpn||barcode) && Number(item.identity_confidence||0)>=.92) return false;
  const titleTokens=tokens(item.title||'');
  const genericWords=new Set(['black','brown','white','blue','red','green','leather','canvas','plastic','vintage','shoes','shoe','boots','boot','bag','tote','purse','toy','figure','shirt','jacket','camera','headphones','item','object']);
  const specific=titleTokens.filter(t=>!genericWords.has(t));
  return Number(item.identity_confidence||0)<.88 || specific.length<2;
}

async function serpLensHints(image={}) {
  if(!SERPAPI_KEY || !image?.buffer || image.buffer.length>1500000) return [];
  const controller1=new AbortController();
  const timer1=setTimeout(()=>controller1.abort(),LENS_UPLOAD_TIMEOUT_MS);
  try {
    const form=new FormData();
    const ext=/png/i.test(image.mime||'')?'png':(/webp/i.test(image.mime||'')?'webp':'jpg');
    form.append('image',new Blob([image.buffer],{type:image.mime||'image/jpeg'}),`orbit.${ext}`);
    form.append('api_key',SERPAPI_KEY);
    const up=await fetch('https://serpapi.com/image',{method:'POST',body:form,signal:controller1.signal});
    const upJson=await up.json().catch(()=>({}));
    if(!up.ok || !upJson.image_id) return [];
    clearTimeout(timer1);
    const controller2=new AbortController();
    const timer2=setTimeout(()=>controller2.abort(),LENS_SEARCH_TIMEOUT_MS);
    try {
      const url=new URL('https://serpapi.com/search.json');
      url.searchParams.set('engine','google_lens');
      url.searchParams.set('image_id',String(upJson.image_id));
      url.searchParams.set('type','visual_matches');
      url.searchParams.set('safe','active');
      url.searchParams.set('api_key',SERPAPI_KEY);
      const r=await fetch(url,{signal:controller2.signal});
      const j=await r.json().catch(()=>({}));
      if(!r.ok) return [];
      return (Array.isArray(j.visual_matches)?j.visual_matches:[]).slice(0,8).map(x=>({title:cleanText(x.title||''),source:cleanText(x.source||''),link:cleanText(x.link||'')})).filter(x=>x.title);
    } finally { clearTimeout(timer2); }
  } catch(err) {
    console.warn(`Google Lens rescue unavailable: ${err?.message||err}`);
    return [];
  } finally { clearTimeout(timer1); }
}


const LENS_LEAD_STOP = new Set('vintage new used genuine authentic original oem replacement compatible wireless bluetooth black white brown blue red green gray grey tan beige mens womens men women pair set lot bundle rare'.split(' '));
const LENS_PRODUCT_WORDS = new Set('headphones headphone earphones earphone headset earbuds earbud neckband speaker speakers shoes shoe boots boot sandals sandal bag tote purse camera cameras figure figures toy toys shirt tshirt t-shirt jacket coat cartridge valve faucet controller game console watch watches'.split(' '));
function lensPhraseSupport(phrase='', lens=[]) {
  const pt=tokens(phrase).filter(Boolean);
  if(!pt.length) return 0;
  return (Array.isArray(lens)?lens:[]).filter(x=>{
    const tt=new Set(tokens(x?.title||''));
    return pt.every(t=>tt.has(t));
  }).length;
}
function lensLeadBrandConsensus(lens=[]) {
  const rows=(Array.isArray(lens)?lens:[]).map(x=>cleanText(x?.title||'')).filter(Boolean).slice(0,8);
  const counts=new Map(), display=new Map();
  for(const title of rows){
    const raw=title.replace(/[^A-Za-z0-9&.'-]+/g,' ').trim().split(/\s+/).filter(Boolean);
    const lower=raw.map(x=>norm(x)).filter(Boolean);
    let idx=-1;
    for(let i=0;i<lower.length;i++){
      const t=lower[i];
      if(!t || LENS_LEAD_STOP.has(t) || LENS_PRODUCT_WORDS.has(t) || /^\d+(?:\.\d+)?$/.test(t)) continue;
      idx=i; break;
    }
    if(idx<0) continue;
    const key=lower[idx];
    if(key.length<3) continue;
    counts.set(key,(counts.get(key)||0)+1);
    if(!display.has(key)) display.set(key,raw[idx]);
  }
  const ranked=[...counts.entries()].sort((a,b)=>b[1]-a[1] || b[0].length-a[0].length);
  if(!ranked.length) return {brand:'',support:0,ratio:0};
  const [key,support]=ranked[0];
  return {brand:display.get(key)||key,support,ratio:rows.length?support/rows.length:0};
}
function lensModelFromTitle(title='', brand='') {
  const raw=cleanText(title).replace(/[^A-Za-z0-9&.'-]+/g,' ').trim().split(/\s+/).filter(Boolean);
  if(!raw.length) return '';
  const bn=norm(brand);
  let start=0;
  if(bn){
    const idx=raw.findIndex(t=>norm(t)===bn);
    if(idx>=0) start=idx+1;
  }
  const out=[];
  for(let i=start;i<raw.length && out.length<4;i++){
    const n=norm(raw[i]);
    if(!n) continue;
    if(LENS_PRODUCT_WORDS.has(n) || ['with','for','and','plus','edition','series'].includes(n)) break;
    if(LENS_LEAD_STOP.has(n) && !out.length) continue;
    out.push(raw[i]);
    if(/\d/.test(n) && out.length>=2) break;
  }
  const model=marketQueryClean(out.join(' '));
  return tokens(model).length<=4?model:'';
}
function topLensIdentityTitle(lens=[], brand='') {
  const rows=(Array.isArray(lens)?lens:[]).map(x=>cleanText(x?.title||'')).filter(Boolean);
  const bn=norm(brand);
  const chosen=rows.find(t=>!bn || norm(t).split(' ').includes(bn)) || rows[0] || '';
  return marketQueryClean(chosen).split(/\s+/).slice(0,12).join(' ');
}
function identityTextSupport(item={}) {
  const visible=norm((item.visible_text||[]).join(' '));
  const hints=norm(item.user_hints||'');
  const brand=norm(item.brand||''), model=norm(usableModelIdentity(item));
  return {
    brandVisible:!!brand && (visible.includes(brand)||hints.includes(brand)),
    modelVisible:!!model && (visible.includes(model)||hints.includes(model))
  };
}
function specificIdentityNeedsCrossCheck(item={}) {
  const brand=marketQueryClean(item.brand||''), model=usableModelIdentity(item);
  if(!brand && !model) return false;
  const support=identityTextSupport(item);
  // If the photo OCR/user hint already directly supports both pieces, Lens is optional.
  if(brand && model && support.brandVisible && support.modelVisible) return false;
  return true;
}
function reconcileIdentityWithLens(item={}, lens=[]) {
  const rows=(Array.isArray(lens)?lens:[]).filter(x=>cleanText(x?.title||''));
  if(rows.length<LENS_CROSSCHECK_MIN_SUPPORT) return ensureBrandInTitle({...item,lens_crosscheck_used:rows.length>0,lens_crosscheck_status:rows.length?'inconclusive':'unavailable'});
  const currentBrand=marketQueryClean(item.brand||''), currentModel=usableModelIdentity(item);
  const currentBrandSupport=currentBrand?lensPhraseSupport(currentBrand,rows):0;
  const currentModelSupport=currentModel?lensPhraseSupport(currentModel,rows):0;
  const consensus=lensLeadBrandConsensus(rows);
  const consensusBrand=marketQueryClean(consensus.brand||'');
  const consensusSupport=Number(consensus.support||0);
  const strongConsensus=consensusBrand && consensusSupport>=LENS_CROSSCHECK_MIN_SUPPORT && Number(consensus.ratio||0)>=.40;
  const preferredBrand=(strongConsensus?consensusBrand:currentBrand)||currentBrand;
  const preferredLensTitle=topLensIdentityTitle(rows,preferredBrand);
  const candidateModel=lensModelFromTitle(preferredLensTitle,preferredBrand);
  const candidateModelSupport=candidateModel?lensPhraseSupport(candidateModel,rows):0;
  const brandConflict=!!(currentBrand && strongConsensus && norm(consensusBrand)!==norm(currentBrand) && consensusSupport>=currentBrandSupport+2 && currentBrandSupport<=1);
  const modelConflict=!!(currentBrand && currentModel && preferredBrand && norm(preferredBrand)===norm(currentBrand) && candidateModel && norm(candidateModel)!==norm(currentModel) && candidateModelSupport>=LENS_CROSSCHECK_MIN_SUPPORT && candidateModelSupport>=currentModelSupport+2 && currentModelSupport<=1);
  const unsupportedSpecific=!!(currentBrand && currentModel && currentBrandSupport===0 && currentModelSupport===0 && strongConsensus);
  if(!(brandConflict||modelConflict||unsupportedSpecific)){
    const supported=currentBrandSupport>=LENS_CROSSCHECK_MIN_SUPPORT || currentModelSupport>=LENS_CROSSCHECK_MIN_SUPPORT;
    return ensureBrandInTitle({...item,
      lens_crosscheck_used:true,lens_crosscheck_status:supported?'supported':'inconclusive',
      lens_crosscheck_brand_support:currentBrandSupport,lens_crosscheck_model_support:currentModelSupport,
      lens_crosscheck_consensus_brand:consensusBrand||null,lens_crosscheck_consensus_support:consensusSupport,
      lens_crosscheck_candidate_model:candidateModel||null,lens_crosscheck_candidate_model_support:candidateModelSupport
    });
  }
  const oldTitle=cleanText(item.title||'');
  const correctedBrand=brandConflict||unsupportedSpecific ? consensusBrand : currentBrand;
  const lensTitle=topLensIdentityTitle(rows,correctedBrand);
  const lensModel=modelConflict||brandConflict||unsupportedSpecific ? (lensModelFromTitle(lensTitle,correctedBrand)||null) : currentModel;
  const oldIdentity=cleanText([currentBrand,currentModel].filter(Boolean).join(' '));
  const query=marketQueryClean([correctedBrand,lensModel].filter(Boolean).join(' ')) || lensTitle;
  const commonCounts=new Map();
  for(const x of rows.slice(0,6)) for(const t of new Set(tokens(x.title||''))) commonCounts.set(t,(commonCounts.get(t)||0)+1);
  const commonTerms=[...commonCounts.entries()].filter(([t,n])=>n>=2 && !ACCESSORY_WORDS.has(t) && !LENS_PRODUCT_WORDS.has(t)).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([t])=>t);
  const corrected={...item,
    title:lensTitle||cleanText(`${consensusBrand} ${item.item_type||''}`),
    brand:correctedBrand||null,
    model:lensModel||null,
    mpn:null,barcode:null,
    identity_terms:uniq([...(lensModel?[lensModel]:[]),...commonTerms]),
    query_candidates:uniq([query,lensTitle,...rows.slice(0,4).map(x=>x.title),...(item.query_candidates||[])]),
    identity_confidence:clamp(Math.max(.76,Number(item.identity_confidence||0)*.92),0,.93),
    alternative_identities:uniq([oldIdentity,oldTitle,...(item.alternative_identities||[])]).slice(0,5),
    lens_rescue_used:true,lens_hint_count:rows.length,
    lens_crosscheck_used:true,lens_crosscheck_status:'corrected_conflict',
    lens_crosscheck_brand_support:currentBrandSupport,lens_crosscheck_model_support:currentModelSupport,
    lens_crosscheck_consensus_brand:consensusBrand,lens_crosscheck_consensus_support:consensusSupport,
    lens_crosscheck_candidate_model:candidateModel||null,lens_crosscheck_candidate_model_support:candidateModelSupport,
    identity_source:'lens_conflict_correction',provisional_identity:false
  };
  console.warn(`Identity cross-check corrected conflict: ${oldIdentity||oldTitle||'unknown'} -> ${query||corrected.title} | Lens brand support ${consensusSupport}/${rows.length}; original brand support ${currentBrandSupport}/${rows.length}`);
  return ensureBrandInTitle(corrected);
}


function provisionalIdentityFromLens(userHints='', lens=[]) {
  const hint=sanitizeUserHints(userHints);
  const lensTitles=uniq((Array.isArray(lens)?lens:[]).map(x=>cleanText(x?.title||'')).filter(Boolean)).slice(0,8);
  const hintQuery=userHintSearchQuery(hint);
  const title=cleanText(hintQuery || lensTitles[0] || '');
  if(!title) return null;
  const titleTokenLists=lensTitles.slice(0,5).map(t=>tokens(t));
  const counts=new Map();
  for(const list of titleTokenLists){ for(const t of new Set(list)){ counts.set(t,(counts.get(t)||0)+1); } }
  const common=[...counts.entries()]
    .filter(([t,n])=>n>=Math.min(2,Math.max(1,titleTokenLists.length)) && !ACCESSORY_WORDS.has(t) && t.length>2)
    .sort((a,b)=>b[1]-a[1] || b[0].length-a[0].length)
    .slice(0,6).map(([t])=>t);
  const candidates=uniq([hintQuery,...lensTitles]).slice(0,8);
  const confidence=clamp((lensTitles.length>=3?.66:lensTitles.length?.56:.42)+(hintQuery?.05:0),0,.78);
  return {
    title, item_type:'item', category:'general merchandise', brand:null, model:null, mpn:null, barcode:null,
    visible_text:[], identity_terms:common.slice(0,4), family_identity_terms:[], velocity_family:'', exclude_terms:[],
    condition:'unknown', price_tag:null, weight_estimate_lb:null, weight_low_lb:null, weight_high_lb:null,
    weight_confidence:0, weight_basis:'', identity_confidence:confidence, alternative_identities:lensTitles.slice(1,4),
    query_candidates:candidates, is_bundle:false, bulky:false, fragile:false, labor_min:12, supplies_estimate:1, shipping_estimate:6,
    bbox:{x:0,y:0,w:1000,h:1000}, user_hints:hint||null, lens_rescue_used:lensTitles.length>0, lens_hint_count:lensTitles.length,
    provisional_identity:true, identity_source:lensTitles.length?'google_lens_fallback':'user_hint_fallback'
  };
}

async function hardFallbackIdentity(image,userHints='') {
  const lens=await serpLensHints(image);
  const provisional=provisionalIdentityFromLens(userHints,lens);
  if(provisional){
    console.warn(`Primary vision unavailable; continuing with ${provisional.identity_source} (${provisional.lens_hint_count||0} Lens hints)`);
    return provisional;
  }
  return null;
}

async function rescueGenericIdentity(item,image) {
  if(!genericIdentityNeedsRescue(item)) return ensureBrandInTitle(item);
  const userHints=sanitizeUserHints(item.user_hints||'');
  const lens=await serpLensHints(image);
  const lensText=lens.length?lens.map((x,i)=>`${i+1}. ${x.title}${x.source?` — ${x.source}`:''}`).join('\n'):'No Google Lens hints were available.';
  const prompt=`You are correcting a weak reseller-item identification. The first pass was too generic.\n\nFIRST PASS:\n${JSON.stringify(item)}\n\nUSER-PROVIDED HINTS (context only, not proof):\n${userHints||'None'}\n\nGOOGLE LENS VISUAL MATCH TITLES:\n${lensText}\n\nUse the target photo as the primary evidence. User hints and Lens titles are clues, not truth. Use them to resolve ambiguity and focus on likely logos/model markings, but reject them if the photo or visible text conflicts. Identify brand, product line/model, maker, and item type as specifically as the evidence supports. If several clues agree and the photo is visually consistent, you may use that consensus. Never invent a brand/model. Return ONLY JSON with one object using the same fields as the first pass, preserving useful weight/condition/price-tag fields when not contradicted.`;
  const parts=[{text:prompt},{inline_data:{mime_type:image.mime||'image/jpeg',data:image.buffer.toString('base64')}}];
  try {
    const out=await geminiGenerate({model:GEMINI_MODEL,fallbackModels:['gemini-3.1-flash-lite'],parts,jsonMode:true});
    const parsed=safeJson(out);
    const r=parsed?.item||parsed?.items?.[0]||parsed;
    if(!r || typeof r!=='object') return ensureBrandInTitle(item);
    const merged={...item,...r,
      title:cleanText(r.title||item.title),
      brand:cleanText(r.brand||item.brand)||null,
      model:cleanText(r.model||item.model)||null,
      mpn:cleanText(r.mpn||item.mpn)||null,
      barcode:cleanText(r.barcode||item.barcode)||null,
      identity_confidence:Math.max(Number(item.identity_confidence||0),clamp(Number(r.identity_confidence)||0,0,1)),
      visible_text:uniq([...(item.visible_text||[]),...(Array.isArray(r.visible_text)?r.visible_text:[])]),
      identity_terms:uniq([...(item.identity_terms||[]),...(Array.isArray(r.identity_terms)?r.identity_terms:[])]),
      family_identity_terms:uniq([...(item.family_identity_terms||[]),...(Array.isArray(r.family_identity_terms)?r.family_identity_terms:[])]),
      query_candidates:uniq([...(Array.isArray(r.query_candidates)?r.query_candidates:[]),...(item.query_candidates||[])]),
      lens_rescue_used:lens.length>0,
      lens_hint_count:lens.length
    };
    return ensureBrandInTitle(merged);
  } catch(err) {
    console.warn(`Generic identity rescue failed: ${err?.message||err}`);
    return ensureBrandInTitle(item);
  }
}

async function identifyImages(images, mode='single', userHints='') {
  if (!GEMINI_API_KEY && !CLOUDFLARE_VISION_CONFIGURED && !SERPAPI_KEY) throw new Error('No vision provider is configured');
  const usable=(Array.isArray(images)?images:[]).filter(x=>x?.buffer).slice(0,IDENTIFY_MAX_IMAGES);
  if(!usable.length) throw new Error('No image uploaded');
  const group = mode === 'group';
  const hintText=sanitizeUserHints(userHints);
  // Start independent Lens evidence alongside Gemini. We only wait for/use it when the
  // returned identity is specific enough to deserve a brand/model cross-check. This prevents
  // a confident-but-wrong first guess from poisoning every downstream market query.
  const lensPromise=!group && SERPAPI_KEY ? serpLensHints(usable[0]) : Promise.resolve([]);
  const hintBlock=hintText?`\nUSER-PROVIDED ITEM HINTS (optional context, NOT authoritative):\n${hintText}\nUse these hints to focus identification, OCR, logos, model numbers, and search terminology. If the hints conflict with the photographs or visible labels, the photographs win. Do not invent unsupported details merely because the user typed them.\n`:'';
  const prompt = `You are the visual identification engine for ProfitQueue, a professional reseller sourcing tool.
Analyze this photo and identify ${group ? 'each distinct sellable item visible (maximum 12)' : 'the single primary sellable item'}.${hintBlock}

Critical rules:
- Never invent a brand, model, maker, edition, material, size, UPC, MPN, or price tag. Use null when not supported by visible evidence.
- Read all visible labels, model numbers, signatures, stamps, logos, tags and price stickers carefully.
- Exact model/part/edition matters more than generic object class.
- identity_terms are the minimum words/numbers a true exact comp should normally contain. Put model numbers, capacities, edition names, sizes, product lines, and distinctive identifiers here.
- family_identity_terms are value-relevant subjects/modifiers (sports team/school, character/franchise, band/artist, licensed theme, named product line). They help explain price differences but are NOT automatically hard blockers for design-family comps. Do NOT put the maker/brand itself here. Leave [] when unsupported.
- velocity_family is a SHORT canonical product-family phrase for demand research, usually 1-4 meaningful words. It should be broader than an exact model but narrower than the whole category. Examples: 'towel poncho', 'moc toe work boots', '35mm point and shoot camera', 'noise cancelling headphones', 'leather tote bag'. Do not include brand, color, size, gender, model number, hype words, or condition.
- exclude_terms are words that usually indicate the wrong product for this exact item (accessories, neighboring model numbers, incompatible sizes, etc.).
- Distinguish the main product from accessories, packaging, manuals and unrelated background objects.
- If identity is uncertain, give the strongest candidate but lower identity_confidence and list alternatives.
- price_tag is the acquisition/store price visibly attached to the item, never an estimated resale value.
- Estimate the ITEM-ONLY physical weight for thrift-bin costing. Use category/material/visible scale cues. If scale is uncertain, give a broad honest range rather than false precision. weight_low_lb <= weight_estimate_lb <= weight_high_lb.
- query_candidates must be concise eBay searches, most specific first, no hype words.
- Estimate listing labor and packing supplies conservatively. shipping_estimate is likely outbound postage if the seller offers free shipping.

Return ONLY valid JSON:
{
  "items": [{
    "title": "specific factual identity",
    "item_type": "object type",
    "category": "resale category",
    "brand": null,
    "model": null,
    "mpn": null,
    "barcode": null,
    "visible_text": ["..."],
    "identity_terms": ["must-match identifier"],
    "family_identity_terms": ["value-relevant subject/theme modifier for family pricing"],
    "velocity_family": "short canonical product family for sell-through",
    "exclude_terms": ["wrong-model/accessory clue"],
    "condition": "new|open_box|used|for_parts|unknown",
    "price_tag": null,
    "weight_estimate_lb": null,
    "weight_low_lb": null,
    "weight_high_lb": null,
    "weight_confidence": 0.0,
    "weight_basis": "short reason for estimate",
    "identity_confidence": 0.0,
    "alternative_identities": ["..."],
    "query_candidates": ["..."],
    "is_bundle": false,
    "bulky": false,
    "fragile": false,
    "labor_min": 12,
    "supplies_estimate": 1.0,
    "shipping_estimate": 6.0,
    "bbox": {"x":0,"y":0,"w":1000,"h":1000}
  }]
}`;

  const parts=[{text:prompt}];
  usable.forEach((img,i)=>{parts.push({text:`TARGET PHOTO ${i+1} OF ${usable.length} — all photos show the same item from different angles`});parts.push({inline_data:{mime_type:img.mime||'image/jpeg',data:img.buffer.toString('base64')}});});
  let parsed;
  let identityProvider='none';
  try {
    let outputText='';
    // When configured, Cloudflare is the low-credit primary path for single-item scans.
    // Gemini is retained as a fallback for difficult/failed Cloudflare calls and for group scans.
    if(CLOUDFLARE_VISION_CONFIGURED && !group){
      try {
        outputText=await cloudflareVisionIdentify(prompt,usable[0]);
        identityProvider='cloudflare';
      } catch(cfErr) {
        console.warn(`Cloudflare primary identification unavailable: ${cfErr?.message||cfErr}`);
        if(!GEMINI_API_KEY) throw cfErr;
        outputText=await identifyWithSoftFallback(parts);
        identityProvider='gemini_fallback';
      }
    } else if(GEMINI_API_KEY) {
      outputText=await identifyWithSoftFallback(parts);
      identityProvider='gemini';
    } else {
      throw new Error('Primary model unavailable; attempting Lens fallback');
    }
    parsed = safeJson(outputText);
  } catch(err) {
    console.warn(`Primary item identification unavailable: ${err?.message||err}`);
    if(!group){
      const lens=await lensPromise.catch(()=>[]);
      const fallback=provisionalIdentityFromLens(hintText,lens);
      if(fallback) return [ensureBrandInTitle({...fallback,identity_provider:'google_lens_fallback'})];
    }
    throw err;
  }
  if (!Array.isArray(parsed.items) || !parsed.items.length) {
    if(!group){
      const lens=await lensPromise.catch(()=>[]);
      const fallback=provisionalIdentityFromLens(hintText,lens);
      if(fallback) return [ensureBrandInTitle(fallback)];
    }
    throw new Error('Vision model returned no identifiable items');
  }
  const baseItems=parsed.items.slice(0, group ? 12 : 1).map(x => ({
    ...x,
    title: cleanText(x.title || x.item_type || 'Unidentified item'),
    identity_confidence: clamp(Number(x.identity_confidence) || 0, 0, 1),
    price_tag: (x.price_tag===null || x.price_tag===undefined || cleanText(x.price_tag)==='') ? null : (Number.isFinite(Number(x.price_tag)) ? Number(x.price_tag) : null),
    weight_estimate_lb: (x.weight_estimate_lb===null || x.weight_estimate_lb===undefined || cleanText(x.weight_estimate_lb)==='') ? null : (Number.isFinite(Number(x.weight_estimate_lb)) ? clamp(Number(x.weight_estimate_lb),.01,150) : null),
    weight_low_lb: (x.weight_low_lb===null || x.weight_low_lb===undefined || cleanText(x.weight_low_lb)==='') ? null : (Number.isFinite(Number(x.weight_low_lb)) ? clamp(Number(x.weight_low_lb),.01,150) : null),
    weight_high_lb: (x.weight_high_lb===null || x.weight_high_lb===undefined || cleanText(x.weight_high_lb)==='') ? null : (Number.isFinite(Number(x.weight_high_lb)) ? clamp(Number(x.weight_high_lb),.01,150) : null),
    weight_confidence: clamp(Number(x.weight_confidence)||0,0,1),
    weight_basis: cleanText(x.weight_basis||''),
    labor_min: clamp(Number(x.labor_min) || 12, 3, 120),
    supplies_estimate: clamp(Number(x.supplies_estimate) || 1, 0, 30),
    shipping_estimate: clamp(Number(x.shipping_estimate) || 0, 0, 150),
    identity_terms: uniq(Array.isArray(x.identity_terms) ? x.identity_terms : []),
    family_identity_terms: uniq(Array.isArray(x.family_identity_terms) ? x.family_identity_terms : []),
    velocity_family: marketQueryClean(x.velocity_family||''),
    exclude_terms: uniq(Array.isArray(x.exclude_terms) ? x.exclude_terms : []),
    user_hints: hintText||null,
    query_candidates: uniq([...(hintText?[userHintSearchQuery(hintText)]:[]),...(Array.isArray(x.query_candidates)?x.query_candidates:[])]),
    is_bundle: !!x.is_bundle,
    identity_provider: identityProvider
  }));
  if(group) return baseItems.map(ensureBrandInTitle);
  const rescued=[];
  for(const base of baseItems){
    let item=base;
    if(specificIdentityNeedsCrossCheck(item)){
      const lens=await Promise.race([lensPromise.catch(()=>[]),sleep(LENS_CROSSCHECK_WAIT_MS).then(()=>[])]);
      if(lens.length) item=reconcileIdentityWithLens(item,lens);
      else item=ensureBrandInTitle({...item,lens_crosscheck_used:false,lens_crosscheck_status:'unavailable'});
    }
    item=await rescueGenericIdentity(item,usable[0]);
    rescued.push(item);
  }
  return rescued;
}


async function identifyImage(buffer,mime,mode='single'){return identifyImages([{buffer,mime}],mode);}

function conditionParam(condition) {
  if (condition === 'new') return '1000';
  if (condition === 'open_box') return '1500';
  if (condition === 'used') return '3000';
  if (condition === 'for_parts') return '7000';
  return null;
}


function isoDateDaysAgo(days) {
  const d=new Date(Date.now()-Math.max(0,days)*86400000);
  return d.toISOString().slice(0,10);
}
function trawlConditionParam(condition) {
  if (condition==='new') return 'new';
  if (condition==='used') return 'used';
  if (condition==='for_parts') return 'parts';
  if (condition==='open_box') return 'new,other';
  return '';
}
function trawlExclude(item, query='') {
  // Trawl rejects requests when any exclude word also appears in query.
  // Reduce phrases like "Eau de Toilette" to only safe non-query words ("toilette").
  const queryWords=new Set(tokens(marketQueryClean(query)));
  const target=new Set(tokens(`${item.title||''} ${item.item_type||''}`));
  const out=[];
  const addSafe=(value)=>{
    for (const word of tokens(marketQueryClean(value))) {
      if (!word || queryWords.has(word)) continue;
      out.push(word);
    }
  };
  for (const term of (item.exclude_terms||[])) addSafe(term);
  if (item.condition!=='for_parts') ['broken','repair','parts'].forEach(addSafe);
  if (!item.is_bundle) ['lot','bundle'].forEach(addSafe);
  for (const word of ['case','cover','manual','charger','cable','adapter']) {
    if (!target.has(word)) addSafe(word);
  }
  return uniq(out).slice(0,18).join(' ');
}
async function trawlSoldPage(query,item,page=1) {
  if (!TRAWL_API_KEY) throw new Error('TRAWL_API_KEY is not configured');
  const cacheKey=`trawl|sold|${page}|${marketQueryClean(query)}|${item.condition||'unknown'}`;
  const cached=cacheGet(cacheKey); if(cached) return cached;
  if (TRAWL_INFLIGHT.has(cacheKey)) return TRAWL_INFLIGHT.get(cacheKey);

  const work=(async()=>{
    const u=new URL('https://api.trawl.dev/ebay/v1/sold');
    u.searchParams.set('query', marketQueryClean(query).slice(0,140));
    u.searchParams.set('site','EBAY_US');
    u.searchParams.set('date_from',isoDateDaysAgo(90));
    u.searchParams.set('date_to',new Date().toISOString().slice(0,10));
    u.searchParams.set('limit','240');
    u.searchParams.set('page',String(page));
    const condition=trawlConditionParam(item.condition);
    if(condition) u.searchParams.set('condition',condition);
    let exclude=trawlExclude(item, query);
    if(exclude) u.searchParams.set('exclude',exclude);

    let lastErr=null;
    const maxAttempts=TRAWL_MAX_ATTEMPTS_FAST;
    for(let attempt=1;attempt<=maxAttempts;attempt++) {
      const controller=new AbortController();
      const timer=setTimeout(()=>controller.abort(),TRAWL_REQUEST_TIMEOUT_MS);
      try {
        const r=await runTrawlQueued(()=>fetch(u,{
          signal:controller.signal,
          headers:{'x-api-key':TRAWL_API_KEY,'User-Agent':`ORBIT/${ENGINE_VERSION}`}
        }));
        const text=await r.text(); let data={};
        try{data=text?JSON.parse(text):{};}catch{}
        if(!r.ok) {
          const msg=cleanText(data?.error||data?.message||'');
          // Defensive fallback: if Trawl still detects an overlap, retry without exclusions.
          if (r.status===400 && /exclude overlaps query/i.test(msg) && exclude) {
            u.searchParams.delete('exclude');
            exclude='';
            if (attempt<maxAttempts) continue;
          }
          const err=new Error(`Trawl ${r.status}${msg?`: ${msg.slice(0,240)}`:''}`);
          err.status=r.status;
          err.retryAfterMs=retryAfterMs(r);
          throw err;
        }
        if(!Array.isArray(data.results)) throw new Error('Trawl returned an invalid sold-results payload');
        cacheSet(cacheKey,data);
        return data;
      } catch(err) {
        lastErr=err;
        const status=Number(err?.status||0);
        if (attempt<maxAttempts && status===429) {
          // Provider plan is 2 req/s. Back off substantially instead of surfacing
          // a transient rate-limit error to the user.
          const providerWait=Math.max(0,Number(err?.retryAfterMs||0));
          const exponential=Math.min(8000, 900 * (2 ** (attempt-1)));
          const jitter=Math.floor(Math.random()*250);
          const waitMs=Math.max(providerWait,exponential+jitter);
          console.warn(`Trawl rate limited (attempt ${attempt}/${maxAttempts}); retrying in ${waitMs}ms`);
          await sleep(waitMs);
          continue;
        }
        if (attempt<maxAttempts && status>=500) {
          await sleep(Math.min(1800,400*attempt));
          continue;
        }
        break;
      } finally { clearTimeout(timer); }
    }
    if(lastErr?.name==='AbortError') throw new Error('Trawl sold search timed out after automatic retries');
    throw lastErr||new Error('Trawl sold search failed');
  })();

  TRAWL_INFLIGHT.set(cacheKey,work);
  try { return await work; }
  finally { TRAWL_INFLIGHT.delete(cacheKey); }
}
function normalizeTrawlResult(r,item) {
  const price=Number(r.sale_price);
  const shipping=Number(r.shipping_price);
  const soldDate=cleanText(r.date_sold)||null;
  const condition=cleanText(r.condition_raw||r.condition);
  const row={
    itemId:cleanText(r.item_id)||null,
    title:cleanText(r.title),
    price:Number.isFinite(price)?price:null,
    shipping:Number.isFinite(shipping)?Math.max(0,shipping):0,
    condition,
    sold_date:soldDate,
    soldDateParsed:parseDate(soldDate),
    link:r.item_link||null,
    imageUrl:cleanText(r.image_url)||null,
    sponsored:false,
    extensions:'',
    bestOfferUnknown:false,
    soldCount:0,
    watchers:0,
    landedPrice:(Number.isFinite(price)?price:0)+(Number.isFinite(shipping)?Math.max(0,shipping):0),
    sourceSoldSearch:true,
    soldProvider:'Trawl'
  };
  return {...row,lexicalMatch:titleMatchScore(row.title,item)};
}
async function sampleTrawlSold(query,item) {
  const rows=[]; let complete=false; let pages=0;
  // Broad discovery queries only need one page for visual matching. Once the
  // identity/query is specific, deeper paging is useful for a better 90-day count.
  const pageLimit=querySpecificEnough(item,query)?TRAWL_MAX_PAGES:1;
  for(let page=1;page<=pageLimit;page++) {
    const data=await trawlSoldPage(query,item,page); pages=page;
    const pageRows=(data.results||[]).map(r=>normalizeTrawlResult(r,item)).filter(r=>r.title&&r.price!=null&&r.price>0);
    rows.push(...pageRows);
    if(pageRows.length<240){complete=true;break;}
  }
  return {
    total:dedupeRows(rows).length,
    exactState:'',categories:[],rows:dedupeRows(rows),conditionApplied:item.condition||'unknown',
    source:'trawl',complete,truncated:!complete,pages
  };
}
function trawlSearchQuality(search,matchedRows) {
  const n=Math.max(0,search.rows.length), k=Math.max(0,matchedRows.length), ci=wilson(k,n);
  return {
    sampleN:n,matchedN:k,precision:ci.p,precisionLow:ci.low,precisionHigh:ci.high,
    complete:!!search.complete,estimate:k,low:k,high:search.complete?k:k+240,total:n,
    lowerBound:!search.complete
  };
}

function ebayConditionParam(condition) {
  // eBay condition IDs used by SerpApi. Keeping active and sold searches in the
  // same condition pool is essential for a meaningful sell-through denominator.
  if(condition==='new') return '1000';
  if(condition==='open_box') return '1500';
  if(condition==='used') return '3000';
  if(condition==='for_parts') return '7000';
  return '';
}

async function serpEbaySearch(query, {sold=false,page=1,condition='unknown'}={}) {
  if (!SERPAPI_KEY) throw new Error('SERPAPI_KEY is not configured');
  if (sold && Date.now() < soldProviderDegradedUntil) {
    const err=new Error(`sold listings temporarily unavailable${soldProviderLastError?`: ${soldProviderLastError}`:''}`);
    err.code='SOLD_PROVIDER_COOLDOWN'; throw err;
  }
  const cacheKey=`${sold?'sold':'active'}|${page}|${marketQueryClean(query)}|${condition||'unknown'}`;
  const cached=cacheGet(cacheKey); if(cached) return cached;
  const u = new URL('https://serpapi.com/search');
  u.searchParams.set('engine', 'ebay');
  u.searchParams.set('_nkw', query.slice(0,120));
  u.searchParams.set('_ipg', '100');
  u.searchParams.set('_pgn', String(page));
  if (sold) u.searchParams.set('show_only', 'Sold');
  const conditionId=ebayConditionParam(condition);
  if(conditionId) u.searchParams.set('LH_ItemCondition',conditionId);
  // Ask eBay not to silently broaden an exact model search through spelling
  // autocorrection. We broaden ourselves via the controlled query ladder instead.
  u.searchParams.set('_blrs','spell_auto_correct');
  u.searchParams.set('api_key', SERPAPI_KEY);
  let lastErr=null;
  const maxAttempts = 1;
  const timeoutMs = SERP_REQUEST_TIMEOUT_MS;
  for (let attempt=1;attempt<=maxAttempts;attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const r = await fetch(u, { signal: controller.signal, headers: { 'User-Agent': `ProfitQueue/${ENGINE_VERSION}` }});
      const bodyText = await r.text();
      let data = {};
      try { data = bodyText ? JSON.parse(bodyText) : {}; } catch {}
      const providerMessage = cleanText(data?.error || '');
      // SerpApi sometimes represents a legitimate empty eBay search as an error string.
      if (providerMessage && /hasn['’]?t returned any results|no results for this query/i.test(providerMessage)) {
        const empty={...data,error:undefined,organic_results:[],search_information:{...(data.search_information||{}),total_results:0}};
        cacheSet(cacheKey,empty); return empty;
      }
      if (!r.ok) throw new Error(`SerpApi eBay ${r.status}${providerMessage ? `: ${providerMessage.slice(0,280)}` : ''}`);
      if (data.error) throw new Error(`SerpApi eBay: ${providerMessage.slice(0,280)}`);
      if (Number(data.search_information?.total_results)>0 && !(data.organic_results||[]).length) throw new Error('eBay result page returned no parseable listings');
      cacheSet(cacheKey,data); return data;
    } catch(err) {
      lastErr=err;
      const msg=cleanText(err?.message || err);
      if (sold && (err?.name==='AbortError' || /aborted|timed out|timeout|high response/i.test(msg))) {
        soldProviderLastError='eBay/SerpApi sold-filter timeout';
        soldProviderDegradedUntil=Date.now()+SOLD_PROVIDER_COOLDOWN_MS;
      }
      if (attempt<maxAttempts) await sleep(350);
    } finally { clearTimeout(timer); }
  }
  if (lastErr?.name==='AbortError') throw new Error(sold?'sold search timed out':'active search timed out');
  throw lastErr||new Error('eBay search failed');
}

function accessoryPenalty(title, identity) {
  const tt = new Set(tokens(title));
  const it = new Set(tokens(`${identity.title} ${identity.item_type || ''}`));
  let p = 0;
  for (const w of ACCESSORY_WORDS) if (tt.has(w) && !it.has(w)) p += .09;
  return Math.min(.45, p);
}
function titleMatchScore(title, item) {
  const titleN = norm(title), titleSet = new Set(tokens(title));
  const baseTokens = tokens(`${item.brand || ''} ${usableModelIdentity(item) || ''} ${item.mpn || ''} ${item.item_type || ''}`);
  const querySet = new Set(baseTokens);
  let inter = 0; for (const t of querySet) if (titleSet.has(t)) inter++;
  const union = new Set([...querySet, ...titleSet]).size || 1;
  let score = (inter / Math.max(1, querySet.size)) * .45 + (inter / union) * .12;
  const brand = norm(item.brand || ''), model = norm(usableModelIdentity(item) || ''), mpn = norm(item.mpn || '');
  if (brand) score += titleN.includes(brand) ? .10 : -.04;
  if (model) score += titleN.includes(model) ? .27 : -.22;
  if (mpn) score += titleN.includes(mpn) ? .25 : -.18;
  const must = (item.identity_terms || []).map(norm).filter(Boolean);
  if (must.length) {
    const hits = must.filter(t=>titleN.includes(t)).length;
    score += (hits/must.length)*.18;
    if (hits===0 && !model && !mpn) score -= .10;
  }
  const excludes=(item.exclude_terms||[]).map(norm).filter(Boolean);
  if (excludes.some(t=>titleN.includes(t))) score -= .35;
  score -= accessoryPenalty(title, item);
  if (LOT_RE.test(title) && !item.is_bundle) score -= .24;
  if (PARTS_RE.test(title) && item.condition !== 'for_parts') score -= .24;
  return clamp(score, 0, 1);
}
function normalizeResult(r, sold=false) {
  const soldDate = r.sold_date || null;
  const condition = cleanText(r.condition);
  const extensions = Array.isArray(r.extensions) ? r.extensions.join(' ') : cleanText(r.extensions || '');
  const shipping = parseMoney(r.shipping);
  return {
    itemId: itemIdFromResult(r),
    title: cleanText(r.title),
    price: parseMoney(r.price),
    shipping: shipping == null ? 0 : Math.max(0,shipping),
    condition,
    sold_date: soldDate,
    soldDateParsed: parseDate(soldDate),
    link: r.link || null,
    imageUrl: cleanText(r.thumbnail || r.image || r.image_url || '') || null,
    sponsored: !!r.sponsored,
    extensions,
    bestOfferUnknown: OFFER_RE.test(`${extensions} ${r.subtitle||''} ${r.returns||''}`),
    soldCount: Number(r.extracted_quantity_sold ?? r.extracted_sold_count ?? 0) || 0,
    watchers: Number(r.extracted_watchers || 0) || 0,
    landedPrice: (parseMoney(r.price)||0) + (shipping == null ? 0 : Math.max(0,shipping)),
    sourceSoldSearch: sold
  };
}
function evaluatePage(data, item, sold=false) {
  const rows = (data.organic_results || []).map(r=>normalizeResult(r,sold)).filter(r => r.title && r.price != null && r.price > 0);
  const scored = rows.map(r => ({...r, lexicalMatch: titleMatchScore(r.title, item)}));
  const totalRaw = Number(data.search_information?.total_results);
  return {
    rows: scored,
    total: Number.isFinite(totalRaw) ? totalRaw : scored.length,
    exactState: data.search_information?.organic_results_state || '',
    queryDisplayed: cleanText(data.search_information?.query_displayed || ''),
    categories: data.categories || []
  };
}

async function sampleSearch(query, item, sold=false) {
  const run=async condition=>{
    const pages=[];
    const firstRaw=await serpEbaySearch(query,{sold,page:1,condition});
    const first=evaluatePage(firstRaw,item,sold); pages.push(first);
    // For a genuinely specific model query, count active listings from as much of the result set
    // as our configured page budget allows. This makes STR much less dependent on one 100-row sample.
    // Broad discovery queries stay on one page because extrapolating a huge mixed market is unsafe.
    const expectedPages=Math.max(1,Math.ceil(Math.max(first.total,first.rows.length)/100));
    const wantedPages=querySpecificEnough(item,query)?Math.min(MARKET_SAMPLE_PAGES,expectedPages):1;
    if(wantedPages>1){
      const pageNums=Array.from({length:wantedPages-1},(_,i)=>i+2);
      const extra=await Promise.all(pageNums.map(async p=>evaluatePage(await serpEbaySearch(query,{sold,page:p,condition}),item,sold)));
      for(const ev of extra){ if(ev.rows.length) pages.push(ev); }
    }
    const rows=dedupeRows(pages.flatMap(p=>p.rows));
    const exactState=/exact spelling/i.test(String(first.exactState||''));
    const specific=querySpecificEnough(item,query);
    // SerpApi documents that eBay total_results can represent broadened results
    // when no exact match exists. Never let that raw total become a STR denominator
    // unless eBay says this is an exact-spelling result and the query is model-specific.
    const totalTrusted=exactState && specific;
    const safeTotal=totalTrusted?Math.max(rows.length,first.total):rows.length;
    return {total:safeTotal,providerTotal:first.total,totalTrusted,exactState:first.exactState,queryDisplayed:first.queryDisplayed,categories:first.categories,rows,conditionApplied:condition};
  };
  let result=await run(item.condition);
  // eBay condition IDs are category-dependent. If a condition-filtered query unexpectedly returns nothing, retry unfiltered rather than reporting false scarcity.
  if (!result.rows.length && item.condition && item.condition!=='unknown') result=await run('unknown');
  return result;
}

function prefilterRows(rows,item,{sold=false}={}) {
  const now=new Date();
  return rows.filter(r=>{
    if (r.lexicalMatch < .20) return false;
    if (!conditionCompatible(item.condition,r.condition)) return false;
    if (LOT_RE.test(r.title) && !item.is_bundle) return false;
    if (PARTS_RE.test(r.title) && item.condition!=='for_parts') return false;
    if (sold) {
      // Sponsored cards can appear inside sold-result pages. A sold date is our proof that the row is an actual sold result.
      if (!r.soldDateParsed) return false;
      const age=daysAgo(r.soldDateParsed,now);
      if (age == null || age < -2 || age > 90) return false;
    }
    return true;
  }).sort((a,b)=>b.lexicalMatch-a.lexicalMatch);
}

function compImageCacheGet(url) {
  const v=COMP_IMAGE_CACHE.get(url);
  if(!v) return null;
  if(Date.now()-v.at>COMP_IMAGE_CACHE_TTL_MS){COMP_IMAGE_CACHE.delete(url);return null;}
  return v.data;
}
function compImageCacheSet(url,data) {
  COMP_IMAGE_CACHE.set(url,{at:Date.now(),data});
  if(COMP_IMAGE_CACHE.size>220){const first=COMP_IMAGE_CACHE.keys().next().value;COMP_IMAGE_CACHE.delete(first);}
}
function trustedCompImageUrl(value='') {
  try {
    const u=new URL(cleanText(value));
    if(u.protocol!=='https:') return null;
    if(!/(^|\.)ebayimg\.com$/i.test(u.hostname)) return null;
    return u.toString();
  } catch { return null; }
}
async function fetchCompImage(value='') {
  const url=trustedCompImageUrl(value);
  if(!url) return null;
  const cached=compImageCacheGet(url); if(cached) return cached;
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),COMP_IMAGE_TIMEOUT_MS);
  try {
    const r=await fetch(url,{signal:controller.signal,headers:{'User-Agent':`ORBIT/${ENGINE_VERSION}`}});
    if(!r.ok) return null;
    const type=cleanText(r.headers.get('content-type')||'').split(';')[0].toLowerCase();
    if(!/^image\/(?:jpeg|png|webp)$/.test(type)) return null;
    const declared=Number(r.headers.get('content-length')||0);
    if(declared>COMP_IMAGE_MAX_BYTES) return null;
    const ab=await r.arrayBuffer();
    if(!ab.byteLength || ab.byteLength>COMP_IMAGE_MAX_BYTES) return null;
    const data={buffer:Buffer.from(ab),mime:type};
    compImageCacheSet(url,data);
    return data;
  } catch { return null; }
  finally { clearTimeout(timer); }
}
function selectVisualCandidates(rows,maxCount) {
  const usable=rows.map((row,index)=>({row,index})).filter(x=>trustedCompImageUrl(x.row.imageUrl));
  if(usable.length<=maxCount) return usable;
  const exactPool=usable.filter(x=>x.row.searchPool!=='similar_style');
  const stylePool=usable.filter(x=>x.row.searchPool==='similar_style');
  const picked=[];
  const takeSpread=(arr,count)=>{
    if(count<=0||!arr.length)return;
    const n=Math.min(count,arr.length);
    for(let j=0;j<n;j++){
      const pos=Math.min(arr.length-1,Math.floor(((j+.5)*arr.length)/n));
      picked.push(arr[pos]);
    }
  };
  // Keep exact-model candidates for price, but reserve substantial room for nearby same-brand
  // styles so velocity is not accidentally an exact-SKU-only measurement.
  if(stylePool.length){
    const styleSlots=Math.max(4,Math.round(maxCount*.42));
    takeSpread(exactPool,Math.max(1,maxCount-styleSlots));
    takeSpread(stylePool,styleSlots);
  } else takeSpread(usable,maxCount);
  const seen=new Set();
  const unique=picked.filter(x=>{if(seen.has(x.index))return false;seen.add(x.index);return true;});
  if(unique.length<maxCount){
    for(const x of usable){if(unique.length>=maxCount)break;if(!seen.has(x.index)){seen.add(x.index);unique.push(x);}}
  }
  return unique.slice(0,maxCount);
}
async function loadVisualCandidates(rows,maxCount) {
  const selected=selectVisualCandidates(rows,maxCount);
  // Image downloads are independent. Fetch the small fast-pass sample concurrently instead
  // of waiting on sequential batches; per-image timeout still bounds slow CDN responses.
  const results=await Promise.all(selected.map(async x=>({ ...x, image:await fetchCompImage(x.row.imageUrl) })));
  return results.filter(x=>x.image);
}

async function withTimeBudget(promise, ms, label='operation') {
  let timer;
  try {
    return await Promise.race([
      promise,
      new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error(`${label} exceeded ${ms}ms fast-path budget`)),ms);})
    ]);
  } finally { if(timer) clearTimeout(timer); }
}

async function classifyCompRows(item, soldRows, activeRows, visualContext={}) {
  const sold = soldRows.slice(0,120), active=activeRows.slice(0,120);
  const targetImages=(Array.isArray(visualContext.images)?visualContext.images:[]).filter(x=>x?.buffer).slice(0,2);
  if(!targetImages.length && visualContext.imageBuffer) targetImages.push({buffer:visualContext.imageBuffer,mime:visualContext.imageMime||'image/jpeg'});
  if (!GEMINI_API_KEY || !targetImages.length) {
    return {sold:[],active:[],visualSoldInspected:0,visualActiveInspected:0,visualSoldExactInspected:0,visualActiveExactInspected:0,visualSoldStyleInspected:0,visualActiveStyleInspected:0,visualRefinement:null,visualUnavailable:true};
  }

  const [soldVisual,activeVisual]=await Promise.all([
    loadVisualCandidates(sold,VISUAL_COMP_MAX_SOLD),
    loadVisualCandidates(active,VISUAL_COMP_MAX_ACTIVE)
  ]);
  if (!soldVisual.length && !activeVisual.length) {
    return {sold:[],active:[],visualSoldInspected:0,visualActiveInspected:0,visualSoldExactInspected:0,visualActiveExactInspected:0,visualSoldStyleInspected:0,visualActiveStyleInspected:0,visualRefinement:null,visualUnavailable:true};
  }

  const identity = {
    title:item.title, brand:item.brand||null, model:item.model||null, mpn:item.mpn||null,
    item_type:item.item_type||null, condition:item.condition||'unknown',
    visible_text:item.visible_text||[], identity_terms:item.identity_terms||[], family_identity_terms:item.family_identity_terms||[], exclude_terms:item.exclude_terms||[], is_bundle:!!item.is_bundle
  };
  const prompt=`You are ORBIT's strict visual resale-comp verifier. The first one or more images are the user's target item from different angles. Every later image is an eBay listing candidate and is preceded by its exact SOLD/ACTIVE index and title.

Target identity from the user's photo: ${JSON.stringify(identity)}

Your job is precision-first. A comp may affect price or sell-through ONLY when the listing photo and title support that it is genuinely the same sellable product/model/design.

Classification:
- exact = Tier 1 verified comp: same product/model/design. Normal color differences are okay only when they do not imply a different edition/model/value tier.
- likely = Tier 2 SIMILAR-STYLE comp: same brand and product type with a closely related silhouette, construction, materials, feature layout, overall design, and roughly similar market/value class. It may be a neighboring model/style, but should look like a realistic substitute to the same shopper.
- variant = same broad family but meaningfully different style, generation, construction, size class, trim, configuration or form factor. VARIANT IS TOO DIFFERENT for similar-style sell-through and must not enter that velocity pool.
- accessory = case, sleeve, laptop case, pouch, charger, replacement part, packaging, manual, strap, etc. instead of the target.
- lot = bundle/multiple units when target is one.
- parts = broken/for-parts when target is not for-parts.
- wrong = different product/model/design or insufficient evidence.

Critical rules:
- Compare PHOTOS, not just words. If the target is a backpack and a candidate photo is a laptop sleeve/case, it is accessory/wrong even if the brand matches.
- Never mark exact merely because brand/category matches.
- For LICENSED or SUBJECT-DRIVEN merchandise, the team/character/theme matters for exact matching, but it is NOT an automatic rejection for family sourcing. A different team/franchise may be a likely/variant FAMILY comp when the maker, product type, era, construction, silhouette, paneling, brim/closure, materials and overall graphic/embroidery layout are genuinely the same or closely related design. It must never be labeled exact.
- Treat family_identity_terms as value modifiers. Different subjects should reduce confidence when they can materially affect collectibility, but similar-design cross-team/cross-theme comps are allowed for a conservative family market.
- If construction/design or market tier is clearly different, classify variant or wrong even when brand/maker matches. Only 'likely' is eligible as a neighboring similar-style velocity comp. Do not use a budget/basic model to represent demand for a premium/pro model (or vice versa) just because the shape is broadly similar. For hats especially compare crown/panel structure, brim shape, closure, materials, embroidery placement/style and era cues.
- If a distinctive model/design is visible, require its shape, construction, pockets, closures, straps, hardware, proportions, materials and major trim to agree for exact, and remain strongly similar for a 'likely' neighboring-style comp.
- If you cannot see enough to verify it, use likely or wrong, not exact.
- Precision is more important than sample size.

Also return a refinement only if Tier-1 matches strongly reveal a specific repeated model/product line that is visually supported by the target. Do not infer a model just because it is common. The proposed query should be brand + model/product line and should avoid generic words when possible.

Return ONLY JSON:
{"sold":[{"i":0,"match":"exact|likely|variant|accessory|lot|parts|wrong","confidence":0.0,"visual_confidence":0.0,"reason":"short"}],"active":[...],"refinement":{"accepted":false,"title":null,"model":null,"query":null,"identity_terms":[],"confidence":0.0,"reason":"short"}}
Classify every provided candidate index exactly once.`;

  const parts=[{text:prompt}];
  targetImages.forEach((img,i)=>{parts.push({text:`TARGET ITEM PHOTO ${i+1} OF ${targetImages.length}`});parts.push({inline_data:{mime_type:img.mime||'image/jpeg',data:img.buffer.toString('base64')}});});
  for(const x of soldVisual){
    parts.push({text:`SOLD index ${x.index}: ${x.row.title} | condition=${x.row.condition||'unknown'} | sold=${x.row.price??'unknown'}`});
    parts.push({inline_data:{mime_type:x.image.mime,data:x.image.buffer.toString('base64')}});
  }
  for(const x of activeVisual){
    parts.push({text:`ACTIVE index ${x.index}: ${x.row.title} | condition=${x.row.condition||'unknown'} | ask=${x.row.price??'unknown'}`});
    parts.push({inline_data:{mime_type:x.image.mime,data:x.image.buffer.toString('base64')}});
  }

  try {
    const outputText=await withTimeBudget(geminiGenerate({model:COMP_MODEL,fallbackModels:[],parts,jsonMode:true}),COMP_CLASSIFY_TIMEOUT_MS,'visual comp verification');
    const parsed=safeJson(outputText);
    const soldAllowed=new Set(soldVisual.map(x=>x.index)), activeAllowed=new Set(activeVisual.map(x=>x.index));
    const sanitize=(arr,allowed)=>(Array.isArray(arr)?arr:[]).filter(c=>allowed.has(Number(c.i))).map(c=>({
      i:Number(c.i),match:String(c.match||'wrong'),confidence:clamp(Number(c.confidence)||0,0,1),
      visual_confidence:clamp(Number(c.visual_confidence??c.confidence)||0,0,1),reason:cleanText(c.reason||'')
    }));
    const refinement=parsed?.refinement&&typeof parsed.refinement==='object'?parsed.refinement:null;
    return {
      sold:sanitize(parsed.sold,soldAllowed),active:sanitize(parsed.active,activeAllowed),
      visualSoldInspected:soldVisual.length,visualActiveInspected:activeVisual.length,
      visualSoldExactInspected:soldVisual.filter(x=>x.row.searchPool!=='similar_style').length,
      visualActiveExactInspected:activeVisual.filter(x=>x.row.searchPool!=='similar_style').length,
      visualSoldStyleInspected:soldVisual.filter(x=>x.row.searchPool==='similar_style').length,
      visualActiveStyleInspected:activeVisual.filter(x=>x.row.searchPool==='similar_style').length,
      visualRefinement:refinement,visualUnavailable:false
    };
  } catch (err) {
    console.warn('Visual comp classifier unavailable:',err.message);
    return {sold:[],active:[],visualSoldInspected:soldVisual.length,visualActiveInspected:activeVisual.length,visualSoldExactInspected:soldVisual.filter(x=>x.row.searchPool!=='similar_style').length,visualActiveExactInspected:activeVisual.filter(x=>x.row.searchPool!=='similar_style').length,visualSoldStyleInspected:soldVisual.filter(x=>x.row.searchPool==='similar_style').length,visualActiveStyleInspected:activeVisual.filter(x=>x.row.searchPool==='similar_style').length,visualRefinement:null,visualUnavailable:true,visualError:err.message};
  }
}

function applyClassification(rows, classes) {
  const byIndex=new Map((classes||[]).map(c=>[Number(c.i),c]));
  return rows.slice(0,400).map((r,i)=>{
    const c=byIndex.get(i)||null;
    if(!c) return {...r,compClass:'unverified',compTier:3,compConfidence:0,visualConfidence:0,visualVerified:false,match:0};
    const label=String(c.match||'wrong');
    const aiConfidence=clamp(Number(c.confidence)||0,0,1);
    const visualConfidence=clamp(Number(c.visual_confidence??c.confidence)||0,0,1);
    const exact=label==='exact' && aiConfidence>=.72 && visualConfidence>=.72;
    const tier=exact?1:((label==='likely'||label==='variant')&&aiConfidence>=.60?2:3);
    return {
      ...r,compClass:label,compTier:tier,compConfidence:aiConfidence,visualConfidence,
      visualVerified:exact,compReason:cleanText(c.reason||''),
      match:exact?clamp(r.lexicalMatch*.20+aiConfidence*.35+visualConfidence*.45,0,1):clamp(r.lexicalMatch*.15+aiConfidence*.25+visualConfidence*.25,0,.79)
    };
  });
}

function hasHardIdentity(item) {
  const model=usableModelIdentity(item), mpn=marketQueryClean(item.mpn), barcode=marketQueryClean(item.barcode);
  if (model || mpn || barcode) return true;
  // Descriptive materials/colors are not a model identity. Without an explicit model,
  // only model-like alphanumeric/numeric identifiers make an identity hard enough for STR.
  const terms=(item.identity_terms||[]).flatMap(t=>tokens(marketQueryClean(t)));
  return terms.some(t=>/\d/.test(t));
}

function querySpecificEnough(item, query) {
  const qClean=marketQueryClean(query), qn=norm(qClean);
  if(!qn) return false;
  const containsIdentity=(value)=>{
    const v=marketQueryClean(value); if(!v) return false;
    const vn=norm(v); if(vn && qn.includes(vn)) return true;
    const vt=tokens(v).filter(t=>t.length>=2);
    const qt=new Set(tokens(qClean));
    return vt.length>0 && vt.every(t=>qt.has(t));
  };
  // A hard identity only makes THIS query specific when the query actually contains it.
  // This prevents a brand-only fallback from inheriting model-level confidence/count behavior.
  if(containsIdentity(item.barcode) || containsIdentity(item.mpn)) return true;
  if(modelSearchVariants(usableModelIdentity(item)).some(containsIdentity)) return true;
  const hardTerms=(item.identity_terms||[]).map(marketQueryClean).filter(Boolean).filter(t=>/\d/.test(t));
  if(hardTerms.some(containsIdentity)) return true;
  // When the item itself has no hard model/identifier, a numeric query can still be specific.
  if(!hasHardIdentity(item)) return tokens(qClean).some(t=>/\d/.test(t));
  return false;
}

function searchQuality(sampleRows, matchedRows, total) {
  const n=Math.max(0,sampleRows.length), k=Math.max(0,matchedRows.length);
  const ci=wilson(k,n);
  const complete = total <= n + 2;
  const estimate = complete ? k : Math.round(total*ci.p);
  const low = complete ? k : Math.floor(total*ci.low);
  const high = complete ? k : Math.ceil(total*ci.high);
  return {sampleN:n,matchedN:k,precision:ci.p,precisionLow:ci.low,precisionHigh:ci.high,complete,estimate,low,high,total};
}

function visualSearchQuality(search, matchedRows, inspectedN) {
  const n=Math.max(0,Number(inspectedN)||0), k=Math.max(0,matchedRows.length);
  const total=Math.max(k,Number(search?.total)||0);
  if(!n) return {sampleN:0,matchedN:k,precision:0,precisionLow:0,precisionHigh:1,complete:false,estimate:k,low:0,high:Math.max(k,total),total,uncertain:true};
  const ci=wilson(k,n);
  const fullyInspected = total>0 && n>=total;
  const estimate=fullyInspected?k:Math.max(k,Math.round(total*ci.p));
  const low=fullyInspected?k:Math.max(0,Math.floor(total*ci.low));
  const high=fullyInspected?k:Math.max(k,Math.ceil(total*ci.high));
  return {sampleN:n,matchedN:k,precision:ci.p,precisionLow:ci.low,precisionHigh:ci.high,complete:fullyInspected,estimate,low,high,total,uncertain:false};
}

function combineVelocityQuality(exactQ, styleQ) {
  const sampleN=Number(exactQ?.sampleN||0)+Number(styleQ?.sampleN||0);
  const matchedN=Number(exactQ?.matchedN||0)+Number(styleQ?.matchedN||0);
  const ci=wilson(matchedN,sampleN);
  return {
    sampleN,matchedN,precision:ci.p,precisionLow:ci.low,precisionHigh:ci.high,
    complete:!!exactQ?.complete && !!styleQ?.complete,
    estimate:Number(exactQ?.estimate||0)+Number(styleQ?.estimate||0),
    low:Number(exactQ?.low||0)+Number(styleQ?.low||0),
    high:Number(exactQ?.high||0)+Number(styleQ?.high||0),
    total:Number(exactQ?.total||0)+Number(styleQ?.total||0),
    uncertain:exactQ?.uncertain===true || styleQ?.uncertain===true,
    exactComponent:exactQ,styleComponent:styleQ
  };
}

function visualRefinedIdentity(item, market) {
  const r=market?.visualRefinement;
  if(!r || r.accepted!==true) return null;
  const confidence=clamp(Number(r.confidence)||0,0,1);
  const query=marketQueryClean(r.query||'');
  const model=marketQueryClean(r.model||'');
  if(confidence<.78 || !query || norm(query)===norm(market.query||'')) return null;
  const brand=marketQueryClean(item.brand||'');
  if(brand && !norm(query).includes(norm(brand))) return null;
  const exactTitles=[...(market.soldExact||[]),...(market.activeExact||[])].map(x=>norm(x.title));
  if(exactTitles.length<2) return null;
  const evidenceTerm=norm(model)||tokens(query).filter(t=>!tokens(brand).includes(t)).join(' ');
  if(evidenceTerm){
    const hits=exactTitles.filter(t=>t.includes(evidenceTerm)).length;
    if(hits<2) return null;
  }
  return {
    ...item,
    title:cleanText(r.title||`${brand} ${model}`||item.title),
    model:model||item.model||null,
    identity_terms:uniq([...(Array.isArray(r.identity_terms)?r.identity_terms:[]),model,...(item.identity_terms||[])]),
    query_candidates:uniq([query,...(item.query_candidates||[])]),
    identity_confidence:Math.max(Number(item.identity_confidence)||0,Math.min(.97,confidence)),
    market_assisted_identity:true,
    market_identity_reason:cleanText(r.reason||'Visually verified comp consensus'),
    market_identity_confidence:confidence
  };
}


function canonicalVelocityFamily(item) {
  const supplied=marketQueryClean(item?.velocity_family||'');
  if(supplied) return supplied;
  let raw=marketQueryClean(item?.item_type||item?.category||'');
  raw=raw.replace(/\b(?:vintage|retro|striped|stripe|organic|cotton|leather|suede|brown|black|white|red|blue|green|grey|gray|tan|beige|mens|men s|womens|women s|male|female|size|os|one size|changing|classic|premium|rare|used|new|authentic|original)\b/gi,' ')
    .replace(/\s+/g,' ').trim();
  const rn=norm(raw);
  const patterns=[
    ['towel poncho',/\b(?:towel|beach)\b.*\bponcho\b|\bponcho\b.*\b(?:towel|beach)\b/],
    ['work boots',/\bwork\b.*\bboots?\b|\bboots?\b.*\bwork\b/],
    ['cowboy boots',/\b(?:cowboy|western)\b.*\bboots?\b|\bboots?\b.*\b(?:cowboy|western)\b/],
    ['point and shoot camera',/\bpoint\b.*\bshoot\b.*\bcamera\b|\bcompact\b.*\bcamera\b/],
    ['film camera',/\bfilm\b.*\bcamera\b/],
    ['over ear headphones',/\bover\b.*\bear\b.*\bheadphones?\b/],
    ['backpack',/\b(?:backpack|rucksack)\b/],
    ['tote bag',/\btote\b.*\bbag\b/],
    ['crossbody bag',/\bcrossbody\b.*\bbag\b/],
    ['snapback hat',/\bsnapback\b.*\b(?:hat|cap)\b/],
    ['t shirt',/\b(?:t shirt|tee|shirt)\b/],
  ];
  for(const [label,re] of patterns) if(re.test(rn)) return label;
  const toks=tokens(raw).filter(t=>t.length>=3);
  return marketQueryClean(toks.slice(-4).join(' ')||raw);
}

function similarStyleMarketQuery(item) {
  const brand=marketQueryClean(item?.brand||'');
  const family=canonicalVelocityFamily(item);
  if(!brand || !family) return '';
  const q=marketQueryClean(`${brand} ${family}`);
  return q.length>=4?q:'';
}

function targetSpecificTokens(item={}) {
  const brandTokens=new Set(tokens(item.brand||''));
  const typeTokens=new Set(tokens(item.item_type||''));
  const generic=new Set(['vintage','new','used','mens','womens','women','men','size','black','white','brown','blue','red','green','gray','grey','tan','beige','one','pair','with','the','and','for','from']);
  return uniq(tokens(item.title||'').filter(t=>t.length>=4 && !brandTokens.has(t) && !typeTokens.has(t) && !generic.has(t)));
}
function targetTitleSupport(item,title='') {
  const tt=new Set(tokens(title));
  const specific=targetSpecificTokens(item);
  if(!specific.length) return false;
  const hits=specific.filter(t=>tt.has(t));
  return hits.length>=2 || hits.some(t=>t.length>=7);
}

function familyTitleAccept(item,row) {
  const title=cleanText(row?.title||'');
  if(!title) return false;
  const titleN=norm(title), brandN=norm(item?.brand||'');
  if(brandN && !titleN.includes(brandN)) return false;
  if(LOT_RE.test(title) && !item?.is_bundle) return false;
  if(PARTS_RE.test(title) && item?.condition!=='for_parts') return false;
  if(accessoryPenalty(title,item)>.12) return false;
  const family=canonicalVelocityFamily(item);
  const ft=tokens(family).filter(t=>t.length>=3);
  if(!ft.length) return false;
  const tt=new Set(tokens(title));
  const hits=ft.filter(t=>tt.has(t)).length;
  const ratio=hits/ft.length;
  if(ft.length===1) return hits===1;
  return ratio>=.60 && hits>=2;
}

function familyMarketQuality(search, candidateRows, matchedRows, {sold=false, familyQuery=''}={}) {
  const n=Math.max(0,candidateRows.length), k=Math.max(0,matchedRows.length);
  const ci=wilson(k,n);
  if(!n) return {sampleN:0,matchedN:0,precision:0,precisionLow:0,precisionHigh:1,complete:false,estimate:0,low:0,high:0,total:0,uncertain:true};
  let total=n, complete=true, uncertain=false;
  if(sold && search?.source==='trawl') {
    complete=!!search.complete;
    uncertain=!complete;
    total=n;
  } else {
    const familySpecific=!!search?.similarStyleQuery;
    const exactSpelling=/exact spelling/i.test(String(familySpecific?(search?.familyExactState||''):(search?.exactState||'')));
    const providerTotal=Math.max(0,Number(familySpecific?(search?.familyProviderTotal||0):(search?.providerTotal||0)));
    const canonical=norm(familyQuery)&&norm(search?.similarStyleQuery||familyQuery)===norm(familyQuery);
    // Broad eBay totals are only used after a tightly scoped brand+family query and
    // observed title precision calibrates how much of that total actually belongs.
    if(exactSpelling && canonical && providerTotal>=n && providerTotal<=5000) {
      total=providerTotal;
      complete=providerTotal<=n+2;
    } else {
      total=n;
      complete=true;
      uncertain=!exactSpelling;
    }
  }
  const estimate=complete?k:Math.max(k,Math.round(total*ci.p));
  const low=complete?k:Math.max(0,Math.floor(total*ci.low));
  const high=complete?k:Math.max(k,Math.ceil(total*ci.high));
  return {sampleN:n,matchedN:k,precision:ci.p,precisionLow:ci.low,precisionHigh:ci.high,complete,estimate,low,high,total,uncertain};
}

function familyAnchorTerms(item) {
  return uniq((Array.isArray(item?.family_identity_terms)?item.family_identity_terms:[])
    .map(marketQueryClean).filter(Boolean));
}
function phraseMostlyPresent(title, phrase) {
  const tt=new Set(tokens(title));
  const pt=tokens(phrase).filter(t=>t.length>=3);
  if(!pt.length) return true;
  const hits=pt.filter(t=>tt.has(t)).length;
  return hits/pt.length>=.67;
}
function familyAnchorsMatchTitle(item,title) {
  const anchors=familyAnchorTerms(item);
  if(!anchors.length) return true;
  return anchors.every(a=>phraseMostlyPresent(title,a));
}
function familyQueryAligned(item,query) {
  const anchors=familyAnchorTerms(item);
  if(!anchors.length) return true;
  return anchors.every(a=>phraseMostlyPresent(query,a));
}

async function analyzeMarketAttempt(query,item,visualContext={}) {
  const familyQuery=similarStyleMarketQuery(item);
  const hardIdentity=hasHardIdentity(item);
  // Style-driven goods do not benefit from doing two nearly identical provider searches.
  // Use one canonical brand+family query, then let the visual verifier separate exact and
  // neighboring styles inside that same pool. This cuts two network calls from common scans.
  const primaryQuery=(!hardIdentity && familyQuery)?familyQuery:query;
  const useFamilyQuery=hardIdentity && familyQuery && norm(familyQuery)!==norm(primaryQuery);
  const soldFn=q=>TRAWL_API_KEY?sampleTrawlSold(q,item):sampleSearch(q,item,true);
  const tasks=[soldFn(primaryQuery),sampleSearch(primaryQuery,item,false)];
  if(useFamilyQuery) tasks.push(soldFn(familyQuery),sampleSearch(familyQuery,item,false));
  const providerStarted=Date.now();
  const results=await Promise.allSettled(tasks);
  const providerMs=Date.now()-providerStarted;
  const [soldResult,activeResult,familySoldResult,familyActiveResult]=results;
  if (soldResult.status==='rejected' && activeResult.status==='rejected') {
    throw new Error(`eBay market provider failed — sold: ${soldResult.reason?.message||'unknown error'}; active: ${activeResult.reason?.message||'unknown error'}`);
  }
  const emptySearch=(error)=>({total:0,exactState:'',categories:[],rows:[],conditionApplied:'unknown',providerError:error||null});
  const primarySold=soldResult.status==='fulfilled'?soldResult.value:emptySearch(soldResult.reason?.message||'sold search unavailable');
  const primaryActive=activeResult.status==='fulfilled'?activeResult.value:emptySearch(activeResult.reason?.message||'active search unavailable');
  const broadSold=familySoldResult?.status==='fulfilled'?familySoldResult.value:null;
  const broadActive=familyActiveResult?.status==='fulfilled'?familyActiveResult.value:null;
  const mergeSearch=(primary,broad)=>{
    if(!broad) return {...primary,rows:(primary.rows||[]).map(r=>({...r,searchPool:'exact'}))};
    const exactRows=(primary.rows||[]).map(r=>({...r,searchPool:'exact'}));
    const styleRows=(broad.rows||[]).map(r=>({...r,searchPool:'similar_style'}));
    const rows=dedupeRows([...exactRows,...styleRows]);
    return {...primary,rows,total:rows.length,providerTotal:Math.max(Number(primary.providerTotal||primary.total||0),Number(broad.providerTotal||broad.total||0)),totalTrusted:false,similarStyleQuery:familyQuery,familyProviderTotal:Number(broad.providerTotal||broad.total||0),familyExactState:broad.exactState||'',familyQueryDisplayed:broad.queryDisplayed||''};
  };
  const soldSearch=mergeSearch(primarySold,broadSold);
  const activeSearch=mergeSearch(primaryActive,broadActive);
  // A successful family search is real market evidence even when the primary exact request
  // fails or times out. Do not discard dozens of usable same-brand family rows merely
  // because one parallel provider request failed. Availability is satisfied by EITHER pool.
  const soldPrimaryAvailable=soldResult.status==='fulfilled';
  const activePrimaryAvailable=activeResult.status==='fulfilled';
  const soldFamilyAvailable=useFamilyQuery && familySoldResult?.status==='fulfilled';
  const activeFamilyAvailable=useFamilyQuery && familyActiveResult?.status==='fulfilled';
  const soldDataAvailable=soldPrimaryAvailable || soldFamilyAvailable;
  const activeDataAvailable=activePrimaryAvailable || activeFamilyAvailable;
  const providerErrors=[];
  if (!soldDataAvailable) providerErrors.push(`sold comps unavailable: ${primarySold.providerError||familySoldResult?.reason?.message||'all sold searches failed'}`);
  if (!activeDataAvailable) providerErrors.push(`active listings unavailable: ${primaryActive.providerError||familyActiveResult?.reason?.message||'all active searches failed'}`);
  if(useFamilyQuery && familySoldResult?.status==='rejected') providerErrors.push(`similar-style sold search unavailable: ${familySoldResult.reason?.message||'unknown error'}`);
  if(useFamilyQuery && familyActiveResult?.status==='rejected') providerErrors.push(`similar-style active search unavailable: ${familyActiveResult.reason?.message||'unknown error'}`);
  const soldPre=prefilterRows(soldSearch.rows,item,{sold:true});
  const activePre=prefilterRows(activeSearch.rows,item,{sold:false});
  const classifyStarted=Date.now();
  const classes=await classifyCompRows(item,soldPre,activePre,visualContext);
  const classifyMs=Date.now()-classifyStarted;
  const visualCompWarning=classes.visualError?`Listing-photo classifier was unavailable or inconclusive (${classes.visualError}). ORBIT continued with title-supported exact/family evidence.`:null;
  const soldClassified=applyClassification(soldPre,classes.sold);
  const activeClassified=applyClassification(activePre,classes.active);
  const soldExact=soldClassified.filter(r=>r.visualVerified===true && r.compTier===1);
  const activeExact=activeClassified.filter(r=>r.visualVerified===true && r.compTier===1);
  const soldTier2=soldClassified.filter(r=>r.compTier===2);
  const activeTier2=activeClassified.filter(r=>r.compTier===2);

  // ORBIT 1.0.2 hybrid sourcing:
  // Exact-model evidence remains the gold standard, but rare/discontinued items should not
  // become non-actionable just because the exact SKU has thin history. Strong Tier-2 rows
  // are visually similar same-brand/product-family comps; accessories/cases/lots/wrong
  // designs were already rejected by the visual verifier and never enter this fallback.
  const brandN=norm(item.brand||'');
  const familyAccept=r=>(!brandN || norm(r.title).includes(brandN) || r.compTier===1) && (r.compTier===1 || (
    r.compTier===2 &&
    r.compClass==='likely' &&
    Number(r.compConfidence||0)>=.72 &&
    Number(r.visualConfidence||0)>=.74
  ));
  const soldFamily=soldClassified.filter(familyAccept);
  const activeFamily=activeClassified.filter(familyAccept);
  // Velocity uses the whole validated brand+family result pool, not only the few listings
  // sent to the image model. The image model validates style; title-family matching scales
  // that evidence across the larger market sample so STR is stable from scan to scan.
  const soldFamilyTitle=soldPre.filter(r=>familyTitleAccept(item,r));
  const activeFamilyTitle=activePre.filter(r=>familyTitleAccept(item,r));
  const soldFamilyVelocity=dedupeRows([...soldFamily,...soldFamilyTitle]);
  const activeFamilyVelocity=dedupeRows([...activeFamily,...activeFamilyTitle]);

  const priceRows=soldExact.filter(r=>!r.bestOfferUnknown);
  const robust=robustPrices(priceRows.map(r=>r.price));
  const familyPriceRows=soldFamily.filter(r=>!r.bestOfferUnknown);
  const familyPrices=robustPrices(familyPriceRows.map(r=>r.price));
  const soldExactPrimary=soldExact.filter(r=>r.searchPool!=='similar_style');
  const activeExactPrimary=activeExact.filter(r=>r.searchPool!=='similar_style');
  const soldStyleMatches=soldClassified.filter(r=>r.searchPool==='similar_style' && familyAccept(r));
  const activeStyleMatches=activeClassified.filter(r=>r.searchPool==='similar_style' && familyAccept(r));
  const soldStyleRows=soldSearch.rows.filter(r=>r.searchPool==='similar_style');
  const activeStyleRows=activeSearch.rows.filter(r=>r.searchPool==='similar_style');
  const soldStyleSearch={...(broadSold||emptySearch()),rows:soldStyleRows,total:soldStyleRows.length,totalTrusted:false};
  const activeStyleSearch={...(broadActive||emptySearch()),rows:activeStyleRows,total:activeStyleRows.length,totalTrusted:false};
  let soldQ=visualSearchQuality(primarySold,soldExactPrimary,classes.visualSoldExactInspected);
  let activeQ=visualSearchQuality(primaryActive,activeExactPrimary,classes.visualActiveExactInspected);
  let soldStyleQ=visualSearchQuality(soldStyleSearch,soldStyleMatches,classes.visualSoldStyleInspected);
  let activeStyleQ=visualSearchQuality(activeStyleSearch,activeStyleMatches,classes.visualActiveStyleInspected);
  // Family velocity is measured from the ENTIRE visually inspected candidate pool,
  // not only rows that happened to come from a separately tagged broad query. This matters
  // when the primary query is already family-level (for example "Sand Cloud Towel Poncho").
  // Tier-1 exact rows and Tier-2 likely neighboring styles both belong to this same pool.
  let familySoldQ=familyMarketQuality(soldSearch,soldPre,soldFamilyVelocity,{sold:true,familyQuery:familyQuery||primaryQuery});
  let familyActiveQ=familyMarketQuality(activeSearch,activePre,activeFamilyVelocity,{sold:false,familyQuery:familyQuery||primaryQuery});
  // If visual verification succeeded, never let lexical family matching claim lower evidence
  // than the actual visually accepted sample.
  familySoldQ={...familySoldQ,matchedN:Math.max(familySoldQ.matchedN,soldFamily.length),estimate:Math.max(familySoldQ.estimate,soldFamily.length)};
  familyActiveQ={...familyActiveQ,matchedN:Math.max(familyActiveQ.matchedN,activeFamily.length),estimate:Math.max(familyActiveQ.estimate,activeFamily.length)};
  if(primarySold.source==='trawl' && primarySold.truncated){
    soldQ={...soldQ,lowerBound:true,uncertain:true};
  }
  if(broadSold?.source==='trawl' && broadSold.truncated){
    soldStyleQ={...soldStyleQ,lowerBound:true,uncertain:true};
  }
  if(soldQ.lowerBound||soldStyleQ.lowerBound) familySoldQ={...familySoldQ,lowerBound:true,uncertain:true};

  const broadActiveUncertain = activeDataAvailable && (activeSearch.totalTrusted===false || !querySpecificEnough(item,primaryQuery)) &&
    Number(activeSearch.providerTotal||activeSearch.total||0) > Math.max(12, activeExact.length*3);
  if (broadActiveUncertain) activeQ={...activeQ,uncertain:true,broadQuery:true};

  const priceMedian=median(robust), priceAverage=trimmedMean(robust,.10);
  const activePrices=robustPrices(activeExact.map(r=>r.price));
  const askingPriceMedian=median(activePrices);
  const activePriceLow=percentile(activePrices,.25), activePriceHigh=percentile(activePrices,.75);
  const activeDispersion=askingPriceMedian>0?(activePriceHigh-activePriceLow)/askingPriceMedian:1;
  const visibleActiveSoldUnits=activeExact.reduce((n,r)=>n+(Number(r.soldCount)||0),0);
  const activeListingsWithSales=activeExact.filter(r=>(Number(r.soldCount)||0)>0).length;
  const activeWatchers=activeExact.reduce((n,r)=>n+(Number(r.watchers)||0),0);
  const demandProxy = activeExact.length<3 ? 'unknown' : (visibleActiveSoldUnits>=50 || activeListingsWithSales>=4 || activeWatchers>=30 ? 'strong' : (visibleActiveSoldUnits>=8 || activeListingsWithSales>=1 || activeWatchers>=8 ? 'moderate' : 'weak'));
  const activeMarketConfidence=clamp(activeQ.precisionLow*.34 + clamp(classes.visualActiveInspected/16,0,1)*.20 + clamp(activeExact.length/8,0,1)*.20 + item.identity_confidence*.16 + (1-clamp(activeDispersion,0,1))*.06 + (activeDataAvailable ? .04 : 0),0,1);
  const dispersion=priceMedian>0?(percentile(robust,.75)-percentile(robust,.25))/priceMedian:1;
  const familyMedian=median(familyPrices);
  const familyDispersion=familyMedian>0?(percentile(familyPrices,.75)-percentile(familyPrices,.25))/familyMedian:1;
  let score = soldDataAvailable ? (soldQ.precisionLow*.25 + activeQ.precisionLow*.18 + clamp(robust.length/10,0,1)*.24 + clamp(classes.visualSoldInspected/14,0,1)*.12 + clamp(classes.visualActiveInspected/16,0,1)*.08 + (1-clamp(dispersion,0,1))*.07 + item.identity_confidence*.06) : activeMarketConfidence;
  const familyScore = soldDataAvailable ? (
    familySoldQ.precisionLow*.22 + familyActiveQ.precisionLow*.16 +
    clamp(familyPrices.length/10,0,1)*.22 + clamp(soldFamily.length/10,0,1)*.12 +
    clamp(activeFamily.length/8,0,1)*.10 + (1-clamp(familyDispersion,0,1))*.08 +
    item.identity_confidence*.10
  ) : 0;
  score=Math.max(score,familyScore*.90);
  if (!activeDataAvailable) score*=.35;
  if(classes.visualUnavailable) score*=.15;
  return {
    query:primaryQuery,familyQuery:(familyQuery&&norm(familyQuery)!==norm(primaryQuery))?familyQuery:null,providerMs,classifyMs,soldSearch,activeSearch,soldPre,activePre,soldExact,activeExact,soldTier2,activeTier2,soldFamily,activeFamily,soldFamilyVelocity,activeFamilyVelocity,
    priceRows,prices:robust,familyPriceRows,familyPrices,activePrices,
    askingPriceMedian,activePriceLow,activePriceHigh,activeMarketConfidence,visibleActiveSoldUnits,activeListingsWithSales,activeWatchers,demandProxy,
    soldQ,activeQ,soldStyleQ,activeStyleQ,familySoldQ,familyActiveQ,score,soldDataAvailable,activeDataAvailable,providerErrors,soldSource:soldSearch.source==='trawl'?'Trawl':'SerpApi',
    soldCountLowerBound:!!soldQ.lowerBound,familySoldCountLowerBound:!!familySoldQ.lowerBound,
    visualVerificationAvailable:!classes.visualUnavailable,visualSoldInspected:classes.visualSoldInspected,
    visualActiveInspected:classes.visualActiveInspected,visualSoldExactInspected:classes.visualSoldExactInspected,visualActiveExactInspected:classes.visualActiveExactInspected,
    visualSoldStyleInspected:classes.visualSoldStyleInspected,visualActiveStyleInspected:classes.visualActiveStyleInspected,visualRefinement:classes.visualRefinement||null,visualCompWarning
  };
}

function marketIdentityNeedsRefinement(item, market) {
  if (!market?.activeDataAvailable || (market.activeSearch?.rows?.length || 0) < 6) return false;
  const hard = hasHardIdentity(item);
  const exact = Number(market.activeQ?.matchedN || 0);
  const precision = Number(market.activeQ?.precisionLow || 0);
  const broadTotal = Number(market.activeSearch?.total || 0);
  // Generic identities are especially dangerous when the broad query spans many
  // variants. Use the original photo + real listing titles to refine before STR.
  if (!hard && (market.activeQ?.uncertain || broadTotal > Math.max(30,exact*3))) return true;
  return (!hard && exact < 6) || (exact < 2 && precision < .20);
}

async function refineIdentityFromActiveMarket(item, market, imageBuffer, imageMime) {
  if (!GEMINI_API_KEY || !imageBuffer || !marketIdentityNeedsRefinement(item, market)) return null;
  const rows=(market.activeSearch?.rows || []).slice(0,36);
  if (rows.length < 12) return null;
  const listingTitles=rows.map((r,i)=>({i,title:r.title,condition:r.condition,price:r.price}));
  const current={title:item.title,brand:item.brand||null,model:item.model||null,mpn:item.mpn||null,item_type:item.item_type||null,visible_text:item.visible_text||[],identity_terms:item.identity_terms||[]};
  const prompt=`You are doing a second-pass product identification for a reseller app. The first visual pass was too generic, and we now have real active eBay listing titles from a broad search. Use the ORIGINAL PHOTO plus these listing titles to refine the target only when the photo is visually consistent with a specific repeated product line/model.

Current identity: ${JSON.stringify(current)}
Active eBay titles: ${JSON.stringify(listingTitles)}

Rules:
- Do not choose a model just because it is common in the listings.
- A refined model/product line must appear verbatim in at least two supplied listing titles.
- Use visible shape/design/markings in the photo plus any visible text from the first pass.
- Never invent MPN/UPC/size/edition.
- If the photo cannot support a specific refinement, return accepted=false.
- query must be concise, normally brand + model/product line, with no generic hype words.
- confidence is confidence that the refinement identifies the photographed item, not confidence that the listing search is popular.
Return ONLY JSON:
{"accepted":true,"title":"specific identity","model":"model or product line","identity_terms":["must-match term"],"query":"brand model","confidence":0.0,"reason":"short evidence note"}`;
  try {
    const out=await geminiGenerate({model:GEMINI_MODEL,fallbackModels:VISION_FALLBACK_MODELS,prompt,imageBuffer,imageMime:imageMime||'image/jpeg',jsonMode:true});
    const r=safeJson(out);
    if (!r || r.accepted!==true) return null;
    const model=marketQueryClean(r.model);
    const query=marketQueryClean(r.query);
    const confidence=clamp(Number(r.confidence)||0,0,1);
    if (!model || !query || confidence < .72) return null;
    const mn=norm(model);
    const titleHits=rows.filter(x=>norm(x.title).includes(mn)).length;
    if (titleHits < 2) return null;
    const brand=marketQueryClean(item.brand);
    if (brand && !norm(query).includes(norm(brand))) return null;
    return {
      ...item,
      title:cleanText(r.title || `${brand} ${model}` || item.title),
      model:model,
      identity_terms:uniq([model,...(Array.isArray(r.identity_terms)?r.identity_terms:[]),...(item.identity_terms||[])]),
      query_candidates:uniq([query,...(item.query_candidates||[])]),
      identity_confidence:Math.max(Number(item.identity_confidence)||0, Math.min(.96,confidence)),
      market_assisted_identity:true,
      market_identity_reason:cleanText(r.reason||''),
      market_identity_confidence:confidence
    };
  } catch(err) {
    console.warn(`Market-assisted identity refinement failed for ${item.title}: ${err.message}`);
    return null;
  }
}

async function bestMarketSearch(item, visualContext={}) {
  const candidates=itemQueryCandidates(item);
  if (!candidates.length) throw new Error('Not enough visible identity to build a market query');
  const attempts=[];
  // Normally stop after the first useful active search. If eBay returns no active listings,
  // broaden only then. This preserves the low-cost mode while avoiding false zero-result cards
  // from over-specific AI-generated queries.
  const maxAdaptiveAttempts=Math.min(candidates.length, Math.max(2, MARKET_QUERY_ATTEMPTS));
  for (const query of candidates.slice(0,maxAdaptiveAttempts)) {
    try {
      const attempt=await analyzeMarketAttempt(query,item,visualContext);
      attempts.push(attempt);
      const rawCandidates=(attempt.soldSearch?.rows?.length||0)+(attempt.activeSearch?.rows?.length||0);
      const verifiedMatches=(attempt.soldExact?.length||0)+(attempt.activeExact?.length||0);
      const probableMatches=(attempt.soldTier2?.length||0)+(attempt.activeTier2?.length||0);
      const familySoldMatches=attempt.soldFamily?.length||0;
      const familyActiveMatches=attempt.activeFamily?.length||0;
      // Raw search hits are only candidates. If visual verification rejects almost everything,
      // continue down the query ladder instead of stopping on a broad/irrelevant search.
      const exactSoldMatches=attempt.soldExact?.length||0;
      const soldEvidenceAvailable=attempt.soldDataAvailable!==true || exactSoldMatches>=1 || familySoldMatches>=2 || Number(attempt.familySoldQ?.matchedN||0)>=2;
      // Active-only success is not enough to stop the ladder when the sold provider returned zero
      // relevant rows. Continue to a human-readable model/title query so obvious sold comps are not missed.
      const usableMarket = soldEvidenceAvailable && (verifiedMatches>=2 || (verifiedMatches>=1 && probableMatches>=2));
      // The family pool is deliberately useful with smaller samples because it is a visual
      // demand sample, not an exact-SKU price claim. Three sold + two active verified family
      // matches are enough to stop searching and calculate a confidence-aware STR.
      const usableFamilyMarket = Number(attempt.familySoldQ?.matchedN||0)>=2 && Number(attempt.familyActiveQ?.matchedN||0)>=1;
      const specificWithEvidence = soldEvidenceAvailable && querySpecificEnough(item,query) && verifiedMatches>=1 && rawCandidates>=3;
      // For non-model goods, do not burn another full provider + Gemini cycle once the first
      // broad-but-controlled pool has useful visual evidence.
      const onePassFamilyEvidence = !hasHardIdentity(item) && rawCandidates>=5 && familySoldMatches>=2 && familyActiveMatches>=1;
      if (usableMarket || usableFamilyMarket || specificWithEvidence || onePassFamilyEvidence) break;
    } catch (err) {
      attempts.push({query,error:err.message,score:-1});
      // Keep broadening for query-specific no-result/provider errors, but do not fan out endlessly.
    }
  }
  const valid=attempts.filter(a=>!a.error).sort((a,b)=>b.score-a.score);
  if (!valid.length) throw new Error(attempts.map(a=>`${a.query}: ${a.error}`).join(' | ')||'No market data returned');
  const best=valid[0];
  const second=valid[1]||null;
  let agreement=1;
  const bestAgreePrices=best.prices.length>=3?best.prices:best.activePrices;
  const secondAgreePrices=second?(second.prices.length>=3?second.prices:second.activePrices):[];
  if (second && bestAgreePrices.length>=3 && secondAgreePrices.length>=3) {
    const a=trimmedMean(bestAgreePrices), b=trimmedMean(secondAgreePrices);
    if (a>0&&b>0) agreement=Math.min(a,b)/Math.max(a,b);
    const s1=best.activeQ.estimate>0?best.soldQ.estimate/best.activeQ.estimate:0;
    const s2=second.activeQ.estimate>0?second.soldQ.estimate/second.activeQ.estimate:0;
    if (s1>0&&s2>0) agreement=Math.min(agreement,Math.min(s1,s2)/Math.max(s1,s2));
  }
  return {...best,agreement,attempts:attempts.map(a=>a.error?{query:a.query,error:a.error}:{query:a.query,score:a.score,soldSample:a.soldQ.sampleN,soldExact:a.soldQ.matchedN,activeSample:a.activeQ.sampleN,activeExact:a.activeQ.matchedN,soldPrecision:a.soldQ.precision,activePrecision:a.activeQ.precision})};
}

function sellThroughEvidenceAssessment(identity, market, mode, soldQ, activeQ) {
  const soldMatched=Math.max(0,Number(soldQ?.matchedN||0));
  const activeMatched=Math.max(0,Number(activeQ?.matchedN||0));
  const soldInspected=Math.max(0,Number(mode==='exact'?market?.visualSoldExactInspected:market?.visualSoldInspected)||0);
  const activeInspected=Math.max(0,Number(mode==='exact'?market?.visualActiveExactInspected:market?.visualActiveInspected)||0);
  const soldPrecision=clamp(Number(soldQ?.precisionLow||0),0,1);
  const activePrecision=clamp(Number(activeQ?.precisionLow||0),0,1);
  const agreement=clamp(Number(market?.agreement||1),0,1);
  const identityConfidence=clamp(Number(identity?.identity_confidence||0),0,1);
  const specificity=mode==='exact' ? (querySpecificEnough(identity,market?.query||'')?1:.35) : (market?.familyQuery?1:.65);
  const score=clamp(
    clamp(soldMatched/12,0,1)*.18 + clamp(activeMatched/12,0,1)*.16 +
    clamp(soldInspected/20,0,1)*.10 + clamp(activeInspected/20,0,1)*.10 +
    soldPrecision*.12 + activePrecision*.12 + agreement*.10 +
    identityConfidence*.05 + specificity*.07,
    0,1
  );
  let label='Low';
  if(score>=.74 && soldMatched>=8 && activeMatched>=8) label='High';
  else if(score>=.46 && soldMatched>=3 && activeMatched>=2) label='Medium';
  else if(mode!=='exact' && soldMatched>=2 && activeMatched>=1 && (soldInspected+activeInspected)>=3) label='Medium';
  return {score,label,soldMatched,activeMatched,soldInspected,activeInspected};
}


function modelTitleSupport(title='',model='') {
  const mt=tokens(model).filter(Boolean), tt=new Set(tokens(title));
  if(!mt.length) return false;
  const digitish=mt.filter(t=>/\d/.test(t));
  if(digitish.length && !digitish.every(t=>tt.has(t))) return false;
  const hits=mt.filter(t=>tt.has(t)).length;
  if(mt.length===1) return hits===1;
  return hits>=Math.max(2,Math.ceil(mt.length*.60));
}
function queryTitleSupport(title='',query='',brand='') {
  const brandSet=new Set(tokens(brand));
  const qt=tokens(query).filter(t=>!brandSet.has(t));
  if(!qt.length) return false;
  const tt=new Set(tokens(title));
  const digitish=qt.filter(t=>/\d/.test(t));
  if(digitish.length && !digitish.every(t=>tt.has(t))) return false;
  const hits=qt.filter(t=>tt.has(t)).length;
  return hits>=Math.max(1,Math.ceil(qt.length*.55));
}
function soldTitlePricingCandidates(identity,market,{family=false}={}) {
  const rows=Array.isArray(market?.soldPre)?market.soldPre:[];
  const brand=marketQueryClean(identity.brand||''), brandN=norm(brand);
  const model=usableModelIdentity(identity), query=marketQueryClean(market.query||'');
  return rows.filter(r=>{
    if(r.bestOfferUnknown || !Number.isFinite(Number(r.price)) || Number(r.price)<=0) return false;
    const title=cleanText(r.title||''), tn=norm(title);
    if(brandN && !tn.includes(brandN)) return false;
    if(LOT_RE.test(title) && !identity.is_bundle) return false;
    if(PARTS_RE.test(title) && identity.condition!=='for_parts') return false;
    if(accessoryPenalty(title,identity)>.12) return false;
    if(family){
      if(!familyTitleAccept(identity,r)) return false;
      if(!familyAnchorsMatchTitle(identity,title)) return false;
      // A row from the exact-query pool or a target-specific title is suitable as a family price comp.
      return r.searchPool==='exact' || targetTitleSupport(identity,title) || modelTitleSupport(title,model);
    }
    if(model && modelTitleSupport(title,model)) return true;
    if(querySpecificEnough(identity,query) && r.searchPool==='exact' && queryTitleSupport(title,query,brand)) return true;
    return false;
  });
}
function pricePoolReliability(rows,{min=3,maxDispersion=.90}={}) {
  const prices=robustPrices(rows.map(r=>Number(r.price)));
  const med=median(prices);
  const dispersion=med>0?(percentile(prices,.75)-percentile(prices,.25))/med:99;
  return {rows,prices,median:med,dispersion,reliable:prices.length>=min&&dispersion<=maxDispersion};
}


function adaptivePricePool(identity, market, scope='exact') {
  // Pricing and velocity now share the SAME validated market hierarchy. Exact rows are
  // preferred, but when exact evidence is thin ORBIT automatically broadens to the
  // already-validated same-brand family pool instead of rebuilding a second stricter filter.
  const sourceRows = scope==='exact'
    ? dedupeRows([...(market.soldExact||[]), ...soldTitlePricingCandidates(identity,market,{family:false})])
    : dedupeRows([...(market.soldFamilyVelocity||[]), ...(market.soldFamily||[])]);
  const rows=sourceRows.filter(r=>{
    if(r.bestOfferUnknown || !Number.isFinite(Number(r.price)) || Number(r.price)<=0) return false;
    const title=cleanText(r.title||'');
    if(LOT_RE.test(title) && !identity.is_bundle) return false;
    if(PARTS_RE.test(title) && identity.condition!=='for_parts') return false;
    if(accessoryPenalty(title,identity)>.12) return false;
    return true;
  });
  const prices=robustPrices(rows.map(r=>Number(r.price)));
  const med=median(prices);
  const q1=percentile(prices,.25), q3=percentile(prices,.75);
  const dispersion=med>0?(q3-q1)/med:99;
  const matchedN=scope==='exact'?Number(market.soldQ?.matchedN||0):Number(market.familySoldQ?.matchedN||0);
  const visualN=rows.filter(r=>r.visualVerified===true || Number(r.visualConfidence||0)>=.72).length;
  const identityConfidence=Number(identity.identity_confidence||0);
  const dispersionScore=dispersion===99?0:1-clamp(dispersion/1.5,0,1);
  let score=clamp(
    clamp(prices.length/8,0,1)*.34 + clamp(matchedN/10,0,1)*.22 +
    Math.min(1,visualN/2)*.14 + dispersionScore*.18 + identityConfidence*.12,
    0,1
  );
  if(scope!=='exact') score=Math.min(score,.82);
  let label='Low';
  if(prices.length>=6 && matchedN>=6 && dispersion<=.70 && score>=.64) label='High';
  else if((prices.length>=3 && matchedN>=3 && dispersion<=1.25) ||
          (prices.length>=2 && visualN>=1 && dispersion<=.50)) label='Medium';
  const available=prices.length>=1;
  const verified=label!=='Low' && available;
  return {scope,rows,prices,median:med,q1,q3,dispersion,matchedN,visualN,score,label,available,verified};
}

function selectAdaptivePricingPool(identity, market) {
  const exact=adaptivePricePool(identity,market,'exact');
  const family=adaptivePricePool(identity,market,'family');
  // Narrowest reliable scope wins. If exact is not reliable, broaden automatically.
  // If neither is decision-grade, still expose the best available estimate to the UI.
  if(exact.verified) return {...exact,evidenceMode:exact.visualN>=3?'visual_exact':'title_supported_exact'};
  if(family.verified) return {...family,evidenceMode:family.visualN>=3?'visual_family':'title_supported_family'};
  if(exact.available && (!family.available || exact.score>=family.score+.08)) return {...exact,evidenceMode:'provisional_exact'};
  if(family.available) return {...family,evidenceMode:'provisional_family'};
  return {...exact,evidenceMode:'none'};
}

function marketToItem(identity, market, settings={}) {
  const exactSoldPrices=market.prices||[];
  const familySoldPrices=market.familyPrices||[];
  const soldDataAvailable=market.soldDataAvailable===true;
  const activeDataAvailable=market.activeDataAvailable===true;
  const visualVerificationAvailable=market.visualVerificationAvailable===true;

  // ADAPTIVE EVIDENCE ENGINE: build price evidence from the same validated hierarchy used
  // for demand. Exact model evidence is preferred; if it is thin, broaden automatically to
  // the validated same-brand family pool. No category-specific rules are required.
  const adaptivePricing=selectAdaptivePricingPool(identity,market);
  const pricingMode=adaptivePricing.scope==='family'?'brand_family':(adaptivePricing.available?'exact':'none');
  const pricingVerified=soldDataAvailable && adaptivePricing.verified;
  const pricingAvailable=soldDataAvailable && adaptivePricing.available;
  const soldPrices=adaptivePricing.prices;
  const pricingEvidenceMode=adaptivePricing.evidenceMode;
  const pricingConfidenceLabel=adaptivePricing.label;
  const pricingConfidenceScore=adaptivePricing.score;
  const exactPricingVerified=pricingVerified&&pricingMode==='exact';
  const familyPricingVerified=pricingVerified&&pricingMode==='brand_family';
  const exactHybridReliable=pricingEvidenceMode==='title_supported_exact';
  const familyHybridReliable=pricingEvidenceMode==='title_supported_family';
  const lexicalExactRows=pricingMode==='exact'?adaptivePricing.rows:[];
  const lexicalFamilyRows=pricingMode==='brand_family'?adaptivePricing.rows:[];
  const lexicalExactPrices=pricingMode==='exact'?adaptivePricing.prices:[];
  const lexicalFamilyPrices=pricingMode==='brand_family'?adaptivePricing.prices:[];

  // Pricing and velocity intentionally use different scopes. Price stays exact-model whenever
  // exact sold comps exist. Velocity may broaden to a CONTROLLED same-brand similar-style pool
  // (photo-verified 'likely' neighbors) so fast-selling product lines are not judged from a tiny SKU sample.
  // Sold and active velocity still use the identical matching rule on both sides.
  const familyAddsEvidence = Number(market.familySoldQ?.matchedN||0)>Number(market.soldQ?.matchedN||0) ||
    Number(market.familyActiveQ?.matchedN||0)>Number(market.activeQ?.matchedN||0);
  const exactPoolComplete=Number(market.soldQ?.matchedN||0)>=4 && Number(market.activeQ?.matchedN||0)>=3;
  // Zero active matches can be meaningful evidence when the provider returned only a small,
  // fully inspected pool and several sold matches exist. Treat that as active-market scarcity,
  // not as missing demand data. We still refuse this shortcut on broad/high-total active searches.
  const familyActiveScarcityCandidate=activeDataAvailable && soldDataAvailable &&
    Number(market.familySoldQ?.matchedN||0)>=3 && Number(market.familyActiveQ?.matchedN||0)===0 &&
    Number(market.familyActiveQ?.sampleN||0)>=1 &&
    Number(market.familyActiveQ?.total||0)<=Math.max(8,Number(market.familyActiveQ?.sampleN||0)+2);
  const familyVelocityCandidate=activeDataAvailable && soldDataAvailable && familyAddsEvidence &&
    Number(market.familySoldQ?.matchedN||0)>=2 &&
    ((Number(market.familyActiveQ?.matchedN||0)>=1 && Number(market.familyActiveQ?.sampleN||0)>=1) || familyActiveScarcityCandidate) &&
    (Number(market.familySoldQ?.sampleN||0)>=2 || Number(market.familyActiveQ?.sampleN||0)>=1);
  // Never choose exact velocity just because one exact active listing exists. Exact must have
  // meaningful evidence on BOTH sides; otherwise use the broader validated same-brand family.
  const velocityMode=familyVelocityCandidate && !exactPoolComplete?'similar_style':(familyVelocityCandidate && familyAddsEvidence?'similar_style':(pricingMode==='brand_family'?'brand_family':'exact'));
  const useFamilyVelocity=velocityMode!=='exact';
  const soldQ=useFamilyVelocity?market.familySoldQ:market.soldQ;
  const activeQ=useFamilyVelocity?market.familyActiveQ:market.activeQ;
  const soldMatched=Number(soldQ?.matchedN||0);
  const activeMatched=Number(activeQ?.matchedN||0);
  const activeCountUncertain=activeQ?.uncertain===true;
  const activeSampleN=Math.max(0,Number(activeQ?.sampleN||0));
  const activePoolTotal=Math.max(0,Number(activeQ?.total||0));
  const activeScarcitySignal=activeDataAvailable && soldDataAvailable && soldMatched>=3 && activeMatched===0 &&
    activeSampleN>=1 && activePoolTotal<=Math.max(8,activeSampleN+2) && activeQ?.broadQuery!==true;

  const rawAverage=trimmedMean(soldPrices,.10), rawMedian=median(soldPrices);
  const q1=percentile(soldPrices,.25), q3=percentile(soldPrices,.75);
  const saleAverage=pricingAvailable?rawAverage:0;
  const saleMedian=pricingAvailable?rawMedian:0;

  // GLOBAL MAX-BUY BASIS: confidence-adjust the expected transaction value instead of
  // applying a fixed 30th-percentile haircut to every family-priced item. The pricing score
  // already reflects sample size, dispersion, visual support, identity confidence, and scope,
  // so this works across categories without item-specific rules.
  //
  // Use total order value (item price + buyer-paid shipping) because eBay fees apply to both
  // and buyer-paid shipping offsets postage. This prevents cheap/light items from being
  // penalized as if the seller always offered free shipping.
  const soldGrossValues=robustPrices((adaptivePricing.rows||[]).map(r=>{
    const p=Number(r.price); if(!Number.isFinite(p)||p<=0) return NaN;
    const sh=Number(r.shipping);
    const landed=Number(r.landedPrice);
    if(Number.isFinite(landed)&&landed>=p) return landed;
    return p+(Number.isFinite(sh)&&sh>0?sh:0);
  }));
  const grossAverage=pricingAvailable?trimmedMean(soldGrossValues,.10):0;
  const grossMedian=pricingAvailable?median(soldGrossValues):0;
  const expectedGrossValue=grossMedian>0&&grossAverage>0?grossMedian*.65+grossAverage*.35:(grossMedian||grossAverage||saleAverage);
  const maxBuyRiskFactor=pricingAvailable?clamp(.74+.26*pricingConfidenceScore,.74,.98):0;
  const riskAdjustedGrossValue=pricingAvailable?expectedGrossValue*maxBuyRiskFactor:0;
  const expectedItemValue=saleMedian>0&&saleAverage>0?saleMedian*.65+saleAverage*.35:(saleMedian||saleAverage);
  const riskAdjustedItemValue=pricingAvailable?expectedItemValue*maxBuyRiskFactor:0;
  const typicalBuyerPaidShipping=Math.max(0,median((adaptivePricing.rows||[]).map(r=>{const x=Number(r.shipping);return Number.isFinite(x)&&x>0?x:0;})));

  const sold90=soldDataAvailable?Number(soldQ?.estimate||0):0;
  const activeListings=activeDataAvailable?Number(activeQ?.estimate||0):0;
  const soldCountLowerBound=useFamilyVelocity?market.familySoldCountLowerBound===true:market.soldCountLowerBound===true;
  const soldLow=Number(soldQ?.low||0), soldHigh=Number(soldQ?.high||0);
  const activeLow=Number(activeQ?.low||0), activeHigh=Number(activeQ?.high||0);
  // eBay-style sell-through is sold / active. With zero verified active inventory the true
  // ratio is undefined/infinite, so use a conservative hypothetical denominator of one and
  // mark the result as a lower-bound scarcity signal (e.g. 8 sold / 0 active => >=800%).
  const rawStr=sold90>0?(activeListings>0?sold90/activeListings:(activeScarcitySignal?sold90:null)):null;

  const strEvidence=sellThroughEvidenceAssessment(identity,market,velocityMode,soldQ,activeQ);
  if(activeScarcitySignal && strEvidence.label==='Low') strEvidence.label='Medium';
  const exactVelocityEligible=velocityMode==='exact' && soldDataAvailable && activeDataAvailable &&
    soldMatched>=4 && sold90>0 && ((activeMatched>=3 && activeListings>0 && !activeCountUncertain) || activeScarcitySignal);
  const familyVelocityEligible=useFamilyVelocity && soldDataAvailable && activeDataAvailable &&
    soldMatched>=2 && Number(soldQ?.sampleN||0)>=2 && sold90>0 &&
    ((activeMatched>=1 && Number(activeQ?.sampleN||0)>=1 && activeListings>0) || activeScarcitySignal);
  const velocityEligible=exactVelocityEligible||familyVelocityEligible;
  const velocityVerified=velocityEligible && strEvidence.label!=='Low';

  // Count confidence intervals alone can look falsely precise when only a handful of true
  // sold matches exist. Widen the displayed STR range according to evidence depth.
  const baseStrLow=rawStr!=null&&activeHigh>0?soldLow/activeHigh*100:0;
  const baseStrHigh=rawStr!=null?(activeLow>0?soldHigh/activeLow*100:(soldHigh>0?999:0)):0;
  const evidenceBand=strEvidence.label==='High'?[.82,1.22]:strEvidence.label==='Medium'?[.58,1.70]:[.35,2.60];
  const rawPct=rawStr==null?0:rawStr*100;
  const strLow=rawStr==null?0:(activeScarcitySignal?Math.max(100,Math.min(rawPct,(soldLow>0?soldLow*100:rawPct*.58))):Math.max(0,Math.min(baseStrLow||rawPct,rawPct*evidenceBand[0])));
  const strHigh=rawStr==null?0:(activeScarcitySignal?999:Math.max(baseStrHigh||rawPct,rawPct*evidenceBand[1]));
  const daysToSell=rawStr>0?clamp(Math.round(90/rawStr),2,365):null;

  const dispersion=saleMedian>0?(q3-q1)/saleMedian:1;
  const priceSampleConfidence=clamp(soldPrices.length/10,0,1);
  const soldPrecisionConfidence=Number((pricingMode==='brand_family'?market.familySoldQ:market.soldQ)?.precisionLow||0);
  const activePrecisionConfidence=Number(activeQ?.precisionLow||0);
  const visualCoverage=clamp((Number(market.visualSoldInspected||0)+Number(market.visualActiveInspected||0))/24,0,1);
  const countCertainty=rawStr==null?.20:clamp(strEvidence.score,0,1);
  let marketConfidence=clamp(
    priceSampleConfidence*.18 + soldPrecisionConfidence*.15 + activePrecisionConfidence*.12 + visualCoverage*.16 +
    countCertainty*.17 + (1-clamp(dispersion,0,1))*.07 + Number(market.agreement||1)*.08 + Number(identity.identity_confidence||0)*.07,
    0,1
  );
  if(pricingMode==='brand_family') marketConfidence=Math.min(marketConfidence,.78);
  if(!pricingAvailable) marketConfidence=Math.min(marketConfidence,.30);
  else if(!pricingVerified) marketConfidence=Math.min(marketConfidence,.48);
  if(!velocityVerified) marketConfidence=Math.min(marketConfidence,.56);
  const decisionConfidence=velocityVerified?marketConfidence:Math.min(.49,marketConfidence*.72);

  const tagCost=Number.isFinite(identity.price_tag)?identity.price_tag:null;
  const acquisitionMode=settings.acquisitionMode==='bins'?'bins':'normal';
  const manualCost=(settings.manualPrice===null||settings.manualPrice===undefined||settings.manualPrice==='')?null:(Number.isFinite(Number(settings.manualPrice))?Math.max(0,Number(settings.manualPrice)):null);
  const binsRate=(settings.binsPricePerLb===null||settings.binsPricePerLb===undefined||settings.binsPricePerLb==='')?null:(Number.isFinite(Number(settings.binsPricePerLb))?Math.max(0,Number(settings.binsPricePerLb)):null);
  const weightEstimate=Number.isFinite(identity.weight_estimate_lb)?identity.weight_estimate_lb:null;
  let weightLow=Number.isFinite(identity.weight_low_lb)?identity.weight_low_lb:weightEstimate;
  let weightHigh=Number.isFinite(identity.weight_high_lb)?identity.weight_high_lb:weightEstimate;
  if(weightEstimate!=null){
    if(weightLow==null) weightLow=weightEstimate;
    if(weightHigh==null) weightHigh=weightEstimate;
    weightLow=Math.min(weightLow,weightEstimate); weightHigh=Math.max(weightHigh,weightEstimate);
  }
  const binsCostLow=(binsRate!=null&&weightLow!=null)?binsRate*weightLow:null;
  const binsCostEstimate=(binsRate!=null&&weightEstimate!=null)?binsRate*weightEstimate:null;
  const binsCostHigh=(binsRate!=null&&weightHigh!=null)?binsRate*weightHigh:null;
  // Bins decisions use the high end of the visual weight range so the app does not
  // create a BUY by underestimating the item's weight from a single photo.
  const acquisitionCost=acquisitionMode==='bins'?binsCostHigh:(manualCost!=null?manualCost:tagCost);
  const costSource=acquisitionMode==='bins'?(acquisitionCost!=null?'bins weight estimate':'bins weight/rate unavailable'):(manualCost!=null?'manual item price':(tagCost!=null?'visible price tag':'not visible'));
  const feesPct=Number(settings.defaultFeesPct??15);
  const shipping=Number(identity.shipping_estimate||0);
  const supplies=Number(identity.supplies_estimate||1);
  const targetProfit=Math.max(0,Number(settings.minProfit??10));
  const proceedsBeforeCost=pricingVerified&&riskAdjustedGrossValue>0?
    Math.max(0,riskAdjustedGrossValue-riskAdjustedGrossValue*(feesPct/100)-shipping-supplies):null;
  const verifiedMaxBuyPrice=proceedsBeforeCost==null?null:Math.max(0,proceedsBeforeCost-targetProfit);
  const maxBuyPrice=verifiedMaxBuyPrice;
  const estimatedNetProfit=proceedsBeforeCost!=null&&acquisitionCost!=null?proceedsBeforeCost-acquisitionCost:null;

  const reviewReasons=[];
  const evidenceNotes=[];
  if(!visualVerificationAvailable) evidenceNotes.push(market.visualCompWarning||'Listing-photo classification was unavailable or inconclusive. ORBIT continued with title-supported exact/family evidence and did not use the missing photo classification alone as a PASS veto.');
  if(identity.identity_confidence<.62) reviewReasons.push('item identity uncertain');
  if(!pricingAvailable) reviewReasons.push('sold history was found, but no usable sold prices survived the adaptive exact/family evidence pool');
  else if(!pricingVerified) reviewReasons.push(`price estimate is available but confidence is ${pricingConfidenceLabel.toLowerCase()} (${soldPrices.length} usable sold price${soldPrices.length===1?'':'s'}); ORBIT will show the value but will not use it for a BUY until the evidence strengthens`);
  if(exactPricingVerified && market.soldQ.precisionLow<.20) reviewReasons.push('sold candidate set contains many visual non-matches');
  if(pricingMode==='brand_family') evidenceNotes.push('Exact-model history is thin; value uses validated same-brand/design-family comps. Max-buy is confidence-adjusted from expected order value rather than using a fixed low percentile.');
  evidenceNotes.push(`Max-buy uses a ${(maxBuyRiskFactor*100).toFixed(0)}% confidence-adjusted expected order value (item + typical buyer-paid shipping), then subtracts ${feesPct}% fees, estimated postage, supplies, and the $${targetProfit.toFixed(2)} profit target.`);
  evidenceNotes.push(`Sell-through compares sold and active listings using the same ${useFamilyVelocity?'same-brand similar-style':'exact item/model'} matching rules.`);
  if(useFamilyVelocity) evidenceNotes.push('Sell-through intentionally uses a controlled same-brand similar-style pool. Exact-model pricing remains separate; visibly different styles/generations/form factors are excluded.');
  if(activeScarcitySignal) evidenceNotes.push(`No matching active listings survived the same-pool check while ${soldMatched} recent sold matches did. ORBIT treats this as active-inventory scarcity and reports sell-through as a conservative lower bound using one hypothetical active listing.`);
  if(!velocityVerified){
    if(strEvidence.label==='Low' && rawStr!=null) reviewReasons.push(`sell-through evidence is low confidence (${soldMatched} sold and ${activeMatched} active matches verified)`);
    else if(activeCountUncertain && velocityMode==='exact') reviewReasons.push('active search is still too broad; a more specific model/label photo is needed');
    else reviewReasons.push('not enough same-pool sold and active market evidence survived to estimate sell-through safely');
  }
  if(market.agreement<.70) reviewReasons.push('independent search queries disagree');
  if(saleMedian>0 && (q3-q1)/saleMedian>.85) reviewReasons.push('accepted sold prices are widely dispersed');

  const chosenSoldRows=(adaptivePricing.rows||[]).map(r=>({...r,match:Number(r.match||r.lexicalMatch||titleMatchScore(r.title,identity)),visualConfidence:Number(r.visualConfidence||0),compClass:r.compClass||(pricingMode==='brand_family'?'title_supported_family':'title_supported_exact')}));
  const chosenSoldQ=pricingMode==='brand_family'?market.familySoldQ:market.soldQ;
  const chosenActiveQ=useFamilyVelocity?market.familyActiveQ:market.activeQ;
  const rejectedSold=Math.max(0,Number(market.visualSoldInspected||0)-Number(chosenSoldQ?.matchedN||0));
  const rejectedActive=Math.max(0,Number(market.visualActiveInspected||0)-Number(chosenActiveQ?.matchedN||0));

  return {
    title:identity.title,
    category:identity.category||identity.item_type||'Uncategorized',
    brand:identity.brand||null, model:identity.model||null, mpn:identity.mpn||null,
    userHintsUsed:sanitizeUserHints(identity.user_hints||'')||null,
    lensRescueUsed:identity.lens_rescue_used===true, lensHintCount:Number(identity.lens_hint_count||0),
    marketAssistedIdentity:identity.market_assisted_identity===true, marketIdentityReason:identity.market_identity_reason||null, marketIdentityConfidence:identity.market_identity_confidence||null,
    condition:identity.condition||'unknown',
    acquisitionMode,
    cost:acquisitionCost, costKnown:acquisitionCost!=null, costSource,
    detectedPriceTag:tagCost,
    manualPrice:manualCost,
    binsPricePerLb:binsRate,
    estimatedWeightLb:weightEstimate,
    estimatedWeightLowLb:weightLow,
    estimatedWeightHighLb:weightHigh,
    weightConfidence:Number((Number(identity.weight_confidence)||0).toFixed(2)),
    weightBasis:identity.weight_basis||null,
    binsCostLow:binsCostLow==null?null:Number(binsCostLow.toFixed(2)),
    binsCostEstimate:binsCostEstimate==null?null:Number(binsCostEstimate.toFixed(2)),
    binsCostHigh:binsCostHigh==null?null:Number(binsCostHigh.toFixed(2)),
    maxBuyPrice:maxBuyPrice==null?null:Number(maxBuyPrice.toFixed(2)),
    maxBuyPriceVerified:pricingVerified&&maxBuyPrice!=null,
    minProfitTarget:Number(targetProfit.toFixed(2)),
    estimatedNetProfit:estimatedNetProfit==null?null:Number(estimatedNetProfit.toFixed(2)),
    minResaleValue:Number.isFinite(Number(settings.minResaleValue))?Math.max(0,Number(settings.minResaleValue)):25,
    minSellThrough:Number.isFinite(Number(settings.minSellThrough))?clamp(Number(settings.minSellThrough),0,999):40,
    provisionalResalePrice:null,
    salePrice:Number(saleAverage.toFixed(2)), averageSalePrice:Number(saleAverage.toFixed(2)), medianSalePrice:Number(saleMedian.toFixed(2)),
    conservativeSaleValue:pricingAvailable?Number(riskAdjustedItemValue.toFixed(2)):0,
    salePriceLow:pricingAvailable?Number(q1.toFixed(2)):0, salePriceHigh:pricingAvailable?Number(q3.toFixed(2)):0,
    feesPct, shipping, supplies, laborMin:Number(identity.labor_min||12),
    maxBuyRiskFactor:Number(maxBuyRiskFactor.toFixed(3)), expectedGrossOrderValue:Number((expectedGrossValue||0).toFixed(2)), riskAdjustedGrossValue:Number((riskAdjustedGrossValue||0).toFixed(2)), riskAdjustedItemValue:Number((riskAdjustedItemValue||0).toFixed(2)), typicalBuyerPaidShipping:Number((typicalBuyerPaidShipping||0).toFixed(2)),
    sold90, activeListings, soldCountLowerBound, activeCountUncertain, activeCountUpperBound:false, activeScarcitySignal,
    sellThrough90:rawStr==null?null:Number((rawStr*100).toFixed(1)), sellThroughLowerBound:velocityVerified&&(soldCountLowerBound||activeScarcitySignal),
    sellThroughConfidenceLabel:strEvidence.label, sellThroughConfidenceScore:Number(strEvidence.score.toFixed(3)),
    sellThroughMatchBasis:useFamilyVelocity?'Same-brand similar style':'Exact item/model', sellThroughDecisionReady:velocityVerified,
    sellThroughLow:Number(strLow.toFixed(1)), sellThroughHigh:Number(Math.min(strHigh,999).toFixed(1)),
    soldCountLow:soldLow, soldCountHigh:soldHigh, activeCountLow:activeLow, activeCountHigh:activeHigh,
    soldSample:soldPrices.length, soldCompSample:Number(chosenSoldQ?.matchedN||0), activeCompSample:Number(chosenActiveQ?.matchedN||0),
    exactSoldCompSample:Number(market.soldQ?.matchedN||0), exactActiveCompSample:Number(market.activeQ?.matchedN||0),
    familySoldCompSample:Number(market.familySoldQ?.matchedN||0), familyActiveCompSample:Number(market.familyActiveQ?.matchedN||0),
    soldSearchSample:Number(chosenSoldQ?.sampleN||0), activeSearchSample:Number(chosenActiveQ?.sampleN||0),
    visualSoldInspected:Number(market.visualSoldInspected||0), visualActiveInspected:Number(market.visualActiveInspected||0),
    rejectedSoldComps:rejectedSold,rejectedActiveComps:rejectedActive,
    soldMatchPrecision:Number(Number(chosenSoldQ?.precision||0).toFixed(3)), activeMatchPrecision:Number(Number(chosenActiveQ?.precision||0).toFixed(3)),
    queryAgreement:Number(Number(market.agreement||1).toFixed(3)),
    daysToSell, quantity:1, bulky:!!identity.bulky, fragile:!!identity.fragile,
    confidence:decisionConfidence, identityConfidence:identity.identity_confidence, marketConfidence, activeMarketConfidence:market.activeMarketConfidence||0, decisionConfidence,
    marketQuery:market.query, velocityFamily:canonicalVelocityFamily(identity), soldDataAvailable, activeDataAvailable, pricingAvailable, pricingVerified, velocityVerified, visualVerificationAvailable,
    pricingMode,pricingEvidenceMode,pricingConfidenceLabel,pricingConfidenceScore:Number(pricingConfidenceScore.toFixed(3)),velocityMode,brandFamilyFallback:pricingMode==='brand_family'||useFamilyVelocity,
    askingPriceMedian:market.askingPriceMedian?Number(market.askingPriceMedian.toFixed(2)):null,
    activePriceLow:market.activePriceLow?Number(market.activePriceLow.toFixed(2)):null,activePriceHigh:market.activePriceHigh?Number(market.activePriceHigh.toFixed(2)):null,
    demandProxy:market.demandProxy||'unknown',visibleActiveSoldUnits:market.visibleActiveSoldUnits||0,activeListingsWithSales:market.activeListingsWithSales||0,activeWatchers:market.activeWatchers||0,providerErrors:market.providerErrors||[],
    marketSource:visualVerificationAvailable?`${market.soldSource||'Trawl'} sold history + eBay active listings; ${pricingMode==='brand_family'||useFamilyVelocity?'photo-verified similar-style velocity pool':'photo-to-photo + title verification'}`:`${market.soldSource||'Trawl'} sold history + eBay active listings; listing-photo classifier inconclusive, title-supported evidence used`,
    visibleText:identity.visible_text||[], alternativeIdentities:identity.alternative_identities||[],
    evidenceNotes,
    compExamples:chosenSoldRows.slice(0,8).map(x=>({title:x.title,price:x.price,shipping:x.shipping,soldDate:x.sold_date,match:Number(x.match.toFixed(2)),visualConfidence:Number((x.visualConfidence||0).toFixed(2)),compClass:x.compClass||'exact',link:x.link,imageUrl:x.imageUrl||null})),
    reviewRequired:reviewReasons.length>0 || decisionConfidence<.52 || !pricingVerified || !velocityVerified,
    reviewReasons,
    bbox:identity.bbox||null
  };
}

const AUTH_FAILURES=new Map();
function accessMatches(candidate='') {
  if (!APP_ACCESS_CODE) return true;
  const a=Buffer.from(String(candidate));
  const b=Buffer.from(APP_ACCESS_CODE);
  return a.length===b.length && crypto.timingSafeEqual(a,b);
}
function requireAccess(req,res,next) {
  if (!APP_ACCESS_CODE) return next();
  const key=String(req.ip||req.socket?.remoteAddress||'unknown');
  const now=Date.now();
  const state=AUTH_FAILURES.get(key)||{count:0,since:now};
  if(now-state.since>10*60*1000){state.count=0;state.since=now;}
  if(state.count>=10)return res.status(429).json({error:'Too many access-code attempts. Try again later.',code:'ACCESS_RATE_LIMIT'});
  const candidate=req.get('X-ProfitQueue-Access') || '';
  if (!accessMatches(candidate)) { state.count++;AUTH_FAILURES.set(key,state);return res.status(401).json({error:'ProfitQueue access code required',code:'ACCESS_REQUIRED'}); }
  AUTH_FAILURES.delete(key);next();
}

app.post('/api/access/check', requireAccess, (_req,res)=>res.json({ok:true}));

app.get('/api/health', (_req,res) => {
  res.json({
    ok:true, engineVersion:ENGINE_VERSION, configured:Boolean((GEMINI_API_KEY||CLOUDFLARE_VISION_CONFIGURED)&&SERPAPI_KEY&&TRAWL_API_KEY), geminiConfigured:Boolean(GEMINI_API_KEY), cloudflareVisionConfigured:CLOUDFLARE_VISION_CONFIGURED, trawlConfigured:Boolean(TRAWL_API_KEY), soldMarketData:Boolean(TRAWL_API_KEY), soldProviderDegraded:Date.now()<soldProviderDegradedUntil, soldProviderMessage:soldProviderLastError||null,
    model:GEMINI_MODEL, fastIdentifyModel:FAST_IDENTIFY_MODEL, cloudflareVisionModel:CLOUDFLARE_VISION_MODEL, compModel:COMP_MODEL, visionFallbacks:VISION_FALLBACK_MODELS, compFallbacks:COMP_FALLBACK_MODELS, marketProvider:'Trawl sold + SerpApi active + hierarchical exact/family validation',
    samplePages:MARKET_SAMPLE_PAGES, queryAttempts:MARKET_QUERY_ATTEMPTS, accessProtected:Boolean(APP_ACCESS_CODE), deployment:process.env.RENDER?'render':'node', port:PORT
  });
});

app.post('/api/analyze', requireAccess, upload.fields([{name:'images',maxCount:5},{name:'image',maxCount:1}]), async (req,res) => {
  const started=Date.now();
  try {
    const uploaded=[...(req.files?.images||[]),...(req.files?.image||[])].slice(0,5);
    if (!uploaded.length) return res.status(400).json({error:'No image uploaded'});
    if (!(GEMINI_API_KEY||CLOUDFLARE_VISION_CONFIGURED)||!SERPAPI_KEY||!TRAWL_API_KEY) return res.status(503).json({error:'Backend needs at least one vision provider (Gemini or Cloudflare Workers AI), plus SERPAPI_KEY and TRAWL_API_KEY',code:'NOT_CONFIGURED'});
    let settings={}; try{settings=req.body.settings?JSON.parse(req.body.settings):{};}catch{}
    const mode=req.body.mode==='group'?'group':'single';
    const barcode=cleanText(req.body.barcode||'');
    const userHints=sanitizeUserHints(settings.itemHints||req.body.itemHints||'');
    settings.itemHints=userHints;
    const snapshotKey=analysisFingerprint(uploaded,mode,barcode,settings);
    const cachedSnapshot=analysisCacheGet(snapshotKey);
    if(cachedSnapshot){
      const elapsedMs=Date.now()-started;
      console.log(`ORBIT stable snapshot hit: ${snapshotKey.slice(0,10)} | ${cachedSnapshot.items?.length||0} item(s) | ${elapsedMs}ms`);
      return res.json({...cachedSnapshot,meta:{...(cachedSnapshot.meta||{}),elapsedMs,cacheHit:true,stableSnapshot:true,sourceElapsedMs:cachedSnapshot.meta?.elapsedMs||null}});
    }
    const targetImages=uploaded.map(f=>({buffer:f.buffer,mime:f.mimetype||'image/jpeg'}));
    const identifyStarted=Date.now();
    const identities=await identifyImages(targetImages,mode,userHints);
    const identifyMs=Date.now()-identifyStarted;
    for(const identity of identities){ if(userHints) identity.user_hints=userHints; }
    if (barcode&&identities[0]) {
      identities[0].barcode=barcode;
      identities[0].query_candidates=uniq([barcode,...(identities[0].query_candidates||[])]);
      identities[0].visible_text=uniq([...(identities[0].visible_text||[]),`Barcode ${barcode}`]);
      identities[0].identity_confidence=Math.max(.90,identities[0].identity_confidence||0);
    }
    const visualContext={images:targetImages};
    const analyzeOne=async identity=>{
      try {
        const marketStarted=Date.now();
        let market=await bestMarketSearch(identity,visualContext);
        const marketMs=Date.now()-marketStarted;
        let finalIdentity=identity;

        // Fast path: use comp consensus to improve the displayed identity, but do NOT launch
        // a second complete market search. 1.2.7 could spend another 10-20 seconds here even
        // after the first pass had enough evidence. The first-pass candidate pool is retained.
        const visualRefined=visualRefinedIdentity(identity,market);
        if(visualRefined){
          finalIdentity=visualRefined;
          console.log(`Visual identity refinement applied without re-search: ${identity.title} -> ${visualRefined.title}`);
        }

        const itemResult=marketToItem(finalIdentity,market,settings);
        console.log(`ORBIT timing: ${finalIdentity.title} | identify=${identifyMs}ms | identifyProvider=${finalIdentity.identity_provider||'unknown'} | userHints=${userHints?'yes':'no'} | lensRescue=${finalIdentity.lens_rescue_used===true?'yes':'no'} | lensCheck=${finalIdentity.lens_crosscheck_status||'none'} | providers=${market.providerMs??'n/a'}ms | classify=${market.classifyMs??'n/a'}ms | market=${marketMs}ms`);
        console.log(`ORBIT market: ${finalIdentity.title} | query=${market.query}${market.familyQuery?` | familyQuery=${market.familyQuery}`:''} | soldSource=${market.soldSource||'unknown'} | visualSold=${market.visualSoldInspected||0} | soldExact=${market.soldQ?.matchedN||0}${market.soldCountLowerBound?'+':''} | soldFamily=${market.familySoldQ?.matchedN||0} | visualActive=${market.visualActiveInspected||0} | activeExact=${market.activeQ?.matchedN||0} | activeFamily=${market.familyActiveQ?.matchedN||0} | velocityMode=${itemResult.velocityMode||'none'} | activeEstimate=${itemResult.activeListings||0}`);
        console.log(`ORBIT decision inputs: ${finalIdentity.title} | pricingAvailable=${itemResult.pricingAvailable} | pricingVerified=${itemResult.pricingVerified} | pricingMode=${itemResult.pricingMode} | pricingConfidence=${itemResult.pricingConfidenceLabel||'Low'} | pricingEvidence=${itemResult.pricingEvidenceMode||'none'} | soldPriceN=${itemResult.soldSample||0} | avg=${itemResult.averageSalePrice||0} | velocityVerified=${itemResult.velocityVerified} | str=${itemResult.sellThrough90??'null'} | cost=${itemResult.cost??'unknown'} | maxBuy=${itemResult.maxBuyPrice??'null'} | maxBuyBasis=${itemResult.riskAdjustedGrossValue??'null'} | maxBuyRisk=${itemResult.maxBuyRiskFactor??'null'} | typicalBuyerShip=${itemResult.typicalBuyerPaidShipping??'null'} | review=${(itemResult.reviewReasons||[]).join('; ')}`);
        return itemResult;
      }
      catch(err) {
        console.warn(`Market verification failed for ${identity.title}: ${err.message}`);
        return {
          title:identity.title,category:identity.category||identity.item_type||'Uncategorized',acquisitionMode:settings.acquisitionMode==='bins'?'bins':'normal',cost:(settings.manualPrice!==null&&settings.manualPrice!==undefined&&settings.manualPrice!==''&&Number.isFinite(Number(settings.manualPrice)))?Number(settings.manualPrice):(identity.price_tag??null),costKnown:(settings.manualPrice!==null&&settings.manualPrice!==undefined&&settings.manualPrice!==''&&Number.isFinite(Number(settings.manualPrice)))||identity.price_tag!=null,
          salePrice:0,averageSalePrice:0,medianSalePrice:0,maxBuyPrice:null,feesPct:Number(settings.defaultFeesPct??15),shipping:Number(identity.shipping_estimate||0),
          supplies:Number(identity.supplies_estimate||1),laborMin:Number(identity.labor_min||12),sold90:0,activeListings:0,sellThrough90:null,
          daysToSell:null,quantity:1,bulky:!!identity.bulky,fragile:!!identity.fragile,confidence:identity.identity_confidence*.15,
          identityConfidence:identity.identity_confidence,marketConfidence:0,activeMarketConfidence:0,decisionConfidence:0,soldDataAvailable:false,activeDataAvailable:false,pricingVerified:false,visualVerificationAvailable:false,reviewRequired:true,reviewReasons:[`market verification failed: ${err.message}`],analysisError:err.message,
          marketSource:'No verified visual comps',visibleText:identity.visible_text||[],alternativeIdentities:identity.alternative_identities||[],bbox:identity.bbox||null
        };
      }
    };
    const items=[];
    // Limit external search concurrency so rapid/group scanning does not create noisy provider failures.
    for (let i=0;i<identities.length;i+=2) items.push(...await Promise.all(identities.slice(i,i+2).map(analyzeOne)));
    const elapsedMs=Date.now()-started; console.log(`ORBIT analyze completed: ${identities.length} item(s) in ${elapsedMs}ms (${Math.round(elapsedMs/Math.max(1,identities.length))}ms/item)`);
    const payload={items,meta:{engineVersion:ENGINE_VERSION,elapsedMs,mode,model:GEMINI_MODEL,fastIdentifyModel:FAST_IDENTIFY_MODEL,compModel:COMP_MODEL,provider:'Trawl sold + SerpApi active + hierarchical exact/family validation',visionProvider:CLOUDFLARE_VISION_CONFIGURED?'Cloudflare Workers AI primary + Gemini fallback':'Gemini primary + Lens conflict fallback',soldProviderDegraded:Date.now()<soldProviderDegradedUntil,cacheHit:false,stableSnapshot:true}};
    analysisCacheSet(snapshotKey,payload);
    res.json(payload);
  } catch(err) {
    console.error(err); res.status(500).json({error:err.message||'Analysis failed'});
  }
});

app.use((err,_req,res,_next)=>{
  console.error(err);
  if (err?.code==='LIMIT_FILE_SIZE') return res.status(413).json({error:'Image is too large (14 MB max)'});
  res.status(500).json({error:err.message||'Server error'});
});

if (require.main === module) {
  app.listen(PORT,HOST,()=>{
    console.log(`\nProfitQueue AI ${ENGINE_VERSION} listening on ${HOST}:${PORT}`);
    console.log(`Vision model: ${GEMINI_MODEL}`);
    console.log(`Fast identify model: ${FAST_IDENTIFY_MODEL}`);
    console.log(`Comp classifier: ${COMP_MODEL}`);
    console.log(`Vision fallbacks: ${VISION_FALLBACK_MODELS.join(', ')}`);
    console.log(`Comp fallbacks: ${COMP_FALLBACK_MODELS.join(', ')}`);
    console.log(`Market sampling: up to ${MARKET_SAMPLE_PAGES} page(s) x ${MARKET_QUERY_ATTEMPTS} query formulation(s)`);
    console.log(`Visual comp verification: up to ${VISUAL_COMP_MAX_SOLD} sold + ${VISUAL_COMP_MAX_ACTIVE} active listing photos`);
    console.log(`Cloudflare vision configured: ${CLOUDFLARE_VISION_CONFIGURED}${CLOUDFLARE_VISION_CONFIGURED?` (${CLOUDFLARE_VISION_MODEL})`:''}`);
    console.log(`Gemini configured: ${Boolean(GEMINI_API_KEY)}`);
    console.log(`SerpApi configured: ${Boolean(SERPAPI_KEY)}`);
    console.log(`Trawl configured: ${Boolean(TRAWL_API_KEY)}`);
    console.log(`Access protection: ${Boolean(APP_ACCESS_CODE)}\n`);
  });
}

module.exports={app,mean,median,trimmedMean,robustPrices,parseMoney,parseDate,daysAgo,wilson,titleMatchScore,conditionCompatible,dedupeRows,searchQuality,marketToItem,itemQueryCandidates,cleanText,reconcileIdentityWithLens,lensLeadBrandConsensus,lensModelFromTitle,cloudflareResultText};
