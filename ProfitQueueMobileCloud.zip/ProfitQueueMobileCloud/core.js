'use strict';

const STOP = new Set(`a an and are as at be by for from in is it of on or the to with without used new vintage rare lot bundle size color mens men's womens women's unisex genuine authentic original preowned pre-owned condition ebay mercari poshmark etsy amazon walmart target listing sale sold`.split(/\s+/));
const GENERIC = new Set(`item items product products accessory accessories collectible collectibles clothing apparel gear equipment misc unknown`.split(/\s+/));

function clamp(n, min, max) { return Math.max(min, Math.min(max, n)); }
function money(n) { return Math.round((Number(n) || 0) * 100) / 100; }
function median(values) {
  const a = values.filter(Number.isFinite).slice().sort((x,y)=>x-y);
  if (!a.length) return null;
  const m = Math.floor(a.length/2);
  return a.length % 2 ? a[m] : (a[m-1] + a[m]) / 2;
}
function quantile(values, q) {
  const a = values.filter(Number.isFinite).slice().sort((x,y)=>x-y);
  if (!a.length) return null;
  const p = (a.length - 1) * q, lo = Math.floor(p), hi = Math.ceil(p);
  if (lo === hi) return a[lo];
  return a[lo] + (a[hi] - a[lo]) * (p - lo);
}
function robustPrices(values) {
  const a = values.filter(v => Number.isFinite(v) && v > 0 && v < 100000);
  if (a.length < 4) return a;
  const q1 = quantile(a, .25), q3 = quantile(a, .75), iqr = Math.max(1, q3-q1);
  const lo = Math.max(0.5, q1 - 1.75*iqr), hi = q3 + 1.75*iqr;
  const filtered = a.filter(v => v >= lo && v <= hi);
  return filtered.length >= Math.max(3, Math.floor(a.length * .55)) ? filtered : a;
}
function tokenize(s='') {
  // Normalize marketplace spelling variants before tokenization (e.g. L.L.Bean vs LL Bean).
  return String(s).toLowerCase()
    .replace(/\bl[\s.\-]*l[\s.\-]*bean\b/gi,'ll bean')
    .replace(/[’']/g,'').replace(/[^a-z0-9]+/g,' ').trim().split(/\s+/).filter(Boolean);
}
function usefulTokens(s='') {
  return tokenize(s).filter(t => !STOP.has(t) && !GENERIC.has(t) && (t.length > 1 || /\d/.test(t)));
}
function distinctiveTokens(s='') {
  return usefulTokens(s).filter(t => t.length >= 3 || /\d/.test(t));
}
function tokenSimilarity(a,b) {
  const A = new Set(usefulTokens(a)), B = new Set(usefulTokens(b));
  if (!A.size || !B.size) return 0;
  let inter=0; for (const t of A) if (B.has(t)) inter++;
  return inter / Math.max(1, Math.min(A.size, B.size));
}
function titleMatches(query,title,{min=0.42}={}) {
  const q = distinctiveTokens(query), t = new Set(usefulTokens(title));
  if (!q.length) return false;
  const hits = q.filter(x => t.has(x)).length;
  const ratio = hits / q.length;
  const modelTokens = q.filter(x => /\d/.test(x) && /[a-z]/i.test(x));
  const modelOkay = !modelTokens.length || modelTokens.some(x => t.has(x));
  return modelOkay && (ratio >= min || hits >= Math.min(3,q.length));
}


// Variant-aware comp validation. Search can stay broad enough to find candidates,
// but exact market pools must not mix materially different models/variants.
const FOOTWEAR_HEADS = new Set('shoe shoes sneaker sneakers boot boots sandal sandals loafer loafers clog clogs heel heels'.split(/\s+/));
function phraseInTokens(words, tokens){
  if(!words.length||tokens.length<words.length)return false;
  outer: for(let i=0;i<=tokens.length-words.length;i++){
    for(let j=0;j<words.length;j++) if(tokens[i+j]!==words[j]) continue outer;
    return true;
  }
  return false;
}
function compMatch(query,title){
  const q=queryTokens(query), t=tokenize(title);
  const tset=new Set(t), qset=new Set(q);
  if(!q.length||!t.length)return {accept:false,class:'reject',score:0,reason:'empty'};
  const brand=queryBrandPrefix(q);
  const brandHits=brand.filter(x=>tset.has(x)).length;
  if(brand.length && brandHits<brand.length) return {accept:false,class:'reject',score:0,reason:'brand-mismatch'};

  const category=canonicalCategory(q);
  const catParts=category.split(/\s+/).filter(Boolean);
  const categoryHit=!catParts.length || catParts.some(x=>tset.has(x));
  const footwear=q.some(x=>FOOTWEAR_HEADS.has(x)) || catParts.some(x=>FOOTWEAR_HEADS.has(x));
  const yearRx=/^(?:19\d\d|20\d\d)$/;
  const hardIds=q.filter(x=>!yearRx.test(x) && ((/[a-z]/.test(x)&&/\d/.test(x)) || /^\d{3,8}$/.test(x)));
  const hardHits=hardIds.filter(x=>tset.has(x));

  const shortPairs=[];
  for(let i=1;i<q.length;i++){
    if(!/^\d{1,2}$/.test(q[i]))continue;
    const prev=q[i-1];
    if(!prev || brand.includes(prev) || FOOTWEAR_HEADS.has(prev) || QUERY_CATEGORY.has(prev))continue;
    shortPairs.push([prev,q[i]]);
  }
  const shortPairHits=shortPairs.filter(pair=>phraseInTokens(pair,t));

  const descriptor=q.filter(x=>
    !brand.includes(x) && !catParts.includes(x) && !QUERY_CATEGORY.has(x) &&
    !hardIds.includes(x) && !/^\d+$/.test(x) && !yearRx.test(x) && x.length>=3
  );
  const descriptorHits=descriptor.filter(x=>tset.has(x));
  const overlap=distinctiveTokens(query).filter(x=>tset.has(x)).length/Math.max(1,distinctiveTokens(query).length);

  if(footwear){
    // A model/SKU is the strongest identity key for shoes. Same brand but a different
    // SKU/model is a close candidate at best and must not contaminate exact STR/pricing.
    if(hardIds.length && hardHits.length===0){
      const close=categoryHit && descriptorHits.length>0;
      return {accept:false,class:close?'close':'reject',score:close?.58:.15,reason:'model-id-mismatch',matchedIds:[]};
    }
    // Named generation pairs such as Clifton 8 must remain intact. A Clifton 9 is not
    // an exact Clifton 8 comp even though most title words overlap.
    if(shortPairs.length && shortPairHits.length===0){
      const lineHit=shortPairs.some(([line])=>tset.has(line));
      return {accept:false,class:lineHit?'close':'reject',score:lineHit?.62:.2,reason:'generation-mismatch',matchedIds:hardHits};
    }
    const strongIdentity=(hardIds.length?hardHits.length>0:false) || shortPairHits.length>0 || descriptorHits.length>=Math.min(2,descriptor.length||2);
    const score=Math.min(1,.30 + .22*(brand.length?brandHits/brand.length:1) + .20*(categoryHit?1:0) + .18*(hardIds.length?hardHits.length/hardIds.length:0) + .10*Math.min(1,descriptorHits.length/Math.max(1,descriptor.length)) + .10*overlap);
    if(!categoryHit || !strongIdentity) return {accept:false,class:'close',score,reason:!categoryHit?'product-type-mismatch':'weak-variant-match',matchedIds:hardHits};
    return {accept:true,class:'exact',score,reason:'variant-validated',matchedIds:hardHits};
  }

  const accept=titleMatches(query,title,{min:.42});
  return {accept,class:accept?'exact':'reject',score:overlap,reason:accept?'token-match':'insufficient-overlap',matchedIds:hardHits};
}

function cleanCandidateTitle(s='') {
  return String(s)
    .replace(/\s+[|–—-]\s+(eBay|Mercari|Poshmark|Etsy|Amazon|Walmart).*$/i,'')
    .replace(/\b(Buy|Shop|For Sale|Free Shipping|Fast Shipping|New Listing)\b.*$/i,'')
    .replace(/\s+/g,' ').trim().slice(0,140);
}
function inferIdentity(matches=[], keywords='') {
  const rows = matches.filter(x=>x && x.title).slice(0,20);
  if (!rows.length) {
    const k = cleanCandidateTitle(keywords);
    return { title:k || 'Unidentified item', confidence:k ? .58 : .15, evidence:[], familyQuery:k || '' };
  }
  const freq = new Map();
  for (const r of rows) for (const t of new Set(usefulTokens(r.title))) freq.set(t,(freq.get(t)||0)+1);
  const trusted = /ebay|mercari|poshmark|etsy|grailed|depop|walmart|amazon|target|shop|store/i;
  let best = null;
  for (const r of rows) {
    const title = cleanCandidateTitle(r.title);
    const toks = usefulTokens(title);
    let score = 0;
    for (const t of toks) score += Math.min(4,freq.get(t)||0);
    score += trusted.test(`${r.source||''} ${r.link||''}`) ? 6 : 0;
    if (r.price) score += 2;
    if (keywords) score += tokenSimilarity(keywords,title)*8;
    score -= Math.max(0,toks.length-12)*.25;
    if (!best || score > best.score) best = {title,score,row:r};
  }
  const common = [...freq.entries()].filter(([,n])=>n>=2).sort((a,b)=>b[1]-a[1]).map(([t])=>t);
  let family = usefulTokens(best.title).filter(t => common.includes(t) || /\d/.test(t)).slice(0,7);
  if (family.length < 3) family = usefulTokens(best.title).slice(0,6);
  if (keywords) family = [...new Set([...usefulTokens(keywords),...family])].slice(0,7);
  const agreement = rows.filter(r=>tokenSimilarity(best.title,r.title)>=.45).length / rows.length;
  return {
    title: best.title,
    confidence: clamp(.45 + agreement*.45 + (keywords ? .07 : 0), .2, .96),
    evidence: rows.slice(0,8).map(r=>({title:cleanCandidateTitle(r.title),source:r.source||'',link:r.link||'',thumbnail:r.thumbnail||r.image||''})),
    familyQuery: family.join(' ')
  };
}


// Query engine: separate product identity from marketplace-title noise.
const QUERY_NOISE = new Set(`
  a an and are as at be by for from in is it of on or the to without
  sale sold listing ebay mercari poshmark etsy amazon walmart target shop store
  buy fast free shipping ship ships choose selection assorted assorted
  new used preowned pre owned sealed open box nwt nwot nib bnwt vintage vtg rare
  authentic genuine original real oem knock off knockoff not replica compatible replacement
  look looks wow nice great excellent mint clean tested works working made chunky
  mens men's man men womens women's woman women unisex size sz
  black white blue red green brown grey gray dark light navy indigo teal aqua aquarelle
  chocolate desert tan beige cream pink purple orange yellow silver gold
  wide long side pair lot bundle
`.split(/\s+/).filter(Boolean));

const QUERY_CATEGORY = new Set(`
  shoe shoes sneaker sneakers boot boots sandal sandals heel heels
  jean jeans denim pants pant shorts short shirt shirts tee tshirt sweater hoodie jacket coat
  hat cap beanie bag purse backpack
  headphones headphone headset earbuds wireless neckband noise cancelling canceling
  valve cartridge faucet handle single replacement
  water gun toy figure doll game playset castle stable camera lens phone smartphone bow bows recurve fragrance perfume cologne edp edt parfum
  ornament ornaments decoration decorations figurine figurines statue statues sculpture sculptures plaque plaques
  mug mugs cup cups glass glasses plate plates bowl bowls vase vases planter planters
  plush stuffed pillow pillows blanket blankets towel towels robe robes
  clock clocks lamp lamps light lights sign signs frame frames print prints poster posters
  book books dvd dvds cd cds record records vinyl cassette cassettes
  beach cover blanket towel robe
  running hiking leather lace western cowgirl embroidered utility work washed stretch
`.split(/\s+/).filter(Boolean));

function stripQueryNoise(text='') {
  let source=String(text);
  // Preserve spaced device model IDs that otherwise look like a year (e.g. Sony CFM 2000).
  source=source.replace(/\b(cfm)\s*[- ]?\s*(\d{3,4})\b/ig, '$1$2');
  source=source.replace(/\bx[\s-]+men\b/ig,'xmen');
  if(/\b(?:bow|recurve)\b/i.test(source)) source=source.replace(/#\s*\d{1,3}\b/g,' ');
  return source
    // Storage/capacity variants are part of electronics identity, unlike clothing measurements.
    .replace(/\b(\d{2,4})\s*(gb|tb)\b/ig, '$1$2')
    // Physical measurements, volume and resolution are attributes, not model IDs.
    .replace(/\b\d+(?:\.\d+)?\s*(?:fl\s*oz|fluid\s*ounces?|oz|ml|milliliters?|liters?|litres?|mp|megapixels?)\b/ig,' ')
    .replace(/\b\d+(?:\.\d+)?\s*["”″']\s*[x×]\s*\d+(?:\.\d+)?\s*["”″']?/ig,' ') 
    // Remove seller-language phrases before tokenization so words such as "not" can never become descriptors.
    .replace(/\bnot\s+(?:a\s+)?(?:knock\s*[- ]?off|replica|fake)\b/ig,' ')
    .replace(/\b(?:100\s*%\s*)?(?:authentic|genuine|real|original)\b/ig,' ')
    .replace(/\b(?:free|fast)\s+shipping\b/ig,' ')
    .replace(/\b(?:new|just)\s+listed\b/ig,' ')
    // Material composition is not a product identifier (e.g. "100% cotton").
    .replace(/\b\d{1,3}\s*%\s*(?:cotton|polyester|wool|silk|linen|nylon|rayon|acrylic|spandex|elastane|leather)?\b/ig,' ')
    .replace(/\b100\s+(?:percent\s+)?(?:cotton|polyester|wool|silk|linen|nylon|rayon|acrylic|spandex|elastane|leather)\b/ig,' ')
    .replace(/\$\s*\d+(?:[.,]\d+)?/g,' ')
    .replace(/\b(?:msrp|retail|value|price)\s*[:$]?\s*\d+(?:[.,]\d+)?\b/ig,' ')
    // Measurements and apparel sizing must never become model/style numbers.
    .replace(/\b\d{1,3}\s*[-–—]\s*\d{1,3}(?:\s+\d+\/\d+)?\b/g,' ')
    .replace(/\b\d{1,3}\s+\d+\/\d+\b/g,' ')
    .replace(/\b\d+\/\d+\b/g,' ')
    .replace(/\b\d{1,3}\s*[x×]\s*\d{1,3}(?:\s*[x×]\s*\d{1,3})?\b/ig,' ')
    .replace(/\b\d+(?:\.\d+)?\s*(?:inches?|inch|in|cm|mm|ft|feet|foot)\b/ig,' ')
    .replace(/\b\d+(?:\.\d+)?\s*[\"”″']+/g,' ')
    .replace(/\b(?:size|sz|mens?|womens?|men's|women's|waist|inseam|chest|neck|sleeve)\s*[:#-]?\s*\d+(?:\.\d+)?(?:\s+\d+\/\d+)?\b/ig,' ')
    .replace(/\b\d{1,2}\.\d+\b/g,' ')
    .replace(/\b(?:nwt|nwot|nib|bnwt|pre[- ]?owned|open box)\b/ig,' ')
    .replace(/\s+/g,' ').trim();
}

function queryTokens(text='') {
  return tokenize(stripQueryNoise(text)).filter(t => !QUERY_NOISE.has(t));
}

function queryBrandPrefix(tokens=[]) {
  const t=tokens.filter(x=>!/^(?:19\d\d|20\d\d)$/.test(x));
  const twoWordBrands=new Set(['toy biz','dr martens','old west','emporio armani','lisa frank','fred bear','harvey lewis','nick nora','marc jacobs','harley davidson','brooks brothers','ll bean','ray ban','thursday boot','fisher price']);
  if(t[0]&&t[1]&&twoWordBrands.has(`${t[0]} ${t[1]}`)) return [t[0],t[1]];
  if(t[0]==='dr'&&t[1]==='martens') return ['dr','martens'];
  if(t[0]==='old'&&t[1]==='west') return ['old','west'];
  if(t[0]==='hoka'&&t[1]==='one') return ['hoka'];
  if(t[0]==='levis'||t[0]==='levi') return ['levis'];
  return t[0]?[t[0]]:[];
}

function canonicalCategory(tokens=[]) {
  const has=(...xs)=>xs.every(x=>tokens.includes(x));
  // Prefer specific compound product types first. These describe WHAT the item is,
  // and therefore belong in STR queries even when a title also contains a franchise,
  // character, collection, material, holiday, color, or other descriptive words.
  const compounds=[
    [['valve','cartridge'],'valve cartridge'],
    [['water','gun'],'water gun'],
    [['bat','bag'],'bat bag'],
    [['running','shoes'],'running shoes'],[['running','shoe'],'running shoes'],
    [['cowgirl','boots'],'cowgirl boots'],[['cowgirl','boot'],'cowgirl boots'],
    [['western','boots'],'western boots'],[['western','boot'],'western boots'],
    [['beach','cover'],'beach cover'],
    [['sleep','pants'],'sleep pants'],
    [['bean','bag','plush'],'plush'],
    [['recurve','bow'],'recurve bow'],
    [['digital','camera'],'digital camera'],
  ];
  for(const [parts,label] of compounds) if(has(...parts)) return label;

  // Product-head nouns. This is deliberately object-focused: a word such as
  // "Christmas" can describe an ornament, mug, sweater, DVD, etc.; the object noun
  // is much more important for matching sold and active pools to the same item type.
  const heads=[
    ['ornaments','ornament'],['ornament','ornament'],
    ['sculptures','sculpture'],['sculpture','sculpture'],
    ['figurines','figurine'],['figurine','figurine'],['statues','statue'],['statue','statue'],
    ['decorations','decoration'],['decoration','decoration'],['plaques','plaque'],['plaque','plaque'],
    ['headphones','headphones'],['headphone','headphones'],['headsets','headset'],['headset','headset'],
    ['earbuds','earbuds'],['boots','boots'],['boot','boots'],['jeans','jeans'],['jean','jeans'],
    ['shorts','shorts'],['short','shorts'],['shoes','shoes'],['shoe','shoes'],
    ['sandals','sandals'],['sandal','sandals'],['shirts','shirt'],['shirt','shirt'],
    ['sweaters','sweater'],['sweater','sweater'],['hoodies','hoodie'],['hoodie','hoodie'],
    ['jackets','jacket'],['jacket','jacket'],['coats','coat'],['coat','coat'],
    ['hats','hat'],['hat','hat'],['caps','cap'],['cap','cap'],['beanies','beanie'],['beanie','beanie'],
    ['plush','plush'],['bows','bow'],['bow','bow'],['fragrances','fragrance'],['fragrance','fragrance'],['perfumes','fragrance'],['perfume','fragrance'],['colognes','fragrance'],['cologne','fragrance'],
    ['bags','bag'],['bag','bag'],['purses','purse'],['purse','purse'],['backpacks','backpack'],['backpack','backpack'],
    ['chairs','chair'],['chair','chair'],['rockers','chair'],['rocker','chair'],['stools','stool'],['stool','stool'],['tables','table'],['table','table'],
    ['mugs','mug'],['mug','mug'],['cups','cup'],['cup','cup'],['glasses','glass'],['glass','glass'],
    ['plates','plate'],['plate','plate'],['bowls','bowl'],['bowl','bowl'],['vases','vase'],['vase','vase'],
    ['planters','planter'],['planter','planter'],['pillows','pillow'],['pillow','pillow'],
    ['blankets','blanket'],['blanket','blanket'],['towels','towel'],['towel','towel'],['robes','robe'],['robe','robe'],
    ['clocks','clock'],['clock','clock'],['lamps','lamp'],['lamp','lamp'],['signs','sign'],['sign','sign'],
    ['frames','frame'],['frame','frame'],['prints','print'],['print','print'],['posters','poster'],['poster','poster'],
    ['books','book'],['book','book'],['dvds','dvd'],['dvd','dvd'],['records','record'],['record','record'],
    ['vinyl','vinyl'],['cassettes','cassette'],['cassette','cassette'],['cameras','camera'],['camera','camera'],
    ['lenses','lens'],['lens','lens'],['figures','figure'],['figure','figure'],['dolls','doll'],['doll','doll'],
    ['playsets','playset'],['playset','playset'],['castles','castle'],['castle','castle'],['stables','stable'],['stable','stable'],
    ['games','game'],['game','game'],['phones','phone'],['phone','phone'],['smartphones','phone'],['smartphone','phone'],['cartridge','cartridge'],['toys','toy'],['toy','toy']
  ];
  for(const [token,label] of heads) if(tokens.includes(token)) return label;
  return '';
}

function evidenceTokenFrequency(evidence=[]) {
  const freq=new Map();
  for(const row of evidence||[]) {
    const title=typeof row==='string'?row:(row&&row.title)||'';
    const toks=new Set(queryTokens(title));
    for(const t of toks) freq.set(t,(freq.get(t)||0)+1);
  }
  return freq;
}



// Some marketplace identities are phrases rather than independent tokens: "Brain Warp",
// "Red Man Tobacco", "iPhone 12 Pro Max", "Harvey Lewis", etc.  Scoring tokens
// independently can drop one half of the identity and badly widen the active pool.
const GENERIC_FEATURE_WORDS = new Set(`
  art hand carved signed graphic logo patch adjustable poseable talking handheld memory
  limited edition anniversary mashup shimmery tone canvas burlap crystal crystals
  from with works working welcome holiday christmas
`.split(/\s+/).filter(Boolean));

const PHRASE_HARD_NOISE = new Set(`
  a an and are as at be by for from in is it of on or the to without
  sale sold listing ebay mercari poshmark etsy amazon walmart target shop store buy
  new used preowned sealed nwt nwot nib bnwt vintage vtg rare authentic genuine original real oem
  size sz free fast shipping choose works working
`.split(/\s+/).filter(Boolean));

function identityPhraseTokens(text='') {
  return tokenize(stripQueryNoise(text)).filter(t=>!PHRASE_HARD_NOISE.has(t));
}

function evidencePhraseFrequency(evidence=[]) {
  const freq=new Map();
  for(const row of evidence||[]) {
    const title=typeof row==='string'?row:(row&&row.title)||'';
    const toks=identityPhraseTokens(title);
    for(let n=2;n<=4;n++) for(let i=0;i+n<=toks.length;i++) {
      const phrase=toks.slice(i,i+n).join(' ');
      freq.set(phrase,(freq.get(phrase)||0)+1);
    }
  }
  return freq;
}

function phraseAnchors(tokens=[],brand=[],evidence=[],category='',rawTokens=[]) {
  const out=[];
  const pf=evidencePhraseFrequency(evidence);
  const brandLen=brand.length;
  const categorySet=new Set(String(category||'').split(/\s+/).filter(Boolean));
  const yearRx=/^(?:19\d\d|20\d\d)$/;
  const add=(words,score,reason)=>{
    const clean=words.filter(Boolean);
    if(clean.length<2)return;
    const phrase=clean.join(' ');
    if(out.some(x=>x.phrase===phrase))return;
    out.push({phrase,words:clean,score,reason,rawStart:rawTokens.join(' ').indexOf(phrase)>=0?rawTokens.findIndex((_,i)=>rawTokens.slice(i,i+clean.length).join(' ')===phrase):-1});
  };

  // Electronics model families are especially order-sensitive. Preserve the whole
  // model chain and capacity when present (e.g. apple iphone 12 pro max 256gb).
  const iphone=tokens.indexOf('iphone');
  if(iphone>=0){
    const w=[];
    if(tokens[iphone])w.push(tokens[iphone]);
    for(let j=iphone+1;j<tokens.length && w.length<5;j++){
      const t=tokens[j];
      if(categorySet.has(t)||yearRx.test(t))continue;
      if(/^(?:pro|max|mini|plus|se|ultra|\d{1,2}|\d{2,4}(?:gb|tb))$/.test(t))w.push(t);
      else if(w.length>=2)break;
    }
    add(w,40,'device-model-chain');
  }

  // Rescue ambiguous words that generic filters normally remove when marketplace evidence
  // repeatedly shows they are actually part of a name (e.g. Red Man Tobacco).
  for(let n=4;n>=2;n--){
    for(let i=0;i+n<=rawTokens.length;i++){
      const words=rawTokens.slice(i,i+n);
      const phrase=words.join(' '), count=pf.get(phrase)||0;
      if(count<2)continue;
      if(words.filter(t=>categorySet.has(t)||QUERY_CATEGORY.has(t)).length>1)continue;
      if(words.filter(t=>GENERIC_FEATURE_WORDS.has(t)).length>Math.floor(words.length/2))continue;
      add(words,count*12 + (i<=1?6:0),'marketplace-consensus');
    }
  }

  // Candidate identity phrases. Evidence consensus is the strongest signal; title
  // position and proximity to the product noun are secondary signals.
  for(let n=2;n<=4;n++){
    for(let i=0;i+n<=tokens.length;i++){
      const words=tokens.slice(i,i+n);
      if(words.some(t=>yearRx.test(t)))continue;
      if(words.every(t=>categorySet.has(t)||QUERY_CATEGORY.has(t)))continue;
      if(words.filter(t=>/^\d+$/.test(t)).length>1)continue;
      const phrase=words.join(' ');
      let score=(pf.get(phrase)||0)*10;
      if(i===brandLen)score+=7;
      if(i===0)score+=5;
      if(words.some(t=>/[a-z]/.test(t)&&/\d/.test(t)))score+=7;
      if(words.some(t=>/^\d{1,2}$/.test(t)))score+=4;
      if(words.some(t=>/^\d{2,4}(?:gb|tb)$/.test(t)))score+=6;
      // A phrase made mostly of generic feature words should not outrank a product name.
      score-=words.filter(t=>GENERIC_FEATURE_WORDS.has(t)).length*4;
      score-=words.filter(t=>categorySet.has(t)||QUERY_CATEGORY.has(t)).length*2;
      if((pf.get(phrase)||0)>=2) add(words,score,'marketplace-consensus');
      else if(score>=18) add(words,score,'title-structure');
    }
  }

  // A proper product phrase immediately before the object noun is often the most
  // discriminating description for art/decor/collectibles.
  let catIndex=-1;
  for(let i=0;i<tokens.length;i++) if(categorySet.has(tokens[i])){catIndex=i;break;}
  if(catIndex>1){
    const prior=tokens.slice(Math.max(brandLen,catIndex-4),catIndex)
      .filter(t=>!GENERIC_FEATURE_WORDS.has(t)&&!/^\d+$/.test(t));
    if(prior.length>=2)add(prior.slice(-3),6,'object-proximity');
  }

  out.sort((a,b)=>b.score-a.score||b.words.length-a.words.length);
  return out;
}



// Preserve marketplace identity phrases that lose meaning when their words are ranked independently.
const PROTECTED_IDENTITY_PHRASES = [
  ['ll','bean'],['ray','ban'],['mid','century'],['parties','mate'],['walk','off','elite'],
  ['stronger','with','you'],['kodiak','magnum'],['beaver','state'],['fisher','price'],['little','people'],['klip','klop'],['power','shot'],['cyber','shot'],
  ['toy','biz'],['my','first','sony'],['marvel','x','men'],['die','cast']
];
function protectedIdentityPhrases(tokens=[]) {
  const joined=` ${tokens.join(' ')} `;
  const hits=[];
  for(const words of PROTECTED_IDENTITY_PHRASES){
    if(joined.includes(` ${words.join(' ')} `)) hits.push(words);
  }
  return hits;
}

const APPAREL_TERMS = new Set(`shirt shirts tee tshirt sweater hoodie jacket coat jeans jean denim pants pant shorts short dress skirt blouse jersey jerseys pajamas pyjamas sleepwear robe robes hat cap beanie shoe shoes sneaker sneakers boot boots sandal sandals`.split(/\s+/));
const APPAREL_SIZE_WORDS = new Set(`xxs xs small medium large xl xxl xxxl 2xl 3xl 4xl 5xl petite tall regular big husky`.split(/\s+/));

const LOW_INFO_DESCRIPTOR = new Set(`woolen mills fantastic world glass powered solid aluminum portable set kit non stick logo athletic pro line rare edition limited bag bean art hand signed carved digital leather lace up cap toe`.split(/\s+/).filter(Boolean));
const CRITICAL_VARIANT = new Set(`edp edt parfum perfume intensely elixir extreme sport pro max mini plus ultra se repair parts broken asis prototype limited`.split(/\s+/).filter(Boolean));
function criticalVariantTokens(text=''){
  const toks=tokenize(stripQueryNoise(text));
  const out=[];
  for(let i=0;i<toks.length;i++){
    const t=toks[i];
    if(CRITICAL_VARIANT.has(t) && !out.includes(t)) out.push(t);
  }
  if(/for\s+parts|parts\s*\/?\s*repair|parts\s+or\s+repair|as[- ]?is|broken/i.test(text)){
    for(const t of ['parts','repair']) if(!out.includes(t))out.push(t);
  }
  return out;
}


const TYPE_QUALIFIERS = new Set(`
  messenger shoulder crossbody tote satchel duffel bat baseball softball camera laptop travel
  oxford loafer mule clog trail hiking running walking wrestling golf soccer basketball skate
  rocking rocker lounge dining office accent bentwood cane thonet
  bean kitten bunny bear character christmas holiday
`.split(/\s+/).filter(Boolean));

function categorySchema(category='',tokens=[]){
  const c=String(category||'');
  const set=new Set(tokens||[]);
  if(/shoe|boot|sandal|heel/.test(c))return 'footwear';
  if(/fragrance/.test(c)||set.has('edp')||set.has('edt')||set.has('parfum'))return 'fragrance';
  if(/camera|lens|phone|headphone|headset|earbuds|game|cassette/.test(c))return 'electronics';
  if(/bag|purse|backpack/.test(c))return 'bags';
  if(/shirt|sweater|hoodie|jacket|coat|jeans|shorts|pants|robe|hat|cap|beanie/.test(c))return 'apparel';
  if(/plush|figure|doll|ornament|figurine|statue|sculpture|toy|playset|castle|stable/.test(c))return 'collectible';
  if(/chair|stool|table|lamp|clock|vase|planter|blanket|pillow|frame|print|poster|sign/.test(c))return 'home';
  if(/bow/.test(c))return 'sporting';
  return 'generic';
}


const MODEL_PREFIX_NOISE = new Set(`size sz mens womens men women inch inches mm cm oz ml gb tb mp lcd lens item model vintage vtg circa year rh lh right left`.split(/\s+/));
function spacedModelGroups(tokens=[],brand=[]){
  const brandSet=new Set(brand||[]);
  const groups=[];
  for(let i=0;i<tokens.length-1;i++){
    const a=tokens[i], b=tokens[i+1];
    if(!/^[a-z]{2,5}$/.test(a) || !/^\d{2,5}$/.test(b))continue;
    if(brandSet.has(a)||QUERY_CATEGORY.has(a)||QUERY_NOISE.has(a)||MODEL_PREFIX_NOISE.has(a))continue;
    if(!groups.some(g=>g[0]===a&&g[1]===b))groups.push([a,b]);
  }
  return groups.slice(0,3);
}
function phraseIndex(tokens=[],words=[]){
  if(!words.length)return -1;
  outer: for(let i=0;i<=tokens.length-words.length;i++){
    for(let j=0;j<words.length;j++)if(tokens[i+j]!==words[j])continue outer;
    return i;
  }
  return -1;
}
const COLLECTIBLE_SUBJECT_NOISE=new Set(`action mini miniature die cast metal plastic vinyl poseable figure figurine doll toy toys playset set castle stable works working parts repair broken only`.split(/\s+/));
function collectibleSubjectTokens(tokens=[],brand=[],productLine=[],category=''){
  let start=0;
  const li=phraseIndex(tokens,productLine||[]);
  if(li>=0)start=li+(productLine||[]).length;
  else{
    const bi=phraseIndex(tokens,brand||[]);
    if(bi>=0)start=bi+(brand||[]).length;
  }
  const catSet=new Set(String(category||'').split(/\s+/).filter(Boolean));
  const out=[];
  for(let i=start;i<tokens.length&&out.length<2;i++){
    const t=tokens[i];
    if(catSet.has(t)||QUERY_CATEGORY.has(t))break;
    if(/^(?:19\d\d|20\d\d)$/.test(t)||/^\d+$/.test(t)||COLLECTIBLE_SUBJECT_NOISE.has(t)||CRITICAL_VARIANT.has(t))continue;
    if(TYPE_QUALIFIERS.has(t)||LOW_INFO_DESCRIPTOR.has(t))continue;
    if(t.length>=3)out.push(t);
  }
  return out;
}
function materialIdentityTokens(tokens=[]){
  const out=[];
  if(phraseInTokens(['die','cast'],tokens)){out.push('die','cast');}
  for(const t of ['metal','wood','wooden','ceramic','porcelain','glass','resin','plush','vinyl','leather']){
    if(tokens.includes(t)&&!out.includes(t))out.push(t);
  }
  return out.slice(0,4);
}
function titleModelChain(tokens=[],hardIds=[]){
  const out=[];
  for(let i=0;i<tokens.length;i++){
    const t=tokens[i];
    if(!hardIds.includes(t))continue;
    const prev=tokens[i-1]||'';
    if(/^[a-z]{2,5}$/.test(prev) && !QUERY_NOISE.has(prev) && !QUERY_CATEGORY.has(prev) && !GENERIC_FEATURE_WORDS.has(prev)){
      if(!out.includes(prev))out.push(prev);
    }
    if(!out.includes(t))out.push(t);
  }
  return out.slice(0,4);
}


// ORBIT 1.6: constraint-based identity graph. This is intentionally data-driven:
// title/evidence spans become roles first, and queries are synthesized from roles later.
const IDENTITY_ATTRIBUTE_NOISE = new Set(`
  black white blue red green brown grey gray dark light navy indigo teal aqua pink purple orange yellow silver gold
  small medium large xl xxl xxxl mens womens men women unisex size sz
  vintage vtg rare tested works working new used sealed nwt nwot authentic genuine original real oem
  chunky lace embroidered adjustable zip pockets graphic print comfort casual plaid camouflage girl girls boy boys
  die cast metal plastic action miniature mini rh lh right left
`.split(/\s+/).filter(Boolean));
const IDENTITY_CONDITION_TERMS = new Set(`parts repair broken asis damaged nonworking non working for-parts`.split(/\s+/));
const BRAND_EXTENSION_NOISE = new Set(`my first the a an for with edition series model style item product vintage vtg`.split(/\s+/));

function phraseSupport(words=[], evidence=[]){
  if(!words.length)return 0;
  let n=0, rows=0;
  for(const row of evidence||[]){
    const title=typeof row==='string'?row:(row&&row.title)||'';
    if(!title)continue; rows++;
    const toks=identityPhraseTokens(title);
    if(phraseInTokens(words,toks))n++;
  }
  return {count:n,rows,ratio:rows?n/rows:0};
}
function dynamicBrandTokens(rawTokens=[], evidence=[], fallback=[]){
  const known=(fallback||[]).slice();
  if(known.length>1)return known;
  const start=rawTokens.findIndex(t=>!(/^(?:19\d\d|20\d\d)$/.test(t)));
  if(start<0)return known;
  const one=[rawTokens[start]], two=rawTokens.slice(start,start+2);
  if(two.length===2 && !BRAND_EXTENSION_NOISE.has(two[1]) && !QUERY_CATEGORY.has(two[1]) && !IDENTITY_ATTRIBUTE_NOISE.has(two[1])){
    const ps=phraseSupport(two,evidence);
    const next=rawTokens[start+2]?[two[1],rawTokens[start+2]]:[];
    const nextSupport=next.length?phraseSupport(next,evidence):{ratio:0,count:0};
    // Promote an unknown two-word manufacturer only when the prefix is distinctly
    // more stable than the following phrase. This avoids swallowing the first word
    // of a product line (Orbitron Moon Runner) while still learning North Star.
    if(ps.count>=2 && ps.ratio>=.50 && ps.ratio-nextSupport.ratio>=.20)return two;
  }
  return known.length?known:one;
}
function modelRoleGroups(text='', tokens=[], brand=[], evidence=[], schema='generic'){
  const groups=[]; const seen=new Set();
  const add=(arr,score,reason)=>{
    const clean=arr.filter(Boolean).filter(x=>!brand.includes(x));
    if(!clean.length)return; const key=clean.join(' '); if(seen.has(key))return;
    seen.add(key); groups.push({tokens:clean,phrase:key,score,reason,support:phraseSupport(clean,evidence)});
  };
  // contiguous alphanumeric IDs, including normalized CFM2000 / RB4165 / RP50587.
  for(const t of tokens){
    if((/[a-z]/.test(t)&&/\d/.test(t)) || /^\d{5,9}$/.test(t)) add([t],34,'hard-id');
  }
  // Preserve letter+number chains that tokenizers split (DSC S930, D F20, CFM 2000).
  for(const g of spacedModelGroups(tokens,brand)) add(g,38,'spaced-model');
  const raw=String(text).replace(/[’']/g,' ');
  const rx=/\b([A-Z]{1,6})\s*[- ]\s*([A-Z]?\d{2,7})\b/g;
  let m; while((m=rx.exec(raw))){
    const arr=[m[1],m[2]].filter(Boolean).map(x=>x.toLowerCase().replace(/[^a-z0-9]/g,''));
    if(arr[0] && !MODEL_PREFIX_NOISE.has(arr[0]) && !QUERY_CATEGORY.has(arr[0]))add(arr,42,'raw-model-chain');
  }
  // Short numeric generations are useful primarily for footwear and electronics.
  // In other categories they are more often size, draw weight, dimensions, or quantity (cat 8, RH 52, etc.).
  if(schema==='footwear'||schema==='electronics') for(let i=1;i<tokens.length;i++){
    if(!/^\d{1,2}$/.test(tokens[i]))continue;
    const prev=tokens[i-1];
    if(!prev||brand.includes(prev)||QUERY_CATEGORY.has(prev)||IDENTITY_ATTRIBUTE_NOISE.has(prev)||GENERIC_FEATURE_WORDS.has(prev))continue;
    const ps=phraseSupport([prev,tokens[i]],evidence);
    add([prev,tokens[i]],24+(ps.count*4),'named-generation');
  }
  return groups.sort((a,b)=>b.score-a.score||b.tokens.length-a.tokens.length).slice(0,5);
}
function dynamicIdentitySpans(rawTokens=[], brand=[], category='', models=[], evidence=[]){
  const modelSet=new Set(models.flatMap(x=>x.tokens||[]));
  const categorySet=new Set(String(category||'').split(/\s+/).filter(Boolean));
  const brandEnd=Math.max(0, phraseIndex(rawTokens,brand));
  const startsAt=brandEnd>=0?brandEnd+brand.length:0;
  const candidates=[]; const seen=new Set();
  const add=(words,score,reason,support)=>{
    const clean=words.filter(t=>t&&!/^\d+$/.test(t)&&!modelSet.has(t)&&!categorySet.has(t)&&!QUERY_CATEGORY.has(t)&&!IDENTITY_CONDITION_TERMS.has(t));
    if(!clean.length)return;
    const key=clean.join(' '); if(seen.has(key))return; seen.add(key);
    candidates.push({tokens:clean,phrase:key,score,reason,support:support||phraseSupport(clean,evidence)});
  };
  // Evidence-supported phrases are the strongest dynamic entities. No hard-coded brand/product dictionary required.
  for(let n=4;n>=2;n--){
    for(let i=startsAt;i+n<=rawTokens.length;i++){
      const words=rawTokens.slice(i,i+n);
      if(words.some(t=>/^(?:19\d\d|20\d\d)$/.test(t)||IDENTITY_ATTRIBUTE_NOISE.has(t)))continue;
      if(words.filter(t=>QUERY_CATEGORY.has(t)||categorySet.has(t)).length>0)continue;
      const ps=phraseSupport(words,evidence);
      if(ps.count<2)continue;
      const generic=words.filter(t=>GENERIC_FEATURE_WORDS.has(t)||LOW_INFO_DESCRIPTOR.has(t)).length;
      add(words,ps.ratio*70+ps.count*3+words.length*3-generic*8,'market-entity',ps);
    }
  }
  // Title-structure fallback: contiguous meaningful words between brand and object noun.
  let catAt=rawTokens.length;
  for(let i=startsAt;i<rawTokens.length;i++)if(categorySet.has(rawTokens[i])||QUERY_CATEGORY.has(rawTokens[i])){catAt=i;break;}
  const middle=rawTokens.slice(startsAt,catAt).filter(t=>
    !/^(?:19\d\d|20\d\d)$/.test(t) && !IDENTITY_ATTRIBUTE_NOISE.has(t) && !modelSet.has(t) &&
    !CRITICAL_VARIANT.has(t) && !GENERIC_FEATURE_WORDS.has(t) && !LOW_INFO_DESCRIPTOR.has(t)
  );
  if(middle.length)add(middle.slice(0,4),18+Math.min(4,middle.length)*3,'title-entity');
  // Retain old protected phrases only as a fallback signal, not as the primary engine.
  for(const words of protectedIdentityPhrases(rawTokens)){
    if(words.join(' ')===brand.join(' '))continue;
    add(words,20+words.length*3,'protected-fallback');
  }
  candidates.sort((a,b)=>b.score-a.score||b.tokens.length-a.tokens.length);
  const selected=[];
  for(const c of candidates){
    if(selected.some(x=>c.tokens.every(t=>x.tokens.includes(t))))continue;
    selected.push(c); if(selected.length>=3)break;
  }
  return selected;
}
function buildIdentityGraph(title='',keywords='',evidence=[],legacyStructured={}){
  const sourceText=`${keywords} ${title}`.trim();
  let rawTokens=identityPhraseTokens(sourceText);
  const searchTokens=queryTokens(sourceText);
  if(searchTokens[0]==='hoka') rawTokens=rawTokens.filter((t,i)=>!(t==='one'&&i>0&&i<3));
  const fallbackBrand=queryBrandPrefix(searchTokens);
  const brand=dynamicBrandTokens(rawTokens,evidence,fallbackBrand);
  let category=legacyStructured.category||canonicalCategory(searchTokens);
  const schema=categorySchema(category,searchTokens);
  const models=modelRoleGroups(sourceText,searchTokens,brand,evidence,schema);
  const spans=dynamicIdentitySpans(rawTokens,brand,category,models,evidence);
  const conditionTerms=criticalVariantTokens(sourceText).filter(x=>['parts','repair','broken','asis'].includes(x));
  const productVariants=criticalVariantTokens(sourceText).filter(x=>!conditionTerms.includes(x));
  const typeQualifiers=searchTokens.filter(t=>TYPE_QUALIFIERS.has(t)&&!brand.includes(t)).slice(0,3);
  const protectedNonBrand=protectedIdentityPhrases(rawTokens).filter(words=>words.join(' ')!==brand.join(' ')&&!words.every(x=>['die','cast'].includes(x)));
  let productLine=(spans[0]?.tokens||[]).filter(x=>!brand.includes(x));
  let subject=(spans[1]?.tokens||[]).filter(x=>!brand.includes(x));
  // Schema-specific role resolution is generic: object-form words are not named bag lines,
  // and footwear named-generation pairs are stronger than branding fluff.
  const supportedSpan=spans.find(x=>x.support?.count>=2);
  const namedGeneration=models.find(x=>x.reason==='named-generation');
  if(schema==='footwear'&&namedGeneration) productLine=namedGeneration.tokens.slice();
  if(schema==='bags'&&!supportedSpan){
    const protectedLine=protectedNonBrand.find(x=>x.length>=2);
    if(protectedLine)productLine=protectedLine.slice();
    else if(typeQualifiers[0])productLine=[typeQualifiers[0]];
  }
  if(schema==='collectible'&&!supportedSpan){
    const usefulProtected=protectedNonBrand.filter(x=>!x.every(t=>['die','cast','metal'].includes(t))).slice(0,2);
    if(usefulProtected.length){
      const combined=[]; for(const words of usefulProtected)for(const t of words)if(!brand.includes(t)&&!combined.includes(t))combined.push(t);
      if(combined.length)productLine=combined.slice(0,5);
    }
    // If the protected phrases are only material descriptors, keep the meaningful title entity.
    if(!productLine.length && spans[0])productLine=spans[0].tokens.filter(x=>!brand.includes(x));
  }
  productLine=[...new Set(productLine.filter(x=>!IDENTITY_ATTRIBUTE_NOISE.has(x)&&!IDENTITY_CONDITION_TERMS.has(x)))];
  subject=[...new Set(subject.filter(x=>!productLine.includes(x)&&!IDENTITY_ATTRIBUTE_NOISE.has(x)&&!IDENTITY_CONDITION_TERMS.has(x)))];
  let modelTokens=[...new Set(models.flatMap(x=>x.tokens||[]))].slice(0,6);
  const hardIds0=[...new Set(modelTokens.filter(t=>(/[a-z]/.test(t)&&/\d/.test(t))||/^\d{5,9}$/.test(t)))];
  // Prefer a normalized hard ID over its split spelling (CFM 2000 -> CFM2000).
  for(const hard of hardIds0){
    modelTokens=modelTokens.filter((t,i,a)=>{
      if(t===hard)return true;
      for(let j=0;j<a.length-1;j++)if(`${a[j]}${a[j+1]}`===hard&&(t===a[j]||t===a[j+1]))return false;
      return true;
    });
  }
  modelTokens=[...new Set(modelTokens)].slice(0,6);
  const hardIds=[...new Set(modelTokens.filter(t=>(/[a-z]/.test(t)&&/\d/.test(t))||/^\d{5,9}$/.test(t)))];
  const required=[...new Set([...brand,...productLine,...modelTokens].filter(Boolean))];
  const graph={
    schema,brand:brand.join(' '),brandTokens:brand,productLine:productLine.join(' '),productLineTokens:productLine,
    subject:subject.join(' '),subjectTokens:subject,modelTokens,modelGroups:models,hardIds,
    category,criticalVariants:productVariants,typeQualifiers,conditionTerms,
    entities:spans,required,useful:[...new Set([...typeQualifiers,...String(category).split(/\s+/),...productVariants].filter(Boolean))],
    sourceTokens:rawTokens,
    roles:{brand,productLine,subject,models:models.map(x=>x.tokens),object:String(category).split(/\s+/).filter(Boolean),variant:productVariants,condition:conditionTerms}
  };
  graph.identityCompleteness=identityCompletenessV2(graph,sourceText,evidence);
  return graph;
}
function identityCompletenessV2(graph={},title='',evidence=[]){
  let score=0, possible=0; const missing=[];
  const brand=graph.brandTokens||[], named=graph.productLineTokens||[], subject=graph.subjectTokens||[], models=graph.modelTokens||[];
  if(brand.length){possible+=25;score+=25;} else {possible+=25;missing.push('brand/manufacturer');}
  if(graph.category){possible+=20;score+=20;} else {possible+=20;missing.push('object type');}
  // A strong model OR a named identity span can be the primary discriminator.
  possible+=35;
  if(models.length)score+=35;
  else if(named.length>=2)score+=32;
  else if(named.length===1)score+=24;
  else if(subject.length)score+=20;
  else missing.push('model/product line/subject');
  possible+=20;
  const evidenceRows=(evidence||[]).filter(x=>x&&x.title).length;
  const supported=(graph.entities||[]).some(x=>x.support?.count>=2)||(graph.modelGroups||[]).some(x=>x.support?.count>=2);
  if(supported)score+=20; else if(evidenceRows>=3)score+=8; else score+=5;
  const value=Math.round(score/possible*100);
  return {value,confidence:value>=82?'high':value>=62?'medium':'low',missing:[...new Set(missing)],evidenceSupported:supported};
}
function synthesizeConstraintQueries(graph={},legacy={}){
  const out=[]; const seen=new Set();
  const clean=(arr,max=9)=>{const x=[];for(const t of arr){if(t&&!x.includes(t)){x.push(t);if(x.length>=max)break;}}return x;};
  const add=(id,arr,intent)=>{const q=clean(arr).join(' ').trim();if(!q||seen.has(q))return;seen.add(q);out.push({id,query:q,intent,schema:graph.schema||'generic'});};
  const b=graph.brandTokens||[], l=graph.productLineTokens||[], s=graph.subjectTokens||[], m=graph.modelTokens||[];
  const cat=String(graph.category||'').split(/\s+/).filter(Boolean), q=(graph.typeQualifiers||[]).slice(0,1), v=(graph.criticalVariants||[]).slice(0,2);
  // Most specific hypothesis first, followed by minimal discriminative hypotheses.
  add('identity-exact',[...b,...l,...s,...m,...cat,...v],'all high-confidence identity constraints');
  if(m.length)add('model-anchor',[...b,...m,...l.slice(0,2),...cat],'manufacturer + exact model + object');
  if(l.length)add('named-object',[...b,...l,...s.slice(0,1),...cat],'named product line/subject + object');
  if(s.length)add('subject-object',[...b,...s,...cat],'manufacturer + subject/character + object');
  if(q.length)add('form-object',[...b,...l.slice(0,2),...q,...cat],'named identity + specific object form');
  add('minimal-identity',[...b,...m.slice(0,2),...l.slice(0,3),...cat],'smallest discriminative identity');
  // Keep one legacy exact query only as a safety net; legacy family queries are too broad to outrank role constraints.
  if(legacy.exact)add('legacy-safety',String(legacy.exact).split(/\s+/).filter(t=>!IDENTITY_CONDITION_TERMS.has(t)&&!['parts','repair','broken','asis'].includes(t)),'legacy safety fallback');
  return out.slice(0,6);
}
function clusterObjectConsistency(rows=[]){
  const counts=new Map(); let seen=0;
  for(const row of rows){
    const groups=observedObjectGroups(queryTokens(row.title||''));
    if(!groups.length)continue; seen++;
    const g=groups[0]; counts.set(g,(counts.get(g)||0)+1);
  }
  if(!seen)return {dominance:1,groups:0};
  const vals=[...counts.values()].sort((a,b)=>b-a);
  return {dominance:vals[0]/seen,groups:counts.size};
}
function marketRefinement(graph={},pool={},currentQuery=''){
  const rows=(pool?.rawItems||[]).filter(x=>x&&x.title).slice(0,30);
  if(rows.length<5)return null;
  const current=new Set(queryTokens(currentQuery));
  const source=(graph.sourceTokens||[]).filter(t=>!IDENTITY_ATTRIBUTE_NOISE.has(t)&&!IDENTITY_CONDITION_TERMS.has(t)&&!QUERY_CATEGORY.has(t)&&!GENERIC_FEATURE_WORDS.has(t)&&t.length>1);
  const df=new Map();
  for(const row of rows){const set=new Set(identityPhraseTokens(row.title));for(const t of source)if(set.has(t))df.set(t,(df.get(t)||0)+1);}
  const candidates=source.filter(t=>!current.has(t)&&(df.get(t)||0)>=Math.max(2,Math.ceil(rows.length*.25)))
    .sort((a,b)=>(df.get(b)||0)-(df.get(a)||0));
  if(!candidates.length)return null;
  const b=graph.brandTokens||[], m=graph.modelTokens||[], l=graph.productLineTokens||[], s=graph.subjectTokens||[], cat=String(graph.category||'').split(/\s+/).filter(Boolean);
  const additions=candidates.slice(0,2);
  const parts=[]; for(const t of [...b,...m,...l,...s,...additions,...cat])if(t&&!parts.includes(t)&&parts.length<9)parts.push(t);
  const query=parts.join(' ').trim();
  if(!query||query===currentQuery)return null;
  return {query,addedTokens:additions,reason:'active-market-consensus',support:additions.map(t=>({token:t,count:df.get(t),ratio:(df.get(t)||0)/rows.length}))};
}

function buildQueryCandidates({brand=[],productLine=[],modelChain=[],hardIds=[],shortStyles=[],category='',criticalVariants=[],typeQualifiers=[],schema='generic',legacy={}}){
  const out=[];
  const seen=new Set();
  const clean=(arr,max=9)=>{
    const x=[]; for(const t of arr){if(t&&!x.includes(t))x.push(t);if(x.length>=max)break;} return x;
  };
  const add=(id,arr,intent)=>{
    const q=clean(arr).join(' ').trim();
    if(!q||seen.has(q))return;
    seen.add(q); out.push({id,query:q,intent,schema});
  };
  const cat=String(category||'').split(/\s+/).filter(Boolean);
  const anchor=productLine.length?productLine:[];
  const ids=modelChain.length?modelChain:hardIds;
  const gen=shortStyles.slice(0,1);
  const variants=criticalVariants.slice(0,3);
  const qualifier=typeQualifiers.slice(0,1);

  if(schema==='footwear'){
    add('model-specific',[...brand,...anchor,...gen,...ids,...cat],'same shoe model/generation');
    add('line-specific',[...brand,...anchor,...gen,...cat],'same product line and generation');
    if(ids.length)add('sku-specific',[...brand,...ids,...cat],'same style/SKU and product type');
    add('line-broad',[...brand,...anchor,...gen],'same product line without extra descriptors');
  }else if(schema==='electronics'){
    add('model-specific',[...brand,...anchor,...ids,...cat],'same exact device model');
    add('model-clean',[...brand,...ids,...cat],'brand + exact model + product type');
    add('line-specific',[...brand,...anchor,...ids],'same device family/model');
  }else if(schema==='fragrance'){
    add('flanker-specific',[...brand,...anchor,...variants],'same fragrance + flanker/concentration');
    add('fragrance-line',[...brand,...anchor,...variants.slice(0,1)],'same fragrance line');
    add('fragrance-clean',[...brand,...anchor],'same named fragrance');
  }else if(schema==='bags'){
    add('named-product',[...brand,...anchor,...qualifier,...cat,...ids],'same named bag/product line');
    add('type-specific',[...brand,...anchor,...cat],'same brand + line + bag type');
    add('brand-type',[...brand,...qualifier,...cat],'same brand + specific bag form');
  }else if(schema==='collectible'){
    add('named-object',[...brand,...anchor,...cat,...ids],'same named collectible/object');
    add('subject-object',[...brand,...anchor,...cat],'same subject/product + object type');
    add('identity-clean',[...brand,...anchor,...ids],'same named collectible identity');
  }else if(schema==='apparel'){
    add('line-garment',[...brand,...anchor,...ids,...cat],'same brand/line and garment type');
    add('model-garment',[...brand,...ids,...cat],'same style/model and garment type');
    add('brand-garment',[...brand,...anchor,...cat],'same branded garment family');
  }else if(schema==='home'){
    add('style-object',[...brand,...anchor,...qualifier,...cat],'same style/maker and object type');
    add('object-clean',[...brand,...anchor,...cat],'same named object');
    add('descriptor-object',[...anchor,...qualifier,...cat],'same design/object type');
  }else if(schema==='sporting'){
    add('model-equipment',[...brand,...anchor,...ids,...cat],'same maker/model/equipment type');
    add('line-equipment',[...brand,...anchor,...cat],'same product line and equipment type');
  }else{
    add('identity',[...brand,...anchor,...ids,...gen,...cat],'most specific structured identity');
    add('identity-clean',[...brand,...anchor,...ids,...cat],'identity without secondary descriptors');
  }
  add('legacy-exact',String(legacy.exact||'').split(/\s+/),'legacy exact fallback');
  add('legacy-style',String(legacy.style||'').split(/\s+/),'legacy style fallback');
  add('legacy-family',String(legacy.family||'').split(/\s+/),'legacy family fallback');
  return out.slice(0,6);
}

function categoryTitleMatch(category='',titleTokens=[]){
  if(!category)return true;
  const t=new Set(titleTokens);
  const parts=String(category).split(/\s+/).filter(Boolean);
  if(category==='bat bag')return t.has('bat')&&['bag','bags','backpack','backpacks'].some(x=>t.has(x));
  if(parts.some(x=>t.has(x)))return true;
  if(/shoes/.test(category) && ['sneaker','sneakers','shoe','shoes','trainer','trainers'].some(x=>t.has(x)))return true;
  if(/boots/.test(category) && ['boot','boots'].some(x=>t.has(x)))return true;
  if(/sandals/.test(category) && ['sandal','sandals','slide','slides'].some(x=>t.has(x)))return true;
  if(/backpack/.test(category) && ['backpack','backpacks','rucksack'].some(x=>t.has(x)))return true;
  if(/^bag$|\bbag\b|purse/.test(category) && ['bag','bags','backpack','backpacks','purse','purses','messenger','satchel','tote','duffel'].some(x=>t.has(x)))return true;
  if(/camera/.test(category) && ['camera','cameras'].some(x=>t.has(x)))return true;
  if(/headphones/.test(category) && ['headphone','headphones','headset','headsets','earbuds','earphones'].some(x=>t.has(x)))return true;
  if(/fragrance/.test(category) && ['fragrance','perfume','cologne','edp','edt','parfum'].some(x=>t.has(x)))return true;
  if(/chair/.test(category) && ['chair','chairs','rocker','rocking'].some(x=>t.has(x)))return true;
  if(/playset/.test(category) && ['playset','playsets','set'].some(x=>t.has(x)))return true;
  if(/castle/.test(category) && ['castle','castles'].some(x=>t.has(x)))return true;
  if(/stable/.test(category) && ['stable','stables'].some(x=>t.has(x)))return true;
  if(/plush/.test(category) && ['plush','stuffed','beanbag'].some(x=>t.has(x)))return true;
  return false;
}

const MARKET_OBJECT_GROUPS={
  bag:new Set('bag bags backpack backpacks purse purses messenger satchel tote totes duffel rucksack'.split(/\s+/)),
  footwear:new Set('shoe shoes sneaker sneakers trainer trainers boot boots sandal sandals slide slides loafer loafers clog clogs heel heels'.split(/\s+/)),
  apparel:new Set('shirt shirts tee tshirt sweater hoodie jacket coat jeans jean pants shorts dress skirt blouse jersey pajamas pyjamas robe robes hat cap beanie'.split(/\s+/)),
  camera:new Set('camera cameras camcorder'.split(/\s+/)),
  audio:new Set('headphone headphones headset headsets earbuds earbud earphones neckband'.split(/\s+/)),
  toy:new Set('doll dolls figure figures figurine figurines plush stuffed toy toys playset playsets castle castles stable stables vehicle vehicles'.split(/\s+/)),
  home:new Set('chair chairs rocker rocking stool stools table tables lamp lamps clock clocks vase vases planter planters blanket blankets pillow pillows frame frames print prints poster posters sign signs'.split(/\s+/)),
  sporting:new Set('bow bows recurve bat bats glove gloves racket rackets club clubs'.split(/\s+/))
};
function expectedObjectGroup(structured={}){
  const c=String(structured.category||'');
  const schema=structured.schema||'generic';
  if(schema==='bags'||/bag|backpack|purse/.test(c))return 'bag';
  if(schema==='footwear'||/shoe|boot|sandal|heel/.test(c))return 'footwear';
  if(schema==='apparel')return 'apparel';
  if(/camera/.test(c))return 'camera';
  if(/headphone|headset|earbud/.test(c))return 'audio';
  if(schema==='collectible'||/doll|figure|figurine|plush|toy|playset|castle|stable/.test(c))return 'toy';
  if(schema==='home')return 'home';
  if(schema==='sporting')return 'sporting';
  return '';
}
function observedObjectGroups(tokens=[]){
  const set=new Set(tokens), out=[];
  for(const [group,words] of Object.entries(MARKET_OBJECT_GROUPS)){
    for(const w of words){if(set.has(w)){out.push(group);break;}}
  }
  return out;
}
function categoryMandatory(structured={}){
  const schema=structured.schema||'generic', category=structured.category||'';
  if(!category)return false;
  // Model/SKU-driven electronics can be safely identified without the object noun.
  if(schema==='electronics' && (structured.hardIds||[]).length)return false;
  // Generic exact-SKU parts are likewise driven by the hard ID.
  if(schema==='generic' && (structured.hardIds||[]).length)return false;
  return ['bags','footwear','apparel','collectible','home','sporting'].includes(schema) || !!expectedObjectGroup(structured);
}
function queryStructureFit(structured={},query=''){
  const toks=queryTokens(query), set=new Set(toks);
  const brand=[...new Set(structured.brandTokens||[])];
  const line=[...new Set(queryTokens(structured.productLine||''))];
  const models=[...new Set(structured.modelTokens||[])];
  const category=structured.category||'';
  const brandRatio=brand.length?brand.filter(x=>set.has(x)).length/brand.length:1;
  const lineRatio=line.length?line.filter(x=>set.has(x)).length/line.length:1;
  const modelRatio=models.length?models.filter(x=>set.has(x)).length/models.length:1;
  const categoryOk=categoryTitleMatch(category,toks);
  const mustCategory=categoryMandatory(structured);
  let score=.22*brandRatio+.28*lineRatio+.32*modelRatio+.18*(categoryOk?1:0);
  if(mustCategory&&!categoryOk)score-=.45;
  if(brand.length&&brandRatio<1)score-=.35;
  return {score:clamp(score,0,1),brandRatio,lineRatio,modelRatio,categoryOk,mustCategory};
}
function scoreQueryCandidate(structured={},pool={},meta={}){
  const rows=(pool?.rawItems||[]).filter(x=>x&&x.title).slice(0,30);
  const brand=[...new Set(structured.brandTokens||[])];
  const line=[...new Set(queryTokens(structured.productLine||''))];
  const models=[...new Set(structured.modelTokens||[])];
  const variants=[...new Set(structured.criticalVariants||[])];
  const category=structured.category||'';
  const mustCategory=categoryMandatory(structured);
  const expectedGroup=expectedObjectGroup(structured);
  const structureFit=queryStructureFit(structured,pool?.query||meta.query||'');
  if(!rows.length)return {...meta,query:pool?.query||meta.query||'',score:0,precision:0,productPurity:0,lexicalPrecision:0,checked:0,matched:0,confidence:'none',reason:'no-active-results',queryStructure:structureFit};
  let pureMatched=0, lexicalMatched=0, sum=0, brandHits=0, lineHits=0, modelHits=0, categoryHits=0, variantHits=0, wrongObject=0, conflictModels=0;
  for(const row of rows){
    const toks=queryTokens(row.title); const set=new Set(toks);
    const brandOk=!brand.length||brand.every(x=>set.has(x));
    const lineRatio=line.length?line.filter(x=>set.has(x)).length/line.length:1;
    const lineThreshold=line.length<=2?1:Math.max(.67,(line.length-1)/line.length);
    const lineOk=!line.length||lineRatio>=lineThreshold;
    const modelRatio=models.length?models.filter(x=>set.has(x)).length/models.length:1;
    const modelOk=!models.length||modelRatio>=Math.min(1,Math.max(.5,1/models.length));
    const catOk=categoryTitleMatch(category,toks);
    const variantRatio=variants.length?variants.filter(x=>set.has(x)).length/variants.length:1;
    const variantOk=!variants.length||variantRatio>=.5;
    if(brandOk)brandHits++; if(lineOk)lineHits++; if(modelOk)modelHits++; if(catOk)categoryHits++; if(variantOk)variantHits++;
    const hasPrimary=models.length?modelOk:(line.length?lineOk:catOk);
    const lexicalRequired=brandOk&&hasPrimary&&(structured.schema==='fragrance'&&variants.length?variantOk:true);
    if(lexicalRequired)lexicalMatched++;

    const groups=observedObjectGroups(toks);
    const hasExpectedObject=!expectedGroup||groups.includes(expectedGroup)||catOk;
    const conflictingObject=!!expectedGroup && groups.length>0 && !hasExpectedObject;
    if(conflictingObject)wrongObject++;

    // Hard IDs are exact identity anchors. A candidate title carrying other alphanumeric
    // model-like tokens but not the target hard ID is likely a neighboring product/model.
    let modelConflict=false;
    const targetHard=[...new Set(structured.hardIds||[])];
    if(targetHard.length&&!targetHard.some(x=>set.has(x))){
      const rowIds=toks.filter(x=>(/[a-z]/.test(x)&&/\d/.test(x))||/^\d{3,8}$/.test(x));
      modelConflict=rowIds.some(x=>!targetHard.includes(x));
    }
    if(modelConflict)conflictModels++;

    const semanticRequired=lexicalRequired && (!mustCategory||catOk) && !conflictingObject && !modelConflict;
    if(semanticRequired)pureMatched++;
    let rowScore=(brandOk?.16:0)+(line.length?lineRatio*.24:.08)+(models.length?modelRatio*.30:.08)+(catOk?.18:0)+(variants.length?variantRatio*.08:.04);
    if(!brandOk&&brand.length)rowScore-=.25;
    if(models.length&&!modelOk)rowScore-=.22;
    if(mustCategory&&!catOk)rowScore-=.32;
    if(conflictingObject)rowScore-=.38;
    if(modelConflict)rowScore-=.30;
    sum+=clamp(rowScore,0,1);
  }
  const lexicalPrecision=lexicalMatched/rows.length;
  const productPurity=pureMatched/rows.length;
  const avg=sum/rows.length;
  const sampleBonus=Math.min(10,rows.length)/10;
  const strong=models.length||line.length;
  const cluster=clusterObjectConsistency(rows);
  const qTokens=queryTokens(pool?.query||meta.query||'');
  const compactness=Math.max(0,1-Math.max(0,qTokens.length-6)*.10);
  // Product purity is deliberately dominant. Cluster consistency catches queries whose
  // returned titles fragment across multiple product types even when lexical overlap looks good.
  let score=(productPurity*52)+(avg*18)+(structureFit.score*12)+(cluster.dominance*8)+(compactness*5)+(sampleBonus*3)+(strong?2:0);
  if(rows.length===1)score-=5;
  if(productPurity<.25&&rows.length>=8)score-=15;
  if(structureFit.mustCategory&&!structureFit.categoryOk)score-=22;
  score=clamp(score,0,100);
  const confidence=score>=78&&productPurity>=.7&&rows.length>=5?'high':score>=58&&productPurity>=.5?'medium':score>=38&&productPurity>=.3?'low':'poor';
  return {...meta,query:pool?.query||meta.query||'',score:money(score),precision:money(productPurity),productPurity:money(productPurity),lexicalPrecision:money(lexicalPrecision),averageIdentityScore:money(avg),checked:rows.length,matched:pureMatched,lexicalMatched,
    brandRate:money(brandHits/rows.length),lineRate:money(lineHits/rows.length),modelRate:money(modelHits/rows.length),categoryRate:money(categoryHits/rows.length),variantRate:money(variantHits/rows.length),wrongObjectRate:money(wrongObject/rows.length),conflictingModelRate:money(conflictModels/rows.length),clusterConsistency:money(cluster.dominance),clusterGroups:cluster.groups,compactness:money(compactness),confidence,queryStructure:structureFit,
    reason:`${pureMatched}/${rows.length} active titles were same-product matches (${lexicalMatched}/${rows.length} lexical matches); object-cluster dominance ${Math.round(cluster.dominance*100)}%`};
}

function rankQueryCandidates(candidates=[],structured={}){
  return candidates.map(x=>({...x,validation:scoreQueryCandidate(structured,x.active,x)}))
    .sort((a,b)=>b.validation.score-a.validation.score || b.validation.precision-a.validation.precision || (b.active?.sampleCount||0)-(a.active?.sampleCount||0));
}

function identityCompleteness(structured={}, title='') {
  const source=queryTokens(title), set=new Set(source);
  const brand=[...new Set(structured.brandTokens||[])];
  const line=[...new Set(structured.productLineTokens||[])];
  const models=[...new Set(structured.modelTokens||[])];
  const category=structured.category||'';
  let score=0, possible=0, missing=[];
  if(brand.length){possible+=30; if(brand.every(x=>set.has(x)))score+=30; else missing.push('brand');}
  if(line.length){possible+=25; const hits=line.filter(x=>set.has(x)).length; score+=25*hits/line.length; if(hits<line.length)missing.push('product line');}
  if(models.length){possible+=30; const hits=models.filter(x=>set.has(x)).length; score+=30*hits/models.length; if(!hits)missing.push('model/SKU');}
  if(category){possible+=15; if(categoryTitleMatch(category,source))score+=15; else missing.push('object type');}
  const value=possible?Math.round(score/possible*100):0;
  return {value,confidence:value>=80?'high':value>=60?'medium':'low',missing:[...new Set(missing)]};
}

function queryProfiles(title='',keywords='',evidence=[]) {
  // User keywords are allowed to supply missing brand/model context, but marketplace-title noise is stripped identically.
  const rawPhraseTokens=identityPhraseTokens(`${keywords} ${title}`);
  let tokens=queryTokens(`${keywords} ${title}`);
  if(!tokens.length) return {exact:'',style:'',family:'',diagnostics:{}};
  const seen=new Set();
  tokens=tokens.filter(t=>{
    if(t==='one'&&tokens[0]==='hoka') return false;
    if(seen.has(t)) return false;
    seen.add(t); return true;
  });
  // Clothing sizes are attributes, not item identity. Strip them only when the title
  // is clearly apparel/footwear so words such as "medium" remain available in non-apparel contexts.
  const apparelContext=tokens.some(t=>APPAREL_TERMS.has(t));
  if(apparelContext) tokens=tokens.filter(t=>!APPAREL_SIZE_WORDS.has(t) && !/^(?:[2-9]x?l|x{1,4}l)$/.test(t));
  const brand=queryBrandPrefix(tokens), brandSet=new Set(brand);
  const freq=evidenceTokenFrequency(evidence);
  const keywordSet=new Set(queryTokens(keywords));
  const yearRx=/^(?:19\d\d|20\d\d)$/;
  const eraRx=/^(?:\d{2}s|y2k|y2k\d*)$/;
  const hardIds=tokens.filter(t=>!brandSet.has(t) && !yearRx.test(t) && !eraRx.test(t) && (
    (/[a-z]/.test(t)&&/\d/.test(t)) || /^\d{3,8}$/.test(t)
  ));
  // A one/two-digit number is a style generation only when tied to a meaningful word (Clifton 8),
  // not just because a listing contains a size.
  const shortStyles=[];
  for(let i=0;i<tokens.length;i++){
    const t=tokens[i]; if(!/^\d{1,2}$/.test(t)) continue;
    const prev=tokens[i-1]||'';
    const repeated=(freq.get(t)||0)>=2;
    const attached=prev && !brandSet.has(prev) && !QUERY_CATEGORY.has(prev) && !QUERY_NOISE.has(prev) && !/^\d+$/.test(prev);
    const digits=t;
    const duplicatedByHard=hardIds.some(x=>x.replace(/\D/g,'')===digits);
    if((attached||repeated)&&!duplicatedByHard) shortStyles.push(t);
  }
  const idSet=new Set([...hardIds,...shortStyles]);
  let category=canonicalCategory(tokens);
  // Listings that explicitly say '<object> only' describe the sold configuration, not merely a descriptor.
  // Prefer that scoped object over a broader playset/container also named in the title (e.g. 'Castle, Stable Only').
  const onlyIdx=tokens.indexOf('only');
  if(onlyIdx>0){
    const scoped=canonicalCategory([tokens[onlyIdx-1]]);
    if(scoped)category=scoped;
  }
  const categoryParts=new Set(category.split(/\s+/).filter(Boolean));
  const criticalVariants=criticalVariantTokens(`${keywords} ${title}`);
  const phrases=phraseAnchors(tokens,brand,evidence,category,rawPhraseTokens);
  const protectedPhrases=protectedIdentityPhrases(rawPhraseTokens);
  const topPhrase=phrases.find(x=>x.reason==='device-model-chain'||x.reason==='marketplace-consensus')||null;

  const descriptors=[];
  for(let i=0;i<tokens.length;i++){
    const t=tokens[i];
    if(brandSet.has(t)||idSet.has(t)||QUERY_CATEGORY.has(t)||categoryParts.has(t)||CRITICAL_VARIANT.has(t)||yearRx.test(t)||/^\d+$/.test(t)) continue;
    if(t.length<3) continue;
    const prior=tokens[i-1]||'';
    const looksLikeTrailingCode=/^[a-z]{2,4}$/.test(t) && prior.length>=5 && hardIds.includes(prior) && (freq.get(t)||0)<2 && !keywordSet.has(t);
    if(looksLikeTrailingCode) continue;
    let score=0;
    score += Math.min(4,freq.get(t)||0)*4;
    if(keywordSet.has(t)) score += 8;
    if(CRITICAL_VARIANT.has(t)) score += 12;
    if(LOW_INFO_DESCRIPTOR.has(t)) score -= 6;
    score += Math.max(0,7-i)*0.7;
    if(/^\d{1,2}$/.test(tokens[i+1]||'')) score += 8; // named line before generation, e.g. Clifton 8
    if(hardIds.includes(tokens[i+1]||'')) score += 3;
    descriptors.push({t,score,i});
  }
  descriptors.sort((a,b)=>b.score-a.score||a.i-b.i);
  const descriptorOrder=descriptors.map(x=>x.t);
  const add=(arr,x)=>{if(x&&!arr.includes(x))arr.push(x);};

  const phraseCanLead=topPhrase && topPhrase.reason==='marketplace-consensus' && (topPhrase.rawStart===0 || (topPhrase.rawStart===1 && (rawPhraseTokens[0]||'').length===1));
  const exact=phraseCanLead?[]:[...brand];
  // Phrase anchors come before loose descriptors. Strong marketplace consensus can
  // even repair an ambiguous brand prefix such as "Red Man Tobacco".
  if(topPhrase) topPhrase.words.forEach(x=>{if(exact.length<8)add(exact,x)});
  protectedPhrases.forEach(words=>words.forEach(x=>{if(exact.length<8)add(exact,x)}));
  // Put the strongest named descriptor immediately after the brand/phrase, then model IDs.
  // This preserves identity phrases such as Old West Apache while keeping Delta RP50587 ahead of category words.
  const strongDescriptors=descriptorOrder.filter(d=>!LOW_INFO_DESCRIPTOR.has(d));
  if(strongDescriptors[0] && exact.length<8)add(exact,strongDescriptors[0]);
  shortStyles.slice(0,1).forEach(x=>{if(exact.length<8)add(exact,x)});
  hardIds.slice(0,2).forEach(x=>{if(exact.length<8)add(exact,x)});
  // Product type is never optional in the exact query.
  if(category) category.split(' ').forEach(x=>{if(exact.length<8)add(exact,x)});
  for(const d of strongDescriptors.slice(1,4)){if(exact.length<8)add(exact,d)}
  criticalVariants.forEach(x=>{if(exact.length<8)add(exact,x)});


  const style=phraseCanLead?[]:[...brand];
  if(topPhrase) topPhrase.words.slice(0,4).forEach(x=>{if(style.length<7)add(style,x)});
  protectedPhrases.forEach(words=>words.forEach(x=>{if(style.length<7)add(style,x)}));
  for(const d of descriptorOrder.slice(0,2)){if(!LOW_INFO_DESCRIPTOR.has(d) && style.length<7)add(style,d)}
  criticalVariants.slice(0,2).forEach(x=>{if(style.length<7)add(style,x)});
  shortStyles.slice(0,1).forEach(x=>add(style,x));
  // Keep a human-readable model number in style tier, but omit long SKU when a named style already exists.
  const humanId=hardIds.find(t=>t.length<=6);
  if(humanId) add(style,humanId);
  if(category) category.split(' ').forEach(x=>{if(style.length<6)add(style,x)});
  if(descriptorOrder[1]&&style.length<6)add(style,descriptorOrder[1]);

  const family=[...brand];
  if(descriptorOrder[0]) add(family,descriptorOrder[0]);
  if(shortStyles[0] && family.length<4) add(family,shortStyles[0]);
  if(family.length<2 && category) category.split(' ').forEach(x=>add(family,x));

  // If there is a hard model/SKU but no useful descriptor, exact must still contain product type.
  if(hardIds.length && exact.length<=brand.length+hardIds.length && category){
    category.split(' ').forEach(x=>{if(exact.length<6)add(exact,x)});
  }
  const legacy={exact:exact.slice(0,8).join(' '),style:style.slice(0,7).join(' '),family:family.slice(0,4).join(' ')};
  const nonBrandProtectedAll=protectedPhrases.filter(words=>words.join(' ')!==brand.join(' '));
  const evidencePhrase=phrases.find(x=>x.reason==='marketplace-consensus' && !x.words.every(w=>brandSet.has(w)));
  const typeQualifiers=tokens.filter(t=>TYPE_QUALIFIERS.has(t) && !brandSet.has(t) && !categoryParts.has(t));
  const identityDescriptors=descriptorOrder.filter(d=>!LOW_INFO_DESCRIPTOR.has(d));
  let productLineTokens=[];
  if(nonBrandProtectedAll.length){
    for(const words of nonBrandProtectedAll.slice(0,2)) for(const w of words){
      if(!brandSet.has(w)&&!productLineTokens.includes(w)&&productLineTokens.length<4)productLineTokens.push(w);
    }
  }
  else if(evidencePhrase)productLineTokens=evidencePhrase.words.slice();
  else if(identityDescriptors[0]){productLineTokens=[identityDescriptors[0]];if(shortStyles[0])productLineTokens.push(shortStyles[0]);}
  const modelChain=titleModelChain(tokens,hardIds);
  const schema=categorySchema(category,tokens);
  // Role-aware identity repair: collectibles need franchise/character subject, while exact-ID
  // generic products should not promote condition words or generic player/features to product line.
  if(schema==='collectible'&&(!nonBrandProtectedAll.length||productLineTokens.every(x=>['die','cast','metal'].includes(x)))&&!evidencePhrase){
    const subjectNoise=new Set(['die','cast','metal','action','small','large','plastic','vinyl']);
    const subjects=identityDescriptors.filter(x=>!subjectNoise.has(x)&&!CRITICAL_VARIANT.has(x)).slice(0,3);
    if(subjects.length)productLineTokens=subjects;
  }
  if(schema==='generic'&&hardIds.length&&!nonBrandProtectedAll.length&&!evidencePhrase){
    productLineTokens=[];
  }
  // For bags/home goods, form words are stronger identity than colors/materials when no named line was found.
  if(!nonBrandProtectedAll.length&&!evidencePhrase&&typeQualifiers[0]&&(schema==='bags'||schema==='home'))productLineTokens=[typeQualifiers[0]];
  else if(!productLineTokens.length && typeQualifiers[0])productLineTokens=[typeQualifiers[0]];
  const structured={
    schema,brand:brand.join(' '),brandTokens:brand.slice(),productLine:productLineTokens.join(' '),productLineTokens:productLineTokens.slice(),
    modelTokens:[...new Set([...modelChain,...hardIds,...shortStyles])].slice(0,5),hardIds:hardIds.slice(),generationTokens:shortStyles.slice(),
    category,criticalVariants:criticalVariants.slice(),typeQualifiers:typeQualifiers.slice(0,3),
    required:[...new Set([...brand,...productLineTokens,...modelChain,...hardIds].filter(Boolean))],
    useful:[...new Set([...typeQualifiers,...String(category).split(/\s+/),...criticalVariants].filter(Boolean))]
  };
  // 1.6 replaces token-first query construction with a role graph and constraint synthesis.
  // The legacy structure above remains only as a fallback signal for difficult sparse items.
  const graph=buildIdentityGraph(title,keywords,evidence,structured);
  const candidateQueries=synthesizeConstraintQueries(graph,legacy);
  return {
    ...legacy,candidates:candidateQueries,structured:graph,
    diagnostics:{brand:graph.brandTokens,hardIds:graph.hardIds,criticalVariants:graph.criticalVariants,conditionTerms:graph.conditionTerms,category:graph.category,schema:graph.schema,productLine:graph.productLine,subject:graph.subject,modelTokens:graph.modelTokens,typeQualifiers:graph.typeQualifiers,entities:(graph.entities||[]).map(x=>({phrase:x.phrase,reason:x.reason,score:money(x.score),support:x.support})),roles:graph.roles}
  };
}

function parseMoney(v) {
  if (Number.isFinite(v)) return v;
  if (v && Number.isFinite(v.extracted)) return v.extracted;
  if (v && Number.isFinite(v.extracted_value)) return v.extracted_value;
  const s = typeof v === 'string' ? v : (v && v.raw) || (v && v.value) || '';
  const m = String(s).replace(/,/g,'').match(/-?\d+(?:\.\d+)?/);
  return m ? Number(m[0]) : null;
}
function shippingValue(v) {
  if (Number.isFinite(v)) return Math.max(0,v);
  if (v && Number.isFinite(v.extracted)) return Math.max(0,v.extracted);
  const s = typeof v === 'string' ? v : (v && (v.raw||v.value)) || '';
  if (/free/i.test(s)) return 0;
  return Math.max(0,parseMoney(s)||0);
}
function normalizeMarketResults(data, query, mode='active') {
  const organic = Array.isArray(data?.organic_results) ? data.organic_results : [];
  const totalRaw = Number(data?.search_information?.total_results);
  const accepted=[], close=[];
  for (const r of organic) {
    if (!r?.title || r.sponsored) continue;
    const match=compMatch(query,r.title);
    if (!match.accept) {
      if(match.class==='close') close.push({title:r.title,link:r.link||'',condition:r.condition||'',thumbnail:r.thumbnail||'',matchClass:'close',matchScore:money(match.score)});
      continue;
    }
    const itemPrice = parseMoney(r.price);
    const shipping = shippingValue(r.shipping);
    accepted.push({
      title:r.title, link:r.link||'', productId:r.product_id||'', condition:r.condition||'',
      price:itemPrice, shipping, gross:Number.isFinite(itemPrice)?itemPrice+shipping:null,
      soldDate:r.sold_date||'', unsoldDate:r.unsold_date||'', thumbnail:r.thumbnail||'',
      matchClass:match.class, matchScore:money(match.score), matchReason:match.reason
    });
  }
  const rawLimit=mode==='sold'?250:30;
  const rawItems=organic.filter(r=>r&&r.title&&!r.sponsored).slice(0,rawLimit).map(r=>({
    title:r.title,link:r.link||'',productId:r.product_id||'',condition:r.condition||'',
    price:parseMoney(r.price),shipping:shippingValue(r.shipping),gross:Number.isFinite(parseMoney(r.price))?parseMoney(r.price)+shippingValue(r.shipping):null,
    soldDate:r.sold_date||'',unsoldDate:r.unsold_date||'',thumbnail:r.thumbnail||''
  }));
  const checked = rawItems.length;
  const ratio = checked ? accepted.length/checked : 0;
  const specific = distinctiveTokens(query).length >= 4 || distinctiveTokens(query).some(t=>/\d/.test(t));
  const totalTrusted = Number.isFinite(totalRaw) && totalRaw >= 0 && specific && checked >= 8 && ratio >= .72;
  const exhaustiveChecked = Number.isFinite(totalRaw) && totalRaw >= 0 && totalRaw <= checked && checked < 30;
  const denominatorTrusted = totalTrusted || exhaustiveChecked;
  const count = totalTrusted ? Math.max(accepted.length,Math.round(totalRaw)) : accepted.length;
  return { query, mode, count, sampleCount:accepted.length, closeSampleCount:close.length, checked, ratio, totalRaw:Number.isFinite(totalRaw)?totalRaw:null, totalTrusted, denominatorTrusted, exhaustiveChecked, items:accepted, closeItems:close.slice(0,8), rawItems };
}

function normalizeTrawlSold(data, query) {
  const results = Array.isArray(data?.results) ? data.results : [];
  const organic_results = results.map(r => ({
    title: r.title || '',
    link: r.item_link || '',
    product_id: r.item_id || '',
    condition: r.condition_raw || r.condition || '',
    price: { extracted: Number(r.sale_price) },
    shipping: { extracted: Number(r.shipping_price || 0) },
    sold_date: r.date_sold || '',
    thumbnail: r.image_url || ''
  }));
  const out = normalizeMarketResults({
    organic_results,
    search_information: { total_results: Number(data?.count) }
  }, query, 'sold');
  out.provider = 'Trawl';
  out.creditsCharged = Number(data?.credits_charged || 0);
  const pages = Math.max(1, Number(data?.max_pages || data?.maxPages || 1));
  out.maxPages = pages;
  // Full response means older matching sales may still exist. With max_pages=2, 200 is a lower bound, not an exact count.
  out.capped = Number(data?.count || 0) >= pages * 100;
  return out;
}

function chooseMarketPool(exact, family) {
  const enoughExact = exact && ((exact.totalTrusted && exact.count >= 3) || exact.sampleCount >= 5);
  if (enoughExact) return {...exact, pool:'exact'};
  if (family && ((family.totalTrusted && family.count >= 4) || family.sampleCount >= 6)) return {...family,pool:'family'};
  if (family && (family.sampleCount||0) >= 2 && (family.sampleCount||0) > (exact?.sampleCount||0)) return {...family,pool:'family-thin'};
  return {...(exact||family||{count:0,sampleCount:0,items:[]}),pool: exact ? 'exact-thin' : 'family-thin'};
}
function estimateCappedSoldCount(pool, windowDays=90) {
  if(!pool?.capped)return {available:false,reason:'not-capped'};
  const items=Array.isArray(pool?.items)?pool.items:[];
  const sample=Math.max(0,Number(pool?.sampleCount)||items.length);
  const observed=Math.max(0,Number(pool?.count)||sample);
  const dated=items.map(x=>new Date(x?.soldDate||x?.sold_date||'')).filter(d=>Number.isFinite(d.getTime()));
  const coverage=sample?dated.length/sample:0;
  if(dated.length<12 || coverage<.65)return {available:false,reason:'insufficient-dated-sales',datedCount:dated.length,coverage:money(coverage)};
  dated.sort((a,b)=>a-b);
  const day=86400000;
  const spanDays=Math.max(1,((dated[dated.length-1]-dated[0])/day)+1);
  if(spanDays>windowDays+5)return {available:false,reason:'date-span-outside-window',datedCount:dated.length,spanDays:money(spanDays)};
  // The accepted comp sample is what matters. If 100 query results contain only 72 exact
  // model matches, estimate the velocity of those 72 exact matches rather than the broad query.
  const ratePerDay=sample/spanDays;
  const rawEstimated=ratePerDay*windowDays;
  // Do not let a very short burst create an absurdly precise projection. Short spans are
  // still shown as a low-confidence estimate, but are conservatively capped.
  const multiplierCap=spanDays<7?6:spanDays<14?8:12;
  const estimated=Math.max(observed,Math.min(rawEstimated,Math.max(observed*multiplierCap,observed)));
  const confidence=spanDays>=28&&coverage>=.85?'high':spanDays>=10&&coverage>=.75?'medium':'low';
  return {available:true,estimatedSold:Math.round(estimated),rawEstimatedSold:Math.round(rawEstimated),observedSold:observed,datedCount:dated.length,coverage:money(coverage),spanDays:money(spanDays),ratePerDay:money(ratePerDay),windowDays,confidence};
}
function computeSellThrough(soldPool, activePool) {
  // A provider outage/quota exhaustion is unknown data, never evidence of 0% sell-through.
  if (soldPool?.error || soldPool?.provider === 'none') {
    return {available:false,value:null,label:'Unavailable',confidence:'none',providerUnavailable:true,error:soldPool?.error||'Sold data unavailable'};
  }
  const sold = Math.max(0,Number(soldPool?.count)||0), active = Math.max(0,Number(activePool?.count)||0);
  const soldSample = Number(soldPool?.sampleCount)||0, activeSample = Number(activePool?.sampleCount)||0;
  const evidence = soldSample + activeSample;
  if (!sold && !active && evidence === 0) return {available:false,value:null,label:'Unavailable',confidence:'none'};
  if(activePool?.mode==='active' && activePool?.denominatorTrusted===false && (Number(activePool?.checked)||0)>=30){
    return {available:false,value:null,label:'Unavailable',confidence:'low',denominatorUncertain:true,note:'Active market total is sample-limited, so STR denominator is not trustworthy.'};
  }
  if (active === 0 && sold >= 2) {
    const lb = clamp(sold * 100,100,999);
    return {available:true,value:lb,label:`≥${Math.round(lb)}%`,lowerBound:true,confidence:evidence>=5?'medium':'low'};
  }
  if (active <= 0) return {available:false,value:null,label:'Unavailable',confidence:'low'};
  const observed = clamp((sold/active)*100,0,999);
  const lowerBound = !!soldPool?.capped;
  const baseConfidence = (soldPool?.totalTrusted && activePool?.totalTrusted) ? 'high' : evidence>=12 ? 'medium' : evidence>=6 ? 'low' : 'very-low';
  if(lowerBound){
    const velocity=estimateCappedSoldCount(soldPool,90);
    if(velocity.available){
      const estimated=clamp((velocity.estimatedSold/active)*100,0,999);
      // Low-confidence burst estimates are informative but are not allowed to drive Buy/Pass.
      // Keep the conservative observed floor as value and expose the estimate separately.
      if(velocity.confidence==='low') return {available:true,value:observed,label:`≥${observed.toFixed(observed<10?1:0)}%`,lowerBound:true,confidence:baseConfidence,estimatedValue:estimated,estimatedLabel:`~${estimated.toFixed(estimated<10?1:0)}%`,velocity};
      // Extremely high extrapolated STRs are directionally useful but falsely precise.
      // Keep the observed floor as the decision value and show a guarded qualitative label.
      if(estimated>200) return {available:true,value:observed,label:'Very high',lowerBound:true,estimated:true,unstableEstimate:true,observedValue:observed,observedLabel:`≥${observed.toFixed(observed<10?1:0)}%`,confidence:'medium',estimatedValue:estimated,estimatedLabel:'>200%',velocity,note:'Velocity estimate exceeds 200%; direction is strong but exact percentage is unstable.'};
      return {available:true,value:estimated,label:`~${estimated.toFixed(estimated<10?1:0)}%`,lowerBound:true,estimated:true,observedValue:observed,observedLabel:`≥${observed.toFixed(observed<10?1:0)}%`,confidence:velocity.confidence,estimatedValue:estimated,estimatedLabel:`~${estimated.toFixed(estimated<10?1:0)}%`,velocity};
    }
  }
  return {available:true,value:observed,label:`${lowerBound?'≥':''}${observed.toFixed(observed<10?1:0)}%`,lowerBound,confidence:baseConfidence};
}
function friendlyListPrice(n) {
  n=Number(n);
  if(!Number.isFinite(n)||n<=0)return null;
  return money(Math.max(.99,Math.floor(n)+.99));
}
function pricingFromSold(pool) {
  const prices = robustPrices((pool?.items||[]).map(x=>x.gross).filter(Number.isFinite));
  if (!prices.length) return {available:false,asp:null,median:null,count:0,verified:false,low:null,high:null,tiers:{available:false,quick:null,market:null,highAsk:null,confidence:'none',note:'No usable sold prices'}};
  const med = median(prices), avg = prices.reduce((a,b)=>a+b,0)/prices.length;
  const q25=quantile(prices,.25), q75=quantile(prices,.75);
  const asp = money((med*0.65)+(avg*0.35));
  let tiers;
  if(prices.length<3){
    tiers={available:false,quick:null,market:friendlyListPrice(med),highAsk:null,confidence:'low',note:'Too few validated sold comps for three pricing targets.'};
  }else if(prices.length<5){
    tiers={available:false,quick:null,market:friendlyListPrice(med),highAsk:null,confidence:'low',note:`${prices.length} validated sold comps — market price shown, but more sales are needed for reliable quick/high targets.`};
  }else{
    tiers={available:true,quick:friendlyListPrice(q25),market:friendlyListPrice(med),highAsk:friendlyListPrice(q75),confidence:prices.length>=10?'high':'medium',note:`Based on ${prices.length} validated sold comps after outlier filtering.`};
  }
  return {available:true,asp,median:money(med),count:prices.length,verified:prices.length>=3,low:money(q25),high:money(q75),tiers};
}
function recommendedSoldPages(activeCount,minStr,maxPages=2){
  const active=Math.max(0,Number(activeCount)||0), threshold=Math.max(0,Number(minStr)||0), cap=Math.max(1,Math.floor(Number(maxPages)||1));
  if(!active||!threshold||cap===1)return {pages:1,onePageLowerBound:active?money(10000/active):null,reason:'one-page-default'};
  const onePageLowerBound=(100/active)*100;
  if(onePageLowerBound>=threshold)return {pages:1,onePageLowerBound:money(onePageLowerBound),reason:'one-page-already-clears-threshold'};
  return {pages:Math.min(2,cap),onePageLowerBound:money(onePageLowerBound),reason:'second-page-can-resolve-threshold'};
}
function estimateWeightLb(title='') {
  const s=title.toLowerCase();
  if (/hat|cap|beanie/.test(s)) return .35;
  if (/shirt|tee|t-shirt|blouse|tank/.test(s)) return .65;
  if (/sweater|hoodie|sweatshirt/.test(s)) return 1.3;
  if (/jean|pants|trouser/.test(s)) return 1.5;
  if (/shoe|sneaker|boot/.test(s)) return 2.6;
  if (/jacket|coat/.test(s)) return 2.2;
  if (/game|disc|dvd|blu-ray/.test(s)) return .35;
  if (/camera|lens/.test(s)) return 2.0;
  if (/figure|doll|toy/.test(s)) return 1.0;
  if (/bag|backpack|purse/.test(s)) return 1.4;
  if (/lamp|vase|decor|ceramic|glass/.test(s)) return 3.0;
  return 1.25;
}
function acquisitionCost({manualPrice,visiblePrice,binsMode,pricePerLb,title}) {
  const m=Number(manualPrice); if (Number.isFinite(m) && m>=0) return {known:true,cost:money(m),source:'manual'};
  if (binsMode) {
    const ppl=Number(pricePerLb); if (Number.isFinite(ppl) && ppl>0) {
      const wt=estimateWeightLb(title); return {known:true,cost:money(ppl*wt),source:'bins estimate',weightLb:wt};
    }
  }
  const v=Number(visiblePrice); if (Number.isFinite(v) && v>=0) return {known:true,cost:money(v),source:'detected tag'};
  return {known:false,cost:null,source:'unknown'};
}

// ---------------------------------------------------------------------------
// ORBIT 1.7 — Marketplace Title Distillation
//
// The listing title selected from image/market evidence is the primary truth source.
// ORBIT now keeps that title intact, creates progressively smaller search hypotheses,
// and lets free eBay active-result clusters prove which title terms are anchors.
// Pricing and STR then use the SAME direct title-to-title matcher on sold and active
// listings so a broad raw marketplace result count cannot masquerade as exact demand.
// ---------------------------------------------------------------------------
const TITLE_DROP = new Set(`
  new used preowned pre owned sealed open box nwt nwot nib bnwt tested works working
  authentic genuine original real oem rare vtg vintage mint excellent clean listing sale
  mens men's man men womens women's woman women unisex size sz
  black white blue red green brown grey gray dark light navy indigo teal aqua pink purple orange yellow
  silver gold tan beige cream chocolate wheat multicolor assorted
  free shipping fast choose
`.split(/\s+/).filter(Boolean));
const TITLE_LOW_WEIGHT = new Set(`
  leather suede metal plastic wood cotton wool canvas denim graphic print zip zipper lace laces
  adjustable comfort casual athletic small large mini portable compact
  charger battery case box strap
`.split(/\s+/).filter(Boolean));
const TITLE_FEATURE_LOW = new Set(`
  zoom fly low top line pro digital action single handle
`.split(/\s+/).filter(Boolean));

function normalizeTitleText(text=''){
  return String(text)
    .replace(/\bx\s*[- ]\s*men\b/ig,'xmen')
    .replace(/\bl[.\s-]*l[.\s-]*bean\b/ig,'ll bean')
    .replace(/\bray\s*[- ]\s*ban\b/ig,'ray ban')
    .replace(/\bfisher\s*[- ]\s*price\b/ig,'fisher price')
    .replace(/\btoy\s*[- ]\s*biz\b/ig,'toy biz')
    .replace(/\b(?:for\s+)?parts(?:\s+or|\s*\/)?\s*repair\b/ig,' ')
    .replace(/\bno\s+(?:sound|power|audio|display|video)\b/ig,' ')
    .replace(/\b(?:as\s*is|broken|untested)\b/ig,' ')
    .replace(/\$\s*\d+(?:[.,]\d+)?/g,' ')
    .replace(/\b(?:msrp|retail|value|price)\s*[:$]?\s*\d+(?:[.,]\d+)?\b/ig,' ')
    .replace(/\b\d{1,3}\s*[x×]\s*\d{1,3}(?:\s*[x×]\s*\d{1,3})?\b/ig,' ')
    .replace(/\b\d+(?:\.\d+)?\s*(?:inches?|inch|in|cm|mm|ft|feet|foot|fl\s*oz|oz|ml)\b/ig,' ')
    .replace(/\b\d+(?:\.\d+)?\s*(?:mp|megapixels?)\b/ig,' ')
    .replace(/\b(?:size|sz|waist|inseam|chest|neck|sleeve)\s*[:#-]?\s*\d+(?:\.\d+)?(?:\s+\d+\/\d+)?\b/ig,' ')
    .replace(/\b(?:mens?|womens?|men's|women's)\s*[:#-]?\s*\d+(?:\.\d+)?\b/ig,' ')
    .replace(/\b\d{1,2}\.\d+\b/g,' ')
    .replace(/\s+/g,' ').trim();
}
function titleDistillTokens(text=''){
  const toks=tokenize(normalizeTitleText(text));
  const out=[];
  for(const t of toks){
    if(TITLE_DROP.has(t))continue;
    if(/^(?:xxxs|xxs|xs|s|m|l|xl|xxl|xxxl|[2-9]xl)$/.test(t))continue;
    if(!out.includes(t))out.push(t);
  }
  return out;
}
function titleModelIds(tokens=[]){
  const ids=[];
  for(const t of tokens){
    if(/^(?:19\d\d|20\d\d)$/.test(t))continue;
    if(/^\d+x$/.test(t))continue; // zoom multiplier, not a model
    if((/[a-z]/.test(t)&&/\d/.test(t)) || /^\d{3,8}$/.test(t)) ids.push(t);
  }
  return [...new Set(ids)];
}
function titleCategory(tokens=[]){ return canonicalCategory(tokens)||canonicalCategory(queryTokens(tokens.join(' '))); }
function titleTokenWeight(t,i,tokens=[]){
  const modelIds=titleModelIds(tokens);
  const cat=String(titleCategory(tokens)||'').split(/\s+/).filter(Boolean);
  if(modelIds.includes(t))return 6;
  if(cat.includes(t)||QUERY_CATEGORY.has(t))return 3.2;
  if(/^(?:19\d\d|20\d\d)$/.test(t))return 2.2;
  if(/^\d{2}s$/.test(t)||t==='y2k')return 1.2;
  if(TITLE_LOW_WEIGHT.has(t))return .7;
  if(TITLE_FEATURE_LOW.has(t))return 1.05;
  let w=1.65;
  if(i<4)w+=.55;
  if(t.length>=7)w+=.2;
  return w;
}
function titleDistillationQueries(title='',keywords=''){
  const source=`${keywords} ${title}`.trim();
  const toks=titleDistillTokens(source);
  if(!toks.length)return [];
  const weighted=toks.map((t,i)=>({t,i,w:titleTokenWeight(t,i,toks)}));
  const cat=String(titleCategory(toks)||'').split(/\s+/).filter(Boolean);
  const models=titleModelIds(toks);
  const seen=new Set(),out=[];
  const add=(id,arr,intent)=>{
    const keep=[]; for(const t of arr){if(t&&!keep.includes(t))keep.push(t);}
    const q=keep.join(' ').trim(); if(!q||seen.has(q))return; seen.add(q);
    out.push({id,query:q,intent});
  };
  // Keep the cleaned source title as the first hypothesis. We no longer silently discard
  // potentially valuable title terms before the marketplace has had a chance to test them.
  add('title-full',toks.slice(0,12),'cleaned listing title');
  const sizes=[10,8,6,5,4];
  for(const n of sizes){
    const top=new Set(weighted.slice().sort((a,b)=>b.w-a.w||a.i-b.i).slice(0,Math.min(n,weighted.length)).map(x=>x.t));
    for(const x of [...models,...cat])top.add(x);
    const arr=toks.filter(t=>top.has(t)).slice(0,12);
    add(`title-top-${n}`,arr,`top ${n} title constraints preserved in title order`);
  }
  return out.slice(0,6);
}
function titlePhrases(tokens=[]){
  const out=[];
  for(let n=3;n>=2;n--)for(let i=0;i+n<=tokens.length;i++){
    const p=tokens.slice(i,i+n);
    if(p.every(t=>TITLE_LOW_WEIGHT.has(t)||TITLE_FEATURE_LOW.has(t)||QUERY_CATEGORY.has(t)))continue;
    out.push(p);
  }
  return out;
}
function titleCompSimilarity(targetTitle='',candidateTitle=''){
  const target=titleDistillTokens(targetTitle), cand=titleDistillTokens(candidateTitle);
  if(!target.length||!cand.length)return {accept:false,score:0,tokenRecall:0,phraseRecall:0,objectOk:false,modelOk:false,conflictingModel:false};
  const cset=new Set(cand);
  const weights=target.map((t,i)=>titleTokenWeight(t,i,target));
  const totalW=weights.reduce((a,b)=>a+b,0)||1;
  let hitW=0; for(let i=0;i<target.length;i++)if(cset.has(target[i]))hitW+=weights[i];
  const tokenRecall=hitW/totalW;
  const phrases=titlePhrases(target);
  let phraseTotal=0,phraseHit=0;
  for(const p of phrases){
    const w=p.reduce((sum,t)=>sum+titleTokenWeight(t,target.indexOf(t),target),0)/p.length;
    phraseTotal+=w; if(phraseInTokens(p,cand))phraseHit+=w;
  }
  const phraseRecall=phraseTotal?phraseHit/phraseTotal:tokenRecall;
  const category=titleCategory(target);
  const objectOk=!category||categoryTitleMatch(category,cand);
  const targetModels=titleModelIds(target), candModels=titleModelIds(cand);
  const modelOk=!targetModels.length||targetModels.some(x=>cset.has(x));
  const conflictingModel=targetModels.length>0 && candModels.some(x=>!targetModels.includes(x)) && !modelOk;
  // Physical scale is a real variant for figures/dolls/plush/statues, but usually noise for apparel/footwear.
  // This catches cases like a target "mini" die-cast figure being mixed with a 12-inch figure.
  const scaleSensitive=/figure|figurine|doll|plush|statue|sculpture|toy/.test(String(category||''));
  const targetMini=scaleSensitive&&/\b(?:mini|miniature)\b/i.test(String(targetTitle));
  const candidateMeasure=String(candidateTitle).match(/\b(\d+(?:\.\d+)?)\s*(?:inches?|inch|in|["”″])\b/i);
  const scaleConflict=!!(targetMini&&candidateMeasure&&Number(candidateMeasure[1])>=6);
  let score=.64*tokenRecall+.22*phraseRecall+.10*(objectOk?1:0)+.04*(modelOk?1:0);
  if(!objectOk)score-=.22;
  if(targetModels.length&&!modelOk)score-=.34;
  if(conflictingModel)score-=.18;
  if(scaleConflict)score-=.30;
  score=clamp(score,0,1);
  const accept=modelOk&&objectOk&&!scaleConflict&&score>=.54&&(tokenRecall>=.50||phraseRecall>=.42);
  return {accept,score:money(score),tokenRecall:money(tokenRecall),phraseRecall:money(phraseRecall),objectOk,modelOk,conflictingModel,scaleConflict,targetModels};
}
function titleAnchorCoverage(targetTitle='',rows=[]){
  const target=titleDistillTokens(targetTitle); if(!target.length||!rows.length)return 0;
  const weights=target.map((t,i)=>titleTokenWeight(t,i,target)); const total=weights.reduce((a,b)=>a+b,0)||1;
  let sum=0;
  for(let i=0;i<target.length;i++){
    let hits=0; for(const row of rows){if(new Set(titleDistillTokens(row.title||'')).has(target[i]))hits++;}
    sum+=weights[i]*(hits/rows.length);
  }
  return sum/total;
}
function queryTitleCoverage(targetTitle='',query=''){
  const target=titleDistillTokens(targetTitle); if(!target.length)return 0;
  const qset=new Set(titleDistillTokens(query));
  const weights=target.map((t,i)=>titleTokenWeight(t,i,target));
  const total=weights.reduce((a,b)=>a+b,0)||1;
  let hit=0; for(let i=0;i<target.length;i++)if(qset.has(target[i]))hit+=weights[i];
  return hit/total;
}
function queryTitleTerms(targetTitle='',query=''){
  const target=titleDistillTokens(targetTitle), qset=new Set(titleDistillTokens(query));
  const ranked=target.map((t,i)=>({t,w:titleTokenWeight(t,i,target),i})).sort((a,b)=>b.w-a.w||a.i-b.i);
  return {retained:ranked.filter(x=>qset.has(x.t)).map(x=>x.t),dropped:ranked.filter(x=>!qset.has(x.t)).map(x=>x.t)};
}
function scoreTitleDistillationCandidate(targetTitle='',pool={},meta={}){
  const rows=(pool?.rawItems||[]).filter(x=>x&&x.title).slice(0,30);
  if(!rows.length)return {...meta,query:pool?.query||meta.query||'',score:0,precision:0,productPurity:0,titleSimilarity:0,anchorCoverage:0,checked:0,matched:0,confidence:'none',reason:'no-active-results'};
  const sims=rows.map(r=>titleCompSimilarity(targetTitle,r.title));
  const matched=sims.filter(x=>x.accept).length;
  const purity=matched/rows.length;
  const avg=sims.reduce((a,b)=>a+Number(b.score||0),0)/rows.length;
  const coverage=titleAnchorCoverage(targetTitle,rows);
  const query=pool?.query||meta.query||'';
  const queryCoverage=queryTitleCoverage(targetTitle,query);
  const terms=queryTitleTerms(targetTitle,query);
  const cluster=clusterObjectConsistency(rows);
  const qlen=titleDistillTokens(query).length;
  // Query selection is title-driven: marketplace purity proves that a reduction is safe,
  // while queryCoverage prevents a broad query from winning merely because it returns a
  // superficially consistent category. STR itself is NOT title-matched after selection.
  const breadth=purity>=.78&&queryCoverage>=.62?clamp((11-qlen)/8,0,1):0;
  let score=purity*38+avg*20+coverage*15+queryCoverage*20+cluster.dominance*5+breadth*2;
  if(rows.length<5)score-=4;
  if(purity<.45&&rows.length>=8)score-=12;
  if(queryCoverage<.42)score-=10;
  score=clamp(score,0,100);
  const confidence=score>=78&&purity>=.70&&coverage>=.58&&queryCoverage>=.58?'high':score>=62&&purity>=.56&&queryCoverage>=.48?'medium':score>=45&&purity>=.4?'low':'poor';
  return {...meta,query,score:money(score),precision:money(purity),productPurity:money(purity),lexicalPrecision:money(purity),titleSimilarity:money(avg),anchorCoverage:money(coverage),queryCoverage:money(queryCoverage),retainedTitleTerms:terms.retained,droppedTitleTerms:terms.dropped,clusterConsistency:money(cluster.dominance),checked:rows.length,matched,confidence,reason:`${matched}/${rows.length} active titles support this title-derived query; query keeps ${Math.round(queryCoverage*100)}% of weighted title identity and marketplace anchor coverage is ${Math.round(coverage*100)}%`};
}
function rankTitleDistillationCandidates(candidates=[],targetTitle=''){
  return candidates.map(x=>({...x,validation:scoreTitleDistillationCandidate(targetTitle,x.active,x)}))
    .sort((a,b)=>b.validation.score-a.validation.score || b.validation.productPurity-a.validation.productPurity || b.validation.queryCoverage-a.validation.queryCoverage || b.validation.anchorCoverage-a.validation.anchorCoverage || titleDistillTokens(a.query).length-titleDistillTokens(b.query).length);
}
function filterMarketPoolAgainstTitle(pool={},targetTitle=''){
  const raw=(pool?.rawItems||[]).filter(x=>x&&x.title);
  const accepted=[]; const rejected=[];
  for(const r of raw){
    const m=titleCompSimilarity(targetTitle,r.title);
    const row={...r,matchClass:m.accept?'title-match':'reject',matchScore:money(m.score),matchReason:m.accept?'direct-title-match':'direct-title-mismatch'};
    if(m.accept)accepted.push(row); else rejected.push(row);
  }
  const checked=raw.length, purity=checked?accepted.length/checked:0;
  const avgSim=checked?raw.reduce((sum,r)=>sum+Number(titleCompSimilarity(targetTitle,r.title).score||0),0)/checked:0;
  const coverage=checked?titleAnchorCoverage(targetTitle,raw):0;
  const totalRaw=Number(pool?.totalRaw);
  let count=accepted.length, denominatorTrusted=false, totalTrusted=false, estimatedFromSample=false;
  if(pool?.mode==='active'){
    const exhaustive=Number.isFinite(totalRaw)&&totalRaw>=0&&totalRaw<=checked;
    if(exhaustive){count=accepted.length;denominatorTrusted=true;totalTrusted=true;}
    else if(Number.isFinite(totalRaw)&&checked>=12&&purity>=.72&&avgSim>=.57&&coverage>=.58){
      count=Math.max(accepted.length,Math.round(totalRaw*purity));
      denominatorTrusted=true; totalTrusted=true; estimatedFromSample=true;
    }
  }else{
    // For Trawl sold results, rawItems contains every returned sold row (up to the page cap).
    // The matched count—not the broad query count—is the sold numerator.
    count=accepted.length;
    denominatorTrusted=true;
    totalTrusted=!pool?.capped;
  }
  return {...pool,count,sampleCount:accepted.length,checked,ratio:money(purity),titlePurity:money(purity),titleSimilarity:money(avgSim),anchorCoverage:money(coverage),items:accepted,closeItems:rejected.slice(0,8),totalTrusted,denominatorTrusted,estimatedFromSample,matchedToTitle:true};
}

function classifyMarket(soldCount=0,activeCount=0) {
  const sold=Math.max(0,Number(soldCount)||0), active=Math.max(0,Number(activeCount)||0);
  if(sold===0 && active<=3) return {key:'rare',label:'Rare / insufficient data',scarce:true,veryThin:true};
  if(sold<=2 && active<=10) return {key:'scarce',label:'Scarce market',scarce:true,veryThin:true};
  if(sold<5 && active<=25) return {key:'limited',label:'Limited market',scarce:true,veryThin:false};
  if(sold<5 && active>=50) return {key:'oversupplied',label:'Low demand / high supply',scarce:false,veryThin:false};
  return {key:'normal',label:'Normal market',scarce:false,veryThin:false};
}
function decision({title,pricing,str,cost,soldCount=0,activeCount=0,minValue=15,minStr=20,minProfit=10,feeRate=.14,shipCost=8,supplies=1}) {
  const sale=Number(pricing?.asp); const fee = Number.isFinite(sale) ? sale*feeRate : null;
  const maxBuy = Number.isFinite(sale) ? Math.max(0,sale-fee-shipCost-supplies-minProfit) : null;
  const projected = Number.isFinite(sale) && cost?.known ? sale-fee-shipCost-supplies-cost.cost : null;
  const valueOkay=Number.isFinite(sale) && sale>=minValue;
  const strOkay=!!str?.available && Number(str.value)>=minStr;
  const profitOkay=Number.isFinite(maxBuy) && maxBuy>0 && (!cost?.known || cost.cost<=maxBuy);
  const market=classifyMarket(soldCount,activeCount);
  // In a genuinely thin market, low STR is weak evidence: few sales can mean scarcity rather than weak demand.
  // STR therefore cannot cause a PASS by itself when both sold and active supply are scarce.
  const scarceStrOverride=market.scarce && Number(soldCount)<5;
  const economicBuy=valueOkay && profitOkay;
  let verdict;
  if(!pricing?.available && market.scarce) verdict='REVIEW';
  else if(economicBuy && (strOkay || scarceStrOverride)) verdict='BUY';
  else verdict='PASS';
  const buy=verdict==='BUY';
  const reasons=[];
  if(market.scarce) reasons.push(`${market.label}: low sales are not treated as automatic weak demand`);
  if (!pricing?.available) reasons.push(market.scarce?'Too little sold pricing to value confidently':'No usable sold pricing');
  else if (!valueOkay) reasons.push(`ASP below $${minValue}`);
  if (!str?.available) {
    if(!market.scarce) reasons.push('Sell-through unavailable');
  } else if (!strOkay && !scarceStrOverride) reasons.push(`Sell-through below ${minStr}%`);
  else if (!strOkay && scarceStrOverride) reasons.push('Low STR sample overridden because active supply is also scarce');
  if (Number.isFinite(maxBuy) && maxBuy<=0) reasons.push('No room for target profit');
  if (cost?.known && Number.isFinite(maxBuy) && cost.cost>maxBuy) reasons.push('Cost exceeds max buy');
  return {verdict,maxBuy:Number.isFinite(maxBuy)?money(maxBuy):null,projectedNet:Number.isFinite(projected)?money(projected):null,fee:Number.isFinite(fee)?money(fee):null,reasons,buy,marketState:market.label,marketKey:market.key,scarcityOverride:scarceStrOverride};
}

module.exports={clamp,money,median,quantile,robustPrices,tokenize,usefulTokens,distinctiveTokens,tokenSimilarity,titleMatches,compMatch,cleanCandidateTitle,inferIdentity,stripQueryNoise,queryTokens,queryProfiles,identityCompleteness,identityCompletenessV2,buildIdentityGraph,synthesizeConstraintQueries,marketRefinement,scoreQueryCandidate,rankQueryCandidates,categorySchema,parseMoney,shippingValue,normalizeMarketResults,normalizeTrawlSold,chooseMarketPool,estimateCappedSoldCount,computeSellThrough,pricingFromSold,recommendedSoldPages,estimateWeightLb,acquisitionCost,classifyMarket,decision,normalizeTitleText,titleDistillTokens,titleDistillationQueries,titleCompSimilarity,titleAnchorCoverage,queryTitleCoverage,queryTitleTerms,scoreTitleDistillationCandidate,rankTitleDistillationCandidates,filterMarketPoolAgainstTitle};
