'use strict';

const STOP = new Set(`a an and are as at be by for from in is it of on or the to with without used new vintage rare lot bundle size color mens men's womens women's unisex genuine authentic original preowned pre-owned condition ebay mercari poshmark etsy amazon walmart target listing sale sold`.split(/\s+/));
const GENERIC = new Set(`item items product products accessory accessories collectible collectibles clothing apparel gear equipment misc unknown`.split(/\s+/));

function clamp(n, min, max) { return Math.max(min, Math.min(max, n)); }
function money(n) { return Math.round((Number(n) || 0) * 100) / 100; }
function median(values) {
  const a = values.filter(Number.isFinite).slice().sort((x,y)=>x-y);
  if (!a.length) return null;
  const m = Math.floor(a.length/2);
  return a.length % 2 ? a[m] : (a[m-1] + a[m]) / 2;
}
function quantile(values, q) {
  const a = values.filter(Number.isFinite).slice().sort((x,y)=>x-y);
  if (!a.length) return null;
  const p = (a.length - 1) * q, lo = Math.floor(p), hi = Math.ceil(p);
  if (lo === hi) return a[lo];
  return a[lo] + (a[hi] - a[lo]) * (p - lo);
}
function robustPrices(values) {
  const a = values.filter(v => Number.isFinite(v) && v > 0 && v < 100000);
  if (a.length < 4) return a;
  const q1 = quantile(a, .25), q3 = quantile(a, .75), iqr = Math.max(1, q3-q1);
  const lo = Math.max(0.5, q1 - 1.75*iqr), hi = q3 + 1.75*iqr;
  const filtered = a.filter(v => v >= lo && v <= hi);
  return filtered.length >= Math.max(3, Math.floor(a.length * .55)) ? filtered : a;
}
function tokenize(s='') {
  return String(s).toLowerCase().replace(/[’']/g,'').replace(/[^a-z0-9]+/g,' ').trim().split(/\s+/).filter(Boolean);
}
function usefulTokens(s='') {
  return tokenize(s).filter(t => !STOP.has(t) && !GENERIC.has(t) && (t.length > 1 || /\d/.test(t)));
}
function distinctiveTokens(s='') {
  return usefulTokens(s).filter(t => t.length >= 3 || /\d/.test(t));
}
function tokenSimilarity(a,b) {
  const A = new Set(usefulTokens(a)), B = new Set(usefulTokens(b));
  if (!A.size || !B.size) return 0;
  let inter=0; for (const t of A) if (B.has(t)) inter++;
  return inter / Math.max(1, Math.min(A.size, B.size));
}
function titleMatches(query,title,{min=0.42}={}) {
  const q = distinctiveTokens(query), t = new Set(usefulTokens(title));
  if (!q.length) return false;
  const hits = q.filter(x => t.has(x)).length;
  const ratio = hits / q.length;
  const modelTokens = q.filter(x => /\d/.test(x) && /[a-z]/i.test(x));
  const modelOkay = !modelTokens.length || modelTokens.some(x => t.has(x));
  return modelOkay && (ratio >= min || hits >= Math.min(3,q.length));
}
function cleanCandidateTitle(s='') {
  return String(s)
    .replace(/\s+[|–—-]\s+(eBay|Mercari|Poshmark|Etsy|Amazon|Walmart).*$/i,'')
    .replace(/\b(Buy|Shop|For Sale|Free Shipping|Fast Shipping|New Listing)\b.*$/i,'')
    .replace(/\s+/g,' ').trim().slice(0,140);
}
function inferIdentity(matches=[], keywords='') {
  const rows = matches.filter(x=>x && x.title).slice(0,20);
  if (!rows.length) {
    const k = cleanCandidateTitle(keywords);
    return { title:k || 'Unidentified item', confidence:k ? .58 : .15, evidence:[], familyQuery:k || '' };
  }
  const freq = new Map();
  for (const r of rows) for (const t of new Set(usefulTokens(r.title))) freq.set(t,(freq.get(t)||0)+1);
  const trusted = /ebay|mercari|poshmark|etsy|grailed|depop|walmart|amazon|target|shop|store/i;
  let best = null;
  for (const r of rows) {
    const title = cleanCandidateTitle(r.title);
    const toks = usefulTokens(title);
    let score = 0;
    for (const t of toks) score += Math.min(4,freq.get(t)||0);
    score += trusted.test(`${r.source||''} ${r.link||''}`) ? 6 : 0;
    if (r.price) score += 2;
    if (keywords) score += tokenSimilarity(keywords,title)*8;
    score -= Math.max(0,toks.length-12)*.25;
    if (!best || score > best.score) best = {title,score,row:r};
  }
  const common = [...freq.entries()].filter(([,n])=>n>=2).sort((a,b)=>b[1]-a[1]).map(([t])=>t);
  let family = usefulTokens(best.title).filter(t => common.includes(t) || /\d/.test(t)).slice(0,7);
  if (family.length < 3) family = usefulTokens(best.title).slice(0,6);
  if (keywords) family = [...new Set([...usefulTokens(keywords),...family])].slice(0,7);
  const agreement = rows.filter(r=>tokenSimilarity(best.title,r.title)>=.45).length / rows.length;
  return {
    title: best.title,
    confidence: clamp(.45 + agreement*.45 + (keywords ? .07 : 0), .2, .96),
    evidence: rows.slice(0,8).map(r=>({title:cleanCandidateTitle(r.title),source:r.source||'',link:r.link||'',thumbnail:r.thumbnail||r.image||''})),
    familyQuery: family.join(' ')
  };
}


// Query engine: separate product identity from marketplace-title noise.
const QUERY_NOISE = new Set(`
  a an and are as at be by for from in is it of on or the to with without
  sale sold listing ebay mercari poshmark etsy amazon walmart target shop store
  buy fast free shipping ship ships choose selection assorted assorted
  new used preowned pre owned sealed open box nwt nwot nib bnwt vintage vtg rare
  authentic genuine original real oem knock off knockoff not replica compatible replacement
  look looks wow nice great excellent mint clean tested works working made chunky
  mens men's man men womens women's woman women unisex size sz
  black white blue red green brown grey gray dark light navy indigo teal aqua aquarelle
  chocolate desert tan beige cream pink purple orange yellow silver gold
  wide long side pair lot bundle
`.split(/\s+/).filter(Boolean));

const QUERY_CATEGORY = new Set(`
  shoe shoes sneaker sneakers boot boots sandal sandals heel heels
  jean jeans denim pants pant shorts short shirt shirts tee tshirt sweater hoodie jacket coat
  hat cap beanie bag purse backpack
  headphones headphone headset earbuds wireless neckband noise cancelling canceling
  valve cartridge faucet handle single replacement
  water gun toy figure doll game camera lens phone smartphone
  ornament ornaments decoration decorations figurine figurines statue statues sculpture sculptures plaque plaques
  mug mugs cup cups glass glasses plate plates bowl bowls vase vases planter planters
  plush stuffed pillow pillows blanket blankets towel towels robe robes
  clock clocks lamp lamps light lights sign signs frame frames print prints poster posters
  book books dvd dvds cd cds record records vinyl cassette cassettes
  beach cover blanket towel robe
  running hiking leather lace western cowgirl embroidered utility work washed stretch
`.split(/\s+/).filter(Boolean));

function stripQueryNoise(text='') {
  return String(text)
    // Storage/capacity variants are part of electronics identity, unlike clothing measurements.
    .replace(/\b(\d{2,4})\s*(gb|tb)\b/ig, '$1$2')
    // Remove seller-language phrases before tokenization so words such as "not" can never become descriptors.
    .replace(/\bnot\s+(?:a\s+)?(?:knock\s*[- ]?off|replica|fake)\b/ig,' ')
    .replace(/\b(?:100\s*%\s*)?(?:authentic|genuine|real|original)\b/ig,' ')
    .replace(/\b(?:free|fast)\s+shipping\b/ig,' ')
    .replace(/\b(?:new|just)\s+listed\b/ig,' ')
    // Material composition is not a product identifier (e.g. "100% cotton").
    .replace(/\b\d{1,3}\s*%\s*(?:cotton|polyester|wool|silk|linen|nylon|rayon|acrylic|spandex|elastane|leather)?\b/ig,' ')
    .replace(/\b100\s+(?:percent\s+)?(?:cotton|polyester|wool|silk|linen|nylon|rayon|acrylic|spandex|elastane|leather)\b/ig,' ')
    .replace(/\$\s*\d+(?:[.,]\d+)?/g,' ')
    .replace(/\b(?:msrp|retail|value|price)\s*[:$]?\s*\d+(?:[.,]\d+)?\b/ig,' ')
    // Measurements and apparel sizing must never become model/style numbers.
    .replace(/\b\d{1,3}\s*[-–—]\s*\d{1,3}(?:\s+\d+\/\d+)?\b/g,' ')
    .replace(/\b\d{1,3}\s+\d+\/\d+\b/g,' ')
    .replace(/\b\d+\/\d+\b/g,' ')
    .replace(/\b\d{1,3}\s*[x×]\s*\d{1,3}(?:\s*[x×]\s*\d{1,3})?\b/ig,' ')
    .replace(/\b\d+(?:\.\d+)?\s*(?:inches?|inch|in|cm|mm|ft|feet|foot)\b/ig,' ')
    .replace(/\b\d+(?:\.\d+)?\s*[\"”″']+/g,' ')
    .replace(/\b(?:size|sz|mens?|womens?|men's|women's|waist|inseam|chest|neck|sleeve)\s*[:#-]?\s*\d+(?:\.\d+)?(?:\s+\d+\/\d+)?\b/ig,' ')
    .replace(/\b\d{1,2}\.\d+\b/g,' ')
    .replace(/\b(?:nwt|nwot|nib|bnwt|pre[- ]?owned|open box)\b/ig,' ')
    .replace(/\s+/g,' ').trim();
}

function queryTokens(text='') {
  return tokenize(stripQueryNoise(text)).filter(t => !QUERY_NOISE.has(t));
}

function queryBrandPrefix(tokens=[]) {
  const t=tokens.filter(x=>!/^(?:19\d\d|20\d\d)$/.test(x));
  if(t[0]==='dr'&&t[1]==='martens') return ['dr','martens'];
  if(t[0]==='old'&&t[1]==='west') return ['old','west'];
  if(t[0]==='hoka'&&t[1]==='one') return ['hoka'];
  if(t[0]==='levis'||t[0]==='levi') return ['levis'];
  return t[0]?[t[0]]:[];
}

function canonicalCategory(tokens=[]) {
  const has=(...xs)=>xs.every(x=>tokens.includes(x));
  // Prefer specific compound product types first. These describe WHAT the item is,
  // and therefore belong in STR queries even when a title also contains a franchise,
  // character, collection, material, holiday, color, or other descriptive words.
  const compounds=[
    [['valve','cartridge'],'valve cartridge'],
    [['water','gun'],'water gun'],
    [['running','shoes'],'running shoes'],[['running','shoe'],'running shoes'],
    [['cowgirl','boots'],'cowgirl boots'],[['cowgirl','boot'],'cowgirl boots'],
    [['western','boots'],'western boots'],[['western','boot'],'western boots'],
    [['beach','cover'],'beach cover'],
    [['sleep','pants'],'sleep pants'],
  ];
  for(const [parts,label] of compounds) if(has(...parts)) return label;

  // Product-head nouns. This is deliberately object-focused: a word such as
  // "Christmas" can describe an ornament, mug, sweater, DVD, etc.; the object noun
  // is much more important for matching sold and active pools to the same item type.
  const heads=[
    ['ornaments','ornament'],['ornament','ornament'],
    ['sculptures','sculpture'],['sculpture','sculpture'],
    ['figurines','figurine'],['figurine','figurine'],['statues','statue'],['statue','statue'],
    ['decorations','decoration'],['decoration','decoration'],['plaques','plaque'],['plaque','plaque'],
    ['headphones','headphones'],['headphone','headphones'],['headsets','headset'],['headset','headset'],
    ['earbuds','earbuds'],['boots','boots'],['boot','boots'],['jeans','jeans'],['jean','jeans'],
    ['shorts','shorts'],['short','shorts'],['shoes','shoes'],['shoe','shoes'],
    ['sandals','sandals'],['sandal','sandals'],['shirts','shirt'],['shirt','shirt'],
    ['sweaters','sweater'],['sweater','sweater'],['hoodies','hoodie'],['hoodie','hoodie'],
    ['jackets','jacket'],['jacket','jacket'],['coats','coat'],['coat','coat'],
    ['hats','hat'],['hat','hat'],['caps','cap'],['cap','cap'],['beanies','beanie'],['beanie','beanie'],
    ['bags','bag'],['bag','bag'],['purses','purse'],['purse','purse'],['backpacks','backpack'],['backpack','backpack'],
    ['mugs','mug'],['mug','mug'],['cups','cup'],['cup','cup'],['glasses','glass'],['glass','glass'],
    ['plates','plate'],['plate','plate'],['bowls','bowl'],['bowl','bowl'],['vases','vase'],['vase','vase'],
    ['planters','planter'],['planter','planter'],['plush','plush'],['pillows','pillow'],['pillow','pillow'],
    ['blankets','blanket'],['blanket','blanket'],['towels','towel'],['towel','towel'],['robes','robe'],['robe','robe'],
    ['clocks','clock'],['clock','clock'],['lamps','lamp'],['lamp','lamp'],['signs','sign'],['sign','sign'],
    ['frames','frame'],['frame','frame'],['prints','print'],['print','print'],['posters','poster'],['poster','poster'],
    ['books','book'],['book','book'],['dvds','dvd'],['dvd','dvd'],['records','record'],['record','record'],
    ['vinyl','vinyl'],['cassettes','cassette'],['cassette','cassette'],['cameras','camera'],['camera','camera'],
    ['lenses','lens'],['lens','lens'],['figures','figure'],['figure','figure'],['dolls','doll'],['doll','doll'],
    ['games','game'],['game','game'],['phones','phone'],['phone','phone'],['smartphones','phone'],['smartphone','phone'],['cartridge','cartridge'],['toys','toy'],['toy','toy']
  ];
  for(const [token,label] of heads) if(tokens.includes(token)) return label;
  return '';
}

function evidenceTokenFrequency(evidence=[]) {
  const freq=new Map();
  for(const row of evidence||[]) {
    const title=typeof row==='string'?row:(row&&row.title)||'';
    const toks=new Set(queryTokens(title));
    for(const t of toks) freq.set(t,(freq.get(t)||0)+1);
  }
  return freq;
}



// Some marketplace identities are phrases rather than independent tokens: "Brain Warp",
// "Red Man Tobacco", "iPhone 12 Pro Max", "Harvey Lewis", etc.  Scoring tokens
// independently can drop one half of the identity and badly widen the active pool.
const GENERIC_FEATURE_WORDS = new Set(`
  art hand carved signed graphic logo patch adjustable poseable talking handheld memory
  limited edition anniversary mashup shimmery tone canvas burlap crystal crystals
  from with works working welcome holiday christmas
`.split(/\s+/).filter(Boolean));

const PHRASE_HARD_NOISE = new Set(`
  a an and are as at be by for from in is it of on or the to with without
  sale sold listing ebay mercari poshmark etsy amazon walmart target shop store buy
  new used preowned sealed nwt nwot nib bnwt vintage vtg rare authentic genuine original real oem
  size sz free fast shipping choose works working
`.split(/\s+/).filter(Boolean));

function identityPhraseTokens(text='') {
  return tokenize(stripQueryNoise(text)).filter(t=>!PHRASE_HARD_NOISE.has(t));
}

function evidencePhraseFrequency(evidence=[]) {
  const freq=new Map();
  for(const row of evidence||[]) {
    const title=typeof row==='string'?row:(row&&row.title)||'';
    const toks=identityPhraseTokens(title);
    for(let n=2;n<=4;n++) for(let i=0;i+n<=toks.length;i++) {
      const phrase=toks.slice(i,i+n).join(' ');
      freq.set(phrase,(freq.get(phrase)||0)+1);
    }
  }
  return freq;
}

function phraseAnchors(tokens=[],brand=[],evidence=[],category='',rawTokens=[]) {
  const out=[];
  const pf=evidencePhraseFrequency(evidence);
  const brandLen=brand.length;
  const categorySet=new Set(String(category||'').split(/\s+/).filter(Boolean));
  const yearRx=/^(?:19\d\d|20\d\d)$/;
  const add=(words,score,reason)=>{
    const clean=words.filter(Boolean);
    if(clean.length<2)return;
    const phrase=clean.join(' ');
    if(out.some(x=>x.phrase===phrase))return;
    out.push({phrase,words:clean,score,reason,rawStart:rawTokens.join(' ').indexOf(phrase)>=0?rawTokens.findIndex((_,i)=>rawTokens.slice(i,i+clean.length).join(' ')===phrase):-1});
  };

  // Electronics model families are especially order-sensitive. Preserve the whole
  // model chain and capacity when present (e.g. apple iphone 12 pro max 256gb).
  const iphone=tokens.indexOf('iphone');
  if(iphone>=0){
    const w=[];
    if(tokens[iphone])w.push(tokens[iphone]);
    for(let j=iphone+1;j<tokens.length && w.length<5;j++){
      const t=tokens[j];
      if(categorySet.has(t)||yearRx.test(t))continue;
      if(/^(?:pro|max|mini|plus|se|ultra|\d{1,2}|\d{2,4}(?:gb|tb))$/.test(t))w.push(t);
      else if(w.length>=2)break;
    }
    add(w,40,'device-model-chain');
  }

  // Rescue ambiguous words that generic filters normally remove when marketplace evidence
  // repeatedly shows they are actually part of a name (e.g. Red Man Tobacco).
  for(let n=4;n>=2;n--){
    for(let i=0;i+n<=rawTokens.length;i++){
      const words=rawTokens.slice(i,i+n);
      const phrase=words.join(' '), count=pf.get(phrase)||0;
      if(count<2)continue;
      if(words.filter(t=>categorySet.has(t)||QUERY_CATEGORY.has(t)).length>1)continue;
      if(words.filter(t=>GENERIC_FEATURE_WORDS.has(t)).length>Math.floor(words.length/2))continue;
      add(words,count*12 + (i<=1?6:0),'marketplace-consensus');
    }
  }

  // Candidate identity phrases. Evidence consensus is the strongest signal; title
  // position and proximity to the product noun are secondary signals.
  for(let n=2;n<=4;n++){
    for(let i=0;i+n<=tokens.length;i++){
      const words=tokens.slice(i,i+n);
      if(words.some(t=>yearRx.test(t)))continue;
      if(words.every(t=>categorySet.has(t)||QUERY_CATEGORY.has(t)))continue;
      if(words.filter(t=>/^\d+$/.test(t)).length>1)continue;
      const phrase=words.join(' ');
      let score=(pf.get(phrase)||0)*10;
      if(i===brandLen)score+=7;
      if(i===0)score+=5;
      if(words.some(t=>/[a-z]/.test(t)&&/\d/.test(t)))score+=7;
      if(words.some(t=>/^\d{1,2}$/.test(t)))score+=4;
      if(words.some(t=>/^\d{2,4}(?:gb|tb)$/.test(t)))score+=6;
      // A phrase made mostly of generic feature words should not outrank a product name.
      score-=words.filter(t=>GENERIC_FEATURE_WORDS.has(t)).length*4;
      score-=words.filter(t=>categorySet.has(t)||QUERY_CATEGORY.has(t)).length*2;
      if((pf.get(phrase)||0)>=2) add(words,score,'marketplace-consensus');
      else if(score>=18) add(words,score,'title-structure');
    }
  }

  // A proper product phrase immediately before the object noun is often the most
  // discriminating description for art/decor/collectibles.
  let catIndex=-1;
  for(let i=0;i<tokens.length;i++) if(categorySet.has(tokens[i])){catIndex=i;break;}
  if(catIndex>1){
    const prior=tokens.slice(Math.max(brandLen,catIndex-4),catIndex)
      .filter(t=>!GENERIC_FEATURE_WORDS.has(t)&&!/^\d+$/.test(t));
    if(prior.length>=2)add(prior.slice(-3),6,'object-proximity');
  }

  out.sort((a,b)=>b.score-a.score||b.words.length-a.words.length);
  return out;
}

const APPAREL_TERMS = new Set(`shirt shirts tee tshirt sweater hoodie jacket coat jeans jean denim pants pant shorts short dress skirt blouse jersey jerseys pajamas pyjamas sleepwear robe robes hat cap beanie shoe shoes sneaker sneakers boot boots sandal sandals`.split(/\s+/));
const APPAREL_SIZE_WORDS = new Set(`xxs xs small medium large xl xxl xxxl 2xl 3xl 4xl 5xl petite tall regular big husky`.split(/\s+/));

function queryProfiles(title='',keywords='',evidence=[]) {
  // User keywords are allowed to supply missing brand/model context, but marketplace-title noise is stripped identically.
  const rawPhraseTokens=identityPhraseTokens(`${keywords} ${title}`);
  let tokens=queryTokens(`${keywords} ${title}`);
  if(!tokens.length) return {exact:'',style:'',family:'',diagnostics:{}};
  const seen=new Set();
  tokens=tokens.filter(t=>{
    if(t==='one'&&tokens[0]==='hoka') return false;
    if(seen.has(t)) return false;
    seen.add(t); return true;
  });
  // Clothing sizes are attributes, not item identity. Strip them only when the title
  // is clearly apparel/footwear so words such as "medium" remain available in non-apparel contexts.
  const apparelContext=tokens.some(t=>APPAREL_TERMS.has(t));
  if(apparelContext) tokens=tokens.filter(t=>!APPAREL_SIZE_WORDS.has(t) && !/^(?:[2-9]x?l|x{1,4}l)$/.test(t));
  const brand=queryBrandPrefix(tokens), brandSet=new Set(brand);
  const freq=evidenceTokenFrequency(evidence);
  const keywordSet=new Set(queryTokens(keywords));
  const yearRx=/^(?:19\d\d|20\d\d)$/;
  const hardIds=tokens.filter(t=>!brandSet.has(t) && !yearRx.test(t) && (
    (/[a-z]/.test(t)&&/\d/.test(t)) || /^\d{3,8}$/.test(t)
  ));
  // A one/two-digit number is a style generation only when tied to a meaningful word (Clifton 8),
  // not just because a listing contains a size.
  const shortStyles=[];
  for(let i=0;i<tokens.length;i++){
    const t=tokens[i]; if(!/^\d{1,2}$/.test(t)) continue;
    const prev=tokens[i-1]||'';
    const repeated=(freq.get(t)||0)>=2;
    const attached=prev && !brandSet.has(prev) && !QUERY_CATEGORY.has(prev) && !QUERY_NOISE.has(prev) && !/^\d+$/.test(prev);
    const digits=t;
    const duplicatedByHard=hardIds.some(x=>x.replace(/\D/g,'')===digits);
    if((attached||repeated)&&!duplicatedByHard) shortStyles.push(t);
  }
  const idSet=new Set([...hardIds,...shortStyles]);
  const category=canonicalCategory(tokens);
  const categoryParts=new Set(category.split(/\s+/).filter(Boolean));
  const phrases=phraseAnchors(tokens,brand,evidence,category,rawPhraseTokens);
  const topPhrase=phrases.find(x=>x.reason==='device-model-chain'||x.reason==='marketplace-consensus')||null;

  const descriptors=[];
  for(let i=0;i<tokens.length;i++){
    const t=tokens[i];
    if(brandSet.has(t)||idSet.has(t)||QUERY_CATEGORY.has(t)||categoryParts.has(t)||yearRx.test(t)||/^\d+$/.test(t)) continue;
    if(t.length<3) continue;
    const prior=tokens[i-1]||'';
    const looksLikeTrailingCode=/^[a-z]{2,4}$/.test(t) && prior.length>=5 && hardIds.includes(prior) && (freq.get(t)||0)<2 && !keywordSet.has(t);
    if(looksLikeTrailingCode) continue;
    let score=0;
    score += Math.min(4,freq.get(t)||0)*4;
    if(keywordSet.has(t)) score += 8;
    score += Math.max(0,7-i)*0.7;
    if(/^\d{1,2}$/.test(tokens[i+1]||'')) score += 8; // named line before generation, e.g. Clifton 8
    if(hardIds.includes(tokens[i+1]||'')) score += 3;
    descriptors.push({t,score,i});
  }
  descriptors.sort((a,b)=>b.score-a.score||a.i-b.i);
  const descriptorOrder=descriptors.map(x=>x.t);
  const add=(arr,x)=>{if(x&&!arr.includes(x))arr.push(x);};

  const phraseCanLead=topPhrase && topPhrase.reason==='marketplace-consensus' && (topPhrase.rawStart===0 || (topPhrase.rawStart===1 && (rawPhraseTokens[0]||'').length===1));
  const exact=phraseCanLead?[]:[...brand];
  // Phrase anchors come before loose descriptors. Strong marketplace consensus can
  // even repair an ambiguous brand prefix such as "Red Man Tobacco".
  if(topPhrase) topPhrase.words.forEach(x=>{if(exact.length<7)add(exact,x)});
  if(descriptorOrder[0] && !exact.includes(descriptorOrder[0])) add(exact,descriptorOrder[0]);
  shortStyles.slice(0,1).forEach(x=>add(exact,x));
  hardIds.slice(0,2).forEach(x=>add(exact,x));
  if(category) category.split(' ').forEach(x=>{if(exact.length<7)add(exact,x)});
  if(descriptorOrder[1] && exact.length<7 && !exact.includes(descriptorOrder[1])) add(exact,descriptorOrder[1]);

  const style=phraseCanLead?[]:[...brand];
  if(topPhrase) topPhrase.words.slice(0,4).forEach(x=>{if(style.length<6)add(style,x)});
  if(descriptorOrder[0] && !style.includes(descriptorOrder[0])) add(style,descriptorOrder[0]);
  shortStyles.slice(0,1).forEach(x=>add(style,x));
  // Keep a human-readable model number in style tier, but omit long SKU when a named style already exists.
  const humanId=hardIds.find(t=>t.length<=6);
  if(humanId) add(style,humanId);
  if(category) category.split(' ').forEach(x=>{if(style.length<6)add(style,x)});
  if(descriptorOrder[1]&&style.length<6)add(style,descriptorOrder[1]);

  const family=[...brand];
  if(descriptorOrder[0]) add(family,descriptorOrder[0]);
  if(shortStyles[0] && family.length<4) add(family,shortStyles[0]);
  if(family.length<2 && category) category.split(' ').forEach(x=>add(family,x));

  // If there is a hard model/SKU but no useful descriptor, exact must still contain product type.
  if(hardIds.length && exact.length<=brand.length+hardIds.length && category){
    category.split(' ').forEach(x=>{if(exact.length<6)add(exact,x)});
  }
  return {
    exact:exact.slice(0,7).join(' '),
    style:style.slice(0,6).join(' '),
    family:family.slice(0,4).join(' '),
    diagnostics:{brand,hardIds,shortStyles,descriptors:descriptorOrder.slice(0,4),category,phrases:phrases.slice(0,3).map(x=>({phrase:x.phrase,reason:x.reason,score:x.score}))}
  };
}

function parseMoney(v) {
  if (Number.isFinite(v)) return v;
  if (v && Number.isFinite(v.extracted)) return v.extracted;
  if (v && Number.isFinite(v.extracted_value)) return v.extracted_value;
  const s = typeof v === 'string' ? v : (v && v.raw) || (v && v.value) || '';
  const m = String(s).replace(/,/g,'').match(/-?\d+(?:\.\d+)?/);
  return m ? Number(m[0]) : null;
}
function shippingValue(v) {
  if (Number.isFinite(v)) return Math.max(0,v);
  if (v && Number.isFinite(v.extracted)) return Math.max(0,v.extracted);
  const s = typeof v === 'string' ? v : (v && (v.raw||v.value)) || '';
  if (/free/i.test(s)) return 0;
  return Math.max(0,parseMoney(s)||0);
}
function normalizeMarketResults(data, query, mode='active') {
  const organic = Array.isArray(data?.organic_results) ? data.organic_results : [];
  const totalRaw = Number(data?.search_information?.total_results);
  const accepted=[];
  for (const r of organic) {
    if (!r?.title || r.sponsored) continue;
    if (!titleMatches(query,r.title,{min: mode==='sold' ? .38 : .42})) continue;
    const itemPrice = parseMoney(r.price);
    const shipping = shippingValue(r.shipping);
    accepted.push({
      title:r.title, link:r.link||'', productId:r.product_id||'', condition:r.condition||'',
      price:itemPrice, shipping, gross:Number.isFinite(itemPrice)?itemPrice+shipping:null,
      soldDate:r.sold_date||'', unsoldDate:r.unsold_date||'', thumbnail:r.thumbnail||''
    });
  }
  const checked = organic.filter(r=>r && r.title && !r.sponsored).length;
  const ratio = checked ? accepted.length/checked : 0;
  const specific = distinctiveTokens(query).length >= 4 || distinctiveTokens(query).some(t=>/\d/.test(t));
  const totalTrusted = Number.isFinite(totalRaw) && totalRaw >= 0 && specific && checked >= 8 && ratio >= .72;
  const count = totalTrusted ? Math.max(accepted.length,Math.round(totalRaw)) : accepted.length;
  return { query, mode, count, sampleCount:accepted.length, checked, ratio, totalRaw:Number.isFinite(totalRaw)?totalRaw:null, totalTrusted, items:accepted };
}

function normalizeTrawlSold(data, query) {
  const results = Array.isArray(data?.results) ? data.results : [];
  const organic_results = results.map(r => ({
    title: r.title || '',
    link: r.item_link || '',
    product_id: r.item_id || '',
    condition: r.condition_raw || r.condition || '',
    price: { extracted: Number(r.sale_price) },
    shipping: { extracted: Number(r.shipping_price || 0) },
    sold_date: r.date_sold || '',
    thumbnail: r.image_url || ''
  }));
  const out = normalizeMarketResults({
    organic_results,
    search_information: { total_results: Number(data?.count) }
  }, query, 'sold');
  out.provider = 'Trawl';
  out.creditsCharged = Number(data?.credits_charged || 0);
  const pages = Math.max(1, Number(data?.max_pages || data?.maxPages || 1));
  out.maxPages = pages;
  // Full response means older matching sales may still exist. With max_pages=2, 200 is a lower bound, not an exact count.
  out.capped = Number(data?.count || 0) >= pages * 100;
  return out;
}

function chooseMarketPool(exact, family) {
  const enoughExact = exact && ((exact.totalTrusted && exact.count >= 3) || exact.sampleCount >= 5);
  if (enoughExact) return {...exact, pool:'exact'};
  if (family && ((family.totalTrusted && family.count >= 4) || family.sampleCount >= 6)) return {...family,pool:'family'};
  if (family && (family.sampleCount||0) >= 2 && (family.sampleCount||0) > (exact?.sampleCount||0)) return {...family,pool:'family-thin'};
  return {...(exact||family||{count:0,sampleCount:0,items:[]}),pool: exact ? 'exact-thin' : 'family-thin'};
}
function computeSellThrough(soldPool, activePool) {
  // A provider outage/quota exhaustion is unknown data, never evidence of 0% sell-through.
  if (soldPool?.error || soldPool?.provider === 'none') {
    return {available:false,value:null,label:'Unavailable',confidence:'none',providerUnavailable:true,error:soldPool?.error||'Sold data unavailable'};
  }
  const sold = Math.max(0,Number(soldPool?.count)||0), active = Math.max(0,Number(activePool?.count)||0);
  const soldSample = Number(soldPool?.sampleCount)||0, activeSample = Number(activePool?.sampleCount)||0;
  const evidence = soldSample + activeSample;
  if (!sold && !active && evidence === 0) return {available:false,value:null,label:'Unavailable',confidence:'none'};
  if (active === 0 && sold >= 2) {
    const lb = clamp(sold * 100,100,999);
    return {available:true,value:lb,label:`≥${Math.round(lb)}%`,lowerBound:true,confidence:evidence>=5?'medium':'low'};
  }
  if (active <= 0) return {available:false,value:null,label:'Unavailable',confidence:'low'};
  const v = clamp((sold/active)*100,0,999);
  const lowerBound = !!soldPool?.capped;
  const confidence = (soldPool?.totalTrusted && activePool?.totalTrusted) ? 'high' : evidence>=12 ? 'medium' : evidence>=6 ? 'low' : 'very-low';
  return {available:true,value:v,label:`${lowerBound?'≥':''}${v.toFixed(v<10?1:0)}%`,lowerBound,confidence};
}
function pricingFromSold(pool) {
  const prices = robustPrices((pool?.items||[]).map(x=>x.gross).filter(Number.isFinite));
  if (!prices.length) return {available:false,asp:null,median:null,count:0,verified:false,low:null,high:null};
  const med = median(prices), avg = prices.reduce((a,b)=>a+b,0)/prices.length;
  const asp = money((med*0.65)+(avg*0.35));
  return {available:true,asp,median:money(med),count:prices.length,verified:prices.length>=3,low:money(quantile(prices,.25)),high:money(quantile(prices,.75))};
}
function estimateWeightLb(title='') {
  const s=title.toLowerCase();
  if (/hat|cap|beanie/.test(s)) return .35;
  if (/shirt|tee|t-shirt|blouse|tank/.test(s)) return .65;
  if (/sweater|hoodie|sweatshirt/.test(s)) return 1.3;
  if (/jean|pants|trouser/.test(s)) return 1.5;
  if (/shoe|sneaker|boot/.test(s)) return 2.6;
  if (/jacket|coat/.test(s)) return 2.2;
  if (/game|disc|dvd|blu-ray/.test(s)) return .35;
  if (/camera|lens/.test(s)) return 2.0;
  if (/figure|doll|toy/.test(s)) return 1.0;
  if (/bag|backpack|purse/.test(s)) return 1.4;
  if (/lamp|vase|decor|ceramic|glass/.test(s)) return 3.0;
  return 1.25;
}
function acquisitionCost({manualPrice,visiblePrice,binsMode,pricePerLb,title}) {
  const m=Number(manualPrice); if (Number.isFinite(m) && m>=0) return {known:true,cost:money(m),source:'manual'};
  if (binsMode) {
    const ppl=Number(pricePerLb); if (Number.isFinite(ppl) && ppl>0) {
      const wt=estimateWeightLb(title); return {known:true,cost:money(ppl*wt),source:'bins estimate',weightLb:wt};
    }
  }
  const v=Number(visiblePrice); if (Number.isFinite(v) && v>=0) return {known:true,cost:money(v),source:'detected tag'};
  return {known:false,cost:null,source:'unknown'};
}
function decision({title,pricing,str,cost,minValue=15,minStr=20,minProfit=10,feeRate=.14,shipCost=8,supplies=1}) {
  const sale=Number(pricing?.asp); const fee = Number.isFinite(sale) ? sale*feeRate : null;
  const maxBuy = Number.isFinite(sale) ? Math.max(0,sale-fee-shipCost-supplies-minProfit) : null;
  const projected = Number.isFinite(sale) && cost?.known ? sale-fee-shipCost-supplies-cost.cost : null;
  const valueOkay=Number.isFinite(sale) && sale>=minValue;
  const strOkay=!!str?.available && Number(str.value)>=minStr;
  const profitOkay=Number.isFinite(maxBuy) && maxBuy>0 && (!cost?.known || cost.cost<=maxBuy);
  const buy=valueOkay && strOkay && profitOkay;
  const reasons=[];
  if (!pricing?.available) reasons.push('No usable sold pricing');
  else if (!valueOkay) reasons.push(`ASP below $${minValue}`);
  if (!str?.available) reasons.push('Sell-through unavailable');
  else if (!strOkay) reasons.push(`Sell-through below ${minStr}%`);
  if (Number.isFinite(maxBuy) && maxBuy<=0) reasons.push('No room for target profit');
  if (cost?.known && Number.isFinite(maxBuy) && cost.cost>maxBuy) reasons.push('Cost exceeds max buy');
  return {verdict:buy?'BUY':'PASS',maxBuy:Number.isFinite(maxBuy)?money(maxBuy):null,projectedNet:Number.isFinite(projected)?money(projected):null,fee:Number.isFinite(fee)?money(fee):null,reasons,buy};
}

module.exports={clamp,money,median,quantile,robustPrices,tokenize,usefulTokens,distinctiveTokens,tokenSimilarity,titleMatches,cleanCandidateTitle,inferIdentity,stripQueryNoise,queryTokens,queryProfiles,parseMoney,shippingValue,normalizeMarketResults,normalizeTrawlSold,chooseMarketPool,computeSellThrough,pricingFromSold,estimateWeightLb,acquisitionCost,decision};
