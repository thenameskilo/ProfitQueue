'use strict';

const STOP = new Set(`a an and are as at be by for from in is it of on or the to with without used new vintage rare lot bundle size color mens men's womens women's unisex genuine authentic original preowned pre-owned condition ebay mercari poshmark etsy amazon walmart target listing sale sold`.split(/\s+/));
const GENERIC = new Set(`item items product products accessory accessories collectible collectibles clothing apparel gear equipment misc unknown`.split(/\s+/));

function clamp(n, min, max) { return Math.max(min, Math.min(max, n)); }
function money(n) { return Math.round((Number(n) || 0) * 100) / 100; }
function median(values) {
  const a = values.filter(Number.isFinite).slice().sort((x,y)=>x-y);
  if (!a.length) return null;
  const m = Math.floor(a.length/2);
  return a.length % 2 ? a[m] : (a[m-1] + a[m]) / 2;
}
function quantile(values, q) {
  const a = values.filter(Number.isFinite).slice().sort((x,y)=>x-y);
  if (!a.length) return null;
  const p = (a.length - 1) * q, lo = Math.floor(p), hi = Math.ceil(p);
  if (lo === hi) return a[lo];
  return a[lo] + (a[hi] - a[lo]) * (p - lo);
}
function robustPrices(values) {
  const a = values.filter(v => Number.isFinite(v) && v > 0 && v < 100000);
  if (a.length < 4) return a;
  const q1 = quantile(a, .25), q3 = quantile(a, .75), iqr = Math.max(1, q3-q1);
  const lo = Math.max(0.5, q1 - 1.75*iqr), hi = q3 + 1.75*iqr;
  const filtered = a.filter(v => v >= lo && v <= hi);
  return filtered.length >= Math.max(3, Math.floor(a.length * .55)) ? filtered : a;
}
function tokenize(s='') {
  return String(s).toLowerCase().replace(/[’']/g,'').replace(/[^a-z0-9]+/g,' ').trim().split(/\s+/).filter(Boolean);
}
function usefulTokens(s='') {
  return tokenize(s).filter(t => !STOP.has(t) && !GENERIC.has(t) && (t.length > 1 || /\d/.test(t)));
}
function distinctiveTokens(s='') {
  return usefulTokens(s).filter(t => t.length >= 3 || /\d/.test(t));
}
function tokenSimilarity(a,b) {
  const A = new Set(usefulTokens(a)), B = new Set(usefulTokens(b));
  if (!A.size || !B.size) return 0;
  let inter=0; for (const t of A) if (B.has(t)) inter++;
  return inter / Math.max(1, Math.min(A.size, B.size));
}
function titleMatches(query,title,{min=0.42}={}) {
  const q = distinctiveTokens(query), t = new Set(usefulTokens(title));
  if (!q.length) return false;
  const hits = q.filter(x => t.has(x)).length;
  const ratio = hits / q.length;
  const modelTokens = q.filter(x => /\d/.test(x) && /[a-z]/i.test(x));
  const modelOkay = !modelTokens.length || modelTokens.some(x => t.has(x));
  return modelOkay && (ratio >= min || hits >= Math.min(3,q.length));
}
function cleanCandidateTitle(s='') {
  return String(s)
    .replace(/\s+[|–—-]\s+(eBay|Mercari|Poshmark|Etsy|Amazon|Walmart).*$/i,'')
    .replace(/\b(Buy|Shop|For Sale|Free Shipping|Fast Shipping|New Listing)\b.*$/i,'')
    .replace(/\s+/g,' ').trim().slice(0,140);
}
function inferIdentity(matches=[], keywords='') {
  const rows = matches.filter(x=>x && x.title).slice(0,20);
  if (!rows.length) {
    const k = cleanCandidateTitle(keywords);
    return { title:k || 'Unidentified item', confidence:k ? .58 : .15, evidence:[], familyQuery:k || '' };
  }
  const freq = new Map();
  for (const r of rows) for (const t of new Set(usefulTokens(r.title))) freq.set(t,(freq.get(t)||0)+1);
  const trusted = /ebay|mercari|poshmark|etsy|grailed|depop|walmart|amazon|target|shop|store/i;
  let best = null;
  for (const r of rows) {
    const title = cleanCandidateTitle(r.title);
    const toks = usefulTokens(title);
    let score = 0;
    for (const t of toks) score += Math.min(4,freq.get(t)||0);
    score += trusted.test(`${r.source||''} ${r.link||''}`) ? 6 : 0;
    if (r.price) score += 2;
    if (keywords) score += tokenSimilarity(keywords,title)*8;
    score -= Math.max(0,toks.length-12)*.25;
    if (!best || score > best.score) best = {title,score,row:r};
  }
  const common = [...freq.entries()].filter(([,n])=>n>=2).sort((a,b)=>b[1]-a[1]).map(([t])=>t);
  let family = usefulTokens(best.title).filter(t => common.includes(t) || /\d/.test(t)).slice(0,7);
  if (family.length < 3) family = usefulTokens(best.title).slice(0,6);
  if (keywords) family = [...new Set([...usefulTokens(keywords),...family])].slice(0,7);
  const agreement = rows.filter(r=>tokenSimilarity(best.title,r.title)>=.45).length / rows.length;
  return {
    title: best.title,
    confidence: clamp(.45 + agreement*.45 + (keywords ? .07 : 0), .2, .96),
    evidence: rows.slice(0,8).map(r=>({title:cleanCandidateTitle(r.title),source:r.source||'',link:r.link||'',thumbnail:r.thumbnail||r.image||''})),
    familyQuery: family.join(' ')
  };
}
function parseMoney(v) {
  if (Number.isFinite(v)) return v;
  if (v && Number.isFinite(v.extracted)) return v.extracted;
  if (v && Number.isFinite(v.extracted_value)) return v.extracted_value;
  const s = typeof v === 'string' ? v : (v && v.raw) || (v && v.value) || '';
  const m = String(s).replace(/,/g,'').match(/-?\d+(?:\.\d+)?/);
  return m ? Number(m[0]) : null;
}
function shippingValue(v) {
  if (Number.isFinite(v)) return Math.max(0,v);
  if (v && Number.isFinite(v.extracted)) return Math.max(0,v.extracted);
  const s = typeof v === 'string' ? v : (v && (v.raw||v.value)) || '';
  if (/free/i.test(s)) return 0;
  return Math.max(0,parseMoney(s)||0);
}
function normalizeMarketResults(data, query, mode='active') {
  const organic = Array.isArray(data?.organic_results) ? data.organic_results : [];
  const totalRaw = Number(data?.search_information?.total_results);
  const accepted=[];
  for (const r of organic) {
    if (!r?.title || r.sponsored) continue;
    if (!titleMatches(query,r.title,{min: mode==='sold' ? .38 : .42})) continue;
    const itemPrice = parseMoney(r.price);
    const shipping = shippingValue(r.shipping);
    accepted.push({
      title:r.title, link:r.link||'', productId:r.product_id||'', condition:r.condition||'',
      price:itemPrice, shipping, gross:Number.isFinite(itemPrice)?itemPrice+shipping:null,
      soldDate:r.sold_date||'', unsoldDate:r.unsold_date||'', thumbnail:r.thumbnail||''
    });
  }
  const checked = organic.filter(r=>r && r.title && !r.sponsored).length;
  const ratio = checked ? accepted.length/checked : 0;
  const specific = distinctiveTokens(query).length >= 4 || distinctiveTokens(query).some(t=>/\d/.test(t));
  const totalTrusted = Number.isFinite(totalRaw) && totalRaw >= 0 && specific && checked >= 8 && ratio >= .72;
  const count = totalTrusted ? Math.max(accepted.length,Math.round(totalRaw)) : accepted.length;
  return { query, mode, count, sampleCount:accepted.length, checked, ratio, totalRaw:Number.isFinite(totalRaw)?totalRaw:null, totalTrusted, items:accepted };
}
function chooseMarketPool(exact, family) {
  const enoughExact = exact && ((exact.totalTrusted && exact.count >= 3) || exact.sampleCount >= 5);
  if (enoughExact) return {...exact, pool:'exact'};
  if (family && ((family.totalTrusted && family.count >= 4) || family.sampleCount >= 6)) return {...family,pool:'family'};
  if (family && (family.sampleCount||0) >= 2 && (family.sampleCount||0) > (exact?.sampleCount||0)) return {...family,pool:'family-thin'};
  return {...(exact||family||{count:0,sampleCount:0,items:[]}),pool: exact ? 'exact-thin' : 'family-thin'};
}
function computeSellThrough(soldPool, activePool) {
  const sold = Math.max(0,Number(soldPool?.count)||0), active = Math.max(0,Number(activePool?.count)||0);
  const soldSample = Number(soldPool?.sampleCount)||0, activeSample = Number(activePool?.sampleCount)||0;
  const evidence = soldSample + activeSample;
  if (!sold && !active && evidence === 0) return {available:false,value:null,label:'Unavailable',confidence:'none'};
  if (active === 0 && sold >= 2) {
    const lb = clamp(sold * 100,100,999);
    return {available:true,value:lb,label:`≥${Math.round(lb)}%`,lowerBound:true,confidence:evidence>=5?'medium':'low'};
  }
  if (active <= 0) return {available:false,value:null,label:'Unavailable',confidence:'low'};
  const v = clamp((sold/active)*100,0,999);
  const confidence = (soldPool?.totalTrusted && activePool?.totalTrusted) ? 'high' : evidence>=12 ? 'medium' : evidence>=6 ? 'low' : 'very-low';
  return {available:true,value:v,label:`${v.toFixed(v<10?1:0)}%`,lowerBound:false,confidence};
}
function pricingFromSold(pool) {
  const prices = robustPrices((pool?.items||[]).map(x=>x.gross).filter(Number.isFinite));
  if (!prices.length) return {available:false,asp:null,median:null,count:0,verified:false,low:null,high:null};
  const med = median(prices), avg = prices.reduce((a,b)=>a+b,0)/prices.length;
  const asp = money((med*0.65)+(avg*0.35));
  return {available:true,asp,median:money(med),count:prices.length,verified:prices.length>=3,low:money(quantile(prices,.25)),high:money(quantile(prices,.75))};
}
function estimateWeightLb(title='') {
  const s=title.toLowerCase();
  if (/hat|cap|beanie/.test(s)) return .35;
  if (/shirt|tee|t-shirt|blouse|tank/.test(s)) return .65;
  if (/sweater|hoodie|sweatshirt/.test(s)) return 1.3;
  if (/jean|pants|trouser/.test(s)) return 1.5;
  if (/shoe|sneaker|boot/.test(s)) return 2.6;
  if (/jacket|coat/.test(s)) return 2.2;
  if (/game|disc|dvd|blu-ray/.test(s)) return .35;
  if (/camera|lens/.test(s)) return 2.0;
  if (/figure|doll|toy/.test(s)) return 1.0;
  if (/bag|backpack|purse/.test(s)) return 1.4;
  if (/lamp|vase|decor|ceramic|glass/.test(s)) return 3.0;
  return 1.25;
}
function acquisitionCost({manualPrice,visiblePrice,binsMode,pricePerLb,title}) {
  const m=Number(manualPrice); if (Number.isFinite(m) && m>=0) return {known:true,cost:money(m),source:'manual'};
  if (binsMode) {
    const ppl=Number(pricePerLb); if (Number.isFinite(ppl) && ppl>0) {
      const wt=estimateWeightLb(title); return {known:true,cost:money(ppl*wt),source:'bins estimate',weightLb:wt};
    }
  }
  const v=Number(visiblePrice); if (Number.isFinite(v) && v>=0) return {known:true,cost:money(v),source:'detected tag'};
  return {known:false,cost:null,source:'unknown'};
}
function decision({title,pricing,str,cost,minValue=15,minStr=20,minProfit=10,feeRate=.14,shipCost=8,supplies=1}) {
  const sale=Number(pricing?.asp); const fee = Number.isFinite(sale) ? sale*feeRate : null;
  const maxBuy = Number.isFinite(sale) ? Math.max(0,sale-fee-shipCost-supplies-minProfit) : null;
  const projected = Number.isFinite(sale) && cost?.known ? sale-fee-shipCost-supplies-cost.cost : null;
  const valueOkay=Number.isFinite(sale) && sale>=minValue;
  const strOkay=!!str?.available && Number(str.value)>=minStr;
  const profitOkay=Number.isFinite(maxBuy) && maxBuy>0 && (!cost?.known || cost.cost<=maxBuy);
  const buy=valueOkay && strOkay && profitOkay;
  const reasons=[];
  if (!pricing?.available) reasons.push('No usable sold pricing');
  else if (!valueOkay) reasons.push(`ASP below $${minValue}`);
  if (!str?.available) reasons.push('Sell-through unavailable');
  else if (!strOkay) reasons.push(`Sell-through below ${minStr}%`);
  if (Number.isFinite(maxBuy) && maxBuy<=0) reasons.push('No room for target profit');
  if (cost?.known && Number.isFinite(maxBuy) && cost.cost>maxBuy) reasons.push('Cost exceeds max buy');
  return {verdict:buy?'BUY':'PASS',maxBuy:Number.isFinite(maxBuy)?money(maxBuy):null,projectedNet:Number.isFinite(projected)?money(projected):null,fee:Number.isFinite(fee)?money(fee):null,reasons,buy};
}

module.exports={clamp,money,median,quantile,robustPrices,tokenize,usefulTokens,distinctiveTokens,tokenSimilarity,titleMatches,cleanCandidateTitle,inferIdentity,parseMoney,shippingValue,normalizeMarketResults,chooseMarketPool,computeSellThrough,pricingFromSold,estimateWeightLb,acquisitionCost,decision};
