# ORBIT 1.7.0 — Marketplace Title Distillation

This release replaces semantic-role-first query selection with a title-first marketplace validation engine.

- The chosen listing title is the source of truth.
- Obvious size/condition/color/seller noise is cleaned without deleting unknown product terms.
- ORBIT generates a six-step title distillation ladder rather than inventing a new identity query.
- Free eBay active searches determine which title terms are required anchors.
- Candidate ranking uses direct title-to-title comp purity, title similarity, anchor coverage, and object-cluster consistency.
- Sold and active pools are filtered against the exact same chosen-title matcher.
- Active denominators are extrapolated from raw search totals only when the 30-result sample is highly pure and title-consistent.
- Sold numerators use only directly matched returned sold listings; broad raw Trawl counts no longer become the numerator.
- Model/style IDs such as 513, SD750, RP50587, DSC-S930 remain hard anchors.
- The identity graph remains available for diagnostics, but can no longer silently determine the paid sold query.
