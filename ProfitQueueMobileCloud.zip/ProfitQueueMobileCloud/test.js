'use strict';
const assert=require('assert');
const c=require('./core');
let n=0;
function t(name,fn){ try{fn(); n++; console.log('PASS',name)}catch(e){console.error('FAIL',name,e.message);process.exitCode=1;} }

t('median rejects no values',()=>assert.equal(c.median([]),null));
t('robust price filters huge outlier',()=>assert(c.pricingFromSold({items:[10,11,12,13,999].map(gross=>({gross}))}).asp<20));
t('buyer-paid shipping contributes',()=>{const r=c.normalizeMarketResults({organic_results:[{title:'Bose QC30 Headphones',price:{extracted:40},shipping:'$8.00'}]},'Bose QC30 Headphones','sold'); assert.equal(r.items[0].gross,48)});
t('title matching requires useful overlap',()=>assert(c.titleMatches('Bose QuietControl 30 wireless headphones','Bose QuietControl 30 QC30 wireless neckband headphones')));
t('wrong brand does not strongly match',()=>assert(!c.titleMatches('Bose QuietControl 30 headphones','Jabra Elite 25e wireless headset')));
t('identity uses marketplace consensus',()=>{const x=c.inferIdentity([{title:'Bose QuietControl 30 Wireless Headphones QC30',source:'eBay'},{title:'Bose QC30 QuietControl 30 Neckband Headphones',source:'Mercari'},{title:'Bose QuietControl 30 Headphones',source:'Poshmark'}]); assert(/bose/i.test(x.title)); assert(x.confidence>.6)});
t('manual price overrides bins',()=>assert.equal(c.acquisitionCost({manualPrice:5,binsMode:true,pricePerLb:1.99,title:'boots'}).cost,5));
t('bins weight estimates shoes conservatively',()=>assert(c.acquisitionCost({binsMode:true,pricePerLb:1.99,title:'Hoka running shoes'}).cost>4));
t('zero active multiple sold becomes lower bound',()=>{const s=c.computeSellThrough({count:4,sampleCount:4},{count:0,sampleCount:0});assert(s.available&&s.lowerBound&&s.value>=100)});
t('capped sold page marks STR as lower bound',()=>{const r=c.computeSellThrough({count:100,sampleCount:100,capped:true,totalTrusted:true},{count:250,sampleCount:30,totalTrusted:true});assert(r.available&&r.lowerBound&&r.label.startsWith('≥')&&Math.round(r.value)===40)});
t('slow item remains measurable',()=>{const s=c.computeSellThrough({count:2,sampleCount:2},{count:40,sampleCount:20});assert.equal(Math.round(s.value),5)});
t('no market evidence unavailable',()=>assert(!c.computeSellThrough({count:0,sampleCount:0},{count:0,sampleCount:0}).available));
t('exact trusted pool wins',()=>assert.equal(c.chooseMarketPool({count:9,sampleCount:6,totalTrusted:true,items:[]},{count:50,sampleCount:9,totalTrusted:true,items:[]}).pool,'exact'));
t('thin exact broadens to family',()=>assert.equal(c.chooseMarketPool({count:1,sampleCount:1,totalTrusted:false,items:[]},{count:8,sampleCount:8,totalTrusted:false,items:[]}).pool,'family'));
t('two useful family comps beat empty exact pool',()=>assert.equal(c.chooseMarketPool({count:0,sampleCount:0,totalTrusted:false,items:[]},{count:2,sampleCount:2,totalTrusted:false,items:[{gross:25},{gross:30}]}).pool,'family-thin'));
t('max buy drops with higher profit target',()=>{const base={title:'x',pricing:{available:true,asp:50},str:{available:true,value:100},cost:{known:false},minValue:10,minStr:10,feeRate:.14,shipCost:8,supplies:1};assert(c.decision({...base,minProfit:20}).maxBuy<c.decision({...base,minProfit:10}).maxBuy)});
t('higher fee lowers max buy',()=>{const b={pricing:{available:true,asp:50},str:{available:true,value:50},cost:{known:false},minValue:10,minStr:10,minProfit:10,shipCost:8,supplies:1};assert(c.decision({...b,feeRate:.2}).maxBuy<c.decision({...b,feeRate:.1}).maxBuy)});
t('cost above max buy passes false',()=>{const d=c.decision({pricing:{available:true,asp:30},str:{available:true,value:80},cost:{known:true,cost:25},minValue:10,minStr:10,minProfit:10,feeRate:.14,shipCost:6,supplies:1});assert.equal(d.verdict,'PASS')});
t('good economics buys',()=>{const d=c.decision({pricing:{available:true,asp:80},str:{available:true,value:70},cost:{known:true,cost:10},minValue:20,minStr:20,minProfit:10,feeRate:.14,shipCost:8,supplies:1});assert.equal(d.verdict,'BUY')});
t('unknown cost can still return buy with max buy',()=>{const d=c.decision({pricing:{available:true,asp:80},str:{available:true,value:70},cost:{known:false},minValue:20,minStr:20,minProfit:10,feeRate:.14,shipCost:8,supplies:1});assert.equal(d.verdict,'BUY');assert(d.maxBuy>0)});
t('family query strips marketplace fluff',()=>{const x=c.inferIdentity([{title:'Vintage Nike Iowa Hawkeyes Strapback Hat - eBay',source:'eBay'},{title:'Nike Iowa Hawkeyes Vintage Cap',source:'Mercari'}]);assert(!/ebay/i.test(x.familyQuery));});

t('Trawl sold normalization keeps sale price shipping and date',()=>{const r=c.normalizeTrawlSold({count:2,credits_charged:1,results:[{title:'Bose QuietControl 30 QC30 Headphones',sale_price:42,shipping_price:7,date_sold:'2026-09-20T00:00:00Z',item_id:'1',item_link:'https://ebay.com/itm/1'},{title:'Bose QuietControl 30 QC30 Wireless Headphones',sale_price:50,shipping_price:0,date_sold:'2026-09-19T00:00:00Z',item_id:'2'}]},'Bose QuietControl 30 QC30 Headphones');assert.equal(r.provider,'Trawl');assert.equal(r.creditsCharged,1);assert.equal(r.items[0].gross,49);assert(r.items[0].soldDate)});
t('Trawl one-page cap is exposed at 100 results',()=>{const results=Array.from({length:100},(_,i)=>({title:`Hoka Tor Summit Shoes ${i}`,sale_price:50,shipping_price:0}));const r=c.normalizeTrawlSold({count:100,max_pages:1,credits_charged:1,results},'Hoka Tor Summit Shoes');assert.equal(r.capped,true)});
t('Trawl two-page response is exact below 200',()=>{const results=Array.from({length:137},(_,i)=>({title:`Nintendo Gamecube DOL 101 ${i}`,sale_price:70,shipping_price:0}));const r=c.normalizeTrawlSold({count:137,max_pages:2,credits_charged:2,results},'Nintendo Gamecube DOL 101');assert.equal(r.capped,false);assert.equal(r.count,137)});
t('Trawl two-page cap becomes lower bound at 200',()=>{const results=Array.from({length:200},(_,i)=>({title:`Nintendo Gamecube DOL 101 ${i}`,sale_price:70,shipping_price:0}));const r=c.normalizeTrawlSold({count:200,max_pages:2,credits_charged:2,results},'Nintendo Gamecube DOL 101');assert.equal(r.capped,true);const str=c.computeSellThrough(r,{count:996,sampleCount:30,totalTrusted:true});assert(str.lowerBound&&str.label.startsWith('≥'))});

t('same evidence deterministic',()=>{const x=[{title:'Hoka Tor Summit shoes',source:'eBay'},{title:'HOKA Tor Summit hiking shoe',source:'Mercari'}];assert.deepEqual(c.inferIdentity(x),c.inferIdentity(x));});

t('Delta query removes seller negation and keeps model/category',()=>{
  const q=c.queryProfiles('DELTA Single-Handle Valve Cartridge (RP50587) OEM REAL DELTA Not A Knock Off');
  assert.equal(q.exact,'delta rp50587 valve cartridge');
  assert(!/\bnot\b|knock|real|oem/i.test(q.exact));
});
t('Hoka query preserves named line generation and SKU',()=>{
  const q=c.queryProfiles('Hoka One One Clifton 8 Running Shoes Mens 10.5 Real Teal Aquarelle 1119393 RTAR');
  assert(/hoka/.test(q.exact)&&/clifton/.test(q.exact)&&/\b8\b/.test(q.exact)&&/1119393/.test(q.exact));
  assert(!/10\.5|teal|aquarelle/.test(q.exact));
});
t('Levis query keeps model/style but drops waist inseam',()=>{
  const q=c.queryProfiles("Levi's 513 Slim Fit Zip Fly Straight Leg Denim Jeans 38X32 Men's Dark Blue");
  assert(/levis/.test(q.exact)&&/513/.test(q.exact)&&/slim/.test(q.exact));
  assert(!/38|32|blue/.test(q.exact));
});
t('Old West query keeps Apache style rather than generic cowgirl only',()=>{
  const q=c.queryProfiles('Old West Apache Cowgirl Boots Chocolate Brown Snip Toe Western Embroidered 9.5');
  assert(/old west apache/.test(q.exact));
});


t('Wrangler neck-size measurement never becomes STR keyword',()=>{
  const q=c.queryProfiles('Vtg Wrangler Brushpopper Shirt 17-17 1/2 Striped Button Up Western Cowboy AX8');
  assert(/wrangler/.test(q.exact));
  assert(!/(^|\s)17(\s|$)|1\/2/.test(q.exact));
});
t('Nick Nora fiber percentage never becomes STR keyword',()=>{
  const q=c.queryProfiles('Nick & Nora Sleep Pants L Blue Flannel Sock Monkey TV 100% Cotton Pockets VTG');
  assert(/nick/.test(q.exact));
  assert(!/(^|\s)100(\s|$)|cotton/.test(q.exact));
});
t('quoted inch measurement never becomes model keyword',()=>{
  const q=c.queryProfiles('TONKA Green Army Military Jeep Willys Pressed Steel & Plastic 6” Vintage 1970s');
  assert(/tonka/.test(q.exact));
  assert(!/(^|\s)6(\s|$)/.test(q.exact));
});

t('Downton Abbey keeps object type ornament in exact query',()=>{
  const q=c.queryProfiles('Downton Abbey Christmas Ornament Porcelain Holiday Tree Decoration');
  assert(/downton/.test(q.exact)&&/abbey/.test(q.exact)&&/ornament/.test(q.exact));
});
t('object noun outranks material holiday descriptor',()=>{
  const q=c.queryProfiles('Disney Christmas 100% Cotton Red Mickey Holiday Ornament Decoration');
  assert(/disney/.test(q.exact)&&/ornament/.test(q.exact));
  assert(!/(^|\s)100(\s|$)|cotton/.test(q.exact));
});

t('sold provider outage never becomes zero percent STR',()=>{
  const r=c.computeSellThrough({count:0,sampleCount:0,provider:'none',error:'monthly limit reached'},{count:106773,sampleCount:30,provider:'eBay Browse'});
  assert.equal(r.available,false); assert.equal(r.providerUnavailable,true); assert.equal(r.value,null);
});
t('Harley apparel size word is removed from STR query',()=>{
  const q=c.queryProfiles('Vintage Harley Davidson Shirt Womens Large Gray Eagle Snake Sioux Falls SD Biker');
  assert(/harley/.test(q.exact)&&/shirt/.test(q.exact));
  assert(!/\blarge\b/.test(q.exact));
});

t('credit-efficient query profiles stay stable across harmless title order changes',()=>{
  const a=c.queryProfiles('Hoka Clifton 8 Running Shoes 1119393 Mens 10.5 Teal');
  const b=c.queryProfiles('Hoka Running Shoes Clifton 8 Teal 1119393 Size 10.5');
  assert(/hoka/.test(a.exact)&&/clifton/.test(a.exact)&&/1119393/.test(a.exact));
  assert(/hoka/.test(b.exact)&&/clifton/.test(b.exact)&&/1119393/.test(b.exact));
});


t('phrase-aware iPhone keeps full model chain and capacity',()=>{
  const q=c.queryProfiles('Apple iPhone 12 Pro Max - 256 GB - Gold Unlocked');
  assert(/apple/.test(q.exact)&&/iphone/.test(q.exact)&&/\b12\b/.test(q.exact)&&/pro/.test(q.exact)&&/max/.test(q.exact)&&/256gb/.test(q.exact));
});
t('phrase-aware Brain Warp keeps named product phrase',()=>{
  const ev=[{title:'Tiger Electronics Brain Warp Handheld Game'},{title:'Vintage Tiger Brain Warp Electronic Game'},{title:'Tiger Electronics Brain Warp 1996 Game'}];
  const q=c.queryProfiles('VTG 1996 Tiger Electronics Hasbro Brain Warp Handheld Talking Memory Game Works','',ev);
  assert(/brain/.test(q.exact)&&/warp/.test(q.exact)&&/game/.test(q.exact));
});
t('phrase-aware Red Man Tobacco keeps brand phrase and object',()=>{
  const ev=[{title:'Red Man Tobacco Bass Fishing Hat Vintage'},{title:'Red Man Tobacco Tournament Trail Cap'},{title:'Vintage Red Man Tobacco Fishing Snapback Hat'}];
  const q=c.queryProfiles('Red Man Tobacco Vtg 90s Hat Cap Tournament Trail Bass Fishing Snapback Patch','',ev);
  assert(/red/.test(q.exact)&&/man/.test(q.exact)&&/tobacco/.test(q.exact)&&/(hat|cap)/.test(q.exact));
});
t('phrase-aware soapstone sculpture keeps material subject and object noun',()=>{
  const ev=[{title:'Inuit Soapstone Bird Sculpture Signed'},{title:'Carved Soapstone Inuit Bird Sculpture'},{title:'Eskimo Inuit Soapstone Bird Statue'}];
  const q=c.queryProfiles('VTG Eskimo Art Hand Carved Signed Soapstone Inuit Bird Sculpture Statue 7”','',ev);
  assert(/soapstone/.test(q.exact)&&/inuit/.test(q.exact)&&/bird/.test(q.exact)&&/(sculpture|statue)/.test(q.exact));
});


t('decision-aware paging saves second credit when one-page lower bound clears threshold',()=>{
  const p=c.recommendedSoldPages(300,20,2); // 100/300 = 33.3%, already above 20%
  assert.equal(p.pages,1); assert.equal(p.reason,'one-page-already-clears-threshold');
});
t('decision-aware paging allows second page when first page cannot clear threshold',()=>{
  const p=c.recommendedSoldPages(996,20,2); // 100/996 = 10%, 200/996 ~=20.1%
  assert.equal(p.pages,2); assert.equal(p.reason,'second-page-can-resolve-threshold');
});
t('pricing tiers use sold distribution rather than fixed ASP percentages',()=>{
  const r=c.pricingFromSold({items:[30,35,40,45,50,55,60,65,70,75].map(gross=>({gross}))});
  assert(r.tiers.available); assert(r.tiers.quick<r.tiers.market); assert(r.tiers.market<r.tiers.highAsk); assert.equal(r.tiers.confidence,'high');
});
t('pricing tiers suppress fake precision with too few comps',()=>{
  const r=c.pricingFromSold({items:[40,55].map(gross=>({gross}))});
  assert.equal(r.tiers.available,false); assert.equal(r.tiers.quick,null); assert.equal(r.tiers.highAsk,null); assert(r.tiers.market>0);
});

if(!process.exitCode) console.log(`ORBIT 1.4.15 Test Lab: ${n}/${n} passed — 0 external API calls`);
