'use strict';
const assert=require('assert');
const c=require('./core');
let n=0;
function t(name,fn){ try{fn(); n++; console.log('PASS',name)}catch(e){console.error('FAIL',name,e.message);process.exitCode=1;} }

t('median rejects no values',()=>assert.equal(c.median([]),null));
t('robust price filters huge outlier',()=>assert(c.pricingFromSold({items:[10,11,12,13,999].map(gross=>({gross}))}).asp<20));
t('buyer-paid shipping contributes',()=>{const r=c.normalizeMarketResults({organic_results:[{title:'Bose QC30 Headphones',price:{extracted:40},shipping:'$8.00'}]},'Bose QC30 Headphones','sold'); assert.equal(r.items[0].gross,48)});
t('title matching requires useful overlap',()=>assert(c.titleMatches('Bose QuietControl 30 wireless headphones','Bose QuietControl 30 QC30 wireless neckband headphones')));
t('wrong brand does not strongly match',()=>assert(!c.titleMatches('Bose QuietControl 30 headphones','Jabra Elite 25e wireless headset')));
t('identity uses marketplace consensus',()=>{const x=c.inferIdentity([{title:'Bose QuietControl 30 Wireless Headphones QC30',source:'eBay'},{title:'Bose QC30 QuietControl 30 Neckband Headphones',source:'Mercari'},{title:'Bose QuietControl 30 Headphones',source:'Poshmark'}]); assert(/bose/i.test(x.title)); assert(x.confidence>.6)});
t('manual price overrides bins',()=>assert.equal(c.acquisitionCost({manualPrice:5,binsMode:true,pricePerLb:1.99,title:'boots'}).cost,5));
t('bins weight estimates shoes conservatively',()=>assert(c.acquisitionCost({binsMode:true,pricePerLb:1.99,title:'Hoka running shoes'}).cost>4));
t('zero active multiple sold becomes lower bound',()=>{const s=c.computeSellThrough({count:4,sampleCount:4},{count:0,sampleCount:0});assert(s.available&&s.lowerBound&&s.value>=100)});
t('capped sold page marks STR as lower bound',()=>{const r=c.computeSellThrough({count:100,sampleCount:100,capped:true,totalTrusted:true},{count:250,sampleCount:30,totalTrusted:true});assert(r.available&&r.lowerBound&&r.label.startsWith('≥')&&Math.round(r.value)===40)});
t('slow item remains measurable',()=>{const s=c.computeSellThrough({count:2,sampleCount:2},{count:40,sampleCount:20});assert.equal(Math.round(s.value),5)});
t('no market evidence unavailable',()=>assert(!c.computeSellThrough({count:0,sampleCount:0},{count:0,sampleCount:0}).available));
t('exact trusted pool wins',()=>assert.equal(c.chooseMarketPool({count:9,sampleCount:6,totalTrusted:true,items:[]},{count:50,sampleCount:9,totalTrusted:true,items:[]}).pool,'exact'));
t('thin exact broadens to family',()=>assert.equal(c.chooseMarketPool({count:1,sampleCount:1,totalTrusted:false,items:[]},{count:8,sampleCount:8,totalTrusted:false,items:[]}).pool,'family'));
t('two useful family comps beat empty exact pool',()=>assert.equal(c.chooseMarketPool({count:0,sampleCount:0,totalTrusted:false,items:[]},{count:2,sampleCount:2,totalTrusted:false,items:[{gross:25},{gross:30}]}).pool,'family-thin'));
t('max buy drops with higher profit target',()=>{const base={title:'x',pricing:{available:true,asp:50},str:{available:true,value:100},cost:{known:false},minValue:10,minStr:10,feeRate:.14,shipCost:8,supplies:1};assert(c.decision({...base,minProfit:20}).maxBuy<c.decision({...base,minProfit:10}).maxBuy)});
t('higher fee lowers max buy',()=>{const b={pricing:{available:true,asp:50},str:{available:true,value:50},cost:{known:false},minValue:10,minStr:10,minProfit:10,shipCost:8,supplies:1};assert(c.decision({...b,feeRate:.2}).maxBuy<c.decision({...b,feeRate:.1}).maxBuy)});
t('cost above max buy passes false',()=>{const d=c.decision({pricing:{available:true,asp:30},str:{available:true,value:80},cost:{known:true,cost:25},minValue:10,minStr:10,minProfit:10,feeRate:.14,shipCost:6,supplies:1});assert.equal(d.verdict,'PASS')});
t('good economics buys',()=>{const d=c.decision({pricing:{available:true,asp:80},str:{available:true,value:70},cost:{known:true,cost:10},minValue:20,minStr:20,minProfit:10,feeRate:.14,shipCost:8,supplies:1});assert.equal(d.verdict,'BUY')});
t('unknown cost can still return buy with max buy',()=>{const d=c.decision({pricing:{available:true,asp:80},str:{available:true,value:70},cost:{known:false},minValue:20,minStr:20,minProfit:10,feeRate:.14,shipCost:8,supplies:1});assert.equal(d.verdict,'BUY');assert(d.maxBuy>0)});
t('family query strips marketplace fluff',()=>{const x=c.inferIdentity([{title:'Vintage Nike Iowa Hawkeyes Strapback Hat - eBay',source:'eBay'},{title:'Nike Iowa Hawkeyes Vintage Cap',source:'Mercari'}]);assert(!/ebay/i.test(x.familyQuery));});

t('Trawl sold normalization keeps sale price shipping and date',()=>{const r=c.normalizeTrawlSold({count:2,credits_charged:1,results:[{title:'Bose QuietControl 30 QC30 Headphones',sale_price:42,shipping_price:7,date_sold:'2026-09-20T00:00:00Z',item_id:'1',item_link:'https://ebay.com/itm/1'},{title:'Bose QuietControl 30 QC30 Wireless Headphones',sale_price:50,shipping_price:0,date_sold:'2026-09-19T00:00:00Z',item_id:'2'}]},'Bose QuietControl 30 QC30 Headphones');assert.equal(r.provider,'Trawl');assert.equal(r.creditsCharged,1);assert.equal(r.items[0].gross,49);assert(r.items[0].soldDate)});
t('Trawl page cap is exposed at 100 results',()=>{const results=Array.from({length:100},(_,i)=>({title:`Hoka Tor Summit Shoes ${i}`,sale_price:50,shipping_price:0}));const r=c.normalizeTrawlSold({count:100,credits_charged:1,results},'Hoka Tor Summit Shoes');assert.equal(r.capped,true)});

t('same evidence deterministic',()=>{const x=[{title:'Hoka Tor Summit shoes',source:'eBay'},{title:'HOKA Tor Summit hiking shoe',source:'Mercari'}];assert.deepEqual(c.inferIdentity(x),c.inferIdentity(x));});
if(!process.exitCode) console.log(`ORBIT 1.4.6 Test Lab: ${n}/${n} passed — 0 external API calls`);
