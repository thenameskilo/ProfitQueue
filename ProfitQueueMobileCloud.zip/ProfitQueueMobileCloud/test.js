'use strict';
const assert=require('assert');
const c=require('./core');
let n=0;
function t(name,fn){ try{fn(); n++; console.log('PASS',name)}catch(e){console.error('FAIL',name,e.message);process.exitCode=1;} }

t('median rejects no values',()=>assert.equal(c.median([]),null));
t('robust price filters huge outlier',()=>assert(c.pricingFromSold({items:[10,11,12,13,999].map(gross=>({gross}))}).asp<20));
t('buyer-paid shipping contributes',()=>{const r=c.normalizeMarketResults({organic_results:[{title:'Bose QC30 Headphones',price:{extracted:40},shipping:'$8.00'}]},'Bose QC30 Headphones','sold'); assert.equal(r.items[0].gross,48)});
t('title matching requires useful overlap',()=>assert(c.titleMatches('Bose QuietControl 30 wireless headphones','Bose QuietControl 30 QC30 wireless neckband headphones')));
t('wrong brand does not strongly match',()=>assert(!c.titleMatches('Bose QuietControl 30 headphones','Jabra Elite 25e wireless headset')));
t('identity uses marketplace consensus',()=>{const x=c.inferIdentity([{title:'Bose QuietControl 30 Wireless Headphones QC30',source:'eBay'},{title:'Bose QC30 QuietControl 30 Neckband Headphones',source:'Mercari'},{title:'Bose QuietControl 30 Headphones',source:'Poshmark'}]); assert(/bose/i.test(x.title)); assert(x.confidence>.6)});
t('manual price overrides bins',()=>assert.equal(c.acquisitionCost({manualPrice:5,binsMode:true,pricePerLb:1.99,title:'boots'}).cost,5));
t('bins weight estimates shoes conservatively',()=>assert(c.acquisitionCost({binsMode:true,pricePerLb:1.99,title:'Hoka running shoes'}).cost>4));
t('zero active multiple sold becomes lower bound',()=>{const s=c.computeSellThrough({count:4,sampleCount:4},{count:0,sampleCount:0});assert(s.available&&s.lowerBound&&s.value>=100)});
t('capped sold page marks STR as lower bound',()=>{const r=c.computeSellThrough({count:100,sampleCount:100,capped:true,totalTrusted:true},{count:250,sampleCount:30,totalTrusted:true});assert(r.available&&r.lowerBound&&r.label.startsWith('≥')&&Math.round(r.value)===40)});
t('slow item remains measurable',()=>{const s=c.computeSellThrough({count:2,sampleCount:2},{count:40,sampleCount:20});assert.equal(Math.round(s.value),5)});
t('no market evidence unavailable',()=>assert(!c.computeSellThrough({count:0,sampleCount:0},{count:0,sampleCount:0}).available));
t('exact trusted pool wins',()=>assert.equal(c.chooseMarketPool({count:9,sampleCount:6,totalTrusted:true,items:[]},{count:50,sampleCount:9,totalTrusted:true,items:[]}).pool,'exact'));
t('thin exact broadens to family',()=>assert.equal(c.chooseMarketPool({count:1,sampleCount:1,totalTrusted:false,items:[]},{count:8,sampleCount:8,totalTrusted:false,items:[]}).pool,'family'));
t('two useful family comps beat empty exact pool',()=>assert.equal(c.chooseMarketPool({count:0,sampleCount:0,totalTrusted:false,items:[]},{count:2,sampleCount:2,totalTrusted:false,items:[{gross:25},{gross:30}]}).pool,'family-thin'));
t('max buy drops with higher profit target',()=>{const base={title:'x',pricing:{available:true,asp:50},str:{available:true,value:100},cost:{known:false},minValue:10,minStr:10,feeRate:.14,shipCost:8,supplies:1};assert(c.decision({...base,minProfit:20}).maxBuy<c.decision({...base,minProfit:10}).maxBuy)});
t('higher fee lowers max buy',()=>{const b={pricing:{available:true,asp:50},str:{available:true,value:50},cost:{known:false},minValue:10,minStr:10,minProfit:10,shipCost:8,supplies:1};assert(c.decision({...b,feeRate:.2}).maxBuy<c.decision({...b,feeRate:.1}).maxBuy)});
t('cost above max buy passes false',()=>{const d=c.decision({pricing:{available:true,asp:30},str:{available:true,value:80},cost:{known:true,cost:25},minValue:10,minStr:10,minProfit:10,feeRate:.14,shipCost:6,supplies:1});assert.equal(d.verdict,'PASS')});
t('good economics buys',()=>{const d=c.decision({pricing:{available:true,asp:80},str:{available:true,value:70},cost:{known:true,cost:10},minValue:20,minStr:20,minProfit:10,feeRate:.14,shipCost:8,supplies:1});assert.equal(d.verdict,'BUY')});
t('unknown cost can still return buy with max buy',()=>{const d=c.decision({pricing:{available:true,asp:80},str:{available:true,value:70},cost:{known:false},minValue:20,minStr:20,minProfit:10,feeRate:.14,shipCost:8,supplies:1});assert.equal(d.verdict,'BUY');assert(d.maxBuy>0)});
t('family query strips marketplace fluff',()=>{const x=c.inferIdentity([{title:'Vintage Nike Iowa Hawkeyes Strapback Hat - eBay',source:'eBay'},{title:'Nike Iowa Hawkeyes Vintage Cap',source:'Mercari'}]);assert(!/ebay/i.test(x.familyQuery));});

t('Trawl sold normalization keeps sale price shipping and date',()=>{const r=c.normalizeTrawlSold({count:2,credits_charged:1,results:[{title:'Bose QuietControl 30 QC30 Headphones',sale_price:42,shipping_price:7,date_sold:'2026-09-20T00:00:00Z',item_id:'1',item_link:'https://ebay.com/itm/1'},{title:'Bose QuietControl 30 QC30 Wireless Headphones',sale_price:50,shipping_price:0,date_sold:'2026-09-19T00:00:00Z',item_id:'2'}]},'Bose QuietControl 30 QC30 Headphones');assert.equal(r.provider,'Trawl');assert.equal(r.creditsCharged,1);assert.equal(r.items[0].gross,49);assert(r.items[0].soldDate)});
t('Trawl one-page cap is exposed at 100 results',()=>{const results=Array.from({length:100},(_,i)=>({title:`Hoka Tor Summit Shoes ${i}`,sale_price:50,shipping_price:0}));const r=c.normalizeTrawlSold({count:100,max_pages:1,credits_charged:1,results},'Hoka Tor Summit Shoes');assert.equal(r.capped,true)});
t('Trawl two-page response is exact below 200',()=>{const results=Array.from({length:137},(_,i)=>({title:`Nintendo Gamecube DOL 101 ${i}`,sale_price:70,shipping_price:0}));const r=c.normalizeTrawlSold({count:137,max_pages:2,credits_charged:2,results},'Nintendo Gamecube DOL 101');assert.equal(r.capped,false);assert.equal(r.count,137)});
t('Trawl two-page cap becomes lower bound at 200',()=>{const results=Array.from({length:200},(_,i)=>({title:`Nintendo Gamecube DOL 101 ${i}`,sale_price:70,shipping_price:0}));const r=c.normalizeTrawlSold({count:200,max_pages:2,credits_charged:2,results},'Nintendo Gamecube DOL 101');assert.equal(r.capped,true);const str=c.computeSellThrough(r,{count:996,sampleCount:30,totalTrusted:true});assert(str.lowerBound&&str.label.startsWith('≥'))});

t('same evidence deterministic',()=>{const x=[{title:'Hoka Tor Summit shoes',source:'eBay'},{title:'HOKA Tor Summit hiking shoe',source:'Mercari'}];assert.deepEqual(c.inferIdentity(x),c.inferIdentity(x));});

t('Delta query removes seller negation and keeps model/category',()=>{
  const q=c.queryProfiles('DELTA Single-Handle Valve Cartridge (RP50587) OEM REAL DELTA Not A Knock Off');
  assert.equal(q.exact,'delta rp50587 valve cartridge');
  assert(!/\bnot\b|knock|real|oem/i.test(q.exact));
});
t('Hoka query preserves named line generation and SKU',()=>{
  const q=c.queryProfiles('Hoka One One Clifton 8 Running Shoes Mens 10.5 Real Teal Aquarelle 1119393 RTAR');
  assert(/hoka/.test(q.exact)&&/clifton/.test(q.exact)&&/\b8\b/.test(q.exact)&&/1119393/.test(q.exact));
  assert(!/10\.5|teal|aquarelle/.test(q.exact));
});
t('Levis query keeps model/style but drops waist inseam',()=>{
  const q=c.queryProfiles("Levi's 513 Slim Fit Zip Fly Straight Leg Denim Jeans 38X32 Men's Dark Blue");
  assert(/levis/.test(q.exact)&&/513/.test(q.exact)&&/slim/.test(q.exact));
  assert(!/38|32|blue/.test(q.exact));
});
t('Old West query keeps Apache style rather than generic cowgirl only',()=>{
  const q=c.queryProfiles('Old West Apache Cowgirl Boots Chocolate Brown Snip Toe Western Embroidered 9.5');
  assert(/old west apache/.test(q.exact));
});


t('Wrangler neck-size measurement never becomes STR keyword',()=>{
  const q=c.queryProfiles('Vtg Wrangler Brushpopper Shirt 17-17 1/2 Striped Button Up Western Cowboy AX8');
  assert(/wrangler/.test(q.exact));
  assert(!/(^|\s)17(\s|$)|1\/2/.test(q.exact));
});
t('Nick Nora fiber percentage never becomes STR keyword',()=>{
  const q=c.queryProfiles('Nick & Nora Sleep Pants L Blue Flannel Sock Monkey TV 100% Cotton Pockets VTG');
  assert(/nick/.test(q.exact));
  assert(!/(^|\s)100(\s|$)|cotton/.test(q.exact));
});
t('quoted inch measurement never becomes model keyword',()=>{
  const q=c.queryProfiles('TONKA Green Army Military Jeep Willys Pressed Steel & Plastic 6” Vintage 1970s');
  assert(/tonka/.test(q.exact));
  assert(!/(^|\s)6(\s|$)/.test(q.exact));
});

t('Downton Abbey keeps object type ornament in exact query',()=>{
  const q=c.queryProfiles('Downton Abbey Christmas Ornament Porcelain Holiday Tree Decoration');
  assert(/downton/.test(q.exact)&&/abbey/.test(q.exact)&&/ornament/.test(q.exact));
});
t('object noun outranks material holiday descriptor',()=>{
  const q=c.queryProfiles('Disney Christmas 100% Cotton Red Mickey Holiday Ornament Decoration');
  assert(/disney/.test(q.exact)&&/ornament/.test(q.exact));
  assert(!/(^|\s)100(\s|$)|cotton/.test(q.exact));
});

t('sold provider outage never becomes zero percent STR',()=>{
  const r=c.computeSellThrough({count:0,sampleCount:0,provider:'none',error:'monthly limit reached'},{count:106773,sampleCount:30,provider:'eBay Browse'});
  assert.equal(r.available,false); assert.equal(r.providerUnavailable,true); assert.equal(r.value,null);
});
t('Harley apparel size word is removed from STR query',()=>{
  const q=c.queryProfiles('Vintage Harley Davidson Shirt Womens Large Gray Eagle Snake Sioux Falls SD Biker');
  assert(/harley/.test(q.exact)&&/shirt/.test(q.exact));
  assert(!/\blarge\b/.test(q.exact));
});

t('credit-efficient query profiles stay stable across harmless title order changes',()=>{
  const a=c.queryProfiles('Hoka Clifton 8 Running Shoes 1119393 Mens 10.5 Teal');
  const b=c.queryProfiles('Hoka Running Shoes Clifton 8 Teal 1119393 Size 10.5');
  assert(/hoka/.test(a.exact)&&/clifton/.test(a.exact)&&/1119393/.test(a.exact));
  assert(/hoka/.test(b.exact)&&/clifton/.test(b.exact)&&/1119393/.test(b.exact));
});


t('phrase-aware iPhone keeps full model chain and capacity',()=>{
  const q=c.queryProfiles('Apple iPhone 12 Pro Max - 256 GB - Gold Unlocked');
  assert(/apple/.test(q.exact)&&/iphone/.test(q.exact)&&/\b12\b/.test(q.exact)&&/pro/.test(q.exact)&&/max/.test(q.exact)&&/256gb/.test(q.exact));
});
t('phrase-aware Brain Warp keeps named product phrase',()=>{
  const ev=[{title:'Tiger Electronics Brain Warp Handheld Game'},{title:'Vintage Tiger Brain Warp Electronic Game'},{title:'Tiger Electronics Brain Warp 1996 Game'}];
  const q=c.queryProfiles('VTG 1996 Tiger Electronics Hasbro Brain Warp Handheld Talking Memory Game Works','',ev);
  assert(/brain/.test(q.exact)&&/warp/.test(q.exact)&&/game/.test(q.exact));
});
t('phrase-aware Red Man Tobacco keeps brand phrase and object',()=>{
  const ev=[{title:'Red Man Tobacco Bass Fishing Hat Vintage'},{title:'Red Man Tobacco Tournament Trail Cap'},{title:'Vintage Red Man Tobacco Fishing Snapback Hat'}];
  const q=c.queryProfiles('Red Man Tobacco Vtg 90s Hat Cap Tournament Trail Bass Fishing Snapback Patch','',ev);
  assert(/red/.test(q.exact)&&/man/.test(q.exact)&&/tobacco/.test(q.exact)&&/(hat|cap)/.test(q.exact));
});
t('phrase-aware soapstone sculpture keeps material subject and object noun',()=>{
  const ev=[{title:'Inuit Soapstone Bird Sculpture Signed'},{title:'Carved Soapstone Inuit Bird Sculpture'},{title:'Eskimo Inuit Soapstone Bird Statue'}];
  const q=c.queryProfiles('VTG Eskimo Art Hand Carved Signed Soapstone Inuit Bird Sculpture Statue 7”','',ev);
  assert(/soapstone/.test(q.exact)&&/inuit/.test(q.exact)&&/bird/.test(q.exact)&&/(sculpture|statue)/.test(q.exact));
});


t('decision-aware paging saves second credit when one-page lower bound clears threshold',()=>{
  const p=c.recommendedSoldPages(300,20,2); // 100/300 = 33.3%, already above 20%
  assert.equal(p.pages,1); assert.equal(p.reason,'one-page-already-clears-threshold');
});
t('decision-aware paging allows second page when first page cannot clear threshold',()=>{
  const p=c.recommendedSoldPages(996,20,2); // 100/996 = 10%, 200/996 ~=20.1%
  assert.equal(p.pages,2); assert.equal(p.reason,'second-page-can-resolve-threshold');
});
t('pricing tiers use sold distribution rather than fixed ASP percentages',()=>{
  const r=c.pricingFromSold({items:[30,35,40,45,50,55,60,65,70,75].map(gross=>({gross}))});
  assert(r.tiers.available); assert(r.tiers.quick<r.tiers.market); assert(r.tiers.market<r.tiers.highAsk); assert.equal(r.tiers.confidence,'high');
});
t('pricing tiers suppress fake precision with too few comps',()=>{
  const r=c.pricingFromSold({items:[40,55].map(gross=>({gross}))});
  assert.equal(r.tiers.available,false); assert.equal(r.tiers.quick,null); assert.equal(r.tiers.highAsk,null); assert(r.tiers.market>0);
});


t('scarce market low STR does not force pass',()=>{const d=c.decision({pricing:{available:true,asp:80},str:{available:true,value:8},cost:{known:true,cost:10},soldCount:2,activeCount:8,minValue:20,minStr:20,minProfit:10,feeRate:.14,shipCost:8,supplies:1});assert.equal(d.verdict,'BUY');assert.equal(d.scarcityOverride,true)});
t('zero sold and almost no active becomes review not pass',()=>{const d=c.decision({pricing:{available:false,asp:null},str:{available:true,value:0},cost:{known:false},soldCount:0,activeCount:2,minValue:20,minStr:20,minProfit:10,feeRate:.14,shipCost:8,supplies:1});assert.equal(d.verdict,'REVIEW');assert.equal(d.marketKey,'rare')});
t('few sold with many active remains pass on weak STR',()=>{const d=c.decision({pricing:{available:true,asp:80},str:{available:true,value:2},cost:{known:true,cost:10},soldCount:2,activeCount:120,minValue:20,minStr:20,minProfit:10,feeRate:.14,shipCost:8,supplies:1});assert.equal(d.verdict,'PASS');assert.equal(d.marketKey,'oversupplied')});

t('shoe exact comp rejects different Hoka model',()=>{
  const m=c.compMatch('hoka clifton 8 1119393 running shoes','HOKA Bondi 8 Running Shoes Mens 10');
  assert.equal(m.accept,false); assert(['close','reject'].includes(m.class));
});
t('shoe exact comp accepts same Hoka model and SKU',()=>{
  const m=c.compMatch('hoka clifton 8 1119393 running shoes','HOKA Clifton 8 1119393 Running Shoe Mens Blue');
  assert.equal(m.accept,true); assert.equal(m.class,'exact');
});
t('shoe generation mismatch is close not exact',()=>{
  const m=c.compMatch('hoka clifton 8 running shoes','HOKA Clifton 9 Running Shoes Mens');
  assert.equal(m.accept,false); assert.equal(m.class,'close');
});
t('shoe SKU separates Dr Martens variants',()=>{
  assert.equal(c.compMatch('dr martens 10940 shoes','Dr Martens 10940 Brown Leather Shoes').accept,true);
  assert.equal(c.compMatch('dr martens 10940 shoes','Dr Martens 9231 Brown Leather Shoes').accept,false);
});
t('normalized market pool keeps close footwear comps separate',()=>{
  const r=c.normalizeMarketResults({organic_results:[
    {title:'HOKA Clifton 8 1119393 Running Shoes',price:{extracted:55}},
    {title:'HOKA Bondi 8 Running Shoes',price:{extracted:60}},
    {title:'HOKA Clifton 9 Running Shoes',price:{extracted:65}}
  ]},'hoka clifton 8 1119393 running shoes','sold');
  assert.equal(r.sampleCount,1); assert(r.closeSampleCount>=1); assert(/Clifton 8/.test(r.items[0].title));
});


t('velocity estimator projects capped 90-day sold count from date span',()=>{
  const now=new Date('2026-09-24T12:00:00Z');
  const results=Array.from({length:100},(_,i)=>({
    title:`Nintendo Gamecube DOL 101 Console ${i}`,
    sale_price:75,
    shipping_price:0,
    date_sold:new Date(now.getTime()-((i%20)*86400000)).toISOString()
  }));
  const pool=c.normalizeTrawlSold({count:100,max_pages:1,credits_charged:1,results},'nintendo gamecube dol 101');
  const est=c.estimateCappedSoldCount(pool,90);
  assert(est.available); assert(est.estimatedSold>=400&&est.estimatedSold<=500); assert(['medium','high'].includes(est.confidence));
});

t('velocity-estimated STR exposes observed floor and estimate',()=>{
  const now=new Date('2026-09-24T12:00:00Z');
  const results=Array.from({length:100},(_,i)=>({
    title:`Nintendo Gamecube DOL 101 Console ${i}`,
    sale_price:75,
    shipping_price:0,
    date_sold:new Date(now.getTime()-((i%30)*86400000)).toISOString()
  }));
  const pool=c.normalizeTrawlSold({count:100,max_pages:1,credits_charged:1,results},'nintendo gamecube dol 101');
  const str=c.computeSellThrough(pool,{count:1000,sampleCount:30,totalTrusted:true});
  assert(str.estimated); assert(str.observedLabel.startsWith('≥')); assert(str.label.startsWith('~')); assert(str.value>str.observedValue);
});

t('short burst velocity estimate cannot drive buy pass',()=>{
  const now=new Date('2026-09-24T12:00:00Z');
  const results=Array.from({length:100},(_,i)=>({
    title:`Hot Toy Model X ${i}`,
    sale_price:50,
    shipping_price:0,
    date_sold:new Date(now.getTime()-((i%3)*86400000)).toISOString()
  }));
  const pool=c.normalizeTrawlSold({count:100,max_pages:1,credits_charged:1,results},'hot toy model x');
  const str=c.computeSellThrough(pool,{count:1000,sampleCount:30,totalTrusted:true});
  assert.equal(str.estimated,undefined); assert(str.estimatedValue>str.value); assert(str.label.startsWith('≥'));
});

t('uncapped sold pool stays exact and does not extrapolate',()=>{
  const results=Array.from({length:42},(_,i)=>({title:`Item Model 42 ${i}`,sale_price:30,date_sold:`2026-09-${String((i%20)+1).padStart(2,'0')}`}));
  const pool=c.normalizeTrawlSold({count:42,max_pages:1,credits_charged:1,results},'item model 42');
  assert.equal(pool.capped,false);
  const str=c.computeSellThrough(pool,{count:100,sampleCount:30,totalTrusted:true});
  assert.equal(str.estimated,undefined); assert.equal(str.lowerBound,false);
});



t('role-aware fragrance strips volume and preserves flanker',()=>{
  const q=c.queryProfiles('Emporio Armani Stronger With You Intensely 3.4 fl oz 100 ml EDP Sealed Box');
  assert(/emporio/.test(q.exact)&&/armani/.test(q.exact)&&/stronger/.test(q.exact)&&/intensely/.test(q.exact)&&/edp/.test(q.exact));
  assert(!/\b100\b/.test(q.exact)&&!/\b34\b/.test(q.exact));
});
t('role-aware Pendleton keeps line and object not dimensions',()=>{
  const q=c.queryProfiles('Vintage Pendleton Woolen Mills Beaver State Robes & Shawls Aztec Blanket 62”x68”');
  assert(/pendleton/.test(q.exact)&&/beaver/.test(q.exact)&&/state/.test(q.exact)&&/blanket/.test(q.exact));
  assert(!/x68/.test(q.exact));
});
t('role-aware Lisa Frank uses plush object and named subject',()=>{
  const q=c.queryProfiles('Vtg Lisa Frank Fantastic World Playtime Kitten Purple Cat 8" Bean Bag Plush 1998');
  assert(/lisa/.test(q.exact)&&/frank/.test(q.exact)&&/playtime/.test(q.exact)&&/kitten/.test(q.exact)&&/plush/.test(q.exact));
});
t('role-aware parts camera preserves condition state',()=>{
  const q=c.queryProfiles('Canon PowerShot A3100 IS 12.1 MP Digital Camera Silver PC1474 FOR PARTS/REPAIR');
  assert(/canon/.test(q.exact)&&/a3100/.test(q.exact)&&/camera/.test(q.exact)&&/parts/.test(q.exact)&&/repair/.test(q.exact));
});
t('role-aware Fred Bear keeps Kodiak Magnum and strips draw weight',()=>{
  const q=c.queryProfiles('1953 Vintage Fred Bear Glass Powered Kodiak Magnum Recurve Bow RH 52" #48');
  assert(/fred/.test(q.exact)&&/bear/.test(q.exact)&&/kodiak/.test(q.exact)&&/magnum/.test(q.exact)&&/(bow|recurve)/.test(q.exact));
  assert(!/\b48\b/.test(q.exact)&&!/\b52\b/.test(q.exact));
});
t('sample-limited active denominator suppresses STR',()=>{
  const str=c.computeSellThrough({count:100,sampleCount:100,capped:true,mode:'sold'},{count:30,sampleCount:30,checked:30,totalTrusted:false,denominatorTrusted:false,mode:'active'});
  assert.equal(str.available,false); assert.equal(str.denominatorUncertain,true);
});


t('protected phrase keeps LL Bean brand intact',()=>{
  const q=c.queryProfiles('Vtg LL Bean Plaid Messenger Shoulder Bag Green Blue Zip Pockets Adjustable Strap');
  assert(/ll bean/.test(q.exact));
});
t('protected phrase keeps Walk Off Elite product line intact',()=>{
  const q=c.queryProfiles('Easton Walk Off Elite Camouflage Green Baseball Softball Backpack Bat Bag');
  assert(/walk off elite/.test(q.exact));
});
t('protected phrase keeps Skechers Parties Mate line intact',()=>{
  const q=c.queryProfiles("Skechers Parties Mate Shoes Women's 8.5 Black Suede Oxford 90s Y2K Chunky Lace");
  assert(/parties mate/.test(q.exact));
});
t('protected phrase keeps mid century together',()=>{
  const q=c.queryProfiles('Mid Century Modern Oak Cane Bentwood Rocking Chair Rocker Thonet Style');
  assert(/mid century/.test(q.exact));
});
t('very high velocity STR is sanity guarded',()=>{
  const sold={count:200,sampleCount:200,capped:true,totalTrusted:true,items:Array.from({length:100},(_,i)=>({soldDate:new Date(Date.UTC(2026,8,24-i%30)).toISOString()}))};
  const active={count:407,sampleCount:25,totalTrusted:true};
  const r=c.computeSellThrough(sold,active);
  assert(r.available); if(r.estimatedValue>200){ assert.equal(r.label,'Very high'); assert.equal(r.unstableEstimate,true); assert(r.value<=200); }
});



t('1.5 structured shoe identity creates model-level candidates',()=>{
  const q=c.queryProfiles('Hoka One One Rincon 3 Womens Size 9.5 Pink Blue Athletic Running Shoes Sneakers');
  assert.equal(q.structured.schema,'footwear');
  assert.equal(q.structured.productLine,'rincon 3');
  assert(q.candidates.some(x=>x.query==='hoka rincon 3 running shoes'));
  assert(!q.candidates.some(x=>/9\.5/.test(x.query)));
});

t('1.5 bag schema prioritizes messenger form over plaid color descriptor',()=>{
  const q=c.queryProfiles('Vtg LL Bean Plaid Messenger Shoulder Bag Green Blue Zip Pockets Adjustable Strap');
  assert.equal(q.structured.schema,'bags');
  assert.equal(q.structured.brand,'ll bean');
  assert.equal(q.structured.productLine,'messenger');
  assert(q.candidates[0].query.includes('ll bean messenger bag'));
});

t('1.5 protected product line becomes structured Easton identity',()=>{
  const q=c.queryProfiles('Easton Walk Off Elite Camouflage Green Baseball Softball Backpack Bat Bag');
  assert.equal(q.structured.productLine,'walk off elite');
  assert(q.candidates.some(x=>x.query==='easton walk off elite bat bag'));
});

t('1.5 fragrance schema keeps full named line plus flanker',()=>{
  const q=c.queryProfiles('Emporio Armani Stronger With You Intensely 3.4 fl oz 100 ml EDP Sealed Box');
  assert.equal(q.structured.schema,'fragrance');
  assert.equal(q.structured.productLine,'stronger with you');
  assert.equal(q.candidates[0].query,'emporio armani stronger with you intensely edp');
});

t('1.5 electronics model chain preserves DSC S930',()=>{
  const q=c.queryProfiles('Sony Cyber-Shot DSC-S930 Silver Digital camera 10.1 MP Tested Works.');
  assert.equal(q.structured.schema,'electronics');
  assert(q.structured.modelTokens.includes('dsc'));
  assert(q.structured.modelTokens.includes('s930'));
  assert(q.candidates.some(x=>/sony cyber shot dsc s930 digital camera/.test(x.query)));
});

t('1.5 marketplace spelling normalization handles L.L.Bean',()=>{
  assert.deepEqual(c.tokenize('L.L.Bean Messenger Bag').slice(0,2),['ll','bean']);
});

t('1.5 marketplace validation ranks clean model query above polluted query',()=>{
  const q=c.queryProfiles('Hoka One One Rincon 3 Womens Running Shoes');
  const clean={level:'clean',id:'clean',query:'hoka rincon 3 running shoes',active:{rawItems:[
    {title:'HOKA Rincon 3 Womens Running Shoes'},
    {title:'HOKA ONE ONE Rincon 3 Running Sneaker'},
    {title:'Hoka Rincon 3 Athletic Shoes'},
    {title:'Hoka Rincon 3 Womens Shoes'},
    {title:'Hoka Rincon 3 Running Shoe'}
  ]}};
  const broad={level:'broad',id:'broad',query:'hoka running shoes',active:{rawItems:[
    {title:'HOKA Bondi 8 Running Shoes'},
    {title:'HOKA Clifton 9 Running Shoes'},
    {title:'HOKA Speedgoat 5 Trail Shoes'},
    {title:'HOKA Rincon 3 Running Shoes'},
    {title:'HOKA Arahi 7 Running Shoes'},
    {title:'HOKA Mach 6 Running Shoes'},
    {title:'HOKA Clifton 8 Running Shoes'},
    {title:'HOKA Transport Shoes'}
  ]}};
  const ranked=c.rankQueryCandidates([broad,clean],q.structured);
  assert.equal(ranked[0].id,'clean');
  assert(ranked[0].validation.precision>ranked[1].validation.precision);
});

t('1.5 active query validator detects badly contaminated result set',()=>{
  const q=c.queryProfiles('Easton Walk Off Elite Baseball Softball Bat Bag');
  const v=c.scoreQueryCandidate(q.structured,{query:'easton baseball bag',rawItems:[
    {title:'Easton Youth Baseball Backpack'}, {title:'Easton Catchers Bag'}, {title:'Easton Ghost Softball Bag'},
    {title:'Easton Game Ready Bat Bag'}, {title:'Easton Team Equipment Bag'}, {title:'Easton Walk Off Elite Bat Bag'},
    {title:'Easton E100T Tote Bag'}, {title:'Easton Octane Bat Bag'}, {title:'Easton Baseball Backpack'}, {title:'Easton Dugout Wheeled Bag'}
  ]});
  assert(v.precision<.2);
  assert.equal(v.confidence,'poor');
});



t('1.5.1 deduplicates required identity tokens',()=>{
  const q=c.queryProfiles('DELTA Single-Handle Valve Cartridge RP50587 OEM');
  assert.equal(q.structured.required.length,new Set(q.structured.required).size);
});

t('1.5.1 recognizes Fisher Price as one brand and stable as object type',()=>{
  const q=c.queryProfiles('Fisher-Price Little People Disney Princess Klip Klop Castle, Stable Only -Works');
  assert.equal(q.structured.brand,'fisher price');
  assert.equal(q.structured.category,'stable');
  assert(q.structured.productLine.includes('little people'));
  assert(q.structured.productLine.includes('klip klop'));
  assert(q.candidates.some(x=>/fisher price.*little people.*klip klop.*stable/.test(x.query)));
});

t('1.5.1 wrong-object franchise results fail semantic purity',()=>{
  const q=c.queryProfiles("Bratz Lil' Bratz Small Girls Backpack Pink Purple Black Graphic Print Zip");
  const v=c.scoreQueryCandidate(q.structured,{query:'bratz lil',rawItems:[
    {title:'Lil Bratz Yasmin Doll'}, {title:'Lil Bratz Cloe Doll'}, {title:'Lil Bratz Fashion Doll Outfit'},
    {title:'Lil Bratz Doll Playset'}, {title:'Lil Bratz Doll Shoes'}, {title:'Lil Bratz Small Backpack'}
  ]});
  assert(v.lexicalPrecision>.8);
  assert(v.productPurity<.3);
  assert(v.wrongObjectRate>.5);
});

t('1.5.1 object-preserving Bratz query outranks legacy family',()=>{
  const q=c.queryProfiles("Bratz Lil' Bratz Small Girls Backpack Pink Purple Black Graphic Print Zip");
  const clean={id:'named-product',query:'bratz lil backpack',active:{rawItems:[
    {title:'Lil Bratz Girls Backpack'}, {title:'Bratz Lil Bratz Mini Backpack'}, {title:'Lil Bratz Pink Backpack'},
    {title:'Bratz Lil Backpack Bag'}, {title:'Lil Bratz Child Backpack'}
  ]}};
  const broad={id:'legacy-family',query:'bratz lil',active:{rawItems:[
    {title:'Lil Bratz Yasmin Doll'}, {title:'Lil Bratz Cloe Doll'}, {title:'Lil Bratz Doll Outfit'},
    {title:'Lil Bratz Doll Playset'}, {title:'Lil Bratz Backpack'}
  ]}};
  const ranked=c.rankQueryCandidates([broad,clean],q.structured);
  assert.equal(ranked[0].id,'named-product');
  assert(ranked[0].validation.productPurity>ranked[1].validation.productPurity);
});

t('1.5.1 Easton Walk Off Elite keeps bat-bag object identity',()=>{
  const q=c.queryProfiles('Easton Walk Off Elite Camouflage Baseball Softball Backpack Bat Bag');
  assert.equal(q.structured.category,'bat bag');
  assert(q.candidates[0].query.includes('walk off elite'));
  assert(q.candidates[0].query.includes('bat bag'));
});

t('1.5.1 category-dropping query gets structural penalty',()=>{
  const q=c.queryProfiles("Bratz Lil' Bratz Small Girls Backpack Pink Purple Black Graphic Print Zip");
  const broad=c.scoreQueryCandidate(q.structured,{query:'bratz lil',rawItems:[
    {title:'Lil Bratz Backpack'}, {title:'Lil Bratz Backpack Bag'}, {title:'Bratz Lil Backpack'}, {title:'Lil Bratz Mini Backpack'}, {title:'Lil Bratz Kids Backpack'}
  ]});
  const clean=c.scoreQueryCandidate(q.structured,{query:'bratz lil backpack',rawItems:[
    {title:'Lil Bratz Backpack'}, {title:'Lil Bratz Backpack Bag'}, {title:'Bratz Lil Backpack'}, {title:'Lil Bratz Mini Backpack'}, {title:'Lil Bratz Kids Backpack'}
  ]});
  assert(clean.score>broad.score);
  assert.equal(broad.queryStructure.categoryOk,false);
});


t('1.5.2 recognizes Toy Biz as manufacturer and keeps Wolverine collectible identity',()=>{
  const q=c.queryProfiles('1994 Toy Biz Marvel X-Men Wolverine 2.5 Die-Cast Metal Mini Action Figure');
  assert.equal(q.structured.brand,'toy biz');
  assert.equal(q.structured.productLine,'marvel xmen wolverine');
  assert(q.candidates[0].query.includes('wolverine'));
  assert(q.candidates[0].query.includes('xmen'));
  assert(q.candidates.some(x=>x.query.includes('figure')));
  assert(q.structured.identityCompleteness.value>=60);
});

t('1.5.2 preserves Sony CFM 2000 as a model ID',()=>{
  const q=c.queryProfiles('SONY MY FIRST SONY Cassette Player Red CFM 2000 AM/FM Parts Or Repair -No Sound');
  assert(q.structured.modelTokens.includes('cfm2000'));
  assert.equal(q.structured.productLine,'my first');
  assert(q.candidates[0].query.includes('cfm2000'));
  assert(!q.candidates[0].query.includes('parts'));
  assert(!q.candidates[0].query.includes('repair'));
  assert(q.structured.identityCompleteness.value>=60);
});

t('1.5.2 identity completeness exposes missing anchors',()=>{
  const x=c.identityCompleteness({brandTokens:['toy','biz'],productLineTokens:['wolverine'],modelTokens:['abc123'],category:'figure'},'toy figure');
  assert(x.value<60);
  assert(x.missing.includes('product line'));
  assert(x.missing.includes('model/SKU'));
});


t('1.6 dynamically discovers unknown multi-word manufacturer from evidence',()=>{
  const ev=[
    {title:'North Star Galaxy Quest Model Z500 Electronic Game'},
    {title:'North Star Galaxy Quest Z500 Handheld Game'},
    {title:'North Star Z500 Galaxy Quest Electronic Game'}
  ];
  const q=c.queryProfiles('North Star Galaxy Quest Z500 Electronic Handheld Game','',ev);
  assert.equal(q.structured.brand,'north star');
  assert(q.structured.productLine.includes('galaxy'));
  assert(q.structured.productLine.includes('quest'));
});

t('1.6 role graph separates condition from Sony model identity',()=>{
  const q=c.queryProfiles('Sony My First Sony CFM 2000 Cassette Player FOR PARTS OR REPAIR No Sound');
  assert(q.structured.roles.condition.includes('parts'));
  assert(q.structured.modelTokens.includes('cfm2000'));
  for(const x of q.candidates.slice(0,4)) assert(!/\b(parts|repair)\b/.test(x.query));
});

t('1.6 constraint synthesizer avoids broad legacy family query',()=>{
  const q=c.queryProfiles('Easton Walk Off Elite Camo Baseball Softball Backpack Bat Bag');
  assert(q.candidates.some(x=>x.query==='easton walk off elite bat bag'));
  assert(!q.candidates.some(x=>x.id==='legacy-family'));
});

t('1.6 marketplace refinement restores repeated source discriminator',()=>{
  const q=c.queryProfiles('Toy Biz Marvel X-Men Wolverine Mini Action Figure');
  const pool={rawItems:[
    {title:'Toy Biz Marvel X-Men Wolverine Action Figure'},
    {title:'Toy Biz X-Men Wolverine Figure 1994'},
    {title:'Marvel X-Men Wolverine Toy Biz Figure'},
    {title:'Toy Biz Wolverine X-Men Action Figure'},
    {title:'Toy Biz X-Men Wolverine Mini Figure'}
  ]};
  const r=c.marketRefinement(q.structured,pool,'toy biz marvel xmen figure');
  assert(r); assert(r.addedTokens.includes('wolverine')); assert(/wolverine/.test(r.query));
});

t('1.6 object-cluster inconsistency lowers candidate score',()=>{
  const q=c.queryProfiles("Bratz Lil Bratz Backpack");
  const pure=c.scoreQueryCandidate(q.structured,{query:'bratz lil backpack',rawItems:[
    {title:'Lil Bratz Backpack'},{title:'Bratz Lil Backpack Bag'},{title:'Lil Bratz Kids Backpack'},{title:'Lil Bratz Mini Backpack'},{title:'Bratz Backpack Lil'}
  ]});
  const mixed=c.scoreQueryCandidate(q.structured,{query:'bratz lil backpack',rawItems:[
    {title:'Lil Bratz Backpack'},{title:'Lil Bratz Doll'},{title:'Lil Bratz Playset'},{title:'Lil Bratz Shoes'},{title:'Lil Bratz Backpack'}
  ]});
  assert(pure.clusterConsistency>mixed.clusterConsistency);
  assert(pure.score>mixed.score);
});

t('1.6 identity completeness accepts named product without SKU',()=>{
  const q=c.queryProfiles('Pendleton Beaver State Wool Blanket Aztec');
  assert(q.structured.productLine.includes('beaver'));
  assert(q.structured.identityCompleteness.value>=60);
});

t('1.6 unknown evidence phrase becomes named identity without protected dictionary',()=>{
  const ev=[
    {title:'Orbitron Moon Runner Deluxe Backpack'},
    {title:'Orbitron Moon Runner Backpack Black'},
    {title:'Orbitron Moon Runner School Backpack'}
  ];
  const q=c.queryProfiles('Orbitron Moon Runner Deluxe Backpack','',ev);
  assert.equal(q.structured.brand,'orbitron');
  assert(/moon/.test(q.structured.productLine)&&/runner/.test(q.structured.productLine));
  assert(q.candidates[0].query.includes('backpack'));
});

t('1.6 normalized model chain beats feature words',()=>{
  const q=c.queryProfiles('Sony Cyber-Shot DSC-S930 Silver Digital Camera 10.1 MP Tested');
  assert(q.structured.modelTokens.includes('s930'));
  assert(q.candidates.some(x=>/sony.*dsc.*s930.*camera/.test(x.query)));
  assert(!q.candidates[0].query.includes('10'));
});

if(!process.exitCode) console.log(`ORBIT 1.6.0 Identity Lab: ${n}/${n} passed — 0 external API calls`);
