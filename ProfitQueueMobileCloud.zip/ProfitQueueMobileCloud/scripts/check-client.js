'use strict';
const fs=require('fs'),vm=require('vm');
const html=fs.readFileSync(require('path').join(__dirname,'..','public','index.html'),'utf8');
const m=[...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi)];
if(!m.length)throw new Error('No inline script found');
for(const [i,x] of m.entries())new vm.Script(x[1],{filename:`index-inline-${i}.js`});
console.log(`Client syntax OK (${m.length} inline script block${m.length===1?'':'s'})`);
