'use strict';
function median(arr){const a=arr.filter(Number.isFinite).slice().sort((x,y)=>x-y);if(!a.length)return 0;const i=Math.floor(a.length/2);return a.length%2?a[i]:(a[i-1]+a[i])/2;}
function percentile(arr,p){const a=arr.filter(Number.isFinite).slice().sort((x,y)=>x-y);if(!a.length)return 0;const x=(a.length-1)*p,lo=Math.floor(x),hi=Math.ceil(x);return lo===hi?a[lo]:a[lo]+(a[hi]-a[lo])*(x-lo);}
function robustPrices(values){const vals=values.filter(v=>Number.isFinite(v)&&v>0);if(vals.length<5)return vals;const med=median(vals),dev=vals.map(v=>Math.abs(v-med)),mad=median(dev);let filtered=mad>0?vals.filter(v=>Math.abs(v-med)/(1.4826*mad)<=3.5):vals;if(filtered.length<3){const q1=percentile(vals,.25),q3=percentile(vals,.75),iqr=Math.max(.01,q3-q1),lo=Math.max(0,q1-1.5*iqr),hi=q3+1.5*iqr;filtered=vals.filter(v=>v>=lo&&v<=hi);}return filtered.length>=3?filtered:vals;}
function trimmedMean(arr,trim=.1){const a=arr.filter(Number.isFinite).slice().sort((x,y)=>x-y);if(!a.length)return 0;const k=a.length>=10?Math.floor(a.length*trim):0;const b=k&&a.length-k*2>=3?a.slice(k,a.length-k):a;return b.reduce((s,v)=>s+v,0)/b.length;}
function assert(x,msg){if(!x)throw new Error(msg);}
assert(median([1,3,2])===2,'median');
assert(robustPrices([40,41,42,43,44,900]).length===5,'outlier rejection');
assert(trimmedMean([10,20,30,40,50])===30,'mean');

function numOrNull(v){return (v===null||v===undefined||v==='')?null:(Number.isFinite(Number(v))?Number(v):null);}
assert(numOrNull(null)===null,'null stays unknown');
assert(numOrNull('')===null,'blank stays unknown');
assert(numOrNull('0')===0,'explicit zero remains zero');
const serverSource=require('fs').readFileSync(require('path').join(__dirname,'..','server.js'),'utf8');
assert(serverSource.includes("ENGINE_VERSION = '1.0.2-hybrid-sourcing'"),'engine version');
assert(serverSource.includes('extracted_quantity_sold'),'current active sold-quantity field');
assert(serverSource.includes('https://api.trawl.dev/ebay/v1/sold'),'Trawl sold endpoint');
assert(serverSource.includes("'x-api-key':TRAWL_API_KEY"),'Trawl key stays server-side header');
assert(serverSource.includes('sampleTrawlSold'),'Trawl sold sampling enabled');
assert(serverSource.includes('trawlExclude(item, query)'),'Trawl exclusions are query-aware');
assert(serverSource.includes('/exclude overlaps query/i'),'Trawl overlap fallback exists');
assert(serverSource.includes('runTrawlQueued'),'Trawl calls are globally queued');
assert(serverSource.includes('TRAWL_MIN_INTERVAL_MS'),'Trawl request spacing exists');
assert(serverSource.includes('TRAWL_INFLIGHT'),'duplicate in-flight Trawl searches are deduped');
assert(serverSource.includes('retryAfterMs'),'Trawl Retry-After handling exists');
assert(serverSource.includes('status===429'),'Trawl rate-limit retry exists');
assert(serverSource.includes("x.price_tag===null || x.price_tag===undefined"),'null price is guarded before numeric conversion');

const specificIdx=serverSource.indexOf("[brand, model].filter(Boolean).join(' ')");
const genericIdx=serverSource.indexOf("[brand, type].filter(Boolean).join(' ')");
assert(specificIdx>=0 && genericIdx>specificIdx,'specific brand+model query must outrank generic category search');
assert(serverSource.includes('visualRefinedIdentity'),'photo-to-photo market-assisted identity refinement exists');
assert(serverSource.includes('querySpecificEnough'),'broad-query active totals are guarded');
assert(serverSource.includes('activeCountUncertain'),'active count uncertainty is surfaced');
assert(serverSource.includes('visualVerificationAvailable'),'visual verification status is surfaced');
assert(serverSource.includes('fetchCompImage'),'sold/active listing images are fetched server-side');
assert(serverSource.includes('imageUrl:cleanText(r.image_url)'), 'Trawl sold image_url is retained');
assert(serverSource.includes('r.thumbnail || r.image || r.image_url'), 'active listing thumbnail is retained');
assert(serverSource.includes('photo-to-photo + title verification'), 'visual verification source label is exposed');
assert(serverSource.includes('pricingVerified'),'pricing requires verified visual comps');
assert(serverSource.includes('velocityVerified'),'sell-through requires verified visual comps');

assert(serverSource.includes('familyAccept'),'strong visually similar family comps are supported');
assert(serverSource.includes("pricingMode==='brand_family'"),'brand-family pricing fallback exists');
assert(serverSource.includes("velocityMode==='brand_family'"),'brand-family sell-through fallback exists');
assert(serverSource.includes('conservativeSaleValue'),'family fallback uses conservative max-buy value');
assert(serverSource.includes('usableFamilyMarket'),'query ladder can stop on strong family evidence');


const queryFn=serverSource.slice(serverSource.indexOf('function itemQueryCandidates'),serverSource.indexOf('async function identifyImages'));
assert(queryFn.indexOf('titleWithoutColor')>=0,'identified title participates in the query ladder');
assert(queryFn.indexOf('titleWithoutColor') < queryFn.indexOf('...suppliedSpecific'),'identified product title must outrank AI-supplied market queries');
assert(queryFn.indexOf('...suppliedBroad') > queryFn.indexOf('[brand, type]'),'brand-only/broad supplied queries stay at the end');
assert(serverSource.includes('verifiedMatches>=2'),'market search stops on visually verified evidence, not raw hit count');
assert(serverSource.includes('continue down the query ladder'),'query ladder continues when visual verification rejects candidates');

const manifest=JSON.parse(require('fs').readFileSync(require('path').join(__dirname,'..','public','manifest.webmanifest'),'utf8'));assert(manifest.display==='standalone','PWA manifest');assert(manifest.short_name==='ORBIT','ORBIT manifest branding');
console.log('Core math + PWA self-test OK');

const clientSource=require('fs').readFileSync(require('path').join(__dirname,'..','public','index.html'),'utf8');
assert(clientSource.includes("label:'RETRY'"),'missing market data must not become PASS');

assert(clientSource.includes("same-brand family"),'client exposes brand-family evidence mode');
assert(clientSource.includes('velocityVerified'),'client refuses unverified sell-through verdicts');

assert(serverSource.includes("upload.fields([{name:'images',maxCount:5}"),'backend accepts up to five separate target photos');
assert(serverSource.includes('identifyImages(targetImages,mode)'),'multiple target photos are sent separately to vision');
assert(serverSource.includes('TARGET ITEM PHOTO'),'visual verifier receives multiple target photos separately');
assert(clientSource.includes("fd.append('images'"),'client uploads separate target photos instead of a flattened collage');
