'use strict';
const fs=require('fs'),path=require('path');
function median(arr){const a=arr.filter(Number.isFinite).slice().sort((x,y)=>x-y);if(!a.length)return 0;const i=Math.floor(a.length/2);return a.length%2?a[i]:(a[i-1]+a[i])/2;}
function assert(x,msg){if(!x)throw new Error(msg);}
assert(median([1,3,2])===2,'median');
const sandCloudSale=41.65,feesPct=15,shipping=9.12,supplies=1,minProfit=10,cost=1;
const sandCloudMaxBuy=sandCloudSale-sandCloudSale*(feesPct/100)-shipping-supplies-minProfit;
assert(sandCloudMaxBuy>cost,'$41.65 fast-selling item at $1 cost should not fail a hidden $25 profit rule');
const scarcitySold90=8,scarcityActive=0;
const scarcityStr=scarcityActive>0?scarcitySold90/scarcityActive:scarcitySold90;
assert(scarcityStr*100===800,'8 sold / 0 active scarcity lower bound uses one hypothetical active listing');
const serverSource=fs.readFileSync(path.join(__dirname,'..','server.js'),'utf8');
const clientSource=fs.readFileSync(path.join(__dirname,'..','public','index.html'),'utf8');
assert(serverSource.includes("ENGINE_VERSION = '1.2.14-pricing-lens-rescue'"),'engine version');
assert(serverSource.includes('velocity_family'),'vision returns canonical velocity family');
assert(serverSource.includes('function canonicalVelocityFamily'),'canonical family fallback exists');
assert(serverSource.includes('function familyTitleAccept'),'family title validator exists');
assert(serverSource.includes('function familyMarketQuality'),'family market is estimated from a broader pool');
assert(serverSource.includes('soldFamilyVelocity'),'sold family velocity pool exists');
assert(serverSource.includes('activeFamilyVelocity'),'active family velocity pool exists');
assert(serverSource.includes('Never choose exact velocity just because one exact active listing exists.'),'exact pool must be complete on both sides');
assert(serverSource.includes("matchedN||0)>=2") && serverSource.includes("matchedN||0)>=1"),'thin family evidence can still be represented');
assert(serverSource.includes('familyTwoCompReliable'),'two exceptional family price comps are supported');
assert(serverSource.includes('COMP_CLASSIFY_TIMEOUT_MS'),'comp verification has a latency budget');
assert(serverSource.includes('withTimeBudget'),'latency budget wrapper exists');
assert(serverSource.includes("slice(0,2)"),'comp verifier limits target photo payload');
assert(serverSource.includes('ORBIT timing:'),'stage timing is logged');
assert(serverSource.includes('const primaryQuery=(!hardIdentity && familyQuery)?familyQuery:query'),'generic goods use a single family provider search');
assert(serverSource.includes('TRAWL_MAX_ATTEMPTS_FAST'),'sold provider retries are latency bounded');
assert(serverSource.includes('identifyWithSoftFallback'),'identification uses a soft fallback instead of a hard abort');
assert(serverSource.includes('IDENTIFY_FALLBACK_DELAY_MS'),'identification soft budget exists');
assert(serverSource.includes('FAST_IDENTIFY_MODEL'),'fast identification model exists');
assert(serverSource.includes('LH_ItemCondition'),'active condition filter retained');
assert(serverSource.includes('runTrawlQueued'),'Trawl rate limiting retained');
assert(serverSource.includes('similarStyleMarketQuery'),'same-brand family search retained');
assert(serverSource.includes('pricingMode'),'pricing and velocity scopes remain separate');
assert(serverSource.includes('sellThroughEvidenceAssessment'),'STR confidence assessment retained');
assert(serverSource.includes('velocityVerified'),'low-evidence decisions remain gated');
assert(clientSource.includes("label:'BUY'") && clientSource.includes("label:'PASS'"),'binary BUY/PASS remains');
assert(clientSource.includes('velocityVerified'),'client respects verified velocity');
assert(clientSource.includes("max=1152"),'phone images are compressed for faster analysis');
const manifest=JSON.parse(fs.readFileSync(path.join(__dirname,'..','public','manifest.webmanifest'),'utf8'));
assert(manifest.display==='standalone' && manifest.short_name==='ORBIT','PWA manifest');
assert(serverSource.includes('const exactPoolComplete=Number(market.soldQ?.matchedN||0)>=4 && Number(market.activeQ?.matchedN||0)>=3'),'exact velocity requires evidence on both sides');

assert(serverSource.includes('familyActiveScarcityCandidate'),'zero-active family scarcity candidate exists');
assert(serverSource.includes('activeScarcitySignal'),'zero active inventory becomes a scarcity signal');
assert(serverSource.includes('activeListings>0?sold90/activeListings:(activeScarcitySignal?sold90:null)'),'scarcity STR uses conservative one-active denominator');
assert(serverSource.includes('settings.minProfit??10'),'server hidden $25 profit default removed');
assert(clientSource.includes('id="minNetProfit"'),'minimum net profit is visible in decision rules');
assert(clientSource.includes("orbit.minNetProfit"),'minimum net profit is saved on device');
assert(clientSource.includes('minProfit:RULES.minNetProfit'),'client sends visible profit target to server');
assert(clientSource.includes('active inventory scarce'),'scarcity state is visible in results');

assert(!serverSource.includes('IDENTIFY_TIMEOUT_MS'),'hard identification timeout removed');
assert(serverSource.includes('providerMs') && serverSource.includes('classifyMs'),'stage timing breakdown is logged');
assert(serverSource.includes('ANALYSIS_CACHE_TTL_MS = 15 * 60 * 1000'),'stable market snapshot cache exists');
assert(serverSource.includes('analysisFingerprint'),'repeat analyses use a deterministic image/settings fingerprint');
assert(serverSource.includes('temperature: 0'),'Gemini classification is deterministic');
assert(clientSource.includes('stable snapshot reused'),'client discloses snapshot reuse');

assert(serverSource.includes('const sold90=soldDataAvailable?Number(soldQ?.estimate||0):0'),'sell-through independent of pricing verification');
assert(serverSource.includes('exactHybridReliable'),'title-supported exact pricing fallback exists');
assert(serverSource.includes('usableModelIdentity'),'brand-as-model sanitization exists');

assert(serverSource.includes('familyHybridReliable'),'title-supported family pricing fallback exists');
assert(serverSource.includes('targetTitleSupport'),'generic family pricing requires target-specific title support');

assert(serverSource.includes('function soldTitlePricingCandidates'),'larger sold-title pricing pool exists');
assert(serverSource.includes('function pricePoolReliability'),'sold-title pricing pool is dispersion checked');
assert(serverSource.includes('modelTitleSupport'),'model token pricing support exists');
assert(serverSource.includes('queryTitleSupport'),'exact-query title pricing support exists');
assert(serverSource.includes('serpLensHints'),'selective Google Lens rescue exists');
assert(serverSource.includes("engine','google_lens"),'Google Lens engine is wired through SerpApi');
assert(serverSource.includes('ensureBrandInTitle'),'known brands are forced into displayed titles');
assert(clientSource.includes('exact model-matched sold comps'),'pricing evidence mode is disclosed to the user');

console.log('Core math + resilient pricing + Lens rescue + stable demand PWA self-test OK');
