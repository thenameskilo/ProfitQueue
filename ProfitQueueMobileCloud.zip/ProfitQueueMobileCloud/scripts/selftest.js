'use strict';
function median(arr){const a=arr.filter(Number.isFinite).slice().sort((x,y)=>x-y);if(!a.length)return 0;const i=Math.floor(a.length/2);return a.length%2?a[i]:(a[i-1]+a[i])/2;}
function percentile(arr,p){const a=arr.filter(Number.isFinite).slice().sort((x,y)=>x-y);if(!a.length)return 0;const x=(a.length-1)*p,lo=Math.floor(x),hi=Math.ceil(x);return lo===hi?a[lo]:a[lo]+(a[hi]-a[lo])*(x-lo);}
function robustPrices(values){const vals=values.filter(v=>Number.isFinite(v)&&v>0);if(vals.length<5)return vals;const med=median(vals),dev=vals.map(v=>Math.abs(v-med)),mad=median(dev);let filtered=mad>0?vals.filter(v=>Math.abs(v-med)/(1.4826*mad)<=3.5):vals;if(filtered.length<3){const q1=percentile(vals,.25),q3=percentile(vals,.75),iqr=Math.max(.01,q3-q1),lo=Math.max(0,q1-1.5*iqr),hi=q3+1.5*iqr;filtered=vals.filter(v=>v>=lo&&v<=hi);}return filtered.length>=3?filtered:vals;}
function trimmedMean(arr,trim=.1){const a=arr.filter(Number.isFinite).slice().sort((x,y)=>x-y);if(!a.length)return 0;const k=a.length>=10?Math.floor(a.length*trim):0;const b=k&&a.length-k*2>=3?a.slice(k,a.length-k):a;return b.reduce((s,v)=>s+v,0)/b.length;}
function assert(x,msg){if(!x)throw new Error(msg);}
assert(median([1,3,2])===2,'median');
assert(robustPrices([40,41,42,43,44,900]).length===5,'outlier rejection');
assert(trimmedMean([10,20,30,40,50])===30,'mean');
const manifest=JSON.parse(require('fs').readFileSync(require('path').join(__dirname,'..','public','manifest.webmanifest'),'utf8'));assert(manifest.display==='standalone','PWA manifest');
console.log('Core math + PWA self-test OK');
