'use strict';
const fs=require('fs'),path=require('path');
function median(arr){const a=arr.filter(Number.isFinite).slice().sort((x,y)=>x-y);if(!a.length)return 0;const i=Math.floor(a.length/2);return a.length%2?a[i]:(a[i-1]+a[i])/2;}
function assert(x,msg){if(!x)throw new Error(msg);}
assert(median([1,3,2])===2,'median');
const sandCloudSale=41.65,feesPct=15,shipping=9.12,supplies=1,minProfit=10,cost=1;
const sandCloudMaxBuy=sandCloudSale-sandCloudSale*(feesPct/100)-shipping-supplies-minProfit;
assert(sandCloudMaxBuy>cost,'$41.65 fast-selling item at $1 cost should not fail a hidden $25 profit rule');
const scarcitySold90=8,scarcityActive=0;
const scarcityStr=scarcityActive>0?scarcitySold90/scarcityActive:scarcitySold90;
assert(scarcityStr*100===800,'8 sold / 0 active scarcity lower bound uses one hypothetical active listing');
const serverSource=fs.readFileSync(path.join(__dirname,'..','server.js'),'utf8');
const clientSource=fs.readFileSync(path.join(__dirname,'..','public','index.html'),'utf8');
assert(serverSource.includes("ENGINE_VERSION = '1.2.28-str-sanity-identity-guard'"),'engine version');
assert(serverSource.includes('velocity_family'),'vision returns canonical velocity family');
assert(serverSource.includes('function canonicalVelocityFamily'),'canonical family fallback exists');
assert(serverSource.includes('function familyTitleAccept'),'family title validator exists');
assert(serverSource.includes('function familyMarketQuality'),'family market is estimated from a broader pool');
assert(serverSource.includes('soldFamilyVelocity'),'sold family velocity pool exists');
assert(serverSource.includes('activeFamilyVelocity'),'active family velocity pool exists');
assert(serverSource.includes('Never choose exact velocity just because one exact active listing exists.'),'exact pool must be complete on both sides');
assert(serverSource.includes("matchedN||0)>=2") && serverSource.includes("matchedN||0)>=1"),'thin family evidence can still be represented');
assert(serverSource.includes('COMP_CLASSIFY_TIMEOUT_MS'),'comp verification has a latency budget');
assert(serverSource.includes('withTimeBudget'),'latency budget wrapper exists');
assert(serverSource.includes("slice(0,2)"),'comp verifier limits target photo payload');
assert(serverSource.includes('ORBIT timing:'),'stage timing is logged');
assert(serverSource.includes('const primaryQuery=(!hardIdentity && familyQuery)?familyQuery:query'),'generic goods use a single family provider search');
assert(serverSource.includes('TRAWL_MAX_ATTEMPTS_FAST'),'sold provider retries are latency bounded');
assert(serverSource.includes('identifyWithSoftFallback'),'identification uses a soft fallback instead of a hard abort');
assert(serverSource.includes('IDENTIFY_FALLBACK_DELAY_MS'),'identification soft budget exists');
assert(serverSource.includes('FAST_IDENTIFY_MODEL'),'fast identification model exists');
assert(serverSource.includes('LH_ItemCondition'),'active condition filter retained');
assert(serverSource.includes('runTrawlQueued'),'Trawl rate limiting retained');
assert(serverSource.includes('similarStyleMarketQuery'),'same-brand family search retained');
assert(serverSource.includes('adaptive evidence hierarchy')||serverSource.includes('ADAPTIVE EVIDENCE ENGINE'),'adaptive evidence hierarchy is documented in code');
assert(serverSource.includes('sellThroughEvidenceAssessment'),'STR confidence assessment retained');
assert(serverSource.includes('velocityVerified'),'low-evidence decisions remain gated');
assert(clientSource.includes("label:'BUY'") && clientSource.includes("label:'PASS'"),'binary BUY/PASS remains');
assert(clientSource.includes('velocityVerified'),'client respects verified velocity');
assert(clientSource.includes("max=1152"),'phone images are compressed for faster analysis');
const manifest=JSON.parse(fs.readFileSync(path.join(__dirname,'..','public','manifest.webmanifest'),'utf8'));
assert(manifest.display==='standalone' && manifest.short_name==='ORBIT','PWA manifest');
assert(serverSource.includes('const exactPoolComplete=Number(market.soldQ?.matchedN||0)>=4 && Number(market.activeQ?.matchedN||0)>=3'),'exact velocity requires evidence on both sides');

assert(serverSource.includes('familyActiveScarcityCandidate'),'zero-active family scarcity candidate exists');
assert(serverSource.includes('activeScarcitySignal'),'zero active inventory becomes a scarcity signal');
assert(serverSource.includes('activeListings>0?sold90/activeListings:(activeScarcitySignal?sold90:null)'),'scarcity STR uses conservative one-active denominator');
assert(serverSource.includes('settings.minProfit??10'),'server hidden $25 profit default removed');
assert(clientSource.includes('id="minNetProfit"'),'minimum net profit is visible in decision rules');
assert(clientSource.includes("orbit.minNetProfit"),'minimum net profit is saved on device');
assert(clientSource.includes('minProfit:RULES.minNetProfit'),'client sends visible profit target to server');
assert(clientSource.includes('active inventory scarce'),'scarcity state is visible in results');

assert(!serverSource.includes('IDENTIFY_TIMEOUT_MS'),'hard identification timeout removed');
assert(serverSource.includes('providerMs') && serverSource.includes('classifyMs'),'stage timing breakdown is logged');
assert(serverSource.includes('ANALYSIS_CACHE_TTL_MS = 15 * 60 * 1000'),'stable market snapshot cache exists');
assert(serverSource.includes('analysisFingerprint'),'repeat analyses use a deterministic image/settings fingerprint');
assert(serverSource.includes('temperature: 0'),'Gemini classification is deterministic');
assert(clientSource.includes('stable snapshot reused'),'client discloses snapshot reuse');

assert(serverSource.includes('const sold90=soldDataAvailable?Number(soldQ?.estimate||0):0'),'sell-through independent of pricing verification');
assert(serverSource.includes('exactHybridReliable'),'title-supported exact pricing fallback exists');
assert(serverSource.includes('usableModelIdentity'),'brand-as-model sanitization exists');

assert(serverSource.includes('function adaptivePricePool'),'adaptive pricing pool exists');
assert(serverSource.includes('function selectAdaptivePricingPool'),'pricing scope is selected automatically');
assert(serverSource.includes('market.soldFamilyVelocity'),'pricing reuses the same validated family pool as demand');
assert(serverSource.includes('pricingAvailable'),'low-confidence prices can be displayed without authorizing a BUY');

assert(serverSource.includes('function soldTitlePricingCandidates'),'larger sold-title pricing pool exists');
assert(serverSource.includes('function pricePoolReliability'),'sold-title pricing pool is dispersion checked');
assert(serverSource.includes('modelTitleSupport'),'model token pricing support exists');
assert(serverSource.includes('queryTitleSupport'),'exact-query title pricing support exists');
assert(serverSource.includes('serpLensHints'),'selective Google Lens rescue exists');
assert(serverSource.includes('hardFallbackIdentity'),'hard Google Lens/user-hint identification fallback exists');
assert(serverSource.includes('provisionalIdentityFromLens'),'provisional non-Gemini identity builder exists');
assert(serverSource.includes('Primary item identification unavailable'),'Gemini exhaustion is caught before hard failure');
assert(serverSource.includes("engine','google_lens"),'Google Lens engine is wired through SerpApi');
assert(serverSource.includes('ensureBrandInTitle'),'known brands are forced into displayed titles');
assert(clientSource.includes('exact model-matched sold prices'),'pricing evidence mode is disclosed to the user');

assert(!clientSource.includes("if(item.visualVerificationAvailable!==true)return{label:'PASS'"),'visual verification is not a standalone PASS veto');
assert(clientSource.includes('Sold market matches') && clientSource.includes('visually checked'),'market match estimate and visual sample are displayed separately');
assert(serverSource.includes('did not use the missing photo classification alone as a PASS veto'),'visual verification failure is advisory evidence');
assert(serverSource.includes('sanitizeUserHints'),'user hints are sanitized server-side');
assert(serverSource.includes('userHintSearchQuery'),'user hints can seed search queries');
assert(serverSource.includes('USER-PROVIDED ITEM HINTS'),'identification receives user hints as non-authoritative context');
assert(clientSource.includes('id="itemHints"'),'optional item hints field is visible');
assert(clientSource.includes('itemHints}'),'client sends item hints with analysis settings');
assert(clientSource.includes('conflicting photo evidence still wins'),'client explains hints are not authoritative');
assert(clientSource.includes('confidence-adjusted expected order value'),'client explains max-buy basis');

// Confidence-adjusted max-buy applies globally: total buyer-paid order value is used, not a fixed family percentile.
const marvelItem=12.69,marvelBuyerShip=5.99,marvelScore=.65,marvelPostage=5.25,marvelSupplies=1,marvelProfit=5,marvelCost=.338;
const marvelRisk=.74+.26*marvelScore;
const marvelGross=(marvelItem+marvelBuyerShip)*marvelRisk;
const marvelMax=Math.max(0,marvelGross-marvelGross*.15-marvelPostage-marvelSupplies-marvelProfit);
assert(marvelMax>marvelCost,'cheap high-demand item with buyer-paid shipping should have a usable max buy');
assert(!serverSource.includes('Number(conservativeSaleValue.toFixed(2))'),'stale conservativeSaleValue response reference removed');
assert(serverSource.includes('conservativeSaleValue:pricingAvailable?Number(riskAdjustedItemValue.toFixed(2)):0'),'legacy response field now maps to confidence-adjusted item value');
assert(serverSource.includes('riskAdjustedGrossValue'),'max-buy uses confidence-adjusted gross order value');
assert(serverSource.includes('soldGrossValues'),'max-buy includes buyer-paid shipping from sold comps');
assert(serverSource.includes("clamp(.74+.26*pricingConfidenceScore,.74,.98)"),'max-buy conservatism scales continuously with pricing confidence');
assert(!serverSource.includes('percentile(soldPrices,.30)||saleAverage'),'fixed 30th-percentile family max-buy haircut removed');

assert(serverSource.includes('function reconcileIdentityWithLens'),'independent Lens identity reconciliation exists');
assert(serverSource.includes('specificIdentityNeedsCrossCheck'),'specific brand/model answers are cross-checked before market search');
assert(serverSource.includes("lens_crosscheck_status:'corrected_conflict'"),'Lens conflicts can correct a specific identity');
assert(serverSource.includes('modelConflict'),'same-brand wrong-model conflicts are also corrected');
assert(serverSource.includes('const lensPromise=!group && SERPAPI_KEY ? serpLensHints(usable[0])'),'Lens cross-check runs alongside Gemini to reduce latency');
assert(serverSource.includes('Identity cross-check corrected conflict:'),'identity corrections are auditable in logs');
assert(serverSource.includes('lensCheck=${finalIdentity.lens_crosscheck_status'),'stage log exposes Lens cross-check result');
assert(fs.readFileSync(path.join(__dirname,'..','public','sw.js'),'utf8').includes('orbit-shell-v29'),'PWA cache bumped for identity cross-check release');


// Behavioral regression for the real failure we saw: Bose QC30 must not remain Jabra Elite 25e
// when independent Lens evidence strongly agrees on Bose before any market query is built.
const {reconcileIdentityWithLens,itemQueryCandidates}=require('../server');
const wrongSpecific={title:'Jabra Elite 25e Wireless Bluetooth Neckband Earphones',brand:'Jabra',model:'Elite 25e',item_type:'wireless neckband headphones',identity_confidence:.94,visible_text:[],identity_terms:['Elite 25e'],query_candidates:['Jabra Elite-25e'],condition:'used'};
const boseLens=[
  {title:'Bose QuietControl 30 Wireless Headphones'},
  {title:'Bose QuietControl 30 QC30 Bluetooth Neckband Headphones'},
  {title:'Bose QuietControl 30 Wireless Noise Cancelling Headphones'},
  {title:'Bose QuietControl 30 Black Wireless Headset'}
];
const corrected=reconcileIdentityWithLens(wrongSpecific,boseLens);
assert(corrected.lens_crosscheck_status==='corrected_conflict','Jabra -> Bose disagreement must trigger identity correction');
assert((corrected.brand||'').toLowerCase()==='bose','identity correction must choose Bose from Lens consensus');
assert(/quietcontrol/i.test(`${corrected.model||''} ${corrected.title||''}`),'identity correction must recover QuietControl 30 family/model');
const correctedMarketQueries=itemQueryCandidates(corrected);
assert(/bose/i.test(correctedMarketQueries[0]||''),'market search must start from corrected Bose identity');
assert(!/^jabra\b/i.test(correctedMarketQueries[0]||''),'wrong Jabra identity must not seed the first market query');

console.log('Core math + resilient market availability + Lens identity cross-check + visual fallback scope fix + confidence-adjusted max buy + evidence-first decision + adaptive pricing + hard Lens fallback + user hints + stable demand PWA self-test OK');


assert(serverSource.includes('visualCompWarning\n  };')||serverSource.includes('visualCompWarning\r\n  };'),'visual comp warning is returned with market evidence');
assert(serverSource.includes("market.visualCompWarning||'Listing-photo classification was unavailable or inconclusive."),'visual comp warning is read from market scope');
assert(!serverSource.includes('evidenceNotes.push(visualCompWarning||'),'out-of-scope visualCompWarning reference removed');


assert(serverSource.includes("const activeDataAvailable=activePrimaryAvailable || activeFamilyAvailable"),'family active search can satisfy active market availability when primary active request fails');
assert(serverSource.includes("const soldDataAvailable=soldPrimaryAvailable || soldFamilyAvailable"),'family sold search can satisfy sold market availability when primary sold request fails');
assert(!serverSource.includes('not enough active listing photos were available to verify sell-through'),'visual active-photo count is not a hard sell-through gate');

assert(serverSource.includes('listing-photo classifier inconclusive, title-supported evidence used'),'visual classifier failure is described as an advisory fallback');
assert(!serverSource.includes("providerErrors.push(`visual comp verification unavailable"),'visual classifier warning is not exposed as a provider failure');


// 1.2.28 STR sanity + identity guard + zero-credit Test Lab.
const packageJson=JSON.parse(fs.readFileSync(path.join(__dirname,'..','package.json'),'utf8'));
assert(packageJson.version==='1.2.28','package version 1.2.28');
assert(packageJson.scripts.test.includes('scripts/testlab.js'),'deployment test command runs zero-credit Test Lab');
assert(fs.existsSync(path.join(__dirname,'testlab.js')),'offline Test Lab script exists');
assert(serverSource.includes("app.post('/api/testlab/run'"),'authenticated Test Lab API endpoint exists');
assert(clientSource.includes('Run offline regression suite'),'Test Lab is available in the app UI');
assert(clientSource.includes('0 API credits'),'Test Lab clearly discloses zero external API calls');
assert(serverSource.includes('CLOUDFLARE_ACCOUNT_ID') && serverSource.includes('cloudflareVisionIdentify'),'Cloudflare Workers AI optional vision provider exists');
assert(serverSource.includes('GROQ_API_KEY') && serverSource.includes('groqVisionIdentify'),'Groq optional vision provider exists');
assert(serverSource.includes('ORBIT_VISION_PROVIDER_ORDER') && serverSource.includes('identifyWithProviderRouter'),'vision provider router exists');
assert(serverSource.includes("'cloudflare,groq,gemini'"),'provider router defaults to lower-cost alternatives before Gemini when configured');
assert(serverSource.includes("if (!anyVisionProviderConfigured()) throw new Error('No vision provider is configured')"),'Gemini is no longer the only acceptable identity provider');
