'use strict';
const {marketToItem,reconcileIdentityWithLens,itemQueryCandidates,robustPrices,familyMarketQuality}=require('../server');

const jsonMode=process.argv.includes('--json');
const baseSettings={acquisitionMode:'normal',manualPrice:1,binsPricePerLb:null,minProfit:10,minResaleValue:25,minSellThrough:10,defaultFeesPct:15};
function q(matched,estimate,{sampleN,precision=.86,precisionLow=.70,total,uncertain=false,broadQuery=false,low,high}={}){
  const s=sampleN??Math.max(1,matched);
  const t=total??Math.max(s,Math.ceil(estimate||matched));
  return {matchedN:matched,estimate,sampleN:s,total:t,precision,precisionLow,low:low??Math.max(0,(estimate||0)*.8),high:high??Math.max(estimate||0,(estimate||0)*1.2),uncertain,broadQuery};
}
function rows(identity,prices,{family=true,shipping=6,visual=false,titlePrefix=null,searchPool}={}){
  const prefix=titlePrefix||`${identity.brand||''} ${identity.model||identity.item_type||identity.title}`.trim();
  return prices.map((price,i)=>({
    title:`${prefix} ${i+1}`.trim(),price,shipping,landedPrice:price+Math.max(0,shipping),sold_date:`2026-09-${String((i%20)+1).padStart(2,'0')}`,
    searchPool:searchPool||(family?'similar_style':'exact'),visualVerified:visual,visualConfidence:visual?.88:0,match:.92,compTier:visual?1:2,compClass:family?'title_supported_family':'title_supported_exact'
  }));
}
function identity(overrides={}){
  return {title:'Test Item',brand:'TestBrand',model:'Model 1',item_type:'item',category:'General',condition:'used',identity_confidence:.90,identity_terms:['Model 1'],family_identity_terms:[],velocity_family:'item',exclude_terms:[],is_bundle:false,shipping_estimate:6,supplies_estimate:1,labor_min:10,price_tag:null,weight_estimate_lb:.5,weight_low_lb:.4,weight_high_lb:.6,weight_confidence:.8,...overrides};
}
function market(id,{mode='family',prices=[40,42,44,46,48,50],sold=30,active=30,exactSold=0,exactActive=0,visual=false,soldAvailable=true,activeAvailable=true,activeUncertain=false,activeBroad=false,agreement=.96,shipping=6,providerErrors=[],familySample,exactSample,activeTotal,soldTotal,visualWarning=null}={}){
  const familyRows=rows(id,prices,{family:true,shipping,visual,titlePrefix:`${id.brand||''} ${id.model||''} ${id.item_type||''}`});
  const exactRows=mode==='exact'?rows(id,prices,{family:false,shipping,visual,titlePrefix:`${id.brand||''} ${id.model||''}`}):[];
  const familySold=mode==='exact'?Math.max(sold,exactSold||sold):sold;
  const familyActive=mode==='exact'?Math.max(active,exactActive||active):active;
  const exactSoldN=mode==='exact'?(exactSold||sold):exactSold;
  const exactActiveN=mode==='exact'?(exactActive||active):exactActive;
  const soldExactQ=q(exactSoldN,exactSoldN,{sampleN:exactSample??Math.max(4,exactSoldN),total:soldTotal??Math.max(exactSoldN,8),precisionLow:.72});
  const activeExactQ=q(exactActiveN,exactActiveN,{sampleN:exactSample??Math.max(4,exactActiveN),total:activeTotal??Math.max(exactActiveN,8),precisionLow:.72,uncertain:activeUncertain,broadQuery:activeBroad});
  const familySoldQ=q(familySold,sold,{sampleN:familySample??Math.max(2,familySold),total:soldTotal??Math.max(familySold,sold),precisionLow:.72});
  const familyActiveQ=q(familyActive,active,{sampleN:familySample??Math.max(1,familyActive),total:activeTotal??Math.max(familyActive,active),precisionLow:.70,uncertain:activeUncertain,broadQuery:activeBroad});
  return {
    query:`${id.brand||''} ${id.model||''}`.trim(),familyQuery:`${id.brand||''} ${id.velocity_family||id.item_type||''}`.trim(),
    soldDataAvailable:soldAvailable,activeDataAvailable:activeAvailable,visualVerificationAvailable:visual,
    prices:exactRows.map(r=>r.price),familyPrices:familyRows.map(r=>r.price),soldPre:[...exactRows,...familyRows],soldExact:exactRows,soldFamilyVelocity:familyRows,soldFamily:familyRows,
    soldQ:soldExactQ,activeQ:activeExactQ,familySoldQ,familyActiveQ,
    visualSoldInspected:visual?Math.min(4,familyRows.length):0,visualActiveInspected:visual?Math.min(4,Math.max(1,familyActive)):0,
    visualSoldExactInspected:visual?Math.min(4,exactRows.length):0,visualActiveExactInspected:visual?Math.min(4,Math.max(1,exactActiveN)):0,
    agreement,soldSource:'Fixture',providerErrors,visualCompWarning:visualWarning
  };
}
function runMarketCase(name,id,m,settings,check,group='decision'){
  try{
    const result=marketToItem(id,m,{...baseSettings,...settings});
    const verdict=check(result);
    const ok=verdict===true || verdict?.ok===true;
    return {name,group,ok,detail:typeof verdict==='object'&&verdict?.detail?verdict.detail:(ok?'pass':'expectation failed'),metrics:{price:result.averageSalePrice,str:result.sellThrough90,maxBuy:result.maxBuyPrice,pricing:result.pricingVerified,velocity:result.velocityVerified,pricingMode:result.pricingMode,velocityMode:result.velocityMode,confidence:result.sellThroughConfidenceLabel}};
  }catch(err){return{name,group,ok:false,detail:err.message};}
}
function okWhen(ok,detail){return {ok,detail};}
const cases=[];

// Real-world replay-style cases from ORBIT debugging history.
{
  const id=identity({title:'Bose QuietControl 30 Wireless Headphones',brand:'Bose',model:'QuietControl 30',item_type:'wireless neckband headphones',velocity_family:'wireless neckband headphones',identity_confidence:.95,shipping_estimate:5.5,weight_estimate_lb:.3,weight_low_lb:.25,weight_high_lb:.4});
  const m=market(id,{prices:[44,49,52,55,58,61,65,70],sold:60,active:100,visual:false});
  cases.push(runMarketCase('Bose QC30 — visual classifier unavailable still yields STR',id,m,{},r=>okWhen(r.velocityVerified&&r.sellThrough90===60&&r.pricingVerified,'expected verified 60% STR and pricing'),'replay'));
}
{
  const id=identity({title:'Vintage Toy Biz Marvel Wolverine Action Figure 2 Inch',brand:'Toy Biz',model:'Wolverine',item_type:'action figure',velocity_family:'action figure',identity_confidence:.86,shipping_estimate:5.25,supplies_estimate:1,weight_estimate_lb:.1,weight_low_lb:.08,weight_high_lb:.1});
  const m=market(id,{prices:[9.99,11,12.5,13,14.5,15.75,17,19],sold:100,active:85,shipping:6.55});
  cases.push(runMarketCase('Wolverine — cheap high-demand bins item gets nonzero max buy',id,m,{acquisitionMode:'bins',manualPrice:null,binsPricePerLb:1.69,minProfit:5},r=>okWhen(r.maxBuyPrice>r.cost&&r.sellThrough90>100,`maxBuy ${r.maxBuyPrice}, cost ${r.cost}, STR ${r.sellThrough90}`),'replay'));
}
{
  const id=identity({title:'Kim Seybert Beaded Fall Leaves Table Runner',brand:'Kim Seybert',model:null,item_type:'beaded table runner',velocity_family:'beaded table runner',identity_confidence:.90,shipping_estimate:9,supplies_estimate:2});
  const m=market(id,{prices:[95,110,125,135,145,155,170,185,210],sold:9,active:35,shipping:12});
  cases.push(runMarketCase('Kim Seybert — high-value family pricing survives no visual comps',id,m,{},r=>okWhen(r.pricingVerified&&r.averageSalePrice>120&&r.sellThrough90>20&&r.sellThrough90<35,`price ${r.averageSalePrice}, STR ${r.sellThrough90}`),'replay'));
}
{
  const id=identity({title:'HOKA Tor Summit Hiking Shoes',brand:'HOKA',model:'Tor Summit',item_type:'hiking shoes',velocity_family:'hiking shoes',identity_confidence:.94,shipping_estimate:9});
  const m=market(id,{mode:'exact',prices:[48,55,60,64,67,70,75,82],sold:44,active:38,visual:false});
  cases.push(runMarketCase('HOKA Tor Summit — exact title evidence works without image verification',id,m,{},r=>okWhen(r.pricingVerified&&r.velocityVerified&&r.pricingMode==='exact'&&r.sellThrough90>100,`mode ${r.pricingMode}, STR ${r.sellThrough90}`),'replay'));
}
{
  const id=identity({title:'Vintage Pizza Hut Stuffed Crust T-Shirt',brand:'Pizza Hut',model:null,item_type:'graphic t-shirt',velocity_family:'graphic t-shirt',identity_confidence:.82,shipping_estimate:5.25});
  const m=market(id,{prices:[11,13,14,15.5,17,19],sold:4,active:31,shipping:6});
  cases.push(runMarketCase('Pizza Hut tee — low sell-through remains measurable',id,m,{minResaleValue:10},r=>okWhen(r.sellThrough90>10&&r.sellThrough90<20&&r.velocityVerified,`STR ${r.sellThrough90}`),'replay'));
}
{
  const id=identity({title:'Jabra Halo Smart Wireless Neckband Headset',brand:'Jabra',model:'Halo Smart',item_type:'wireless neckband headset',velocity_family:'wireless neckband headset',identity_confidence:.88});
  const m=market(id,{prices:[35,40,48,52,58,65,75],sold:40,active:57,visual:false});
  cases.push(runMarketCase('Jabra family pool — 40 sold / 57 active must not become blank STR',id,m,{},r=>okWhen(r.sellThrough90!==null&&r.velocityVerified&&Math.abs(r.sellThrough90-70.2)<.2,`STR ${r.sellThrough90}`),'replay'));
}


{
  const search={similarStyleQuery:'Bose wireless neckband headphones',familyExactState:'Exact spelling',familyProviderTotal:4200,providerTotal:4200,totalTrusted:false};
  const candidateRows=Array.from({length:20},(_,i)=>({title:`Bose neckband ${i}`}));
  const matchedRows=candidateRows.slice(0,7);
  const qf=familyMarketQuality(search,candidateRows,matchedRows,{sold:false,familyQuery:'Bose wireless neckband headphones'});
  cases.push({name:'Active family provider total cannot inflate STR denominator',group:'sell-through',ok:qf.estimate===7&&qf.total===20&&qf.uncertain===true,detail:`estimate=${qf.estimate}, total=${qf.total}, providerTotal=${search.familyProviderTotal}`,metrics:{estimate:qf.estimate,total:qf.total}});
}
{
  const id=identity({title:'Jabra-looking neckband headset',brand:'Jabra',model:'Halo Smart',item_type:'wireless neckband headset',velocity_family:'wireless neckband headset',identity_confidence:.61,identity_uncorroborated:true});
  const qs=itemQueryCandidates(id);
  cases.push({name:'Uncorroborated model does not lead the market query ladder',group:'identity',ok:qs.length>0&&!/halo smart/i.test(qs[0]||''),detail:`first query=${qs[0]}`,metrics:{first:qs[0]}});
}

// Market-availability and STR resilience.
{
  const id=identity({title:'Family-only active fallback',brand:'Brand A',model:'M1',velocity_family:'headphones'});
  const m=market(id,{sold:24,active:40,visual:false}); m.activeQ=q(0,0,{sampleN:1,total:1,precisionLow:0}); m.activeDataAvailable=true;
  cases.push(runMarketCase('Family active evidence is enough when exact active pool is empty',id,m,{},r=>okWhen(r.velocityVerified&&r.sellThrough90===60,`STR ${r.sellThrough90}`),'sell-through'));
}
{
  const id=identity({title:'Family-only sold fallback',brand:'Brand B',model:'M2',velocity_family:'boots'});
  const m=market(id,{sold:18,active:30}); m.soldQ=q(0,0,{sampleN:1,total:1,precisionLow:0});
  cases.push(runMarketCase('Family sold evidence is enough when exact sold pool is empty',id,m,{},r=>okWhen(r.pricingVerified&&r.velocityVerified&&r.sellThrough90===60,`price ${r.averageSalePrice}, STR ${r.sellThrough90}`),'sell-through'));
}
{
  const id=identity({title:'Visual timeout scenario',brand:'Brand C',model:'M3',velocity_family:'camera'});
  const m=market(id,{sold:20,active:20,visual:false,visualWarning:'simulated visual classifier timeout'});
  cases.push(runMarketCase('Visual timeout is advisory, not an STR veto',id,m,{},r=>okWhen(r.velocityVerified&&r.sellThrough90===100&&!r.reviewReasons.some(x=>/photo/i.test(x)),`review ${r.reviewReasons.join('; ')}`),'stress'));
}
{
  const id=identity({title:'Missing active provider',brand:'Brand D',model:'M4'});
  const m=market(id,{sold:20,active:0,activeAvailable:false});
  cases.push(runMarketCase('No active provider data keeps STR unavailable',id,m,{},r=>okWhen(!r.velocityVerified&&r.sellThrough90===null,'expected null STR'),'stress'));
}
{
  const id=identity({title:'Missing sold provider',brand:'Brand E',model:'M5'});
  const m=market(id,{sold:0,active:20,soldAvailable:false,prices:[]});
  cases.push(runMarketCase('No sold provider data keeps pricing unverified',id,m,{},r=>okWhen(!r.pricingVerified&&r.sellThrough90===null,'expected no verified pricing'),'stress'));
}
{
  const id=identity({title:'Thin demand sample',brand:'Brand F',model:'M6'});
  const m=market(id,{sold:1,active:1,prices:[30],familySample:1});
  cases.push(runMarketCase('Single sold/active match does not authorize velocity',id,m,{},r=>okWhen(!r.velocityVerified,'velocity should remain unverified'),'sell-through'));
}
{
  const id=identity({title:'Scarce collectible',brand:'RareCo',model:'R1',velocity_family:'collectible'});
  const m=market(id,{sold:8,active:0,prices:[55,60,65,70,75,80],familySample:8,activeTotal:1});
  m.familyActiveQ=q(0,0,{sampleN:2,total:2,precisionLow:.75,low:0,high:0});
  cases.push(runMarketCase('Zero active + multiple sold becomes scarcity lower bound',id,m,{},r=>okWhen(r.velocityVerified&&r.activeScarcitySignal&&r.sellThrough90===800&&r.sellThroughLowerBound,`STR ${r.sellThrough90}`),'sell-through'));
}
{
  const id=identity({title:'Broad uncertain exact query',brand:'BroadCo',model:'X1'});
  const m=market(id,{mode:'exact',sold:10,active:100,prices:[25,28,30,31,32,35],activeUncertain:true,activeBroad:true,activeTotal:1000});
  cases.push(runMarketCase('Broad uncertain exact active count is not decision-ready',id,m,{},r=>okWhen(!r.velocityVerified,'broad active query should not be verified'),'sell-through'));
}
{
  const id=identity({title:'Exact complete pool',brand:'ExactCo',model:'E100',velocity_family:'widget'});
  const m=market(id,{mode:'exact',sold:12,active:8,prices:[30,32,34,35,36,38,40]});
  cases.push(runMarketCase('Complete exact pool stays exact for velocity',id,m,{},r=>okWhen(r.velocityMode==='exact'&&r.sellThrough90===150,`mode ${r.velocityMode}, STR ${r.sellThrough90}`),'sell-through'));
}
{
  const id=identity({title:'Thin exact, strong family',brand:'FamilyCo',model:'F200',velocity_family:'running shoes'});
  const m=market(id,{sold:30,active:25,exactSold:1,exactActive:1,prices:[45,48,50,52,55,58]});
  cases.push(runMarketCase('Thin exact pool broadens to controlled family velocity',id,m,{},r=>okWhen(r.velocityMode!=='exact'&&r.velocityVerified,`mode ${r.velocityMode}`),'sell-through'));
}

// Pricing / max-buy math.
{
  const id=identity({title:'Outlier item',brand:'StableCo',model:'S1'});
  const m=market(id,{prices:[40,41,42,43,44,45,400],sold:25,active:25});
  cases.push(runMarketCase('Extreme sold-price outlier is robustly filtered',id,m,{},r=>okWhen(r.averageSalePrice<60,`average ${r.averageSalePrice}`),'pricing'));
}
{
  const id=identity({title:'Buyer-paid shipping item',brand:'ShipCo',model:'S2',shipping_estimate:5});
  const m=market(id,{prices:[12,12.5,13,13.5,14,15],sold:30,active:20,shipping:7});
  cases.push(runMarketCase('Buyer-paid shipping contributes to gross order value',id,m,{minProfit:5},r=>okWhen(r.expectedGrossOrderValue>r.averageSalePrice&&r.maxBuyPrice>0,`gross ${r.expectedGrossOrderValue}, item ${r.averageSalePrice}`),'pricing'));
}
{
  const id=identity({title:'Fee sensitivity item',brand:'FeeCo',model:'F1'}); const m=market(id,{prices:[70,72,75,78,80,82],sold:20,active:20});
  const low=marketToItem(id,m,{...baseSettings,defaultFeesPct:10}); const high=marketToItem(id,m,{...baseSettings,defaultFeesPct:25});
  cases.push({name:'Higher marketplace fee lowers max buy',group:'pricing',ok:high.maxBuyPrice<low.maxBuyPrice,detail:`10%=${low.maxBuyPrice}, 25%=${high.maxBuyPrice}`,metrics:{low:low.maxBuyPrice,high:high.maxBuyPrice}});
}
{
  const id=identity({title:'Profit target item',brand:'ProfitCo',model:'P1'}); const m=market(id,{prices:[70,72,75,78,80,82],sold:20,active:20});
  const low=marketToItem(id,m,{...baseSettings,minProfit:5}); const high=marketToItem(id,m,{...baseSettings,minProfit:25});
  cases.push({name:'Higher profit target lowers max buy dollar-for-dollar',group:'pricing',ok:Math.abs((low.maxBuyPrice-high.maxBuyPrice)-20)<.02,detail:`$5 target=${low.maxBuyPrice}, $25 target=${high.maxBuyPrice}`,metrics:{low:low.maxBuyPrice,high:high.maxBuyPrice}});
}
{
  const id=identity({title:'Bins weight item',brand:'BinsCo',model:'B1',weight_estimate_lb:1,weight_low_lb:.7,weight_high_lb:1.4}); const m=market(id,{prices:[50,52,55,58,60,62],sold:25,active:20});
  cases.push(runMarketCase('Bins mode uses conservative high-end weight cost',id,m,{acquisitionMode:'bins',manualPrice:null,binsPricePerLb:1.69},r=>okWhen(Math.abs(r.cost-2.366)<.01,`cost ${r.cost}`),'pricing'));
}
{
  const id=identity({title:'Manual price override',brand:'CostCo',model:'C1',price_tag:9}); const m=market(id,{prices:[50,52,55,58,60,62],sold:25,active:20});
  cases.push(runMarketCase('Manual acquisition price overrides visible price tag',id,m,{manualPrice:4},r=>okWhen(r.cost===4&&r.costSource==='manual item price',`cost ${r.cost}, source ${r.costSource}`),'pricing'));
}
{
  const id=identity({title:'Visible price tag',brand:'CostCo',model:'C2',price_tag:7}); const m=market(id,{prices:[50,52,55,58,60,62],sold:25,active:20});
  cases.push(runMarketCase('Visible price tag is used when manual price is blank',id,m,{manualPrice:null},r=>okWhen(r.cost===7&&r.costSource==='visible price tag',`cost ${r.cost}, source ${r.costSource}`),'pricing'));
}
{
  const id=identity({title:'Unknown acquisition cost',brand:'CostCo',model:'C3',price_tag:null}); const m=market(id,{prices:[50,52,55,58,60,62],sold:25,active:20});
  cases.push(runMarketCase('Unknown acquisition cost does not erase market analysis',id,m,{manualPrice:null},r=>okWhen(!r.costKnown&&r.pricingVerified&&r.velocityVerified,'market should still verify'),'pricing'));
}
{
  const id=identity({title:'Sparse price pool',brand:'SparseCo',model:'SP1'}); const m=market(id,{prices:[60],sold:6,active:6});
  cases.push(runMarketCase('One usable sold price can be displayed but not decision-verified',id,m,{},r=>okWhen(r.pricingAvailable&&!r.pricingVerified&&r.averageSalePrice>0,'expected provisional price'),'pricing'));
}
{
  const id=identity({title:'Dispersed price pool',brand:'WideCo',model:'W1'}); const m=market(id,{prices:[10,12,20,40,80,150],sold:20,active:20});
  cases.push(runMarketCase('Wild price dispersion triggers caution',id,m,{},r=>okWhen(r.reviewReasons.some(x=>/widely dispersed|price estimate/i.test(x)),`review ${r.reviewReasons.join('; ')}`),'pricing'));
}

// Identity conflict / query poisoning regressions.
{
  const wrong=identity({title:'Jabra Elite 25e Wireless Bluetooth Neckband Earphones',brand:'Jabra',model:'Elite 25e',item_type:'wireless neckband headphones',identity_terms:['Elite 25e'],query_candidates:['Jabra Elite-25e'],identity_confidence:.94});
  const lens=[{title:'Bose QuietControl 30 Wireless Headphones'},{title:'Bose QuietControl 30 QC30 Bluetooth Neckband Headphones'},{title:'Bose QuietControl 30 Wireless Noise Cancelling Headphones'},{title:'Bose QuietControl 30 Black Wireless Headset'}];
  const corrected=reconcileIdentityWithLens(wrong,lens), queries=itemQueryCandidates(corrected);
  cases.push({name:'Jabra -> Bose conflict is corrected before market query',group:'identity',ok:(corrected.brand||'').toLowerCase()==='bose'&&/bose/i.test(queries[0]||'')&&!/^jabra/i.test(queries[0]||''),detail:`${corrected.brand} ${corrected.model||''} -> ${queries[0]}`,metrics:{status:corrected.lens_crosscheck_status}});
}
{
  const wrong=identity({title:'Bose QuietControl 20 Headphones',brand:'Bose',model:'QuietControl 20',item_type:'noise cancelling headphones',identity_confidence:.93});
  const lens=[{title:'Bose QuietControl 30 Wireless Headphones'},{title:'Bose QuietControl 30 QC30 Headphones'},{title:'Bose QuietControl 30 Neckband Headphones'},{title:'Bose QuietControl 30 Wireless Headset'}];
  const corrected=reconcileIdentityWithLens(wrong,lens);
  cases.push({name:'Same-brand wrong-model conflict can be corrected',group:'identity',ok:corrected.lens_crosscheck_status==='corrected_conflict'&&/30/.test(`${corrected.model||''} ${corrected.title||''}`),detail:`${corrected.title}`,metrics:{status:corrected.lens_crosscheck_status}});
}
{
  const right=identity({title:'Bose QuietControl 30 Wireless Headphones',brand:'Bose',model:'QuietControl 30',item_type:'wireless neckband headphones',identity_confidence:.95});
  const lens=[{title:'Bose QuietControl 30 Wireless Headphones'},{title:'Bose QuietControl 30 QC30 Bluetooth Headphones'},{title:'Bose QuietControl 30 Wireless Headset'}];
  const checked=reconcileIdentityWithLens(right,lens);
  cases.push({name:'Supported specific identity is not unnecessarily changed',group:'identity',ok:(checked.brand||'')==='Bose'&&checked.lens_crosscheck_status!=='corrected_conflict',detail:`status ${checked.lens_crosscheck_status}`,metrics:{status:checked.lens_crosscheck_status}});
}
{
  const id=identity({title:'Stable deterministic item',brand:'StableCo',model:'D1'}); const m=market(id,{prices:[45,48,50,52,55,58],sold:30,active:40});
  const a=marketToItem(id,m,baseSettings),b=marketToItem(id,m,baseSettings);
  cases.push({name:'Identical offline evidence produces identical decision metrics',group:'determinism',ok:JSON.stringify([a.averageSalePrice,a.sellThrough90,a.maxBuyPrice,a.velocityVerified,a.pricingVerified])===JSON.stringify([b.averageSalePrice,b.sellThrough90,b.maxBuyPrice,b.velocityVerified,b.pricingVerified]),detail:`${a.averageSalePrice}/${a.sellThrough90}/${a.maxBuyPrice}`,metrics:{price:a.averageSalePrice,str:a.sellThrough90,maxBuy:a.maxBuyPrice}});
}
{
  const prices=robustPrices([10,10,11,11,12,12,500]);
  cases.push({name:'Robust price helper rejects catastrophic outlier influence',group:'math',ok:prices.length<7||Math.max(...prices)<500,detail:`${prices.join(', ')}`,metrics:{n:prices.length}});
}

// Threshold / confidence behavior.
{
  const id=identity({title:'Low identity confidence item',brand:'MaybeCo',model:'Maybe1',identity_confidence:.40}); const m=market(id,{prices:[50,52,55,58,60,62],sold:20,active:20});
  cases.push(runMarketCase('Low identity confidence remains review-required',id,m,{},r=>okWhen(r.reviewRequired&&r.reviewReasons.some(x=>/identity uncertain/i.test(x)),r.reviewReasons.join('; ')),'confidence'));
}
{
  const id=identity({title:'Search disagreement item',brand:'AgreeCo',model:'A1'}); const m=market(id,{prices:[50,52,55,58,60,62],sold:20,active:20,agreement:.50});
  cases.push(runMarketCase('Independent search disagreement is surfaced',id,m,{},r=>okWhen(r.reviewReasons.some(x=>/queries disagree/i.test(x)),r.reviewReasons.join('; ')),'confidence'));
}
{
  const id=identity({title:'High evidence item',brand:'StrongCo',model:'S100',identity_confidence:.98}); const m=market(id,{prices:[80,82,84,85,86,88,90,92],sold:80,active:40,visual:true});
  cases.push(runMarketCase('High-evidence item produces verified pricing and velocity',id,m,{},r=>okWhen(r.pricingVerified&&r.velocityVerified&&r.sellThroughConfidenceLabel!=='Low'&&r.maxBuyPrice>0,`confidence ${r.sellThroughConfidenceLabel}`),'confidence'));
}
{
  const id=identity({title:'Low demand item',brand:'SlowCo',model:'L1'}); const m=market(id,{prices:[80,82,84,85,86,88],sold:3,active:100});
  cases.push(runMarketCase('Slow item still reports low measurable STR instead of blank',id,m,{},r=>okWhen(r.sellThrough90!==null&&r.sellThrough90<5,`STR ${r.sellThrough90}`),'sell-through'));
}
{
  const id=identity({title:'No visual but strong titles',brand:'TitleCo',model:'T1'}); const m=market(id,{prices:[60,62,64,66,68,70],sold:30,active:20,visual:false});
  cases.push(runMarketCase('Title-supported evidence can be decision-grade without visual photos',id,m,{},r=>okWhen(r.pricingVerified&&r.velocityVerified&&/title_supported/.test(r.pricingEvidenceMode),`pricing evidence ${r.pricingEvidenceMode}`),'stress'));
}

const passed=cases.filter(x=>x.ok).length;
const failed=cases.length-passed;
const groups={};
for(const c of cases){groups[c.group]??={passed:0,failed:0,total:0};groups[c.group].total++;groups[c.group][c.ok?'passed':'failed']++;}
const summary={ok:failed===0,passed,failed,total:cases.length,apiCalls:0,groups,cases,generatedAt:new Date().toISOString()};
if(jsonMode) process.stdout.write(JSON.stringify(summary));
else {
  console.log(`ORBIT Test Lab: ${passed}/${cases.length} passed — ${failed} failed — 0 external API calls`);
  for(const c of cases){console.log(`${c.ok?'PASS':'FAIL'}  [${c.group}] ${c.name}${c.ok?'':` — ${c.detail}`}`);}
}
if(failed) process.exitCode=1;
