# ORBIT 1.4.3

- eBay image identification and eBay active listings remain primary.
- SerpApi sold comps are used only while quota is healthy.
- On SerpApi quota exhaustion, a 6-hour cooldown prevents repeated wasted calls.
- Trawl becomes the sold-comps fallback, capped at `max_pages=1` (at most 1 credit per unique sold query).
- Trawl sold results are cached 5 days; empty results 1 day.
- A Trawl 429/monthly-limit response starts a 6-hour cooldown to prevent repeated retries.
- Response diagnostics show sold provider, active provider, Trawl calls, and Trawl credits charged.
- No generative AI in the critical path.


## 1.4.5 condition + STR fix
- Infers NEW vs USED from eBay visual-match condition consensus and filters both sold and active market pools accordingly.
- Trawl sold fallback is now explicitly limited to the most recent 90 days, so STR compares a defined sales window against current active listings.
- Search queries are shortened to brand/model/product essentials; Trawl requires every query word, so this avoids false-low sold counts from long listing-title queries.
- One-page sold results capped at 100 are displayed as a lower-bound STR (≥) rather than a falsely exact percentage.
- Market evidence now shows 90-day sold count, active count, condition, and sample counts.
- Fixed analysis logging that was unreachable after an early return.


## 1.4.6
- Strip prices, apparel sizes, condition words, colors, and marketplace fluff from comp queries.
- Preserve useful model/SKU identifiers.
- If the first paired query returns <=1 sold comp, make one controlled broader family retry only when active evidence supports it.
- Market evidence now renders comp thumbnails, condition, price, and sold dates when provided by the source.


## 1.4.7 STR query hierarchy
- Builds three paired market-query levels: exact model/SKU, style/model, and same-brand family/style.
- Removes price, dimensions, apparel sizes, colors, condition words, and seller/listing fluff before STR search.
- Aggressively preserves useful model/SKU identifiers (e.g. HOKA Clifton 8 / 1119393, Bose QC30, Dr. Martens 9231).
- Checks free eBay active evidence at each level and always prefers the most specific usable pool.
- Uses the exact same selected query for sold and active counts.
- Makes at most one broader sold retry when sold evidence is <=1, limiting Trawl usage.
- Adds STR quality labels (HIGH / MEDIUM / LOW / NONE) and explains exact, style, or family confidence.
- Refuses to show a numeric STR when capped sold results are paired with an excessively broad active pool.
- Keeps sold comp photos, sold dates, prices, and conditions in Market Evidence.


## 1.4.12 — credit-efficient paid data path
- Uses free eBay active evidence to select exact/style/family query before any paid sold lookup.
- Caps automatic paid sold lookups at one per scan; no automatic second Trawl/Serp query on thin results.
- Reuses cached broader sold evidence when available at zero additional paid-provider cost.
- Canonicalizes sold-cache keys so equivalent query token order can reuse the same Trawl result.
- Skips SerpApi Lens when eBay image evidence is already confident, preserving Serp credits without weakening strong identifications.
- Exposes paid sold-call/budget counters in status diagnostics.
