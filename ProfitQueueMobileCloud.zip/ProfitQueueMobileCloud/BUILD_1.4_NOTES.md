# ORBIT 1.4.3

- eBay image identification and eBay active listings remain primary.
- SerpApi sold comps are used only while quota is healthy.
- On SerpApi quota exhaustion, a 6-hour cooldown prevents repeated wasted calls.
- Trawl becomes the sold-comps fallback, capped at `max_pages=1` (at most 1 credit per unique sold query).
- Trawl sold results are cached 5 days; empty results 1 day.
- A Trawl 429/monthly-limit response starts a 6-hour cooldown to prevent repeated retries.
- Response diagnostics show sold provider, active provider, Trawl calls, and Trawl credits charged.
- No generative AI in the critical path.
