# ORBIT 1.4

Critical scan path:
1. eBay Browse image search when eBay OAuth is healthy.
2. SerpApi Google Lens image upload when eBay image search is unavailable or thin.
3. Deterministic identity consensus (no generative AI required).
4. SerpApi eBay Sold search for sold comps and pricing.
5. eBay Browse active search when available; SerpApi eBay active search otherwise.
6. Exact query first; controlled same-brand/product-family query only when exact evidence is thin.

Cost controls:
- Trawl is never called automatically.
- Generative AI is not on the critical path.
- Image identity is cached for 7 days by image hash.
- Market queries are cached for 3 days.
- Exact sold/active searches run in parallel; family searches only run when needed.

Decision output remains BUY / PASS with ASP, sell-through, max-buy cost, projected net, evidence and scan history.
