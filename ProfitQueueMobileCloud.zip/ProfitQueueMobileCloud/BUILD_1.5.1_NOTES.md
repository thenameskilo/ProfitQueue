# ORBIT 1.5.1 — Semantic Marketplace Purity

This release changes active-market candidate validation from mostly lexical token agreement to product-level purity scoring.

## Changes
- Product purity now dominates query ranking.
- Lexical precision is tracked separately from semantic product purity.
- Wrong-object results are penalized/rejected for category-dependent products.
- Category/object type becomes mandatory for bags, footwear, apparel, collectibles, home goods, and sporting goods unless a strong exact-ID rule applies.
- Candidate queries that drop a mandatory product type receive a structural penalty even if their returned titles contain the brand/product-line words.
- Hard-ID/model conflicts receive an explicit penalty.
- Required identity tokens are deduplicated before scoring.
- Fisher-Price is recognized as a two-word brand.
- Multi-part Fisher-Price identity can retain both Little People and Klip Klop.
- `<object> only` wording can define the actual sold configuration (for example, Stable Only).
- `bat bag` is treated as a specific object type rather than a generic bag.
- UI/debug output now shows product purity, lexical precision, wrong-object rate, and query-structure fit.

## Regression examples
- `bratz lil` no longer scores as a perfect query for a Bratz backpack merely because every result contains Bratz/Lil.
- `bratz lil backpack` outranks franchise-only queries when the scanned item is a backpack.
- Fisher-Price Little People Klip Klop `Stable Only` preserves the stable configuration.
- Easton Walk Off Elite Bat Bag preserves the named line and bat-bag object type.

## Verification
- `npm run check`: passed
- `npm test`: 83/83 passed
- Regression tests make zero external API calls.
