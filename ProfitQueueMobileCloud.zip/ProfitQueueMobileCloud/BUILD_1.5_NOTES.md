# ORBIT 1.5.0 — Marketplace-Validated Query Engine

This build changes query selection from a single token-ranking guess into a structured, test-and-rank pipeline.

## Query pipeline
1. Parse detected title/user keywords into structured identity fields: brand, product line, model identifiers, generation, object type, critical variant, and type qualifiers.
2. Apply a category schema (footwear, electronics, fragrance, bags, apparel, collectibles, home, sporting, generic).
3. Generate several candidate comp queries designed for that schema.
4. Search all candidate queries against free eBay active results in parallel.
5. Score each candidate from the actual returned titles using brand/model/product-line/object agreement.
6. Select the highest-quality candidate before any paid sold lookup.
7. Reject severely contaminated marketplace queries before spending Trawl credits.
8. Log the structured identity, every candidate score/precision, and the final selection.

## Diagnostics
The API response now includes `query.structured`, `query.validation`, and `query.candidates` so query mistakes can be traced rather than inferred from only the final selected string.

## Regression lab
77/77 local tests pass with zero external API calls, including Hoka model separation, L.L.Bean normalization, Easton Walk Off Elite contamination detection, fragrance flankers, camera model chains, scarcity behavior, velocity STR, and prior query regressions.
