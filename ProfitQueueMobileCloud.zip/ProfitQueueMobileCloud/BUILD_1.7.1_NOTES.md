# ORBIT 1.7.1 — Title-Derived Query, Query-Defined STR

This corrects the key architectural distinction from 1.7.0:

- The chosen listing title is used to BUILD and VALIDATE the search query.
- Title similarity is NOT used to filter the STR numerator or denominator.
- Once a query is selected, the same query defines both active and sold market universes.
- Pricing also comes from the sold results for that same selected query.

Query selection now adds weighted `queryCoverage`: how much of the important listing-title identity the candidate retains. Marketplace purity, returned-title similarity, market anchor coverage, and query coverage jointly choose the query. Broad candidates are penalized if they discard too much of the source title.

The API/logs expose retained and dropped title terms, query coverage, and a title-match preview. The preview is diagnostic only and never changes STR counts.
