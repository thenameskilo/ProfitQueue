# ORBIT 1.2.7 — Similar-Style Velocity + Fast Path

This release fixes inflated active-market denominators. Active eBay searches now use the same condition pool as sold history, compact split model IDs such as XA 2 into XA2-style search variants, suppress eBay spelling broadening, and only trust provider total_results when eBay reports an exact-spelling, model-specific search.

This is the phone-only build of ORBIT. Once deployed, the only device you need while sourcing is your Android phone.



### 1.2.7 changes

- Pricing remains exact-model whenever enough verified sold comps exist.
- Sell-through can use a separate, controlled same-brand **similar-style** pool. Only photo-verified near-neighbor styles with closely related silhouette, construction, materials, and feature layout qualify; different generations/form factors/styles are excluded.
- Exact and similar-style searches are launched together; sold and active velocity use the same pool rules.
- Fast pass defaults to 12 sold + 12 active visual candidates instead of 24 + 24.
- Comp image downloads and additional active result pages run concurrently.
- Default deep paging/query attempts are reduced, while ambiguous items can still broaden through the query ladder.
- Response metadata and Render logs include total analysis time so real-world scans can be benchmarked toward a sub-10-second target.

## ORBIT 1.2.7 sell-through decision logic

- Sold and active velocity now use the **same exact-model or design-family match pool**.
- ORBIT will not mix exact sold pricing with a broader family active denominator.
- Small sold/active samples lower sell-through confidence and automatically widen the displayed range.
- A BUY requires at least medium demand confidence plus enough statistical support and margin above the user threshold; one extreme lower-bound estimate no longer automatically vetoes an otherwise strong result.
- The UI shows Low / Medium / High sell-through confidence in plain language.

## What happens when you scan an item

1. Android captures a photo or live camera frame.
2. The browser compresses large phone photos before upload so cellular uploads are faster.
3. The photo goes over HTTPS to your private cloud backend.
4. Gemini identifies the product, visible model/MPN/UPC clues, condition, and a store price only when one is actually visible.
5. ORBIT pulls 90-day sold candidates from Trawl and current active candidates from SerpApi.
6. ORBIT downloads each candidate's eBay listing image and gives Gemini the user's original photo(s), listing photo, title, condition, and price together.
7. Candidates are classified as Tier 1 exact, Tier 2 likely/variant, or rejected accessory/lot/parts/wrong item. Only Tier 1 photo-verified sold comps can set Average Sold.
8. Sell-through is calculated only when the active-listing side also has enough photo-verified evidence. Zero verified active comps never becomes an artificial 200%+ STR; ORBIT returns a conservative PASS instead of inventing velocity.
9. If matching comp photos reveal a specific repeated model/product line, ORBIT can refine the identity and run one tighter market query before calculating the result.

No Gemini, Trawl, or SerpApi secret is stored in the Android app.

## Android features

- Installable PWA (Add to Home Screen / Install App)
- Native Android camera/file capture
- Live browser camera over HTTPS
- Single-item scanning with up to five separate photos of one item
- Automatic photo downsizing before upload
- Local inventory saved on the phone
- Offline app shell and saved inventory; new analysis requires internet
- One-time private access code stored on that phone

## Cloud deployment

The included `render.yaml` is ready for a Render Node web service. The Express server serves both the PWA and `/api/*`, so there is no cross-device URL configuration and no computer needs to stay on.

### Environment variables

Set these as server-side secrets:

- `GEMINI_API_KEY` — required
- `SERPAPI_KEY` — required
- `TRAWL_API_KEY` — required
- `APP_ACCESS_CODE` — strongly recommended; use a long private code

Accuracy defaults are already included:

- `GEMINI_VISION_MODEL=gemini-3.5-flash-lite`
- `GEMINI_COMP_MODEL=gemini-3.5-flash-lite`
- `MARKET_SAMPLE_PAGES=2`
- `MARKET_QUERY_ATTEMPTS=3`
- `TRAWL_MIN_INTERVAL_MS=700`
- `VISUAL_COMP_MAX_SOLD=12`
- `VISUAL_COMP_MAX_ACTIVE=12`

ORBIT starts with the strongest readable model identity and broadens only when verified sold evidence is missing or rejected. MPN/UPC searches can still be used, but an identifier-only active result can no longer stop the ladder when the sold side is empty. Specific active searches can sample up to two pages by default. The first pass uses a smaller balanced visual sample for speed; ORBIT broadens through the query ladder only when the evidence is not sufficient.

### Deploy on Render

1. Put this folder in a GitHub repository.
2. In Render choose **New → Blueprint** (or Web Service) and connect that repository.
3. Render detects `render.yaml`.
4. Enter the three secret values when prompted: `GEMINI_API_KEY`, `SERPAPI_KEY`, and `APP_ACCESS_CODE`.
5. Deploy.
6. Open the resulting `https://...onrender.com` address in Chrome on Android.
7. Tap ORBIT's **Install** button when shown, or Chrome menu → **Add to Home screen / Install app**.
8. On the first analysis, enter `APP_ACCESS_CODE` once. ORBIT remembers it on that phone.

For a Web Service created manually, use `npm install` as the build command, `npm start` as the start command, and `/api/health` as the health-check path.

## Free hosting note

Free Render web services can sleep after inactivity, so the first request after a quiet period can take longer while the service wakes up. A paid always-on instance removes that cold-start delay. The app's health check and retry behavior are designed to tolerate startup delay.

## Local test (optional)

You do not need this after cloud deployment, but developers can test locally:

```bash
cp .env.example .env
npm install
npm run check
npm test
npm start
```

Then open `http://localhost:4173`.

## Privacy and security

- API keys exist only in cloud environment variables.
- The browser never receives either secret.
- `APP_ACCESS_CODE` protects the costly analysis endpoint and is compared server-side.
- Repeated wrong access-code attempts are rate-limited.
- API responses are marked no-store.
- Camera permission is restricted to the app origin.
- Do not commit `.env` to Git; it is excluded by `.gitignore`.

## Accuracy behavior

ORBIT uses only **BUY** or **PASS** as sourcing verdicts. BUY requires verified value, at least medium-confidence sell-through evidence, and the selected thresholds to clear conservatively. Low-confidence identity, insufficient verified sold/active evidence, unresolved market data, or provider failure is treated as PASS rather than a speculative buy.

A missing store price remains **unknown**; it is never converted to $0. Sold pricing uses only Tier 1 photo-verified sold comps with usable prices after outlier rejection. Tier 2 likely/variant comps are kept as evidence but do not drive the headline price. Sell-through is withheld when the denominator cannot be verified safely.

## Free-mode notes

This build uses Gemini for item identification and photo-to-photo comp verification, Trawl for sold history, and SerpApi for active eBay candidates. Provider quotas and availability can change. Broad discovery searches use only one Trawl page; deeper sold-history paging is reserved for a specific model query. Trawl requests are globally queued and rate-limit retries honor `Retry-After`.


## 1.0.2 hybrid sourcing
When exact-SKU history is thin, ORBIT can use strong photo-verified same-brand product-family comps for a conservative, actionable sourcing decision. Accessories, cases, lots, parts, and wrong designs remain excluded.


## ORBIT 1.1 cost-aware sourcing
- Standard mode accepts an optional manual acquisition price; when blank, a visible price sticker can be read from the photos.
- Goodwill Bins mode stores a price-per-pound rate, estimates item weight from the photos as a range, and uses the conservative high-end estimated cost in the sourcing decision.
- Family comps may cross teams/themes when the same maker/product type and visual construction/design are strongly similar; those are never treated as exact comps.


## ORBIT 1.2 comp accuracy
- Minimum resale value is user-adjustable and saved on-device.
- Minimum 90-day sell-through is user-adjustable and saved on-device.
- BUY requires the conservative sell-through confidence bound to clear the selected minimum; borderline point estimates route conservatively.
- The UI shows the sell-through confidence level and conservative range alongside sold/active counts.
- Human-readable brand + model searches run before MPN-only searches. If an identifier search finds active listings but no verified sold comps, ORBIT continues down the query ladder instead of stopping.
- Query specificity is based on the identity actually present in the search text, preventing a brand-only fallback from inheriting exact-model counting behavior.
- Specific active searches can sample up to three eBay pages and visually inspect more candidate listings for a more stable denominator.


## ORBIT 1.2.7 decision-first evidence UI

- Keeps the sourcing verdict binary: **BUY** or **PASS**.
- Adds a plain-English decision checklist for resale value, demand, and acquisition cost.
- Replaces confusing “accepted” and “exact / family” counters with four simple evidence fields: sold matches, active matches, match basis, and decision confidence.
- Labels sell-through as an estimate and explicitly distinguishes the verified sample from the estimated matching market used for the ratio.
- Moves query/provider diagnostics into a nested technical-details section so they do not compete with the buying decision.

## ORBIT 1.2.1 binary decisions
- WHATNOT is no longer a sourcing verdict.
- RETRY is no longer a sourcing verdict.
- BUY is reserved for items that clear the selected value and conservative sell-through thresholds.
- Every other analyzed item returns PASS with a reason, including insufficient verification or borderline sell-through.
- Legacy WHATNOT/RETRY history entries display as PASS.
