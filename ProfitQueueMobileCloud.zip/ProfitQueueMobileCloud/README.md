# ProfitQueue Mobile Cloud

This is the phone-only build of ProfitQueue. Once deployed, the only device you need while sourcing is your Android phone.

## What happens when you scan an item

1. Android captures a photo or live camera frame.
2. The browser compresses large phone photos before upload so cellular uploads are faster.
3. The photo goes over HTTPS to your private cloud backend.
4. GPT-5.6 Sol identifies the exact product, visible model/MPN/UPC clues, condition, and any visible store price.
5. ProfitQueue runs multiple eBay Sold and Active searches through SerpApi.
6. GPT-5.6 Luna verifies sampled listing titles as exact item vs variant/accessory/lot/parts/wrong item.
7. ProfitQueue removes bad comps and price outliers, then returns a robust average sold price, median, middle-50% price range, 90-day sell-through, a sell-through confidence range, and the sourcing decision.

No Gemini or SerpApi secret is stored in the Android app.

## Android features

- Installable PWA (Add to Home Screen / Install App)
- Native Android camera/file capture
- Live browser camera over HTTPS
- Single-item, group, and rapid-batch modes
- Automatic photo downsizing before upload
- Local inventory saved on the phone
- Offline app shell and saved inventory; new analysis requires internet
- One-time private access code stored on that phone

## Cloud deployment

The included `render.yaml` is ready for a Render Node web service. The Express server serves both the PWA and `/api/*`, so there is no cross-device URL configuration and no computer needs to stay on.

### Environment variables

Set these as server-side secrets:

- `GEMINI_API_KEY` — required
- `SERPAPI_KEY` — required
- `APP_ACCESS_CODE` — strongly recommended; use a long private code

Accuracy defaults are already included:

- `GEMINI_VISION_MODEL=gemini-3.8-flash`
- `GEMINI_COMP_MODEL=gemini-3.8-flash`
- `MARKET_SAMPLE_PAGES=1`
- `MARKET_QUERY_ATTEMPTS=1`

You can increase the last two to 3 for difficult items, but analysis gets slower and uses more market-search API requests.

### Deploy on Render

1. Put this folder in a GitHub repository.
2. In Render choose **New → Blueprint** (or Web Service) and connect that repository.
3. Render detects `render.yaml`.
4. Enter the three secret values when prompted: `GEMINI_API_KEY`, `SERPAPI_KEY`, and `APP_ACCESS_CODE`.
5. Deploy.
6. Open the resulting `https://...onrender.com` address in Chrome on Android.
7. Tap ProfitQueue's **Install** button when shown, or Chrome menu → **Add to Home screen / Install app**.
8. On the first analysis, enter `APP_ACCESS_CODE` once. ProfitQueue remembers it on that phone.

For a Web Service created manually, use `npm install` as the build command, `npm start` as the start command, and `/api/health` as the health-check path.

## Free hosting note

Free Render web services can sleep after inactivity, so the first request after a quiet period can take longer while the service wakes up. A paid always-on instance removes that cold-start delay. The app's health check and retry behavior are designed to tolerate startup delay.

## Local test (optional)

You do not need this after cloud deployment, but developers can test locally:

```bash
cp .env.example .env
npm install
npm run check
npm test
npm start
```

Then open `http://localhost:4173`.

## Privacy and security

- API keys exist only in cloud environment variables.
- The browser never receives either secret.
- `APP_ACCESS_CODE` protects the costly analysis endpoint and is compared server-side.
- Repeated wrong access-code attempts are rate-limited.
- API responses are marked no-store.
- Camera permission is restricted to the app origin.
- Do not commit `.env` to Git; it is excluded by `.gitignore`.

## Accuracy behavior

ProfitQueue intentionally prefers **REVIEW** over a false precise answer. Low-confidence visual identity, too few exact sold comps, weak exact-match precision, wide pricing dispersion, or disagreement between search formulations will reduce confidence and can block an automatic buy/list recommendation.

The displayed average sold price is not a raw arithmetic average of everything eBay search returns. Only verified exact sold comps with usable prices enter the price model, and statistical outliers are removed before a trimmed average is calculated.

## Free-mode notes

This build uses Gemini for visual identification and exact-comp classification. With Gemini's supported free tier, SerpApi's 250-search free plan, and Render's free web service, it can be run at $0 for testing within provider quotas. The default market settings use one sold page and one active page for one query formulation (about two SerpApi searches per item in the normal case). Set MARKET_SAMPLE_PAGES and MARKET_QUERY_ATTEMPTS higher later if you move to paid search volume and want deeper sampling.
