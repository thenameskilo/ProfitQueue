# ORBIT 1.3.4 — Deterministic Sell-Through Engine

## 1.3.4 architecture change

- **Sold side:** Trawl 90-day sold history using the current `max_pages` API contract.
- **Active side:** official eBay Browse API current inventory using an application OAuth token.
- **No active-count extrapolation:** Orbit fully enumerates the active query pool up to the configured safety ceiling; incomplete pools do not produce decision-grade STR.
- **Same comp definition on both sides:** exact item/model or controlled same-brand family matching is applied consistently to sold and active rows.
- **Auditable STR:** results return the literal evidence formula, e.g. `64 sold / 83 active = 77.1%`.
- **Pricing remains separate:** the sold-price engine and max-buy math are unchanged except for consuming the corrected Trawl response shape.
- SerpApi is now optional for Google Lens identity hints and non-decision-grade active fallback; it is no longer the trusted STR denominator.

# ORBIT 1.2.15 — Adaptive Evidence Engine

## 1.2.15 architecture change

- Replaces item-by-item pricing exceptions with one adaptive evidence hierarchy.
- ORBIT automatically starts at exact model/SKU evidence and broadens to the already-validated same-brand product family when exact evidence is too thin.
- Pricing and sell-through now reuse the same validated family pool, preventing contradictions such as “9 sold matches” but “0 usable sold price comps.”
- Price estimates remain visible even when confidence is low; low-confidence estimates do not authorize a BUY until the evidence becomes decision-grade.
- Exact-model evidence still wins whenever it is reliable, while broader family pricing is clearly labeled and uses conservative max-buy math.
- No extra provider request is required for the adaptive pricing fallback, preserving the fast path.


## 1.2.14 pricing + identification fixes

- Pricing no longer collapses to `$0` just because only one of the small fast-path comp images was accepted. Once an exact model/query is well supported, ORBIT can use the larger matching sold-title pool already fetched from Trawl.
- Same-brand family pricing can use a conservative title-supported pool when visual family matching confirms the market but too few comp images load.
- Pricing evidence is disclosed as visual, exact-title-supported, or same-brand-family-supported instead of labeling all values as visually verified.
- Brandless/generic single-item identifications receive a selective rescue: ORBIT can upload the compressed target photo to SerpApi's Google Lens image search and use those visual-match titles as hints for one stronger visual identification pass.
- If ORBIT already knows the brand but the generated title omits it, the displayed item title is normalized to include the brand.
- Google Lens rescue is only used for weak/brandless IDs so normal successful scans keep the fast path.


This release replaces brittle exact-only sell-through with a three-layer market model: exact item/model, same-brand similar-style family, and a canonical same-brand product-family baseline. Pricing remains anchored to the closest sold comps, while sell-through can broaden when exact SKU history is thin. Visual verification validates a compact sample; validated title/family matching then scales across the larger sold/active result pool instead of treating 4–8 inspected images as the whole market.

### 1.2.12 changes

- **Zero-active scarcity is demand evidence.** If ORBIT finds several verified same-pool sales but no matching active inventory in a small controlled active pool, it now treats that as a conservative sell-through lower bound instead of “not enough data.”
- **No hidden $25 profit rule.** Minimum net profit is now visible and adjustable in Decision rules, saved on-device, and defaults to $10.
- **Max-buy is transparent.** Maximum buy price preserves the user-selected net-profit target after estimated fees, shipping, and supplies.
- **Scarcity UI.** Results explicitly show `sold / 0 verified active` and label the condition as active inventory scarcity rather than presenting a fake precise active count.

- **No hard 6.5s identification failure.** ORBIT starts on the fast vision model and, when needed, races a stronger model instead of aborting the item.
- **Three-photo identity cap.** Extra photos remain available for comp verification, but the first identity request stays small.
- **Tighter provider budgets.** Slow sold/active provider calls are cut sooner so one request cannot dominate total scan time.
- **Single-model comp fast pass.** Initial visual comp verification does not wait through a fallback-model chain.
- **Smaller mobile payloads.** Camera/gallery photos are resized to 1152px before upload.
- **1.2.9 family-demand fix retained.** Exact velocity needs meaningful evidence on both sold and active sides; otherwise verified same-brand similar styles can drive sell-through.


- Vision now returns a short `velocity_family` such as `towel poncho`, `moc toe work boots`, or `35mm point and shoot camera`.
- Non-model goods search brand + canonical product family first, reducing seller-title wording sensitivity.
- Sell-through prefers exact evidence only when both sold and active sides are sufficiently populated; otherwise it uses the validated same-brand family pool.
- Family STR can use all title-qualified same-brand/product-family results after visual validation instead of only the tiny image-verification sample.
- Two exceptionally strong, price-consistent family sold comps can support a conservative value estimate rather than returning a blank card.
- Visual comp verification is capped by a fast-path time budget and uses a smaller 3-sold / 3-active image sample.
- Comp verification uses at most two target photos, and phone uploads are reduced to 1152px to cut upload/vision latency.
- Per-stage timing now logs identification, provider search, visual classification, and total market latency separately.

## What happens when you scan an item

1. Android captures a photo or live camera frame.
2. The browser compresses large phone photos before upload so cellular uploads are faster.
3. The photo goes over HTTPS to your private cloud backend.
4. Gemini identifies the product, visible model/MPN/UPC clues, condition, and a store price only when one is actually visible.
5. ORBIT pulls 90-day sold candidates from Trawl and current active inventory from the official eBay Browse API.
6. ORBIT downloads each candidate's eBay listing image and gives Gemini the user's original photo(s), listing photo, title, condition, and price together.
7. Candidates are classified as Tier 1 exact, Tier 2 likely/variant, or rejected accessory/lot/parts/wrong item. Only Tier 1 photo-verified sold comps can set Average Sold.
8. Sell-through normally compares verified sold and active counts from the same pool. When several verified sales exist and a small, controlled active search contains zero matching inventory, ORBIT marks the result as active scarcity and reports a conservative lower-bound STR using one hypothetical active listing rather than discarding the demand evidence.
9. If matching comp photos reveal a specific repeated model/product line, ORBIT can refine the identity and run one tighter market query before calculating the result.

No Gemini, Trawl, eBay, or SerpApi secret is stored in the Android app.

## Android features

- Installable PWA (Add to Home Screen / Install App)
- Native Android camera/file capture
- Live browser camera over HTTPS
- Single-item scanning with up to five separate photos of one item
- Automatic photo downsizing before upload
- Local inventory saved on the phone
- Offline app shell and saved inventory; new analysis requires internet
- One-time private access code stored on that phone

## Cloud deployment

The included `render.yaml` is ready for a Render Node web service. The Express server serves both the PWA and `/api/*`, so there is no cross-device URL configuration and no computer needs to stay on.

### Environment variables

Set these as server-side secrets:

- `GEMINI_API_KEY` — required
- `TRAWL_API_KEY` — required for sold history
- `EBAY_CLIENT_ID` — required for decision-grade STR (Production App ID / Client ID)
- `EBAY_CLIENT_SECRET` — required for decision-grade STR (Production Cert ID / Client Secret)
- `SERPAPI_KEY` — optional; used for Lens identity hints and fallback diagnostics
- `APP_ACCESS_CODE` — strongly recommended; use a long private code

Accuracy defaults are already included:

- `GEMINI_VISION_MODEL=gemini-3.5-flash-lite`
- `GEMINI_COMP_MODEL=gemini-3.5-flash-lite`
- `MARKET_SAMPLE_PAGES=2`
- `MARKET_QUERY_ATTEMPTS=3`
- `TRAWL_MIN_INTERVAL_MS=700`
- `VISUAL_COMP_MAX_SOLD=12`
- `VISUAL_COMP_MAX_ACTIVE=12`

ORBIT starts with the strongest readable model identity and broadens only when verified sold evidence is missing or rejected. MPN/UPC searches can still be used, but an identifier-only active result can no longer stop the ladder when the sold side is empty. Specific active searches can sample up to two pages by default. The first pass uses a smaller balanced visual sample for speed; ORBIT broadens through the query ladder only when the evidence is not sufficient.

### Deploy on Render

1. Put this folder in a GitHub repository.
2. In Render choose **New → Blueprint** (or Web Service) and connect that repository.
3. Render detects `render.yaml`.
4. Enter the required server-side secrets: at least one vision provider key, `TRAWL_API_KEY`, `EBAY_CLIENT_ID`, `EBAY_CLIENT_SECRET`, and `APP_ACCESS_CODE`. `SERPAPI_KEY` is optional.
5. Deploy.
6. Open the resulting `https://...onrender.com` address in Chrome on Android.
7. Tap ORBIT's **Install** button when shown, or Chrome menu → **Add to Home screen / Install app**.
8. On the first analysis, enter `APP_ACCESS_CODE` once. ORBIT remembers it on that phone.

For a Web Service created manually, use `npm install` as the build command, `npm start` as the start command, and `/api/health` as the health-check path.

## Free hosting note

Free Render web services can sleep after inactivity, so the first request after a quiet period can take longer while the service wakes up. A paid always-on instance removes that cold-start delay. The app's health check and retry behavior are designed to tolerate startup delay.

## Local test (optional)

You do not need this after cloud deployment, but developers can test locally:

```bash
cp .env.example .env
npm install
npm run check
npm test
npm start
```

Then open `http://localhost:4173`.

## Privacy and security

- API keys exist only in cloud environment variables.
- The browser never receives either secret.
- `APP_ACCESS_CODE` protects the costly analysis endpoint and is compared server-side.
- Repeated wrong access-code attempts are rate-limited.
- API responses are marked no-store.
- Camera permission is restricted to the app origin.
- Do not commit `.env` to Git; it is excluded by `.gitignore`.

## Accuracy behavior

ORBIT uses only **BUY** or **PASS** as sourcing verdicts. BUY requires verified value, at least medium-confidence sell-through evidence, and the selected thresholds to clear conservatively. Low-confidence identity, insufficient verified sold/active evidence, unresolved market data, or provider failure is treated as PASS rather than a speculative buy.

A missing store price remains **unknown**; it is never converted to $0. Sold pricing uses only Tier 1 photo-verified sold comps with usable prices after outlier rejection. Tier 2 likely/variant comps are kept as evidence but do not drive the headline price. Sell-through is withheld when the denominator cannot be verified safely.

## Free-mode notes

This build uses configured vision providers for item identification/photo-to-photo verification, Trawl for sold history, and the official eBay Browse API for current active inventory. SerpApi is optional and is not trusted for decision-grade STR. Provider quotas and availability can change. Broad discovery searches use only one Trawl page; deeper sold-history paging is reserved for a specific model query. Trawl requests are globally queued and rate-limit retries honor `Retry-After`.


## 1.0.2 hybrid sourcing
When exact-SKU history is thin, ORBIT can use strong photo-verified same-brand product-family comps for a conservative, actionable sourcing decision. Accessories, cases, lots, parts, and wrong designs remain excluded.


## ORBIT 1.1 cost-aware sourcing
- Standard mode accepts an optional manual acquisition price; when blank, a visible price sticker can be read from the photos.
- Goodwill Bins mode stores a price-per-pound rate, estimates item weight from the photos as a range, and uses the conservative high-end estimated cost in the sourcing decision.
- Family comps may cross teams/themes when the same maker/product type and visual construction/design are strongly similar; those are never treated as exact comps.


## ORBIT 1.2 comp accuracy
- Minimum resale value is user-adjustable and saved on-device.
- Minimum 90-day sell-through is user-adjustable and saved on-device.
- BUY requires the conservative sell-through confidence bound to clear the selected minimum; borderline point estimates route conservatively.
- The UI shows the sell-through confidence level and conservative range alongside sold/active counts.
- Human-readable brand + model searches run before MPN-only searches. If an identifier search finds active listings but no verified sold comps, ORBIT continues down the query ladder instead of stopping.
- Query specificity is based on the identity actually present in the search text, preventing a brand-only fallback from inheriting exact-model counting behavior.
- Specific active searches can sample up to three eBay pages and visually inspect more candidate listings for a more stable denominator.


## ORBIT 1.2.9 decision-first evidence UI

- Keeps the sourcing verdict binary: **BUY** or **PASS**.
- Adds a plain-English decision checklist for resale value, demand, and acquisition cost.
- Replaces confusing “accepted” and “exact / family” counters with four simple evidence fields: sold matches, active matches, match basis, and decision confidence.
- Labels sell-through as an estimate and explicitly distinguishes the verified sample from the estimated matching market used for the ratio.
- Moves query/provider diagnostics into a nested technical-details section so they do not compete with the buying decision.

## ORBIT 1.2.1 binary decisions
- WHATNOT is no longer a sourcing verdict.
- RETRY is no longer a sourcing verdict.
- BUY is reserved for items that clear the selected value and conservative sell-through thresholds.
- Every other analyzed item returns PASS with a reason, including insufficient verification or borderline sell-through.
- Legacy WHATNOT/RETRY history entries display as PASS.


## 1.2.13 audit fixes
- Sell-through is computed independently from price verification.
- Model-specific goods can use a conservative title-supported exact-price fallback after visual anchoring.
- Brand names accidentally returned as the model are ignored as hard identifiers.
- Decision-input diagnostics are logged for false-PASS audits.


## Optional item hints

ORBIT 1.2.17 adds an optional **Item hints** field for fast sourcing. A user can enter information already known about the item (brand, model, style name, size, maker, MPN/SKU, era, team/character, or keywords). The hints are included in the first visual-identification prompt and can seed the market-query ladder, which can reduce generic identifications and unnecessary broad searches. Hints are treated as context rather than truth: the photo, visible labels, and market evidence can override them when they conflict. Hints are included in the stable-snapshot fingerprint so changing the hint forces a fresh analysis.


## ORBIT 1.2.18 — confidence-adjusted max buy

Max-buy now uses one global expected-proceeds model for every scanned category. ORBIT blends the robust median and trimmed-mean total order value from the selected sold evidence pool, including buyer-paid shipping when present. It applies a confidence-scaled risk factor derived from the existing pricing evidence score, then subtracts marketplace fees, estimated outbound postage, supplies, and the user's visible minimum-profit target. This replaces the old fixed 30th-percentile haircut for family-priced items.


## ORBIT 1.2.19 — max-buy response hotfix
- Fixes a stale response-field reference (`conservativeSaleValue`) that could abort scans after the confidence-adjusted max-buy calculation was introduced in 1.2.18.
- The legacy response field now reports the confidence-adjusted item value (`riskAdjustedItemValue`) so older UI paths remain compatible.
- Adds a regression assertion so this stale variable cannot return unnoticed.


## ORBIT 1.2.20 — visual verification advisory wording
- Listing-photo classifier timeouts/inconclusive results are now advisory when title-supported exact/family market evidence remains usable.
- Healthy pricing/demand results no longer show a red `Visual comp verification unavailable` provider error.
- Technical source text explicitly states when title-supported evidence was used after the photo classifier was inconclusive.


## ORBIT 1.2.21 — hard identification fallback
- If all Gemini identification paths time out, hit quota, or are temporarily unavailable, single-item scans no longer fail immediately.
- ORBIT falls back to Google Lens visual-match titles through SerpApi and/or the user's optional item hints to build a provisional identity and continue into market search.
- Provisional identity is intentionally lower-confidence and cannot invent brand/model fields; downstream market evidence can still price and evaluate the item.
- Google Lens upload allowance is increased for normal compressed phone photos.


## ORBIT 1.2.25 — zero-credit Test Lab and vision provider routing

ORBIT now includes an offline regression lab. Open the **ORBIT Test Lab** panel in the app and press **Run offline regression suite**, or run `npm run test:lab`. The suite uses the real pricing, sell-through, max-buy, evidence, and identity-reconciliation functions with simulated/replayed evidence. It never calls Gemini, Google Lens, SerpApi, Trawl, Cloudflare, or Groq, so repeated development testing consumes **0 API credits**.

The initial suite includes replay-style regressions for Bose QuietControl 30, Toy Biz Wolverine, Kim Seybert, HOKA, Pizza Hut apparel, and Jabra, plus provider failures, title-only evidence, zero-active scarcity, pricing outliers, bins costing, identity conflicts, and deterministic repeatability. `npm test` runs both the structural self-test and the offline Test Lab, so a deployment build fails before going live if a covered regression returns.

### Optional alternative vision providers

Item identification is now routed through configured providers in `ORBIT_VISION_PROVIDER_ORDER` (default `cloudflare,groq,gemini`). Unconfigured providers are skipped automatically. Existing deployments with only `GEMINI_API_KEY` continue to work exactly as before; adding another provider does not require removing Gemini.

Cloudflare Workers AI variables:

- `CLOUDFLARE_ACCOUNT_ID`
- `CLOUDFLARE_API_TOKEN`
- `CLOUDFLARE_VISION_MODEL` (default `@cf/meta/llama-3.2-11b-vision-instruct`)

Groq variables:

- `GROQ_API_KEY`
- `GROQ_VISION_MODEL` (default `qwen/qwen3.8-27b`)

Routing variables:

- `ORBIT_VISION_PROVIDER_ORDER=cloudflare,groq,gemini`
- `ALT_VISION_TIMEOUT_MS=6500`

Google Lens remains an independent identity cross-check/rescue path rather than the primary model. Market pricing and sell-through continue to use ORBIT's deterministic exact/family evidence engine.


## 1.3.4 reliability update
- Groq identification output is capped below 1,000 tokens by default (850) with a 600-token lean retry under rate/token pressure.
- Groq identification uses at most 2 images by default to reduce request pressure.
- eBay OAuth is preflighted shortly after startup and exposed in `/api/health`, so invalid credentials are visible before a scan.
- Failed eBay OAuth is cooled down briefly instead of repeated on every query in the same scan.
