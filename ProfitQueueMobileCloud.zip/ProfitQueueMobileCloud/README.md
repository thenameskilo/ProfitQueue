# ORBIT 1.2.15 — Adaptive Evidence Engine

## 1.2.15 architecture change

- Replaces item-by-item pricing exceptions with one adaptive evidence hierarchy.
- ORBIT automatically starts at exact model/SKU evidence and broadens to the already-validated same-brand product family when exact evidence is too thin.
- Pricing and sell-through now reuse the same validated family pool, preventing contradictions such as “9 sold matches” but “0 usable sold price comps.”
- Price estimates remain visible even when confidence is low; low-confidence estimates do not authorize a BUY until the evidence becomes decision-grade.
- Exact-model evidence still wins whenever it is reliable, while broader family pricing is clearly labeled and uses conservative max-buy math.
- No extra provider request is required for the adaptive pricing fallback, preserving the fast path.


## 1.2.14 pricing + identification fixes

- Pricing no longer collapses to `$0` just because only one of the small fast-path comp images was accepted. Once an exact model/query is well supported, ORBIT can use the larger matching sold-title pool already fetched from Trawl.
- Same-brand family pricing can use a conservative title-supported pool when visual family matching confirms the market but too few comp images load.
- Pricing evidence is disclosed as visual, exact-title-supported, or same-brand-family-supported instead of labeling all values as visually verified.
- Brandless/generic single-item identifications receive a selective rescue: ORBIT can upload the compressed target photo to SerpApi's Google Lens image search and use those visual-match titles as hints for one stronger visual identification pass.
- If ORBIT already knows the brand but the generated title omits it, the displayed item title is normalized to include the brand.
- Google Lens rescue is only used for weak/brandless IDs so normal successful scans keep the fast path.


This release replaces brittle exact-only sell-through with a three-layer market model: exact item/model, same-brand similar-style family, and a canonical same-brand product-family baseline. Pricing remains anchored to the closest sold comps, while sell-through can broaden when exact SKU history is thin. Visual verification validates a compact sample; validated title/family matching then scales across the larger sold/active result pool instead of treating 4–8 inspected images as the whole market.

### 1.2.12 changes

- **Zero-active scarcity is demand evidence.** If ORBIT finds several verified same-pool sales but no matching active inventory in a small controlled active pool, it now treats that as a conservative sell-through lower bound instead of “not enough data.”
- **No hidden $25 profit rule.** Minimum net profit is now visible and adjustable in Decision rules, saved on-device, and defaults to $10.
- **Max-buy is transparent.** Maximum buy price preserves the user-selected net-profit target after estimated fees, shipping, and supplies.
- **Scarcity UI.** Results explicitly show `sold / 0 verified active` and label the condition as active inventory scarcity rather than presenting a fake precise active count.

- **No hard 6.5s identification failure.** ORBIT starts on the fast vision model and, when needed, races a stronger model instead of aborting the item.
- **Three-photo identity cap.** Extra photos remain available for comp verification, but the first identity request stays small.
- **Tighter provider budgets.** Slow sold/active provider calls are cut sooner so one request cannot dominate total scan time.
- **Single-model comp fast pass.** Initial visual comp verification does not wait through a fallback-model chain.
- **Smaller mobile payloads.** Camera/gallery photos are resized to 1152px before upload.
- **1.2.9 family-demand fix retained.** Exact velocity needs meaningful evidence on both sold and active sides; otherwise verified same-brand similar styles can drive sell-through.


- Vision now returns a short `velocity_family` such as `towel poncho`, `moc toe work boots`, or `35mm point and shoot camera`.
- Non-model goods search brand + canonical product family first, reducing seller-title wording sensitivity.
- Sell-through prefers exact evidence only when both sold and active sides are sufficiently populated; otherwise it uses the validated same-brand family pool.
- Family STR can use all title-qualified same-brand/product-family results after visual validation instead of only the tiny image-verification sample.
- Two exceptionally strong, price-consistent family sold comps can support a conservative value estimate rather than returning a blank card.
- Visual comp verification is capped by a fast-path time budget and uses a smaller 3-sold / 3-active image sample.
- Comp verification uses at most two target photos, and phone uploads are reduced to 1152px to cut upload/vision latency.
- Per-stage timing now logs identification, provider search, visual classification, and total market latency separately.

## What happens when you scan an item

1. Android captures a photo or live camera frame.
2. The browser compresses large phone photos before upload so cellular uploads are faster.
3. The photo goes over HTTPS to your private cloud backend.
4. Gemini identifies the product, visible model/MPN/UPC clues, condition, and a store price only when one is actually visible.
5. ORBIT pulls 90-day sold candidates from Trawl and current active candidates from SerpApi.
6. ORBIT downloads each candidate's eBay listing image and gives Gemini the user's original photo(s), listing photo, title, condition, and price together.
7. Candidates are classified as Tier 1 exact, Tier 2 likely/variant, or rejected accessory/lot/parts/wrong item. Only Tier 1 photo-verified sold comps can set Average Sold.
8. Sell-through normally compares verified sold and active counts from the same pool. When several verified sales exist and a small, controlled active search contains zero matching inventory, ORBIT marks the result as active scarcity and reports a conservative lower-bound STR using one hypothetical active listing rather than discarding the demand evidence.
9. If matching comp photos reveal a specific repeated model/product line, ORBIT can refine the identity and run one tighter market query before calculating the result.

No Gemini, Trawl, or SerpApi secret is stored in the Android app.

## Android features

- Installable PWA (Add to Home Screen / Install App)
- Native Android camera/file capture
- Live browser camera over HTTPS
- Single-item scanning with up to five separate photos of one item
- Automatic photo downsizing before upload
- Local inventory saved on the phone
- Offline app shell and saved inventory; new analysis requires internet
- One-time private access code stored on that phone

## Cloud deployment

The included `render.yaml` is ready for a Render Node web service. The Express server serves both the PWA and `/api/*`, so there is no cross-device URL configuration and no computer needs to stay on.

### Environment variables

Set these as server-side secrets:

- `GEMINI_API_KEY` — required
- `SERPAPI_KEY` — required
- `TRAWL_API_KEY` — required
- `APP_ACCESS_CODE` — strongly recommended; use a long private code

Accuracy defaults are already included:

- `GEMINI_VISION_MODEL=gemini-3.5-flash-lite`
- `GEMINI_COMP_MODEL=gemini-3.5-flash-lite`
- `MARKET_SAMPLE_PAGES=2`
- `MARKET_QUERY_ATTEMPTS=3`
- `TRAWL_MIN_INTERVAL_MS=700`
- `VISUAL_COMP_MAX_SOLD=12`
- `VISUAL_COMP_MAX_ACTIVE=12`

ORBIT starts with the strongest readable model identity and broadens only when verified sold evidence is missing or rejected. MPN/UPC searches can still be used, but an identifier-only active result can no longer stop the ladder when the sold side is empty. Specific active searches can sample up to two pages by default. The first pass uses a smaller balanced visual sample for speed; ORBIT broadens through the query ladder only when the evidence is not sufficient.

### Deploy on Render

1. Put this folder in a GitHub repository.
2. In Render choose **New → Blueprint** (or Web Service) and connect that repository.
3. Render detects `render.yaml`.
4. Enter the three secret values when prompted: `GEMINI_API_KEY`, `SERPAPI_KEY`, and `APP_ACCESS_CODE`.
5. Deploy.
6. Open the resulting `https://...onrender.com` address in Chrome on Android.
7. Tap ORBIT's **Install** button when shown, or Chrome menu → **Add to Home screen / Install app**.
8. On the first analysis, enter `APP_ACCESS_CODE` once. ORBIT remembers it on that phone.

For a Web Service created manually, use `npm install` as the build command, `npm start` as the start command, and `/api/health` as the health-check path.

## Free hosting note

Free Render web services can sleep after inactivity, so the first request after a quiet period can take longer while the service wakes up. A paid always-on instance removes that cold-start delay. The app's health check and retry behavior are designed to tolerate startup delay.

## Local test (optional)

You do not need this after cloud deployment, but developers can test locally:

```bash
cp .env.example .env
npm install
npm run check
npm test
npm start
```

Then open `http://localhost:4173`.

## Privacy and security

- API keys exist only in cloud environment variables.
- The browser never receives either secret.
- `APP_ACCESS_CODE` protects the costly analysis endpoint and is compared server-side.
- Repeated wrong access-code attempts are rate-limited.
- API responses are marked no-store.
- Camera permission is restricted to the app origin.
- Do not commit `.env` to Git; it is excluded by `.gitignore`.

## Accuracy behavior

ORBIT uses only **BUY** or **PASS** as sourcing verdicts. BUY requires verified value, at least medium-confidence sell-through evidence, and the selected thresholds to clear conservatively. Low-confidence identity, insufficient verified sold/active evidence, unresolved market data, or provider failure is treated as PASS rather than a speculative buy.

A missing store price remains **unknown**; it is never converted to $0. Sold pricing uses only Tier 1 photo-verified sold comps with usable prices after outlier rejection. Tier 2 likely/variant comps are kept as evidence but do not drive the headline price. Sell-through is withheld when the denominator cannot be verified safely.

## Free-mode notes

This build uses Gemini for item identification and photo-to-photo comp verification, Trawl for sold history, and SerpApi for active eBay candidates. Provider quotas and availability can change. Broad discovery searches use only one Trawl page; deeper sold-history paging is reserved for a specific model query. Trawl requests are globally queued and rate-limit retries honor `Retry-After`.


## 1.0.2 hybrid sourcing
When exact-SKU history is thin, ORBIT can use strong photo-verified same-brand product-family comps for a conservative, actionable sourcing decision. Accessories, cases, lots, parts, and wrong designs remain excluded.


## ORBIT 1.1 cost-aware sourcing
- Standard mode accepts an optional manual acquisition price; when blank, a visible price sticker can be read from the photos.
- Goodwill Bins mode stores a price-per-pound rate, estimates item weight from the photos as a range, and uses the conservative high-end estimated cost in the sourcing decision.
- Family comps may cross teams/themes when the same maker/product type and visual construction/design are strongly similar; those are never treated as exact comps.


## ORBIT 1.2 comp accuracy
- Minimum resale value is user-adjustable and saved on-device.
- Minimum 90-day sell-through is user-adjustable and saved on-device.
- BUY requires the conservative sell-through confidence bound to clear the selected minimum; borderline point estimates route conservatively.
- The UI shows the sell-through confidence level and conservative range alongside sold/active counts.
- Human-readable brand + model searches run before MPN-only searches. If an identifier search finds active listings but no verified sold comps, ORBIT continues down the query ladder instead of stopping.
- Query specificity is based on the identity actually present in the search text, preventing a brand-only fallback from inheriting exact-model counting behavior.
- Specific active searches can sample up to three eBay pages and visually inspect more candidate listings for a more stable denominator.


## ORBIT 1.2.9 decision-first evidence UI

- Keeps the sourcing verdict binary: **BUY** or **PASS**.
- Adds a plain-English decision checklist for resale value, demand, and acquisition cost.
- Replaces confusing “accepted” and “exact / family” counters with four simple evidence fields: sold matches, active matches, match basis, and decision confidence.
- Labels sell-through as an estimate and explicitly distinguishes the verified sample from the estimated matching market used for the ratio.
- Moves query/provider diagnostics into a nested technical-details section so they do not compete with the buying decision.

## ORBIT 1.2.1 binary decisions
- WHATNOT is no longer a sourcing verdict.
- RETRY is no longer a sourcing verdict.
- BUY is reserved for items that clear the selected value and conservative sell-through thresholds.
- Every other analyzed item returns PASS with a reason, including insufficient verification or borderline sell-through.
- Legacy WHATNOT/RETRY history entries display as PASS.


## 1.2.13 audit fixes
- Sell-through is computed independently from price verification.
- Model-specific goods can use a conservative title-supported exact-price fallback after visual anchoring.
- Brand names accidentally returned as the model are ignored as hard identifiers.
- Decision-input diagnostics are logged for false-PASS audits.


## Optional item hints

ORBIT 1.2.17 adds an optional **Item hints** field for fast sourcing. A user can enter information already known about the item (brand, model, style name, size, maker, MPN/SKU, era, team/character, or keywords). The hints are included in the first visual-identification prompt and can seed the market-query ladder, which can reduce generic identifications and unnecessary broad searches. Hints are treated as context rather than truth: the photo, visible labels, and market evidence can override them when they conflict. Hints are included in the stable-snapshot fingerprint so changing the hint forces a fresh analysis.


## ORBIT 1.2.18 — confidence-adjusted max buy

Max-buy now uses one global expected-proceeds model for every scanned category. ORBIT blends the robust median and trimmed-mean total order value from the selected sold evidence pool, including buyer-paid shipping when present. It applies a confidence-scaled risk factor derived from the existing pricing evidence score, then subtracts marketplace fees, estimated outbound postage, supplies, and the user's visible minimum-profit target. This replaces the old fixed 30th-percentile haircut for family-priced items.


## ORBIT 1.2.19 — max-buy response hotfix
- Fixes a stale response-field reference (`conservativeSaleValue`) that could abort scans after the confidence-adjusted max-buy calculation was introduced in 1.2.18.
- The legacy response field now reports the confidence-adjusted item value (`riskAdjustedItemValue`) so older UI paths remain compatible.
- Adds a regression assertion so this stale variable cannot return unnoticed.
