'use strict';

require('dotenv').config();
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const multer = require('multer');

const app = express();
const PORT = Number(process.env.PORT || 4173);
const HOST = process.env.HOST || '0.0.0.0';
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 14 * 1024 * 1024, files: 5 },
  fileFilter: (_req, file, cb) => cb(null, /^image\//.test(file.mimetype || ''))
});

// Keep local-development file:// access working; production uses same-origin HTTPS.
app.use((req,res,next)=>{
  const origin=String(req.headers.origin||'');
  const allowed=!origin || origin==='null' || /^https?:\/\/(?:localhost|127\.0\.0\.1)(?::\d+)?$/i.test(origin);
  if(allowed){
    res.setHeader('Access-Control-Allow-Origin',origin||'*');
    res.setHeader('Vary','Origin');
    res.setHeader('Access-Control-Allow-Methods','GET,POST,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers','Content-Type, X-ProfitQueue-Access');
  }
  if(req.method==='OPTIONS') return res.sendStatus(204);
  next();
});
app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use((req,res,next)=>{
  res.setHeader('X-Content-Type-Options','nosniff');
  res.setHeader('Referrer-Policy','same-origin');
  res.setHeader('Permissions-Policy','camera=(self)');
  if (req.path.startsWith('/api/')) res.setHeader('Cache-Control','no-store');
  next();
});
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public'), {
  maxAge: process.env.NODE_ENV==='production' ? '1h' : 0,
  setHeaders(res,file){ if(file.endsWith('index.html')||file.endsWith('sw.js')||file.endsWith('manifest.webmanifest')) res.setHeader('Cache-Control','no-cache'); }
}));

function cleanTextEnv(v='') { return String(v).trim(); }

const ENGINE_VERSION = '1.0.2-hybrid-sourcing';
const GEMINI_MODEL = process.env.GEMINI_VISION_MODEL || 'gemini-3.5-flash';
const COMP_MODEL = process.env.GEMINI_COMP_MODEL || 'gemini-3.5-flash-lite';
const SERPAPI_KEY = process.env.SERPAPI_KEY || '';
const TRAWL_API_KEY = process.env.TRAWL_API_KEY || '';
const TRAWL_MAX_PAGES = Math.max(1, Math.min(6, Number(process.env.TRAWL_MAX_PAGES || 4)));
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || '';
const APP_ACCESS_CODE = cleanTextEnv(process.env.APP_ACCESS_CODE || '');
// Free-mode defaults: one sold page + one active page for one search formulation.
// This is about 2 SerpApi searches/item, so the 250-search free plan goes much further.
const MARKET_SAMPLE_PAGES = Math.max(1, Math.min(3, Number(process.env.MARKET_SAMPLE_PAGES || 1)));
const MARKET_QUERY_ATTEMPTS = Math.max(1, Math.min(3, Number(process.env.MARKET_QUERY_ATTEMPTS || 1)));
const VISUAL_COMP_MAX_SOLD = Math.max(6, Math.min(24, Number(process.env.VISUAL_COMP_MAX_SOLD || 14)));
const VISUAL_COMP_MAX_ACTIVE = Math.max(6, Math.min(24, Number(process.env.VISUAL_COMP_MAX_ACTIVE || 16)));
const COMP_IMAGE_TIMEOUT_MS = Math.max(2500, Math.min(10000, Number(process.env.COMP_IMAGE_TIMEOUT_MS || 5000)));
const COMP_IMAGE_MAX_BYTES = Math.max(250000, Math.min(4000000, Number(process.env.COMP_IMAGE_MAX_BYTES || 1800000)));

const SEARCH_CACHE = new Map();
const SEARCH_CACHE_TTL_MS = 45 * 60 * 1000;
const COMP_IMAGE_CACHE = new Map();
const COMP_IMAGE_CACHE_TTL_MS = 6 * 60 * 60 * 1000;

// Trawl's free plan allows 2 requests/second. Keep every request in this process
// behind one queue so single, group, refinement, and repeated scans cannot burst
// above the provider limit. 650ms gives us headroom beyond the 500ms minimum.
const TRAWL_MIN_INTERVAL_MS = Math.max(550, Math.min(5000, Number(process.env.TRAWL_MIN_INTERVAL_MS || 650)));
const TRAWL_INFLIGHT = new Map();
let trawlQueueTail = Promise.resolve();
let trawlLastStartedAt = 0;
async function runTrawlQueued(task) {
  const previous = trawlQueueTail;
  let release;
  trawlQueueTail = new Promise(resolve => { release = resolve; });
  await previous;
  try {
    const waitMs = Math.max(0, TRAWL_MIN_INTERVAL_MS - (Date.now() - trawlLastStartedAt));
    if (waitMs > 0) await sleep(waitMs);
    trawlLastStartedAt = Date.now();
    return await task();
  } finally {
    release();
  }
}
function retryAfterMs(response) {
  const raw = cleanText(response?.headers?.get?.('retry-after') || '');
  if (!raw) return 0;
  const seconds = Number(raw);
  if (Number.isFinite(seconds) && seconds >= 0) return Math.ceil(seconds * 1000);
  const when = Date.parse(raw);
  return Number.isFinite(when) ? Math.max(0, when - Date.now()) : 0;
}

let soldProviderDegradedUntil = 0;
let soldProviderLastError = '';
const SOLD_PROVIDER_COOLDOWN_MS = 5 * 60 * 1000;
function cacheGet(key){ const v=SEARCH_CACHE.get(key); if(!v) return null; if(Date.now()-v.at>SEARCH_CACHE_TTL_MS){SEARCH_CACHE.delete(key);return null;} return v.data; }
function cacheSet(key,data){ SEARCH_CACHE.set(key,{at:Date.now(),data}); if(SEARCH_CACHE.size>250){ const first=SEARCH_CACHE.keys().next().value; SEARCH_CACHE.delete(first); } }

const STOP = new Set('a an and the of for with without to from by on in at is are was were this that these those vintage rare new used genuine authentic original oem nice great'.split(' '));
const ACCESSORY_WORDS = new Set('case cover manual instructions box packaging charger cable cord adapter replacement part parts shell skin mount stand holder remote strap bag pouch dock cradle battery lens cap'.split(' '));
const LOT_RE = /\b(lot of|bundle of|set of \d+|\d+[- ]?(?:pc|pcs|piece|pack)|pair of|lot\b|bundle\b)/i;
const PARTS_RE = /\b(for parts|parts only|not working|broken|repair|as[- ]?is)\b/i;
const OFFER_RE = /best offer accepted|offer accepted/i;

function cleanText(v='') {
  if (v == null) return '';
  const s = String(v).replace(/\s+/g, ' ').trim();
  return /^(?:null|undefined)$/i.test(s) ? '' : s;
}
function norm(v='') { return cleanText(v).toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim(); }
function tokens(v='') { return norm(v).split(' ').filter(t => t && !STOP.has(t) && t.length > 1); }
function clamp(n, a, b) { return Math.max(a, Math.min(b, n)); }
function uniq(arr) { return [...new Set(arr.filter(Boolean).map(cleanText))]; }
function mean(arr) {
  const a = arr.filter(Number.isFinite);
  return a.length ? a.reduce((s,v)=>s+v,0)/a.length : 0;
}
function median(arr) {
  const a = arr.filter(Number.isFinite).slice().sort((x,y)=>x-y);
  if (!a.length) return 0;
  const i = Math.floor(a.length/2);
  return a.length % 2 ? a[i] : (a[i-1]+a[i])/2;
}
function percentile(arr, p) {
  const a = arr.filter(Number.isFinite).slice().sort((x,y)=>x-y);
  if (!a.length) return 0;
  const x = (a.length - 1) * p;
  const lo = Math.floor(x), hi = Math.ceil(x);
  return lo === hi ? a[lo] : a[lo] + (a[hi]-a[lo])*(x-lo);
}
function trimmedMean(arr, trim=.10) {
  const a = arr.filter(Number.isFinite).slice().sort((x,y)=>x-y);
  if (!a.length) return 0;
  if (a.length < 10) return mean(a);
  const cut = Math.floor(a.length * trim);
  return mean(a.slice(cut, a.length-cut));
}
function robustPrices(values) {
  const vals = values.filter(v => Number.isFinite(v) && v > 0);
  if (vals.length < 5) return vals;
  const med = median(vals);
  const deviations = vals.map(v=>Math.abs(v-med));
  const mad = median(deviations);
  let filtered = vals;
  if (mad > 0) {
    // 3.5 modified-z cutoff. More stable than ordinary mean/SD for collectible outliers.
    filtered = vals.filter(v => (0.6745 * Math.abs(v-med) / mad) <= 3.5);
  }
  if (filtered.length < Math.max(4, Math.floor(vals.length*.6))) {
    const q1 = percentile(vals,.25), q3 = percentile(vals,.75), iqr = Math.max(.01,q3-q1);
    filtered = vals.filter(v => v >= Math.max(0,q1-1.5*iqr) && v <= q3+1.5*iqr);
  }
  return filtered.length >= 3 ? filtered : vals;
}
function parseMoney(v) {
  if (typeof v === 'number') return Number.isFinite(v) ? v : null;
  if (v && typeof v === 'object') {
    for (const k of ['extracted','extracted_value','value','amount','price']) {
      const n = parseMoney(v[k]); if (n != null) return n;
    }
    if (v.from || v.to) {
      const lo = parseMoney(v.from), hi = parseMoney(v.to);
      if (lo != null && hi != null) return (lo+hi)/2;
      return lo ?? hi;
    }
  }
  const s = String(v ?? '');
  if (/free shipping/i.test(s)) return 0;
  const m = s.replace(/,/g,'').match(/-?\d+(?:\.\d{1,2})?/);
  return m ? Number(m[0]) : null;
}
function safeJson(text) {
  let s = String(text || '').trim();
  s = s.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
  const first = s.indexOf('{'), last = s.lastIndexOf('}');
  if (first >= 0 && last > first) s = s.slice(first, last+1);
  return JSON.parse(s);
}

function geminiResponseText(payload) {
  const parts = payload?.candidates?.[0]?.content?.parts || [];
  return parts.map(p => typeof p?.text === 'string' ? p.text : '').join('').trim();
}

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
function uniqueModels(list=[]) {
  return [...new Set(list.map(v=>String(v||'').trim()).filter(Boolean))];
}
const VISION_FALLBACK_MODELS = uniqueModels([
  ...(process.env.GEMINI_VISION_FALLBACKS || '').split(','),
  'gemini-3.5-flash-lite',
  'gemini-3.1-flash-lite',
  'gemini-3.6-flash',
  'gemini-3.7-flash',
  'gemini-3.8-flash'
]);
const COMP_FALLBACK_MODELS = uniqueModels([
  ...(process.env.GEMINI_COMP_FALLBACKS || '').split(','),
  'gemini-3.5-flash-lite',
  'gemini-3.1-flash-lite',
  'gemini-3.5-flash',
  'gemini-3.6-flash'
]);

async function geminiGenerate({ model=GEMINI_MODEL, fallbackModels=[], prompt='', imageBuffer=null, imageMime='image/jpeg', parts=null, jsonMode=true }={}) {
  if (!GEMINI_API_KEY) throw new Error('GEMINI_API_KEY is not configured');
  let requestParts;
  if (Array.isArray(parts) && parts.length) {
    requestParts = parts;
  } else {
    requestParts = [{ text: String(prompt || '') }];
    if (imageBuffer) {
      requestParts.push({
        inline_data: {
          mime_type: imageMime || 'image/jpeg',
          data: imageBuffer.toString('base64')
        }
      });
    }
  }
  const hasImages = requestParts.some(p=>p && p.inline_data && p.inline_data.data);
  const body = {
    contents: [{ role: 'user', parts: requestParts }],
    generationConfig: jsonMode ? { response_mime_type: 'application/json' } : {}
  };
  const models = uniqueModels([model, ...fallbackModels]);
  let lastErr = null;

  for (let modelIndex=0; modelIndex<models.length; modelIndex++) {
    const candidateModel = models[modelIndex];
    for (let attempt=1; attempt<=1; attempt++) {
      const controller = new AbortController();
      const timer = setTimeout(()=>controller.abort(), hasImages ? 26000 : 12000);
      try {
        const response = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(candidateModel)}:generateContent`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'x-goog-api-key': GEMINI_API_KEY },
            body: JSON.stringify(body),
            signal: controller.signal
          }
        );
        const payload = await response.json().catch(() => ({}));
        if (!response.ok) {
          const msg = payload?.error?.message || `Gemini API HTTP ${response.status}`;
          const err = new Error(msg);
          err.status = response.status;
          err.code = payload?.error?.status || 'GEMINI_API_ERROR';
          throw err;
        }
        const text = geminiResponseText(payload);
        if (!text) {
          const reason = payload?.promptFeedback?.blockReason || payload?.candidates?.[0]?.finishReason || 'empty response';
          const err = new Error(`Gemini returned no text (${reason})`);
          err.status = 502;
          err.code = 'EMPTY_RESPONSE';
          throw err;
        }
        if (candidateModel !== model) console.warn(`Gemini fallback succeeded: ${model} -> ${candidateModel}`);
        return text;
      } catch (err) {
        if (err?.name==='AbortError') { const e=new Error('Gemini request timed out'); e.status=408; err=e; }
        lastErr = err;
        const status = Number(err?.status || 0);
        const transient = status === 408 || status === 429 || status >= 500;
        const unavailableModel = status === 404 || /no longer available|not found|unsupported model/i.test(String(err?.message||''));
        console.warn(`Gemini ${candidateModel} attempt ${attempt} failed: ${err.message}`);
        if (unavailableModel || transient) break;
        throw err;
      } finally { clearTimeout(timer); }
    }
  }
  const err = new Error(`Gemini capacity unavailable across ${models.length} supported model${models.length===1?'':'s'}: ${lastErr?.message || 'unknown error'}`);
  err.status = lastErr?.status || 503;
  err.code = lastErr?.code || 'GEMINI_FALLBACK_EXHAUSTED';
  throw err;
}

function parseDate(v) {
  if (!v) return null;
  const cleaned=cleanText(v).replace(/^(sold|ended|completed)\s*(on)?\s*/i,'');
  const d = new Date(cleaned);
  return Number.isFinite(d.getTime()) ? d : null;
}
function daysAgo(date, now=new Date()) {
  if (!(date instanceof Date) || !Number.isFinite(date.getTime())) return null;
  return Math.floor((now.getTime()-date.getTime()) / 86400000);
}
function itemIdFromResult(r) {
  if (r.product_id) return String(r.product_id);
  const link = String(r.link || '');
  const m = link.match(/\/itm\/(?:[^/]+\/)?(\d{9,15})/i);
  return m ? m[1] : null;
}
function dedupeRows(rows) {
  const seen = new Set();
  return rows.filter(r=>{
    const key = r.itemId || `${norm(r.title)}|${r.price}|${r.sold_date||''}`;
    if (seen.has(key)) return false;
    seen.add(key); return true;
  });
}
function wilson(successes, n, z=1.96) {
  if (!n) return {p:0,low:0,high:1};
  const p = clamp(successes/n,0,1), z2=z*z, den=1+z2/n;
  const center=(p+z2/(2*n))/den;
  const spread=(z*Math.sqrt((p*(1-p)+z2/(4*n))/n))/den;
  return {p,low:clamp(center-spread,0,1),high:clamp(center+spread,0,1)};
}

function conditionCompatible(target, text='') {
  const t=norm(text);
  if (!target || target==='unknown' || !t) return true;
  if (target==='for_parts') return PARTS_RE.test(t);
  if (PARTS_RE.test(t)) return false;
  if (target==='new') return /\bnew\b|sealed|new with tags|new in box/.test(t) && !/open box/.test(t);
  if (target==='open_box') return /open box|new other|unused/.test(t) || /\bnew\b/.test(t);
  if (target==='used') return !/brand new|new with|new in|sealed/.test(t);
  return true;
}

function marketQueryClean(v) {
  return cleanText(v)
    .replace(/["“”']/g, ' ')
    .replace(/[\/|]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function itemQueryCandidates(item) {
  const brand = marketQueryClean(item.brand), model = marketQueryClean(item.model), mpn = marketQueryClean(item.mpn);
  const type = marketQueryClean(item.item_type || '');
  const title = marketQueryClean(item.title || '');
  const barcode = marketQueryClean(item.barcode || '');
  const supplied = Array.isArray(item.query_candidates) ? item.query_candidates.map(marketQueryClean).filter(Boolean) : [];
  const identityTerms = Array.isArray(item.identity_terms) ? item.identity_terms.map(marketQueryClean).filter(Boolean) : [];
  const conciseTitle = title.split(/\s+/).slice(0,8).join(' ');
  const brandNorm=norm(brand);
  const suppliedSpecific=supplied.filter(q=>{
    const nq=norm(q), qt=tokens(q);
    if(!nq) return false;
    // AI sometimes emits only the brand even after identifying a specific product line.
    // Keep those broad searches only as a final discovery fallback, never as the first market query.
    if(brandNorm && nq===brandNorm) return false;
    return qt.length>=2 || qt.some(t=>/\d/.test(t));
  });
  const suppliedBroad=supplied.filter(q=>!suppliedSpecific.includes(q));
  const titleWithoutColor=title.replace(/\b(?:black|white|grey|gray|brown|tan|beige|red|blue|green|navy|orange|yellow|purple|pink)\b/ig,' ').replace(/\s+/g,' ').trim();
  // Search ladder: identifiers first, then the visual model's actual identified product name,
  // then model/product-line terms. Broad brand/category discovery is always last.
  return uniq([
    barcode,
    [brand, mpn].filter(Boolean).join(' '),
    [brand, model].filter(Boolean).join(' '),
    [brand, mpn, model].filter(Boolean).join(' '),
    titleWithoutColor,
    conciseTitle,
    [brand, ...identityTerms.slice(0,3)].filter(Boolean).join(' '),
    [brand, model, type].filter(Boolean).join(' '),
    ...suppliedSpecific,
    [brand, type].filter(Boolean).join(' '),
    ...suppliedBroad,
    brand
  ].map(marketQueryClean)).filter(q => q.length >= 3).slice(0, 10);
}

async function identifyImages(images, mode='single') {
  if (!GEMINI_API_KEY) throw new Error('GEMINI_API_KEY is not configured');
  const usable=(Array.isArray(images)?images:[]).filter(x=>x?.buffer).slice(0,5);
  if(!usable.length) throw new Error('No image uploaded');
  const group = mode === 'group';
  const prompt = `You are the visual identification engine for ProfitQueue, a professional reseller sourcing tool.
Analyze this photo and identify ${group ? 'each distinct sellable item visible (maximum 12)' : 'the single primary sellable item'}.

Critical rules:
- Never invent a brand, model, maker, edition, material, size, UPC, MPN, or price tag. Use null when not supported by visible evidence.
- Read all visible labels, model numbers, signatures, stamps, logos, tags and price stickers carefully.
- Exact model/part/edition matters more than generic object class.
- identity_terms are the minimum words/numbers a true comp should normally contain. Put model numbers, capacities, edition names, sizes, product lines, and distinctive identifiers here.
- exclude_terms are words that usually indicate the wrong product for this exact item (accessories, neighboring model numbers, incompatible sizes, etc.).
- Distinguish the main product from accessories, packaging, manuals and unrelated background objects.
- If identity is uncertain, give the strongest candidate but lower identity_confidence and list alternatives.
- price_tag is the acquisition/store price visibly attached to the item, never an estimated resale value.
- query_candidates must be concise eBay searches, most specific first, no hype words.
- Estimate listing labor and packing supplies conservatively. shipping_estimate is likely outbound postage if the seller offers free shipping.

Return ONLY valid JSON:
{
  "items": [{
    "title": "specific factual identity",
    "item_type": "object type",
    "category": "resale category",
    "brand": null,
    "model": null,
    "mpn": null,
    "barcode": null,
    "visible_text": ["..."],
    "identity_terms": ["must-match identifier"],
    "exclude_terms": ["wrong-model/accessory clue"],
    "condition": "new|open_box|used|for_parts|unknown",
    "price_tag": null,
    "identity_confidence": 0.0,
    "alternative_identities": ["..."],
    "query_candidates": ["..."],
    "is_bundle": false,
    "bulky": false,
    "fragile": false,
    "labor_min": 12,
    "supplies_estimate": 1.0,
    "shipping_estimate": 6.0,
    "bbox": {"x":0,"y":0,"w":1000,"h":1000}
  }]
}`;

  const parts=[{text:prompt}];
  usable.forEach((img,i)=>{parts.push({text:`TARGET PHOTO ${i+1} OF ${usable.length} — all photos show the same item from different angles`});parts.push({inline_data:{mime_type:img.mime||'image/jpeg',data:img.buffer.toString('base64')}});});
  const outputText = await geminiGenerate({
    model: GEMINI_MODEL,
    fallbackModels: VISION_FALLBACK_MODELS,
    parts,
    jsonMode: true
  });
  const parsed = safeJson(outputText);
  if (!Array.isArray(parsed.items) || !parsed.items.length) throw new Error('Vision model returned no identifiable items');
  return parsed.items.slice(0, group ? 12 : 1).map(x => ({
    ...x,
    title: cleanText(x.title || x.item_type || 'Unidentified item'),
    identity_confidence: clamp(Number(x.identity_confidence) || 0, 0, 1),
    price_tag: (x.price_tag===null || x.price_tag===undefined || cleanText(x.price_tag)==='') ? null : (Number.isFinite(Number(x.price_tag)) ? Number(x.price_tag) : null),
    labor_min: clamp(Number(x.labor_min) || 12, 3, 120),
    supplies_estimate: clamp(Number(x.supplies_estimate) || 1, 0, 30),
    shipping_estimate: clamp(Number(x.shipping_estimate) || 0, 0, 150),
    identity_terms: uniq(Array.isArray(x.identity_terms) ? x.identity_terms : []),
    exclude_terms: uniq(Array.isArray(x.exclude_terms) ? x.exclude_terms : []),
    is_bundle: !!x.is_bundle
  }));
}


async function identifyImage(buffer,mime,mode='single'){return identifyImages([{buffer,mime}],mode);}

function conditionParam(condition) {
  if (condition === 'new') return '1000';
  if (condition === 'open_box') return '1500';
  if (condition === 'used') return '3000';
  if (condition === 'for_parts') return '7000';
  return null;
}


function isoDateDaysAgo(days) {
  const d=new Date(Date.now()-Math.max(0,days)*86400000);
  return d.toISOString().slice(0,10);
}
function trawlConditionParam(condition) {
  if (condition==='new') return 'new';
  if (condition==='used') return 'used';
  if (condition==='for_parts') return 'parts';
  if (condition==='open_box') return 'new,other';
  return '';
}
function trawlExclude(item, query='') {
  // Trawl rejects requests when any exclude word also appears in query.
  // Reduce phrases like "Eau de Toilette" to only safe non-query words ("toilette").
  const queryWords=new Set(tokens(marketQueryClean(query)));
  const target=new Set(tokens(`${item.title||''} ${item.item_type||''}`));
  const out=[];
  const addSafe=(value)=>{
    for (const word of tokens(marketQueryClean(value))) {
      if (!word || queryWords.has(word)) continue;
      out.push(word);
    }
  };
  for (const term of (item.exclude_terms||[])) addSafe(term);
  if (item.condition!=='for_parts') ['broken','repair','parts'].forEach(addSafe);
  if (!item.is_bundle) ['lot','bundle'].forEach(addSafe);
  for (const word of ['case','cover','manual','charger','cable','adapter']) {
    if (!target.has(word)) addSafe(word);
  }
  return uniq(out).slice(0,18).join(' ');
}
async function trawlSoldPage(query,item,page=1) {
  if (!TRAWL_API_KEY) throw new Error('TRAWL_API_KEY is not configured');
  const cacheKey=`trawl|sold|${page}|${marketQueryClean(query)}|${item.condition||'unknown'}`;
  const cached=cacheGet(cacheKey); if(cached) return cached;
  if (TRAWL_INFLIGHT.has(cacheKey)) return TRAWL_INFLIGHT.get(cacheKey);

  const work=(async()=>{
    const u=new URL('https://api.trawl.dev/ebay/v1/sold');
    u.searchParams.set('query', marketQueryClean(query).slice(0,140));
    u.searchParams.set('site','EBAY_US');
    u.searchParams.set('date_from',isoDateDaysAgo(90));
    u.searchParams.set('date_to',new Date().toISOString().slice(0,10));
    u.searchParams.set('limit','240');
    u.searchParams.set('page',String(page));
    const condition=trawlConditionParam(item.condition);
    if(condition) u.searchParams.set('condition',condition);
    let exclude=trawlExclude(item, query);
    if(exclude) u.searchParams.set('exclude',exclude);

    let lastErr=null;
    const maxAttempts=5;
    for(let attempt=1;attempt<=maxAttempts;attempt++) {
      const controller=new AbortController();
      const timer=setTimeout(()=>controller.abort(),15000);
      try {
        const r=await runTrawlQueued(()=>fetch(u,{
          signal:controller.signal,
          headers:{'x-api-key':TRAWL_API_KEY,'User-Agent':`ORBIT/${ENGINE_VERSION}`}
        }));
        const text=await r.text(); let data={};
        try{data=text?JSON.parse(text):{};}catch{}
        if(!r.ok) {
          const msg=cleanText(data?.error||data?.message||'');
          // Defensive fallback: if Trawl still detects an overlap, retry without exclusions.
          if (r.status===400 && /exclude overlaps query/i.test(msg) && exclude) {
            u.searchParams.delete('exclude');
            exclude='';
            if (attempt<maxAttempts) continue;
          }
          const err=new Error(`Trawl ${r.status}${msg?`: ${msg.slice(0,240)}`:''}`);
          err.status=r.status;
          err.retryAfterMs=retryAfterMs(r);
          throw err;
        }
        if(!Array.isArray(data.results)) throw new Error('Trawl returned an invalid sold-results payload');
        cacheSet(cacheKey,data);
        return data;
      } catch(err) {
        lastErr=err;
        const status=Number(err?.status||0);
        if (attempt<maxAttempts && status===429) {
          // Provider plan is 2 req/s. Back off substantially instead of surfacing
          // a transient rate-limit error to the user.
          const providerWait=Math.max(0,Number(err?.retryAfterMs||0));
          const exponential=Math.min(8000, 900 * (2 ** (attempt-1)));
          const jitter=Math.floor(Math.random()*250);
          const waitMs=Math.max(providerWait,exponential+jitter);
          console.warn(`Trawl rate limited (attempt ${attempt}/${maxAttempts}); retrying in ${waitMs}ms`);
          await sleep(waitMs);
          continue;
        }
        if (attempt<maxAttempts && (err?.name==='AbortError'||status>=500)) {
          await sleep(Math.min(4000,500*attempt));
          continue;
        }
        break;
      } finally { clearTimeout(timer); }
    }
    if(lastErr?.name==='AbortError') throw new Error('Trawl sold search timed out after automatic retries');
    throw lastErr||new Error('Trawl sold search failed');
  })();

  TRAWL_INFLIGHT.set(cacheKey,work);
  try { return await work; }
  finally { TRAWL_INFLIGHT.delete(cacheKey); }
}
function normalizeTrawlResult(r,item) {
  const price=Number(r.sale_price);
  const shipping=Number(r.shipping_price);
  const soldDate=cleanText(r.date_sold)||null;
  const condition=cleanText(r.condition_raw||r.condition);
  const row={
    itemId:cleanText(r.item_id)||null,
    title:cleanText(r.title),
    price:Number.isFinite(price)?price:null,
    shipping:Number.isFinite(shipping)?Math.max(0,shipping):0,
    condition,
    sold_date:soldDate,
    soldDateParsed:parseDate(soldDate),
    link:r.item_link||null,
    imageUrl:cleanText(r.image_url)||null,
    sponsored:false,
    extensions:'',
    bestOfferUnknown:false,
    soldCount:0,
    watchers:0,
    landedPrice:(Number.isFinite(price)?price:0)+(Number.isFinite(shipping)?Math.max(0,shipping):0),
    sourceSoldSearch:true,
    soldProvider:'Trawl'
  };
  return {...row,lexicalMatch:titleMatchScore(row.title,item)};
}
async function sampleTrawlSold(query,item) {
  const rows=[]; let complete=false; let pages=0;
  // Broad discovery queries only need one page for visual matching. Once the
  // identity/query is specific, deeper paging is useful for a better 90-day count.
  const pageLimit=querySpecificEnough(item,query)?TRAWL_MAX_PAGES:1;
  for(let page=1;page<=pageLimit;page++) {
    const data=await trawlSoldPage(query,item,page); pages=page;
    const pageRows=(data.results||[]).map(r=>normalizeTrawlResult(r,item)).filter(r=>r.title&&r.price!=null&&r.price>0);
    rows.push(...pageRows);
    if(pageRows.length<240){complete=true;break;}
  }
  return {
    total:dedupeRows(rows).length,
    exactState:'',categories:[],rows:dedupeRows(rows),conditionApplied:item.condition||'unknown',
    source:'trawl',complete,truncated:!complete,pages
  };
}
function trawlSearchQuality(search,matchedRows) {
  const n=Math.max(0,search.rows.length), k=Math.max(0,matchedRows.length), ci=wilson(k,n);
  return {
    sampleN:n,matchedN:k,precision:ci.p,precisionLow:ci.low,precisionHigh:ci.high,
    complete:!!search.complete,estimate:k,low:k,high:search.complete?k:k+240,total:n,
    lowerBound:!search.complete
  };
}

async function serpEbaySearch(query, {sold=false,page=1,condition='unknown'}={}) {
  if (!SERPAPI_KEY) throw new Error('SERPAPI_KEY is not configured');
  if (sold && Date.now() < soldProviderDegradedUntil) {
    const err=new Error(`sold listings temporarily unavailable${soldProviderLastError?`: ${soldProviderLastError}`:''}`);
    err.code='SOLD_PROVIDER_COOLDOWN'; throw err;
  }
  const cacheKey=`${sold?'sold':'active'}|${page}|${marketQueryClean(query)}`;
  const cached=cacheGet(cacheKey); if(cached) return cached;
  const u = new URL('https://serpapi.com/search');
  u.searchParams.set('engine', 'ebay');
  u.searchParams.set('_nkw', query.slice(0,120));
  u.searchParams.set('_ipg', '100');
  u.searchParams.set('_pgn', String(page));
  if (sold) u.searchParams.set('show_only', 'Sold');
  u.searchParams.set('api_key', SERPAPI_KEY);
  let lastErr=null;
  const maxAttempts = sold ? 1 : 2;
  const timeoutMs = sold ? 12000 : 15000;
  for (let attempt=1;attempt<=maxAttempts;attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const r = await fetch(u, { signal: controller.signal, headers: { 'User-Agent': `ProfitQueue/${ENGINE_VERSION}` }});
      const bodyText = await r.text();
      let data = {};
      try { data = bodyText ? JSON.parse(bodyText) : {}; } catch {}
      const providerMessage = cleanText(data?.error || '');
      // SerpApi sometimes represents a legitimate empty eBay search as an error string.
      if (providerMessage && /hasn['’]?t returned any results|no results for this query/i.test(providerMessage)) {
        const empty={...data,error:undefined,organic_results:[],search_information:{...(data.search_information||{}),total_results:0}};
        cacheSet(cacheKey,empty); return empty;
      }
      if (!r.ok) throw new Error(`SerpApi eBay ${r.status}${providerMessage ? `: ${providerMessage.slice(0,280)}` : ''}`);
      if (data.error) throw new Error(`SerpApi eBay: ${providerMessage.slice(0,280)}`);
      if (Number(data.search_information?.total_results)>0 && !(data.organic_results||[]).length) throw new Error('eBay result page returned no parseable listings');
      cacheSet(cacheKey,data); return data;
    } catch(err) {
      lastErr=err;
      const msg=cleanText(err?.message || err);
      if (sold && (err?.name==='AbortError' || /aborted|timed out|timeout|high response/i.test(msg))) {
        soldProviderLastError='eBay/SerpApi sold-filter timeout';
        soldProviderDegradedUntil=Date.now()+SOLD_PROVIDER_COOLDOWN_MS;
      }
      if (attempt<maxAttempts) await sleep(350);
    } finally { clearTimeout(timer); }
  }
  if (lastErr?.name==='AbortError') throw new Error(sold?'sold search timed out':'active search timed out');
  throw lastErr||new Error('eBay search failed');
}

function accessoryPenalty(title, identity) {
  const tt = new Set(tokens(title));
  const it = new Set(tokens(`${identity.title} ${identity.item_type || ''}`));
  let p = 0;
  for (const w of ACCESSORY_WORDS) if (tt.has(w) && !it.has(w)) p += .09;
  return Math.min(.45, p);
}
function titleMatchScore(title, item) {
  const titleN = norm(title), titleSet = new Set(tokens(title));
  const baseTokens = tokens(`${item.brand || ''} ${item.model || ''} ${item.mpn || ''} ${item.item_type || ''}`);
  const querySet = new Set(baseTokens);
  let inter = 0; for (const t of querySet) if (titleSet.has(t)) inter++;
  const union = new Set([...querySet, ...titleSet]).size || 1;
  let score = (inter / Math.max(1, querySet.size)) * .45 + (inter / union) * .12;
  const brand = norm(item.brand || ''), model = norm(item.model || ''), mpn = norm(item.mpn || '');
  if (brand) score += titleN.includes(brand) ? .10 : -.04;
  if (model) score += titleN.includes(model) ? .27 : -.22;
  if (mpn) score += titleN.includes(mpn) ? .25 : -.18;
  const must = (item.identity_terms || []).map(norm).filter(Boolean);
  if (must.length) {
    const hits = must.filter(t=>titleN.includes(t)).length;
    score += (hits/must.length)*.18;
    if (hits===0 && !model && !mpn) score -= .10;
  }
  const excludes=(item.exclude_terms||[]).map(norm).filter(Boolean);
  if (excludes.some(t=>titleN.includes(t))) score -= .35;
  score -= accessoryPenalty(title, item);
  if (LOT_RE.test(title) && !item.is_bundle) score -= .24;
  if (PARTS_RE.test(title) && item.condition !== 'for_parts') score -= .24;
  return clamp(score, 0, 1);
}
function normalizeResult(r, sold=false) {
  const soldDate = r.sold_date || null;
  const condition = cleanText(r.condition);
  const extensions = Array.isArray(r.extensions) ? r.extensions.join(' ') : cleanText(r.extensions || '');
  const shipping = parseMoney(r.shipping);
  return {
    itemId: itemIdFromResult(r),
    title: cleanText(r.title),
    price: parseMoney(r.price),
    shipping: shipping == null ? 0 : Math.max(0,shipping),
    condition,
    sold_date: soldDate,
    soldDateParsed: parseDate(soldDate),
    link: r.link || null,
    imageUrl: cleanText(r.thumbnail || r.image || r.image_url || '') || null,
    sponsored: !!r.sponsored,
    extensions,
    bestOfferUnknown: OFFER_RE.test(`${extensions} ${r.subtitle||''} ${r.returns||''}`),
    soldCount: Number(r.extracted_quantity_sold ?? r.extracted_sold_count ?? 0) || 0,
    watchers: Number(r.extracted_watchers || 0) || 0,
    landedPrice: (parseMoney(r.price)||0) + (shipping == null ? 0 : Math.max(0,shipping)),
    sourceSoldSearch: sold
  };
}
function evaluatePage(data, item, sold=false) {
  const rows = (data.organic_results || []).map(r=>normalizeResult(r,sold)).filter(r => r.title && r.price != null && r.price > 0);
  const scored = rows.map(r => ({...r, lexicalMatch: titleMatchScore(r.title, item)}));
  const totalRaw = Number(data.search_information?.total_results);
  return {
    rows: scored,
    total: Number.isFinite(totalRaw) ? totalRaw : scored.length,
    exactState: data.search_information?.organic_results_state || '',
    categories: data.categories || []
  };
}

async function sampleSearch(query, item, sold=false) {
  const run=async condition=>{
    const pages=[];
    const firstRaw=await serpEbaySearch(query,{sold,page:1,condition});
    const first=evaluatePage(firstRaw,item,sold); pages.push(first);
    const wantedPages = first.total > 200 ? MARKET_SAMPLE_PAGES : 1;
    for (let p=2;p<=wantedPages;p++) {
      const raw=await serpEbaySearch(query,{sold,page:p,condition});
      const ev=evaluatePage(raw,item,sold); pages.push(ev);
      if (!ev.rows.length) break;
    }
    return {total:first.total,exactState:first.exactState,categories:first.categories,rows:dedupeRows(pages.flatMap(p=>p.rows)),conditionApplied:condition};
  };
  let result=await run(item.condition);
  // eBay condition IDs are category-dependent. If a condition-filtered query unexpectedly returns nothing, retry unfiltered rather than reporting false scarcity.
  if (!result.rows.length && item.condition && item.condition!=='unknown') result=await run('unknown');
  return result;
}

function prefilterRows(rows,item,{sold=false}={}) {
  const now=new Date();
  return rows.filter(r=>{
    if (r.lexicalMatch < .20) return false;
    if (!conditionCompatible(item.condition,r.condition)) return false;
    if (LOT_RE.test(r.title) && !item.is_bundle) return false;
    if (PARTS_RE.test(r.title) && item.condition!=='for_parts') return false;
    if (sold) {
      // Sponsored cards can appear inside sold-result pages. A sold date is our proof that the row is an actual sold result.
      if (!r.soldDateParsed) return false;
      const age=daysAgo(r.soldDateParsed,now);
      if (age == null || age < -2 || age > 90) return false;
    }
    return true;
  }).sort((a,b)=>b.lexicalMatch-a.lexicalMatch);
}

function compImageCacheGet(url) {
  const v=COMP_IMAGE_CACHE.get(url);
  if(!v) return null;
  if(Date.now()-v.at>COMP_IMAGE_CACHE_TTL_MS){COMP_IMAGE_CACHE.delete(url);return null;}
  return v.data;
}
function compImageCacheSet(url,data) {
  COMP_IMAGE_CACHE.set(url,{at:Date.now(),data});
  if(COMP_IMAGE_CACHE.size>220){const first=COMP_IMAGE_CACHE.keys().next().value;COMP_IMAGE_CACHE.delete(first);}
}
function trustedCompImageUrl(value='') {
  try {
    const u=new URL(cleanText(value));
    if(u.protocol!=='https:') return null;
    if(!/(^|\.)ebayimg\.com$/i.test(u.hostname)) return null;
    return u.toString();
  } catch { return null; }
}
async function fetchCompImage(value='') {
  const url=trustedCompImageUrl(value);
  if(!url) return null;
  const cached=compImageCacheGet(url); if(cached) return cached;
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),COMP_IMAGE_TIMEOUT_MS);
  try {
    const r=await fetch(url,{signal:controller.signal,headers:{'User-Agent':`ORBIT/${ENGINE_VERSION}`}});
    if(!r.ok) return null;
    const type=cleanText(r.headers.get('content-type')||'').split(';')[0].toLowerCase();
    if(!/^image\/(?:jpeg|png|webp)$/.test(type)) return null;
    const declared=Number(r.headers.get('content-length')||0);
    if(declared>COMP_IMAGE_MAX_BYTES) return null;
    const ab=await r.arrayBuffer();
    if(!ab.byteLength || ab.byteLength>COMP_IMAGE_MAX_BYTES) return null;
    const data={buffer:Buffer.from(ab),mime:type};
    compImageCacheSet(url,data);
    return data;
  } catch { return null; }
  finally { clearTimeout(timer); }
}
function selectVisualCandidates(rows,maxCount) {
  const usable=rows.map((row,index)=>({row,index})).filter(x=>trustedCompImageUrl(x.row.imageUrl));
  if(usable.length<=maxCount) return usable;
  const headCount=Math.max(4,Math.ceil(maxCount*.62));
  const picked=usable.slice(0,headCount);
  const tail=usable.slice(headCount);
  const remaining=maxCount-picked.length;
  for(let j=0;j<remaining && tail.length;j++){
    const pos=Math.min(tail.length-1,Math.floor(((j+.5)*tail.length)/remaining));
    picked.push(tail[pos]);
  }
  const seen=new Set();
  return picked.filter(x=>{if(seen.has(x.index))return false;seen.add(x.index);return true;}).slice(0,maxCount);
}
async function loadVisualCandidates(rows,maxCount) {
  const selected=selectVisualCandidates(rows,maxCount);
  const loaded=[];
  for(let i=0;i<selected.length;i+=6){
    const batch=selected.slice(i,i+6);
    const results=await Promise.all(batch.map(async x=>({ ...x, image:await fetchCompImage(x.row.imageUrl) })));
    loaded.push(...results.filter(x=>x.image));
  }
  return loaded;
}

async function classifyCompRows(item, soldRows, activeRows, visualContext={}) {
  const sold = soldRows.slice(0,120), active=activeRows.slice(0,120);
  const targetImages=(Array.isArray(visualContext.images)?visualContext.images:[]).filter(x=>x?.buffer).slice(0,5);
  if(!targetImages.length && visualContext.imageBuffer) targetImages.push({buffer:visualContext.imageBuffer,mime:visualContext.imageMime||'image/jpeg'});
  if (!GEMINI_API_KEY || !targetImages.length) {
    return {sold:[],active:[],visualSoldInspected:0,visualActiveInspected:0,visualRefinement:null,visualUnavailable:true};
  }

  const [soldVisual,activeVisual]=await Promise.all([
    loadVisualCandidates(sold,VISUAL_COMP_MAX_SOLD),
    loadVisualCandidates(active,VISUAL_COMP_MAX_ACTIVE)
  ]);
  if (!soldVisual.length && !activeVisual.length) {
    return {sold:[],active:[],visualSoldInspected:0,visualActiveInspected:0,visualRefinement:null,visualUnavailable:true};
  }

  const identity = {
    title:item.title, brand:item.brand||null, model:item.model||null, mpn:item.mpn||null,
    item_type:item.item_type||null, condition:item.condition||'unknown',
    visible_text:item.visible_text||[], identity_terms:item.identity_terms||[], exclude_terms:item.exclude_terms||[], is_bundle:!!item.is_bundle
  };
  const prompt=`You are ORBIT's strict visual resale-comp verifier. The first one or more images are the user's target item from different angles. Every later image is an eBay listing candidate and is preceded by its exact SOLD/ACTIVE index and title.

Target identity from the user's photo: ${JSON.stringify(identity)}

Your job is precision-first. A comp may affect price or sell-through ONLY when the listing photo and title support that it is genuinely the same sellable product/model/design.

Classification:
- exact = Tier 1 verified comp: same product/model/design. Normal color differences are okay only when they do not imply a different edition/model/value tier.
- likely = Tier 2: probably same model/family but the photo/title cannot rule out a meaningful variant.
- variant = same family but visibly different size, edition, generation, trim, configuration, form factor, or other price-relevant version.
- accessory = case, sleeve, laptop case, pouch, charger, replacement part, packaging, manual, strap, etc. instead of the target.
- lot = bundle/multiple units when target is one.
- parts = broken/for-parts when target is not for-parts.
- wrong = different product/model/design or insufficient evidence.

Critical rules:
- Compare PHOTOS, not just words. If the target is a backpack and a candidate photo is a laptop sleeve/case, it is accessory/wrong even if the brand matches.
- Never mark exact merely because brand/category matches.
- If a distinctive model/design is visible, require its shape, construction, pockets, closures, straps, hardware, logo placement, proportions, and major trim to agree.
- If you cannot see enough to verify it, use likely or wrong, not exact.
- Precision is more important than sample size.

Also return a refinement only if Tier-1 matches strongly reveal a specific repeated model/product line that is visually supported by the target. Do not infer a model just because it is common. The proposed query should be brand + model/product line and should avoid generic words when possible.

Return ONLY JSON:
{"sold":[{"i":0,"match":"exact|likely|variant|accessory|lot|parts|wrong","confidence":0.0,"visual_confidence":0.0,"reason":"short"}],"active":[...],"refinement":{"accepted":false,"title":null,"model":null,"query":null,"identity_terms":[],"confidence":0.0,"reason":"short"}}
Classify every provided candidate index exactly once.`;

  const parts=[{text:prompt}];
  targetImages.forEach((img,i)=>{parts.push({text:`TARGET ITEM PHOTO ${i+1} OF ${targetImages.length}`});parts.push({inline_data:{mime_type:img.mime||'image/jpeg',data:img.buffer.toString('base64')}});});
  for(const x of soldVisual){
    parts.push({text:`SOLD index ${x.index}: ${x.row.title} | condition=${x.row.condition||'unknown'} | sold=${x.row.price??'unknown'}`});
    parts.push({inline_data:{mime_type:x.image.mime,data:x.image.buffer.toString('base64')}});
  }
  for(const x of activeVisual){
    parts.push({text:`ACTIVE index ${x.index}: ${x.row.title} | condition=${x.row.condition||'unknown'} | ask=${x.row.price??'unknown'}`});
    parts.push({inline_data:{mime_type:x.image.mime,data:x.image.buffer.toString('base64')}});
  }

  try {
    const outputText=await geminiGenerate({model:COMP_MODEL,fallbackModels:COMP_FALLBACK_MODELS,parts,jsonMode:true});
    const parsed=safeJson(outputText);
    const soldAllowed=new Set(soldVisual.map(x=>x.index)), activeAllowed=new Set(activeVisual.map(x=>x.index));
    const sanitize=(arr,allowed)=>(Array.isArray(arr)?arr:[]).filter(c=>allowed.has(Number(c.i))).map(c=>({
      i:Number(c.i),match:String(c.match||'wrong'),confidence:clamp(Number(c.confidence)||0,0,1),
      visual_confidence:clamp(Number(c.visual_confidence??c.confidence)||0,0,1),reason:cleanText(c.reason||'')
    }));
    const refinement=parsed?.refinement&&typeof parsed.refinement==='object'?parsed.refinement:null;
    return {
      sold:sanitize(parsed.sold,soldAllowed),active:sanitize(parsed.active,activeAllowed),
      visualSoldInspected:soldVisual.length,visualActiveInspected:activeVisual.length,
      visualRefinement:refinement,visualUnavailable:false
    };
  } catch (err) {
    console.warn('Visual comp classifier unavailable:',err.message);
    return {sold:[],active:[],visualSoldInspected:soldVisual.length,visualActiveInspected:activeVisual.length,visualRefinement:null,visualUnavailable:true,visualError:err.message};
  }
}

function applyClassification(rows, classes) {
  const byIndex=new Map((classes||[]).map(c=>[Number(c.i),c]));
  return rows.slice(0,400).map((r,i)=>{
    const c=byIndex.get(i)||null;
    if(!c) return {...r,compClass:'unverified',compTier:3,compConfidence:0,visualConfidence:0,visualVerified:false,match:0};
    const label=String(c.match||'wrong');
    const aiConfidence=clamp(Number(c.confidence)||0,0,1);
    const visualConfidence=clamp(Number(c.visual_confidence??c.confidence)||0,0,1);
    const exact=label==='exact' && aiConfidence>=.72 && visualConfidence>=.72;
    const tier=exact?1:((label==='likely'||label==='variant')&&aiConfidence>=.60?2:3);
    return {
      ...r,compClass:label,compTier:tier,compConfidence:aiConfidence,visualConfidence,
      visualVerified:exact,compReason:cleanText(c.reason||''),
      match:exact?clamp(r.lexicalMatch*.20+aiConfidence*.35+visualConfidence*.45,0,1):clamp(r.lexicalMatch*.15+aiConfidence*.25+visualConfidence*.25,0,.79)
    };
  });
}

function hasHardIdentity(item) {
  const model=marketQueryClean(item.model), mpn=marketQueryClean(item.mpn), barcode=marketQueryClean(item.barcode);
  if (model || mpn || barcode) return true;
  // Descriptive materials/colors are not a model identity. Without an explicit model,
  // only model-like alphanumeric/numeric identifiers make an identity hard enough for STR.
  const terms=(item.identity_terms||[]).flatMap(t=>tokens(marketQueryClean(t)));
  return terms.some(t=>/\d/.test(t));
}

function querySpecificEnough(item, query) {
  if (hasHardIdentity(item)) return true;
  const q=tokens(marketQueryClean(query));
  return q.some(t=>/\d/.test(t));
}

function searchQuality(sampleRows, matchedRows, total) {
  const n=Math.max(0,sampleRows.length), k=Math.max(0,matchedRows.length);
  const ci=wilson(k,n);
  const complete = total <= n + 2;
  const estimate = complete ? k : Math.round(total*ci.p);
  const low = complete ? k : Math.floor(total*ci.low);
  const high = complete ? k : Math.ceil(total*ci.high);
  return {sampleN:n,matchedN:k,precision:ci.p,precisionLow:ci.low,precisionHigh:ci.high,complete,estimate,low,high,total};
}

function visualSearchQuality(search, matchedRows, inspectedN) {
  const n=Math.max(0,Number(inspectedN)||0), k=Math.max(0,matchedRows.length);
  const total=Math.max(k,Number(search?.total)||0);
  if(!n) return {sampleN:0,matchedN:k,precision:0,precisionLow:0,precisionHigh:1,complete:false,estimate:k,low:0,high:Math.max(k,total),total,uncertain:true};
  const ci=wilson(k,n);
  const fullyInspected = total>0 && n>=total;
  const estimate=fullyInspected?k:Math.max(k,Math.round(total*ci.p));
  const low=fullyInspected?k:Math.max(0,Math.floor(total*ci.low));
  const high=fullyInspected?k:Math.max(k,Math.ceil(total*ci.high));
  return {sampleN:n,matchedN:k,precision:ci.p,precisionLow:ci.low,precisionHigh:ci.high,complete:fullyInspected,estimate,low,high,total,uncertain:false};
}

function visualRefinedIdentity(item, market) {
  const r=market?.visualRefinement;
  if(!r || r.accepted!==true) return null;
  const confidence=clamp(Number(r.confidence)||0,0,1);
  const query=marketQueryClean(r.query||'');
  const model=marketQueryClean(r.model||'');
  if(confidence<.78 || !query || norm(query)===norm(market.query||'')) return null;
  const brand=marketQueryClean(item.brand||'');
  if(brand && !norm(query).includes(norm(brand))) return null;
  const exactTitles=[...(market.soldExact||[]),...(market.activeExact||[])].map(x=>norm(x.title));
  if(exactTitles.length<2) return null;
  const evidenceTerm=norm(model)||tokens(query).filter(t=>!tokens(brand).includes(t)).join(' ');
  if(evidenceTerm){
    const hits=exactTitles.filter(t=>t.includes(evidenceTerm)).length;
    if(hits<2) return null;
  }
  return {
    ...item,
    title:cleanText(r.title||`${brand} ${model}`||item.title),
    model:model||item.model||null,
    identity_terms:uniq([...(Array.isArray(r.identity_terms)?r.identity_terms:[]),model,...(item.identity_terms||[])]),
    query_candidates:uniq([query,...(item.query_candidates||[])]),
    identity_confidence:Math.max(Number(item.identity_confidence)||0,Math.min(.97,confidence)),
    market_assisted_identity:true,
    market_identity_reason:cleanText(r.reason||'Visually verified comp consensus'),
    market_identity_confidence:confidence
  };
}

async function analyzeMarketAttempt(query,item,visualContext={}) {
  const soldPromise=TRAWL_API_KEY?sampleTrawlSold(query,item):sampleSearch(query,item,true);
  const [soldResult,activeResult]=await Promise.allSettled([soldPromise,sampleSearch(query,item,false)]);
  if (soldResult.status==='rejected' && activeResult.status==='rejected') {
    throw new Error(`eBay market provider failed — sold: ${soldResult.reason?.message||'unknown error'}; active: ${activeResult.reason?.message||'unknown error'}`);
  }
  const emptySearch=(error)=>({total:0,exactState:'',categories:[],rows:[],conditionApplied:'unknown',providerError:error||null});
  const soldSearch=soldResult.status==='fulfilled'?soldResult.value:emptySearch(soldResult.reason?.message||'sold search unavailable');
  const activeSearch=activeResult.status==='fulfilled'?activeResult.value:emptySearch(activeResult.reason?.message||'active search unavailable');
  const soldDataAvailable=soldResult.status==='fulfilled';
  const activeDataAvailable=activeResult.status==='fulfilled';
  const providerErrors=[];
  if (!soldDataAvailable) providerErrors.push(`sold comps unavailable: ${soldSearch.providerError}`);
  if (!activeDataAvailable) providerErrors.push(`active listings unavailable: ${activeSearch.providerError}`);
  const soldPre=prefilterRows(soldSearch.rows,item,{sold:true});
  const activePre=prefilterRows(activeSearch.rows,item,{sold:false});
  const classes=await classifyCompRows(item,soldPre,activePre,visualContext);
  if(classes.visualError) providerErrors.push(`visual comp verification unavailable: ${classes.visualError}`);
  const soldClassified=applyClassification(soldPre,classes.sold);
  const activeClassified=applyClassification(activePre,classes.active);
  const soldExact=soldClassified.filter(r=>r.visualVerified===true && r.compTier===1);
  const activeExact=activeClassified.filter(r=>r.visualVerified===true && r.compTier===1);
  const soldTier2=soldClassified.filter(r=>r.compTier===2);
  const activeTier2=activeClassified.filter(r=>r.compTier===2);

  // ORBIT 1.0.2 hybrid sourcing:
  // Exact-model evidence remains the gold standard, but rare/discontinued items should not
  // become non-actionable just because the exact SKU has thin history. Strong Tier-2 rows
  // are visually similar same-brand/product-family comps; accessories/cases/lots/wrong
  // designs were already rejected by the visual verifier and never enter this fallback.
  const familyAccept=r=>r.compTier===1 || (
    r.compTier===2 &&
    (r.compClass==='likely'||r.compClass==='variant') &&
    Number(r.compConfidence||0)>=.70 &&
    Number(r.visualConfidence||0)>=.68
  );
  const soldFamily=soldClassified.filter(familyAccept);
  const activeFamily=activeClassified.filter(familyAccept);

  const priceRows=soldExact.filter(r=>!r.bestOfferUnknown);
  const robust=robustPrices(priceRows.map(r=>r.price));
  const familyPriceRows=soldFamily.filter(r=>!r.bestOfferUnknown);
  const familyPrices=robustPrices(familyPriceRows.map(r=>r.price));
  let soldQ=visualSearchQuality(soldSearch,soldExact,classes.visualSoldInspected);
  let activeQ=visualSearchQuality(activeSearch,activeExact,classes.visualActiveInspected);
  let familySoldQ=visualSearchQuality(soldSearch,soldFamily,classes.visualSoldInspected);
  let familyActiveQ=visualSearchQuality(activeSearch,activeFamily,classes.visualActiveInspected);
  if(soldSearch.source==='trawl' && soldSearch.truncated){
    soldQ={...soldQ,lowerBound:true,uncertain:true};
    familySoldQ={...familySoldQ,lowerBound:true,uncertain:true};
  }

  const broadActiveUncertain = activeDataAvailable && !querySpecificEnough(item,query) &&
    activeSearch.total > Math.max(12, activeExact.length*3);
  if (broadActiveUncertain) activeQ={...activeQ,uncertain:true,broadQuery:true};

  const priceMedian=median(robust), priceAverage=trimmedMean(robust,.10);
  const activePrices=robustPrices(activeExact.map(r=>r.price));
  const askingPriceMedian=median(activePrices);
  const activePriceLow=percentile(activePrices,.25), activePriceHigh=percentile(activePrices,.75);
  const activeDispersion=askingPriceMedian>0?(activePriceHigh-activePriceLow)/askingPriceMedian:1;
  const visibleActiveSoldUnits=activeExact.reduce((n,r)=>n+(Number(r.soldCount)||0),0);
  const activeListingsWithSales=activeExact.filter(r=>(Number(r.soldCount)||0)>0).length;
  const activeWatchers=activeExact.reduce((n,r)=>n+(Number(r.watchers)||0),0);
  const demandProxy = activeExact.length<3 ? 'unknown' : (visibleActiveSoldUnits>=50 || activeListingsWithSales>=4 || activeWatchers>=30 ? 'strong' : (visibleActiveSoldUnits>=8 || activeListingsWithSales>=1 || activeWatchers>=8 ? 'moderate' : 'weak'));
  const activeMarketConfidence=clamp(activeQ.precisionLow*.34 + clamp(classes.visualActiveInspected/16,0,1)*.20 + clamp(activeExact.length/8,0,1)*.20 + item.identity_confidence*.16 + (1-clamp(activeDispersion,0,1))*.06 + (activeDataAvailable ? .04 : 0),0,1);
  const dispersion=priceMedian>0?(percentile(robust,.75)-percentile(robust,.25))/priceMedian:1;
  const familyMedian=median(familyPrices);
  const familyDispersion=familyMedian>0?(percentile(familyPrices,.75)-percentile(familyPrices,.25))/familyMedian:1;
  let score = soldDataAvailable ? (soldQ.precisionLow*.25 + activeQ.precisionLow*.18 + clamp(robust.length/10,0,1)*.24 + clamp(classes.visualSoldInspected/14,0,1)*.12 + clamp(classes.visualActiveInspected/16,0,1)*.08 + (1-clamp(dispersion,0,1))*.07 + item.identity_confidence*.06) : activeMarketConfidence;
  const familyScore = soldDataAvailable ? (
    familySoldQ.precisionLow*.22 + familyActiveQ.precisionLow*.16 +
    clamp(familyPrices.length/10,0,1)*.22 + clamp(soldFamily.length/10,0,1)*.12 +
    clamp(activeFamily.length/8,0,1)*.10 + (1-clamp(familyDispersion,0,1))*.08 +
    item.identity_confidence*.10
  ) : 0;
  score=Math.max(score,familyScore*.90);
  if (!activeDataAvailable) score*=.35;
  if(classes.visualUnavailable) score*=.15;
  return {
    query,soldSearch,activeSearch,soldPre,activePre,soldExact,activeExact,soldTier2,activeTier2,soldFamily,activeFamily,
    priceRows,prices:robust,familyPriceRows,familyPrices,activePrices,
    askingPriceMedian,activePriceLow,activePriceHigh,activeMarketConfidence,visibleActiveSoldUnits,activeListingsWithSales,activeWatchers,demandProxy,
    soldQ,activeQ,familySoldQ,familyActiveQ,score,soldDataAvailable,activeDataAvailable,providerErrors,soldSource:soldSearch.source==='trawl'?'Trawl':'SerpApi',
    soldCountLowerBound:!!soldQ.lowerBound,familySoldCountLowerBound:!!familySoldQ.lowerBound,
    visualVerificationAvailable:!classes.visualUnavailable,visualSoldInspected:classes.visualSoldInspected,
    visualActiveInspected:classes.visualActiveInspected,visualRefinement:classes.visualRefinement||null
  };
}

function marketIdentityNeedsRefinement(item, market) {
  if (!market?.activeDataAvailable || (market.activeSearch?.rows?.length || 0) < 6) return false;
  const hard = hasHardIdentity(item);
  const exact = Number(market.activeQ?.matchedN || 0);
  const precision = Number(market.activeQ?.precisionLow || 0);
  const broadTotal = Number(market.activeSearch?.total || 0);
  // Generic identities are especially dangerous when the broad query spans many
  // variants. Use the original photo + real listing titles to refine before STR.
  if (!hard && (market.activeQ?.uncertain || broadTotal > Math.max(30,exact*3))) return true;
  return (!hard && exact < 6) || (exact < 2 && precision < .20);
}

async function refineIdentityFromActiveMarket(item, market, imageBuffer, imageMime) {
  if (!GEMINI_API_KEY || !imageBuffer || !marketIdentityNeedsRefinement(item, market)) return null;
  const rows=(market.activeSearch?.rows || []).slice(0,36);
  if (rows.length < 12) return null;
  const listingTitles=rows.map((r,i)=>({i,title:r.title,condition:r.condition,price:r.price}));
  const current={title:item.title,brand:item.brand||null,model:item.model||null,mpn:item.mpn||null,item_type:item.item_type||null,visible_text:item.visible_text||[],identity_terms:item.identity_terms||[]};
  const prompt=`You are doing a second-pass product identification for a reseller app. The first visual pass was too generic, and we now have real active eBay listing titles from a broad search. Use the ORIGINAL PHOTO plus these listing titles to refine the target only when the photo is visually consistent with a specific repeated product line/model.

Current identity: ${JSON.stringify(current)}
Active eBay titles: ${JSON.stringify(listingTitles)}

Rules:
- Do not choose a model just because it is common in the listings.
- A refined model/product line must appear verbatim in at least two supplied listing titles.
- Use visible shape/design/markings in the photo plus any visible text from the first pass.
- Never invent MPN/UPC/size/edition.
- If the photo cannot support a specific refinement, return accepted=false.
- query must be concise, normally brand + model/product line, with no generic hype words.
- confidence is confidence that the refinement identifies the photographed item, not confidence that the listing search is popular.
Return ONLY JSON:
{"accepted":true,"title":"specific identity","model":"model or product line","identity_terms":["must-match term"],"query":"brand model","confidence":0.0,"reason":"short evidence note"}`;
  try {
    const out=await geminiGenerate({model:GEMINI_MODEL,fallbackModels:VISION_FALLBACK_MODELS,prompt,imageBuffer,imageMime:imageMime||'image/jpeg',jsonMode:true});
    const r=safeJson(out);
    if (!r || r.accepted!==true) return null;
    const model=marketQueryClean(r.model);
    const query=marketQueryClean(r.query);
    const confidence=clamp(Number(r.confidence)||0,0,1);
    if (!model || !query || confidence < .72) return null;
    const mn=norm(model);
    const titleHits=rows.filter(x=>norm(x.title).includes(mn)).length;
    if (titleHits < 2) return null;
    const brand=marketQueryClean(item.brand);
    if (brand && !norm(query).includes(norm(brand))) return null;
    return {
      ...item,
      title:cleanText(r.title || `${brand} ${model}` || item.title),
      model:model,
      identity_terms:uniq([model,...(Array.isArray(r.identity_terms)?r.identity_terms:[]),...(item.identity_terms||[])]),
      query_candidates:uniq([query,...(item.query_candidates||[])]),
      identity_confidence:Math.max(Number(item.identity_confidence)||0, Math.min(.96,confidence)),
      market_assisted_identity:true,
      market_identity_reason:cleanText(r.reason||''),
      market_identity_confidence:confidence
    };
  } catch(err) {
    console.warn(`Market-assisted identity refinement failed for ${item.title}: ${err.message}`);
    return null;
  }
}

async function bestMarketSearch(item, visualContext={}) {
  const candidates=itemQueryCandidates(item);
  if (!candidates.length) throw new Error('Not enough visible identity to build a market query');
  const attempts=[];
  // Normally stop after the first useful active search. If eBay returns no active listings,
  // broaden only then. This preserves the low-cost mode while avoiding false zero-result cards
  // from over-specific AI-generated queries.
  const maxAdaptiveAttempts=Math.min(candidates.length, Math.max(2, MARKET_QUERY_ATTEMPTS));
  for (const query of candidates.slice(0,maxAdaptiveAttempts)) {
    try {
      const attempt=await analyzeMarketAttempt(query,item,visualContext);
      attempts.push(attempt);
      const rawCandidates=(attempt.soldSearch?.rows?.length||0)+(attempt.activeSearch?.rows?.length||0);
      const verifiedMatches=(attempt.soldExact?.length||0)+(attempt.activeExact?.length||0);
      const probableMatches=(attempt.soldTier2?.length||0)+(attempt.activeTier2?.length||0);
      const familySoldMatches=attempt.soldFamily?.length||0;
      const familyActiveMatches=attempt.activeFamily?.length||0;
      // Raw search hits are only candidates. If visual verification rejects almost everything,
      // continue down the query ladder instead of stopping on a broad/irrelevant search.
      const usableMarket = verifiedMatches>=2 || (verifiedMatches>=1 && probableMatches>=2);
      const usableFamilyMarket = familySoldMatches>=5 && familyActiveMatches>=3;
      const specificWithEvidence = querySpecificEnough(item,query) && verifiedMatches>=1 && rawCandidates>=3;
      if (usableMarket || usableFamilyMarket || specificWithEvidence) break;
    } catch (err) {
      attempts.push({query,error:err.message,score:-1});
      // Keep broadening for query-specific no-result/provider errors, but do not fan out endlessly.
    }
  }
  const valid=attempts.filter(a=>!a.error).sort((a,b)=>b.score-a.score);
  if (!valid.length) throw new Error(attempts.map(a=>`${a.query}: ${a.error}`).join(' | ')||'No market data returned');
  const best=valid[0];
  const second=valid[1]||null;
  let agreement=1;
  const bestAgreePrices=best.prices.length>=3?best.prices:best.activePrices;
  const secondAgreePrices=second?(second.prices.length>=3?second.prices:second.activePrices):[];
  if (second && bestAgreePrices.length>=3 && secondAgreePrices.length>=3) {
    const a=trimmedMean(bestAgreePrices), b=trimmedMean(secondAgreePrices);
    if (a>0&&b>0) agreement=Math.min(a,b)/Math.max(a,b);
    const s1=best.activeQ.estimate>0?best.soldQ.estimate/best.activeQ.estimate:0;
    const s2=second.activeQ.estimate>0?second.soldQ.estimate/second.activeQ.estimate:0;
    if (s1>0&&s2>0) agreement=Math.min(agreement,Math.min(s1,s2)/Math.max(s1,s2));
  }
  return {...best,agreement,attempts:attempts.map(a=>a.error?{query:a.query,error:a.error}:{query:a.query,score:a.score,soldSample:a.soldQ.sampleN,soldExact:a.soldQ.matchedN,activeSample:a.activeQ.sampleN,activeExact:a.activeQ.matchedN,soldPrecision:a.soldQ.precision,activePrecision:a.activeQ.precision})};
}

function marketToItem(identity, market, settings={}) {
  const exactSoldPrices=market.prices||[];
  const familySoldPrices=market.familyPrices||[];
  const soldDataAvailable=market.soldDataAvailable===true;
  const activeDataAvailable=market.activeDataAvailable===true;
  const visualVerificationAvailable=market.visualVerificationAvailable===true;

  const exactPricingVerified=visualVerificationAvailable && soldDataAvailable && exactSoldPrices.length>=3;
  const familyPricingVerified=visualVerificationAvailable && soldDataAvailable && !exactPricingVerified &&
    familySoldPrices.length>=5 && Number(market.familySoldQ?.matchedN||0)>=5 &&
    Number(market.familySoldQ?.precisionLow||0)>=.16;

  const pricingMode=exactPricingVerified?'exact':(familyPricingVerified?'brand_family':'none');
  const soldPrices=pricingMode==='exact'?exactSoldPrices:(pricingMode==='brand_family'?familySoldPrices:[]);
  const pricingVerified=pricingMode!=='none';

  const exactActiveCountUncertain=market.activeQ?.uncertain===true;
  const exactVelocityVerified=exactPricingVerified && activeDataAvailable && !exactActiveCountUncertain &&
    Number(market.visualActiveInspected||0)>=6 && Number(market.activeQ?.matchedN||0)>=1 &&
    Number(market.activeQ?.estimate||0)>0;

  // Family-level velocity is intentionally allowed on broad brand/category searches, but only
  // after enough listing photos were inspected and several visually similar family comps survived.
  const familyVelocityVerified=pricingVerified && activeDataAvailable &&
    Number(market.visualActiveInspected||0)>=8 &&
    Number(market.familyActiveQ?.matchedN||0)>=3 &&
    Number(market.familyActiveQ?.estimate||0)>0 &&
    Number(market.familyActiveQ?.precisionLow||0)>=.10 &&
    Number(market.familySoldQ?.matchedN||0)>=5;

  const velocityMode=exactVelocityVerified?'exact':(familyVelocityVerified?'brand_family':'none');
  const velocityVerified=velocityMode!=='none';

  const rawAverage=trimmedMean(soldPrices,.10), rawMedian=median(soldPrices);
  const q1=percentile(soldPrices,.25), q3=percentile(soldPrices,.75);
  const saleAverage=pricingVerified?rawAverage:0;
  const saleMedian=pricingVerified?rawMedian:0;

  // In brand-family mode we DISPLAY the actual family average, but use a lower-percentile
  // conservative value for the max-buy calculation so a premium neighboring model cannot
  // talk ORBIT into overpaying for the target.
  const conservativeSaleValue=pricingMode==='brand_family'?
    Math.min(saleAverage,percentile(soldPrices,.35)||saleAverage):saleAverage;

  const soldQ=velocityMode==='brand_family'?market.familySoldQ:market.soldQ;
  const activeQ=velocityMode==='brand_family'?market.familyActiveQ:market.activeQ;
  const sold90=velocityVerified?Number(soldQ?.estimate||0):(pricingVerified?Number((pricingMode==='brand_family'?market.familySoldQ:market.soldQ)?.estimate||0):0);
  const activeListings=velocityVerified?Number(activeQ?.estimate||0):0;
  const soldCountLowerBound=velocityMode==='brand_family'?market.familySoldCountLowerBound===true:market.soldCountLowerBound===true;
  const activeCountUncertain=velocityMode==='exact'?exactActiveCountUncertain:false;
  const soldLow=Number(soldQ?.low||0), soldHigh=Number(soldQ?.high||0);
  const activeLow=Number(activeQ?.low||0), activeHigh=Number(activeQ?.high||0);
  const rawStr=velocityVerified && activeListings>0 ? sold90/activeListings : null;
  const strLow=velocityVerified && activeHigh>0 ? soldLow/activeHigh*100 : 0;
  const strHigh=velocityVerified ? (activeLow>0?soldHigh/activeLow*100:(soldHigh>0?999:0)) : 0;
  const daysToSell=rawStr>0?clamp(Math.round(90/rawStr),2,365):null;

  const dispersion=saleMedian>0?(q3-q1)/saleMedian:1;
  const priceSampleConfidence=clamp(soldPrices.length/10,0,1);
  const soldPrecisionConfidence=Number((pricingMode==='brand_family'?market.familySoldQ:market.soldQ)?.precisionLow||0);
  const activePrecisionConfidence=Number(activeQ?.precisionLow||0);
  const visualCoverage=clamp((Number(market.visualSoldInspected||0)+Number(market.visualActiveInspected||0))/24,0,1);
  const countCertainty=velocityVerified?clamp(1-((Number(soldQ?.high||0)-Number(soldQ?.low||0))/Math.max(1,Number(soldQ?.estimate||0)+Number(soldQ?.high||0))),0,1):.25;
  let marketConfidence=clamp(
    priceSampleConfidence*.20 + soldPrecisionConfidence*.18 + activePrecisionConfidence*.14 + visualCoverage*.18 +
    countCertainty*.10 + (1-clamp(dispersion,0,1))*.08 + Number(market.agreement||1)*.06 + Number(identity.identity_confidence||0)*.06,
    0,1
  );
  if(pricingMode==='brand_family') marketConfidence=Math.min(marketConfidence,.78);
  if(!pricingVerified) marketConfidence=Math.min(marketConfidence,.38);
  if(!velocityVerified) marketConfidence=Math.min(marketConfidence,.48);
  const decisionConfidence=velocityVerified?marketConfidence:marketConfidence*.55;

  const tagCost=Number.isFinite(identity.price_tag)?identity.price_tag:null;
  const feesPct=Number(settings.defaultFeesPct??15);
  const shipping=Number(identity.shipping_estimate||0);
  const supplies=Number(identity.supplies_estimate||1);
  const targetProfit=Number(settings.minProfit??25);
  const verifiedMaxBuyPrice=pricingVerified&&conservativeSaleValue>0?
    Math.max(0,conservativeSaleValue-conservativeSaleValue*(feesPct/100)-shipping-supplies-targetProfit):null;
  const maxBuyPrice=verifiedMaxBuyPrice;

  const reviewReasons=[];
  const evidenceNotes=[];
  if(!visualVerificationAvailable) reviewReasons.push('listing photos could not be visually verified');
  if(identity.identity_confidence<.62) reviewReasons.push('item identity uncertain');
  if(!pricingVerified) reviewReasons.push(`need at least 3 exact or 5 strong same-brand family sold comps (found ${Math.max(exactSoldPrices.length,familySoldPrices.length)})`);
  if(exactPricingVerified && market.soldQ.precisionLow<.20) reviewReasons.push('sold candidate set contains many visual non-matches');
  if(pricingMode==='brand_family') evidenceNotes.push('Exact-model history is thin; value uses visually similar same-brand product-family comps and a conservative max-buy floor.');
  if(velocityMode==='brand_family') evidenceNotes.push('Sell-through is a same-brand product-family estimate, not an exact-SKU rate.');
  if(!velocityVerified){
    if(exactActiveCountUncertain && pricingMode==='exact') reviewReasons.push('active search is still too broad; a more specific model/label photo is needed');
    else if(Number(market.visualActiveInspected||0)<6) reviewReasons.push('not enough active listing photos were available to verify sell-through');
    else reviewReasons.push('not enough visually similar active listings survived verification to estimate sell-through safely');
  }
  if(market.agreement<.70) reviewReasons.push('independent search queries disagree');
  if(saleMedian>0 && (q3-q1)/saleMedian>.85) reviewReasons.push('accepted sold prices are widely dispersed');

  const chosenSoldRows=pricingMode==='brand_family'?(market.soldFamily||[]):(market.soldExact||[]);
  const chosenSoldQ=pricingMode==='brand_family'?market.familySoldQ:market.soldQ;
  const chosenActiveQ=velocityMode==='brand_family'?market.familyActiveQ:market.activeQ;
  const rejectedSold=Math.max(0,Number(market.visualSoldInspected||0)-Number(chosenSoldQ?.matchedN||0));
  const rejectedActive=Math.max(0,Number(market.visualActiveInspected||0)-Number(chosenActiveQ?.matchedN||0));

  return {
    title:identity.title,
    category:identity.category||identity.item_type||'Uncategorized',
    brand:identity.brand||null, model:identity.model||null, mpn:identity.mpn||null,
    marketAssistedIdentity:identity.market_assisted_identity===true, marketIdentityReason:identity.market_identity_reason||null, marketIdentityConfidence:identity.market_identity_confidence||null,
    condition:identity.condition||'unknown',
    cost:tagCost, costKnown:tagCost!=null, costSource:tagCost!=null?'visible price tag':'not visible',
    maxBuyPrice:maxBuyPrice==null?null:Number(maxBuyPrice.toFixed(2)),
    maxBuyPriceVerified:pricingVerified&&maxBuyPrice!=null,
    provisionalResalePrice:null,
    salePrice:Number(saleAverage.toFixed(2)), averageSalePrice:Number(saleAverage.toFixed(2)), medianSalePrice:Number(saleMedian.toFixed(2)),
    conservativeSaleValue:pricingVerified?Number(conservativeSaleValue.toFixed(2)):0,
    salePriceLow:pricingVerified?Number(q1.toFixed(2)):0, salePriceHigh:pricingVerified?Number(q3.toFixed(2)):0,
    feesPct, shipping, supplies, laborMin:Number(identity.labor_min||12),
    sold90, activeListings, soldCountLowerBound, activeCountUncertain, activeCountUpperBound:false,
    sellThrough90:rawStr==null?null:Number((rawStr*100).toFixed(1)), sellThroughLowerBound:velocityVerified&&soldCountLowerBound,
    sellThroughLow:Number(strLow.toFixed(1)), sellThroughHigh:Number(Math.min(strHigh,999).toFixed(1)),
    soldCountLow:soldLow, soldCountHigh:soldHigh, activeCountLow:activeLow, activeCountHigh:activeHigh,
    soldSample:soldPrices.length, soldCompSample:Number(chosenSoldQ?.matchedN||0), activeCompSample:Number(chosenActiveQ?.matchedN||0),
    exactSoldCompSample:Number(market.soldQ?.matchedN||0), exactActiveCompSample:Number(market.activeQ?.matchedN||0),
    familySoldCompSample:Number(market.familySoldQ?.matchedN||0), familyActiveCompSample:Number(market.familyActiveQ?.matchedN||0),
    soldSearchSample:Number(chosenSoldQ?.sampleN||0), activeSearchSample:Number(chosenActiveQ?.sampleN||0),
    visualSoldInspected:Number(market.visualSoldInspected||0), visualActiveInspected:Number(market.visualActiveInspected||0),
    rejectedSoldComps:rejectedSold,rejectedActiveComps:rejectedActive,
    soldMatchPrecision:Number(Number(chosenSoldQ?.precision||0).toFixed(3)), activeMatchPrecision:Number(Number(chosenActiveQ?.precision||0).toFixed(3)),
    queryAgreement:Number(Number(market.agreement||1).toFixed(3)),
    daysToSell, quantity:1, bulky:!!identity.bulky, fragile:!!identity.fragile,
    confidence:decisionConfidence, identityConfidence:identity.identity_confidence, marketConfidence, activeMarketConfidence:market.activeMarketConfidence||0, decisionConfidence,
    marketQuery:market.query, soldDataAvailable, activeDataAvailable, pricingVerified, velocityVerified, visualVerificationAvailable,
    pricingMode,velocityMode,brandFamilyFallback:pricingMode==='brand_family'||velocityMode==='brand_family',
    askingPriceMedian:market.askingPriceMedian?Number(market.askingPriceMedian.toFixed(2)):null,
    activePriceLow:market.activePriceLow?Number(market.activePriceLow.toFixed(2)):null,activePriceHigh:market.activePriceHigh?Number(market.activePriceHigh.toFixed(2)):null,
    demandProxy:market.demandProxy||'unknown',visibleActiveSoldUnits:market.visibleActiveSoldUnits||0,activeListingsWithSales:market.activeListingsWithSales||0,activeWatchers:market.activeWatchers||0,providerErrors:market.providerErrors||[],
    marketSource:visualVerificationAvailable?`${market.soldSource||'Trawl'} sold history + eBay active listings; ${pricingMode==='brand_family'||velocityMode==='brand_family'?'photo-verified brand-family fallback':'photo-to-photo + title verification'}`:'Market providers connected; visual verification unavailable',
    visibleText:identity.visible_text||[], alternativeIdentities:identity.alternative_identities||[],
    evidenceNotes,
    compExamples:chosenSoldRows.slice(0,8).map(x=>({title:x.title,price:x.price,shipping:x.shipping,soldDate:x.sold_date,match:Number(x.match.toFixed(2)),visualConfidence:Number((x.visualConfidence||0).toFixed(2)),compClass:x.compClass||'exact',link:x.link,imageUrl:x.imageUrl||null})),
    reviewRequired:reviewReasons.length>0 || decisionConfidence<.52 || !pricingVerified || !velocityVerified,
    reviewReasons,
    bbox:identity.bbox||null
  };
}

const AUTH_FAILURES=new Map();
function accessMatches(candidate='') {
  if (!APP_ACCESS_CODE) return true;
  const a=Buffer.from(String(candidate));
  const b=Buffer.from(APP_ACCESS_CODE);
  return a.length===b.length && crypto.timingSafeEqual(a,b);
}
function requireAccess(req,res,next) {
  if (!APP_ACCESS_CODE) return next();
  const key=String(req.ip||req.socket?.remoteAddress||'unknown');
  const now=Date.now();
  const state=AUTH_FAILURES.get(key)||{count:0,since:now};
  if(now-state.since>10*60*1000){state.count=0;state.since=now;}
  if(state.count>=10)return res.status(429).json({error:'Too many access-code attempts. Try again later.',code:'ACCESS_RATE_LIMIT'});
  const candidate=req.get('X-ProfitQueue-Access') || '';
  if (!accessMatches(candidate)) { state.count++;AUTH_FAILURES.set(key,state);return res.status(401).json({error:'ProfitQueue access code required',code:'ACCESS_REQUIRED'}); }
  AUTH_FAILURES.delete(key);next();
}

app.post('/api/access/check', requireAccess, (_req,res)=>res.json({ok:true}));

app.get('/api/health', (_req,res) => {
  res.json({
    ok:true, engineVersion:ENGINE_VERSION, configured:Boolean(GEMINI_API_KEY&&SERPAPI_KEY&&TRAWL_API_KEY), geminiConfigured:Boolean(GEMINI_API_KEY), trawlConfigured:Boolean(TRAWL_API_KEY), soldMarketData:Boolean(TRAWL_API_KEY), soldProviderDegraded:Date.now()<soldProviderDegradedUntil, soldProviderMessage:soldProviderLastError||null,
    model:GEMINI_MODEL, compModel:COMP_MODEL, visionFallbacks:VISION_FALLBACK_MODELS, compFallbacks:COMP_FALLBACK_MODELS, marketProvider:'Trawl sold + SerpApi active + photo-to-photo comp verification',
    samplePages:MARKET_SAMPLE_PAGES, queryAttempts:MARKET_QUERY_ATTEMPTS, accessProtected:Boolean(APP_ACCESS_CODE), deployment:process.env.RENDER?'render':'node', port:PORT
  });
});

app.post('/api/analyze', requireAccess, upload.fields([{name:'images',maxCount:5},{name:'image',maxCount:1}]), async (req,res) => {
  const started=Date.now();
  try {
    const uploaded=[...(req.files?.images||[]),...(req.files?.image||[])].slice(0,5);
    if (!uploaded.length) return res.status(400).json({error:'No image uploaded'});
    if (!GEMINI_API_KEY||!SERPAPI_KEY||!TRAWL_API_KEY) return res.status(503).json({error:'Backend needs GEMINI_API_KEY, SERPAPI_KEY, and TRAWL_API_KEY',code:'NOT_CONFIGURED'});
    let settings={}; try{settings=req.body.settings?JSON.parse(req.body.settings):{};}catch{}
    const mode=req.body.mode==='group'?'group':'single';
    const barcode=cleanText(req.body.barcode||'');
    const targetImages=uploaded.map(f=>({buffer:f.buffer,mime:f.mimetype||'image/jpeg'}));
    const identities=await identifyImages(targetImages,mode);
    if (barcode&&identities[0]) {
      identities[0].barcode=barcode;
      identities[0].query_candidates=uniq([barcode,...(identities[0].query_candidates||[])]);
      identities[0].visible_text=uniq([...(identities[0].visible_text||[]),`Barcode ${barcode}`]);
      identities[0].identity_confidence=Math.max(.90,identities[0].identity_confidence||0);
    }
    const visualContext={images:targetImages};
    const analyzeOne=async identity=>{
      try {
        let market=await bestMarketSearch(identity,visualContext);
        let finalIdentity=identity;

        // ORBIT 1.0: let the photo-to-photo verifier propose a specific model/query
        // only when Tier-1 visually matching comps support it, then re-run market data
        // using that tighter identity. This replaces title-only model guessing.
        const visualRefined=visualRefinedIdentity(identity,market);
        if(visualRefined){
          try{
            const exactQuery=itemQueryCandidates(visualRefined)[0];
            const refinedMarket=await analyzeMarketAttempt(exactQuery,visualRefined,visualContext);
            const refinedSold=Number(refinedMarket.soldQ?.matchedN||0);
            const refinedInspected=Number(refinedMarket.visualSoldInspected||0);
            const refinedSpecific=querySpecificEnough(visualRefined,exactQuery);
            if(refinedSpecific && refinedSold>=3 && refinedInspected>=3){
              refinedMarket.agreement=1;
              refinedMarket.attempts=[{query:exactQuery,score:refinedMarket.score,soldExact:refinedSold,activeExact:Number(refinedMarket.activeQ?.matchedN||0),visualRefined:true}];
              market=refinedMarket; finalIdentity=visualRefined;
              console.log(`Visual identity refinement accepted: ${identity.title} -> ${visualRefined.title} (${exactQuery})`);
            }
          }catch(err){console.warn(`Visual refined search failed for ${identity.title}: ${err.message}`);}
        }

        console.log(`ORBIT market: ${finalIdentity.title} | query=${market.query} | soldSource=${market.soldSource||'unknown'} | visualSold=${market.visualSoldInspected||0} | soldExact=${market.soldQ?.matchedN||0}${market.soldCountLowerBound?'+':''} | visualActive=${market.visualActiveInspected||0} | activeExact=${market.activeQ?.matchedN||0} | activeEstimate=${market.activeQ?.estimate||0}`);
        return marketToItem(finalIdentity,market,settings);
      }
      catch(err) {
        console.warn(`Market verification failed for ${identity.title}: ${err.message}`);
        return {
          title:identity.title,category:identity.category||identity.item_type||'Uncategorized',cost:identity.price_tag??null,costKnown:identity.price_tag!=null,
          salePrice:0,averageSalePrice:0,medianSalePrice:0,maxBuyPrice:null,feesPct:Number(settings.defaultFeesPct??15),shipping:Number(identity.shipping_estimate||0),
          supplies:Number(identity.supplies_estimate||1),laborMin:Number(identity.labor_min||12),sold90:0,activeListings:0,sellThrough90:null,
          daysToSell:null,quantity:1,bulky:!!identity.bulky,fragile:!!identity.fragile,confidence:identity.identity_confidence*.15,
          identityConfidence:identity.identity_confidence,marketConfidence:0,activeMarketConfidence:0,decisionConfidence:0,soldDataAvailable:false,activeDataAvailable:false,pricingVerified:false,visualVerificationAvailable:false,reviewRequired:true,reviewReasons:[`market verification failed: ${err.message}`],analysisError:err.message,
          marketSource:'No verified visual comps',visibleText:identity.visible_text||[],alternativeIdentities:identity.alternative_identities||[],bbox:identity.bbox||null
        };
      }
    };
    const items=[];
    // Limit external search concurrency so rapid/group scanning does not create noisy provider failures.
    for (let i=0;i<identities.length;i+=2) items.push(...await Promise.all(identities.slice(i,i+2).map(analyzeOne)));
    res.json({items,meta:{engineVersion:ENGINE_VERSION,elapsedMs:Date.now()-started,mode,model:GEMINI_MODEL,compModel:COMP_MODEL,provider:'Trawl sold + SerpApi active + photo-to-photo comp verification',soldProviderDegraded:Date.now()<soldProviderDegradedUntil}});
  } catch(err) {
    console.error(err); res.status(500).json({error:err.message||'Analysis failed'});
  }
});

app.use((err,_req,res,_next)=>{
  console.error(err);
  if (err?.code==='LIMIT_FILE_SIZE') return res.status(413).json({error:'Image is too large (14 MB max)'});
  res.status(500).json({error:err.message||'Server error'});
});

if (require.main === module) {
  app.listen(PORT,HOST,()=>{
    console.log(`\nProfitQueue AI ${ENGINE_VERSION} listening on ${HOST}:${PORT}`);
    console.log(`Vision model: ${GEMINI_MODEL}`);
    console.log(`Comp classifier: ${COMP_MODEL}`);
    console.log(`Vision fallbacks: ${VISION_FALLBACK_MODELS.join(', ')}`);
    console.log(`Comp fallbacks: ${COMP_FALLBACK_MODELS.join(', ')}`);
    console.log(`Market sampling: up to ${MARKET_SAMPLE_PAGES} page(s) x ${MARKET_QUERY_ATTEMPTS} query formulation(s)`);
    console.log(`Visual comp verification: up to ${VISUAL_COMP_MAX_SOLD} sold + ${VISUAL_COMP_MAX_ACTIVE} active listing photos`);
    console.log(`Gemini configured: ${Boolean(GEMINI_API_KEY)}`);
    console.log(`SerpApi configured: ${Boolean(SERPAPI_KEY)}`);
    console.log(`Trawl configured: ${Boolean(TRAWL_API_KEY)}`);
    console.log(`Access protection: ${Boolean(APP_ACCESS_CODE)}\n`);
  });
}

module.exports={app,mean,median,trimmedMean,robustPrices,parseMoney,parseDate,daysAgo,wilson,titleMatchScore,conditionCompatible,dedupeRows,searchQuality,marketToItem,itemQueryCandidates,cleanText};
