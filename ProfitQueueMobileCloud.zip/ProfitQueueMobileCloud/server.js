'use strict';
require('dotenv').config();
const express=require('express');
const multer=require('multer');
const crypto=require('crypto');
const fs=require('fs');
const fsp=require('fs/promises');
const path=require('path');
const core=require('./core');

const VERSION='1.4.5-condition-str-fix';
const PORT=Number(process.env.PORT||10000);
const app=express();
const upload=multer({storage:multer.memoryStorage(),limits:{fileSize:10*1024*1024,files:4}});

const env=(...names)=>{for(const n of names){const v=process.env[n];if(v&&String(v).trim())return String(v).trim();}return '';};
const SERP_KEY=env('SERPAPI_API_KEY','SERP_API_KEY','SERPAPI_KEY');
const EBAY_ID=env('EBAY_CLIENT_ID','EBAY_APP_ID','EBAY_CLIENTID');
const EBAY_SECRET=env('EBAY_CLIENT_SECRET','EBAY_CERT_ID','EBAY_CLIENTSECRET');
const ACCESS_CODE=env('ORBIT_ACCESS_CODE','PROFITQUEUE_ACCESS_CODE','APP_ACCESS_CODE','ACCESS_CODE');
const TRAWL_KEY=env('TRAWL_API_KEY','TRAWL_KEY');
const TRAWL_FALLBACK=!!TRAWL_KEY; // 1.4.3 uses Trawl only for sold comps when SerpApi is unavailable/exhausted.

const counters={serp:0,ebay:0,trawl:0,trawlCredits:0,cacheHits:0,analyses:0,startedAt:new Date().toISOString()};
const cache=new Map();
function cached(key){const x=cache.get(key);if(!x)return null;if(x.exp<Date.now()){cache.delete(key);return null;}counters.cacheHits++;return x.v;}
function putCache(key,v,ttlMs){cache.set(key,{v,exp:Date.now()+ttlMs});if(cache.size>1200){const keys=[...cache.keys()].slice(0,200);keys.forEach(k=>cache.delete(k));}return v;}
const TTL={lens:7*24*3600e3,market:3*24*3600e3,sold:5*24*3600e3,emptySold:24*3600e3};
let serpDisabledUntil=0; let serpLastError=''; let trawlDisabledUntil=0; let trawlLastError='';

async function fetchJson(url,opts={},timeoutMs=5000){
  const c=new AbortController(); const t=setTimeout(()=>c.abort(),timeoutMs);
  try{
    const r=await fetch(url,{...opts,signal:c.signal});
    const txt=await r.text(); let data={};
    try{data=txt?JSON.parse(txt):{};}catch{data={raw:txt};}
    if(!r.ok){const e=new Error(data?.error?.message||data?.error||data?.message||`${r.status} ${r.statusText}`);e.status=r.status;e.body=data;throw e;}
    return data;
  } finally {clearTimeout(t);}
}
function qs(obj){const p=new URLSearchParams();for(const [k,v] of Object.entries(obj)){if(v!==undefined&&v!==null&&v!=='')p.set(k,String(v));}return p.toString();}
function hashBuffer(b){return crypto.createHash('sha256').update(b).digest('hex');}

let ebay={token:'',exp:0,ready:false,lastError:'not checked',disabledUntil:0};
async function refreshEbayToken(force=false){
  if(!EBAY_ID||!EBAY_SECRET){ebay={...ebay,ready:false,lastError:'credentials missing'};return false;}
  if(!force&&ebay.ready&&ebay.exp>Date.now()+60_000)return true;
  if(!force&&ebay.disabledUntil>Date.now())return false;
  try{
    counters.ebay++;
    const body=new URLSearchParams({grant_type:'client_credentials',scope:'https://api.ebay.com/oauth/api_scope'}).toString();
    const data=await fetchJson('https://api.ebay.com/identity/v1/oauth2/token',{method:'POST',headers:{Authorization:`Basic ${Buffer.from(`${EBAY_ID}:${EBAY_SECRET}`).toString('base64')}`,'Content-Type':'application/x-www-form-urlencoded'},body},2200);
    ebay={token:data.access_token||'',exp:Date.now()+Math.max(300,Number(data.expires_in)||7200)*1000,ready:!!data.access_token,lastError:'',disabledUntil:0};
    console.log('ORBIT eBay OAuth preflight: READY');
    return ebay.ready;
  }catch(e){
    const pause=e.status===401?30*60e3:5*60e3;
    ebay={...ebay,token:'',ready:false,lastError:`${e.status||''} ${e.message}`.trim(),disabledUntil:Date.now()+pause};
    console.log(`ORBIT eBay OAuth preflight: FAILED | ${ebay.lastError}`);
    return false;
  }
}
async function ebayHeaders(){if(!(await refreshEbayToken(false)))return null;return {'Authorization':`Bearer ${ebay.token}`,'X-EBAY-C-MARKETPLACE-ID':'EBAY_US','Content-Type':'application/json'};}
function ebayImageBase64(input){
  const buffer=Buffer.isBuffer(input)?input:input?.buffer;
  if(!Buffer.isBuffer(buffer)||!buffer.length)throw Object.assign(new Error('Uploaded image buffer is empty'),{status:400});
  return buffer.toString('base64');
}
async function ebayImageMatches(file){
  const h=await ebayHeaders(); if(!h)return [];
  try{
    counters.ebay++;
    const image=ebayImageBase64(file);
    const data=await fetchJson('https://api.ebay.com/buy/browse/v1/item_summary/search_by_image?limit=20',{method:'POST',headers:{...h,'Accept':'application/json'},body:JSON.stringify({image})},7000);
    return (data.itemSummaries||[]).slice(0,20).map(x=>({title:x.title||'',source:'eBay',link:x.itemWebUrl||'',thumbnail:x.image?.imageUrl||'',price:x.price?.value?{extracted:Number(x.price.value)}:null,condition:x.condition||''}));
  }catch(e){
    if(e.status===401){ebay.ready=false;ebay.disabledUntil=Date.now()+30*60e3;ebay.lastError='401 during image search';}
    console.log(`eBay image search unavailable: ${e.message}${e.body?` | ${JSON.stringify(e.body).slice(0,800)}`:''}`); return [];
  }
}
async function ebayActive(query,condition=''){
  const h=await ebayHeaders(); if(!h)return null;
  try{
    counters.ebay++;
    const filter=condition==='new'?'conditions:{NEW}':condition==='used'?'conditions:{USED}':'';
    const url='https://api.ebay.com/buy/browse/v1/item_summary/search?'+qs({q:query,limit:30,filter});
    const data=await fetchJson(url,{headers:{...h,'Accept':'application/json'}},5000);
    const organic=(data.itemSummaries||[]).map(x=>({title:x.title||'',link:x.itemWebUrl||'',condition:x.condition||'',price:{extracted:Number(x.price?.value)},shipping:Array.isArray(x.shippingOptions)&&x.shippingOptions[0]?.shippingCost?{extracted:Number(x.shippingOptions[0].shippingCost.value)}:'',thumbnail:x.image?.imageUrl||'',product_id:x.itemId||''}));
    return core.normalizeMarketResults({organic_results:organic,search_information:{total_results:Number(data.total)}},query,'active');
  }catch(e){
    if(e.status===401){ebay.ready=false;ebay.disabledUntil=Date.now()+30*60e3;ebay.lastError='401 during active search';}
    console.log(`eBay active search unavailable: ${e.message}${e.body?` | ${JSON.stringify(e.body).slice(0,800)}`:''}`); return null;
  }
}

async function serpSearch(params,ttlMs=TTL.market){
  if(!SERP_KEY)throw new Error('SerpApi key is not configured');
  if(serpDisabledUntil>Date.now())throw new Error(`SerpApi temporarily disabled: ${serpLastError||'quota unavailable'}`);
  const key='serp:'+JSON.stringify(params);
  const hit=cached(key); if(hit)return hit;
  counters.serp++;
  try{
    const data=await fetchJson('https://serpapi.com/search.json?'+qs({...params,api_key:SERP_KEY}),{},5000);
    if(data?.error)throw new Error(data.error);
    return putCache(key,data,ttlMs);
  }catch(e){
    const msg=String(e.message||'');
    if(/run out of searches|quota|credits|plan limit/i.test(msg)){
      serpLastError=msg; serpDisabledUntil=Date.now()+6*3600e3;
      console.log(`SerpApi quota cooldown enabled for 6h: ${msg}`);
    }
    throw e;
  }
}
async function serpUploadImage(file){
  if(!SERP_KEY)throw new Error('SerpApi key is not configured');
  const fd=new FormData();
  fd.append('api_key',SERP_KEY);
  fd.append('image',new Blob([file.buffer],{type:file.mimetype||'image/jpeg'}),file.originalname||'scan.jpg');
  counters.serp++;
  return fetchJson('https://serpapi.com/image',{method:'POST',body:fd},4500);
}
const TMP_DIR='/tmp/orbit-images';
try{fs.mkdirSync(TMP_DIR,{recursive:true});}catch{}
const tmpImages=new Map();
async function lensMatches(file,keywords='',req){
  const digest=hashBuffer(file.buffer); const ck=`lens:${digest}:${String(keywords).trim().toLowerCase()}`;
  const hit=cached(ck);if(hit)return hit;
  if(!SERP_KEY)return [];
  let params={engine:'google_lens',type:'visual_matches',hl:'en',country:'us'};
  if(keywords)params.q=keywords;
  try{
    if(file.buffer.length<=490*1024){
      const up=await serpUploadImage(file); if(up.image_id)params.image_id=up.image_id; else throw new Error(up.error||'Serp image upload failed');
    } else {
      const id=crypto.randomUUID()+'.jpg'; const p=path.join(TMP_DIR,id); await fsp.writeFile(p,file.buffer); tmpImages.set(id,Date.now()+10*60e3);
      params.url=`${req.protocol}://${req.get('host')}/tmp-images/${id}`;
    }
    const data=await serpSearch(params,TTL.lens);
    const matches=(data.visual_matches||[]).slice(0,20).map(x=>({title:x.title||'',source:x.source||'',link:x.link||'',thumbnail:x.thumbnail||x.image||'',price:x.price||null}));
    return putCache(ck,matches,TTL.lens);
  }catch(e){console.log(`SerpApi Lens unavailable: ${e.message}`);return [];}
}
async function serpMarket(query,mode){
  const params={engine:'ebay',ebay_domain:'ebay.com',_nkw:query,_ipg:100,_blrs:'spell_auto_correct'};
  if(mode==='sold')params.show_only='Sold';
  const data=await serpSearch(params,TTL.market);
  return core.normalizeMarketResults(data,query,mode);
}
async function trawlSold(query,condition=''){
  if(!TRAWL_KEY)throw new Error('Trawl key is not configured');
  if(trawlDisabledUntil>Date.now())throw new Error(`Trawl temporarily disabled: ${trawlLastError||'quota unavailable'}`);
  const dateFrom=new Date(Date.now()-90*24*3600e3).toISOString().slice(0,10);
  const ck=`trawl:sold90:${condition||'any'}:${dateFrom}:${String(query).trim().toLowerCase()}`;
  const hit=cached(ck); if(hit)return hit;
  counters.trawl++;
  try{
    const url='https://api.trawl.dev/ebay/v1/sold?'+qs({query,site:'EBAY_US',max_pages:1,date_from:dateFrom,condition:condition||undefined});
    const data=await fetchJson(url,{headers:{'x-api-key':TRAWL_KEY,'Accept':'application/json'}},5000);
    const normalized=core.normalizeTrawlSold(data,query);
    counters.trawlCredits += Number(data?.credits_charged||0);
    normalized.provider='Trawl';
    return putCache(ck,normalized,normalized.count>0?TTL.sold:TTL.emptySold);
  }catch(e){
    const msg=String(e.message||'');
    if(e.status===429 || /monthly|credits|allowance|quota|limit/i.test(msg)){
      trawlLastError=msg; trawlDisabledUntil=Date.now()+6*3600e3;
      console.log(`Trawl quota cooldown enabled for 6h: ${msg}`);
    }
    throw e;
  }
}
async function soldMarket(query,condition=''){
  // Prefer SerpApi while it is healthy. If it is exhausted/unavailable, use at most one Trawl page (<=1 credit) and cache it.
  if(SERP_KEY && serpDisabledUntil<=Date.now()){
    try{ const r=await serpMarket(query,'sold'); r.provider='SerpApi'; return r; }catch(e){ console.log(`SerpApi sold unavailable: ${e.message}`); }
  }
  if(TRAWL_FALLBACK){
    try{ return await trawlSold(query,condition); }catch(e){ console.log(`Trawl sold unavailable: ${e.message}`); }
  }
  return {query,mode:'sold',count:0,sampleCount:0,items:[],error:serpLastError||trawlLastError||'No sold-data provider available',provider:'none'};
}
async function activeMarket(query,condition=''){
  const official=await ebayActive(query,condition);
  if(official){official.provider='eBay Browse';return official;}
  if(SERP_KEY && serpDisabledUntil<=Date.now()){
    try{const r=await serpMarket(query,'active');r.provider='SerpApi';return r;}catch(e){console.log(`SerpApi active unavailable: ${e.message}`);}
  }
  return {query,mode:'active',count:0,sampleCount:0,items:[],error:'No active-data provider available',provider:'none'};
}
function activeStrength(p){
  if(!p)return -1;
  const sample=Number(p.sampleCount)||0;
  const count=Number(p.count)||0;
  return sample + (p.totalTrusted?Math.min(count,60)/6:0);
}
function choosePairedQuery(exactQuery, exactActive, familyQuery, familyActive){
  if(!familyQuery || familyQuery===exactQuery || !familyActive) return {query:exactQuery,active:exactActive,mode:'exact'};
  const exactStrong=!!exactActive && ((exactActive.totalTrusted&&exactActive.count>=3)||(exactActive.sampleCount||0)>=5);
  const famStrong=!!familyActive && ((familyActive.totalTrusted&&familyActive.count>=4)||(familyActive.sampleCount||0)>=5);
  if(!exactStrong && activeStrength(familyActive)>activeStrength(exactActive)) return {query:familyQuery,active:familyActive,mode:'family'};
  if(exactStrong && famStrong && (exactActive.sampleCount||0)<8 && activeStrength(familyActive)>=activeStrength(exactActive)*1.35) return {query:familyQuery,active:familyActive,mode:'family'};
  return {query:exactQuery,active:exactActive,mode:'exact'};
}
function slimPool(p){return {query:p.query,pool:p.pool,provider:p.provider||'',count:p.count,sampleCount:p.sampleCount,checked:p.checked,ratio:p.ratio,totalTrusted:!!p.totalTrusted,totalRaw:p.totalRaw,capped:!!p.capped,creditsCharged:Number(p.creditsCharged||0),error:p.error||'',items:(p.items||[]).slice(0,8)};}
function inferredCondition(matches=[]){
  let n=0,u=0;
  for(const m of matches.slice(0,12)){
    const c=String(m?.condition||'').toLowerCase();
    if(!c)continue;
    if(/new|unused|sealed|open box/.test(c))n++;
    else if(/used|pre.?owned|very good|good|acceptable|refurb|parts/.test(c))u++;
  }
  const total=n+u;
  if(total<2)return {value:'',confidence:'low',newVotes:n,usedVotes:u};
  if(n/total>=.6)return {value:'new',confidence:total>=5?'high':'medium',newVotes:n,usedVotes:u};
  if(u/total>=.6)return {value:'used',confidence:total>=5?'high':'medium',newVotes:n,usedVotes:u};
  return {value:'',confidence:'low',newVotes:n,usedVotes:u};
}
function marketQuery(title,keywords=''){
  const kt=core.usefulTokens(keywords);
  const tt=core.usefulTokens(title);
  const all=[]; for(const t of [...kt,...tt])if(!all.includes(t))all.push(t);
  if(!all.length)return '';
  const model=all.filter(t=>/[a-z]/i.test(t)&&/\d/.test(t));
  const hints=/^(headphones?|earbuds?|speaker|camera|lens|cartridge|valve|shoes?|sneakers?|boots?|jacket|coat|shirt|hoodie|hat|cap|figure|toy|game|console|controller|watch|bag|purse|vacuum|remote|receiver|turntable|printer|monitor|keyboard|mouse)$/i;
  const product=all.filter(t=>hints.test(t));
  const out=[];
  const add=t=>{if(t&&!out.includes(t))out.push(t)};
  kt.slice(0,2).forEach(add);
  add(tt[0]);
  model.slice(0,2).forEach(add);
  product.slice(0,2).forEach(add);
  for(const t of all){ if(out.length>= (model.length?4:5))break; add(t); }
  return out.slice(0,model.length?4:5).join(' ');
}
function broaderFamily(identity,keywords=''){
  const toks=core.usefulTokens(`${keywords} ${identity.familyQuery||identity.title}`);
  const out=[];
  const model=toks.find(t=>/[a-z]/i.test(t)&&/\d/.test(t));
  if(toks[0])out.push(toks[0]);
  if(model&&!out.includes(model))out.push(model);
  for(const t of toks){if(out.length>=3)break;if(!out.includes(t))out.push(t);}
  return out.join(' ');
}
async function analyzeOne(file,fields,req){
  const started=Date.now();
  const keywords=String(fields.keywords||'').trim().slice(0,120);
  let imageMatches=[]; let idProvider='';
  if(ebay.ready || (EBAY_ID&&EBAY_SECRET&&ebay.disabledUntil<Date.now())){
    imageMatches=await ebayImageMatches(file);
    if(imageMatches.length>=3)idProvider='eBay image';
  }
  if(imageMatches.length<3){
    const lens=await lensMatches(file,keywords,req);
    if(lens.length){imageMatches=[...imageMatches,...lens];idProvider=imageMatches.length>lens.length?'eBay image + Google Lens':'Google Lens';}
  }
  const identity=core.inferIdentity(imageMatches,keywords);
  if(!imageMatches.length&&keywords){identity.title=keywords;identity.familyQuery=keywords;identity.confidence=.58;idProvider='user keywords';}
  const condition=inferredCondition(imageMatches);
  const qExact=marketQuery(identity.title,keywords);
  if(!qExact)throw Object.assign(new Error('Could not identify the item. Add one or two identifying keywords and rescan.'),{status:422});
  // 1.4.4: choose ONE query using free/official active evidence first, then use
  // that same query for sold + active so STR never mixes exact and family pools.
  const qFamily=broaderFamily(identity,keywords);
  const exactActive=await activeMarket(qExact,condition.value);
  let familyActive=null;
  const exactThin=(exactActive.sampleCount||0)<5 || exactActive.error || !exactActive.totalTrusted;
  if(qFamily&&qFamily!==qExact&&exactThin) familyActive=await activeMarket(qFamily,condition.value);
  const selected=choosePairedQuery(qExact,exactActive,qFamily,familyActive);
  const soldPoolRaw=await soldMarket(selected.query,condition.value);
  const soldPool={...soldPoolRaw,pool:selected.mode};
  const activePool={...selected.active,pool:selected.mode};
  const str=core.computeSellThrough(soldPool,activePool);
  const pricing=core.pricingFromSold(soldPool);
  const bool=v=>/^(1|true|yes|on)$/i.test(String(v||''));
  const cost=core.acquisitionCost({manualPrice:fields.purchasePrice,visiblePrice:fields.visiblePrice,binsMode:bool(fields.binsMode),pricePerLb:fields.pricePerLb,title:identity.title});
  const decision=core.decision({title:identity.title,pricing,str,cost,minValue:Number(fields.minValue||15),minStr:Number(fields.minStr||20),minProfit:Number(fields.minProfit||10),feeRate:Number(fields.feeRate||14)/100,shipCost:Number(fields.shipCost||8),supplies:Number(fields.supplies||1)});
  const result={
    version:VERSION,title:identity.title,identityConfidence:Math.round(identity.confidence*100),identityProvider:idProvider||'unverified',identityEvidence:identity.evidence,
    query:{exact:qExact,family:qFamily&&qFamily!==qExact?qFamily:null,selected:selected.query,selectedMode:selected.mode},condition,pricing,str,cost,decision,
    market:{sold:slimPool(soldPool),active:slimPool(activePool)},
    diagnostics:{ms:Date.now()-started,serpCalls:counters.serp,ebayCalls:counters.ebay,trawlCalls:counters.trawl,trawlCredits:counters.trawlCredits,cacheHits:counters.cacheHits,trawlUsed:(soldPool.provider==='Trawl'),soldProvider:soldPool.provider||'none',activeProvider:activePool.provider||'none',pairedMarketPools:true,aiUsed:false}
  };
  console.log(`ORBIT analysis | title=${JSON.stringify(result.title)} | condition=${condition.value||'any'}(${condition.newVotes}/${condition.usedVotes}) | mode=${selected.mode} | query=${JSON.stringify(selected.query)} | sold=${soldPool.provider||'none'}:${soldPool.count||0}/${soldPool.sampleCount||0}${soldPool.capped?'+':''} | active=${activePool.provider||'none'}:${activePool.count||0}/${activePool.sampleCount||0} | ASP=${pricing.available?pricing.asp:'NA'} | STR=${str.available?str.label:'NA'} | ${Date.now()-started}ms`);
  return result;
}

app.disable('x-powered-by');
app.set('trust proxy',1);
app.use(express.json({limit:'1mb'}));
app.use(express.urlencoded({extended:true}));
app.get('/tmp-images/:id',async(req,res)=>{const exp=tmpImages.get(req.params.id);if(!exp||exp<Date.now())return res.sendStatus(404);res.set('Cache-Control','public,max-age=600');res.type('jpg').sendFile(path.join(TMP_DIR,req.params.id));});
setInterval(async()=>{for(const [id,exp] of tmpImages){if(exp<Date.now()){tmpImages.delete(id);fsp.unlink(path.join(TMP_DIR,id)).catch(()=>{});}}},5*60e3).unref();

function auth(req,res,next){if(!ACCESS_CODE)return next();const got=req.get('x-orbit-code')||req.body?.accessCode||'';if(crypto.timingSafeEqual(Buffer.from(String(got).padEnd(Math.max(String(got).length,ACCESS_CODE.length),'\0')),Buffer.from(ACCESS_CODE.padEnd(Math.max(String(got).length,ACCESS_CODE.length),'\0'))))return next();return res.status(401).json({error:'Access code required'});}
app.get('/api/status',(req,res)=>res.json({ok:true,version:VERSION,protected:!!ACCESS_CODE,providers:{serpApi:!!SERP_KEY,serpCoolingDown:serpDisabledUntil>Date.now(),serpError:serpLastError,ebayConfigured:!!(EBAY_ID&&EBAY_SECRET),ebayReady:ebay.ready,ebayError:ebay.lastError,trawlConfigured:!!TRAWL_KEY,trawlAutomaticFallback:TRAWL_FALLBACK,trawlCoolingDown:trawlDisabledUntil>Date.now(),trawlError:trawlLastError,generativeAiCriticalPath:false},usage:counters,cacheEntries:cache.size}));
app.post('/api/analyze',auth,upload.array('images',4),async(req,res)=>{
  try{
    counters.analyses++;
    const files=req.files||[];if(!files.length)return res.status(400).json({error:'Add at least one photo.'});
    // Multiple photos are treated as views of the same item; use the first for visual search to conserve quota.
    const result=await analyzeOne(files[0],req.body||{},req);
    result.photoCount=files.length;
    res.json(result);
  }catch(e){console.error('Analyze error:',e);res.status(e.status||503).json({error:e.message||'Analysis failed',version:VERSION});}
});

app.use(express.static(path.join(__dirname,'public'),{maxAge:'10m',etag:true}));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.use((err,req,res,next)=>{if(err?.code==='LIMIT_FILE_SIZE')return res.status(413).json({error:'Photo is too large. Use a photo under 10 MB.'});console.error(err);res.status(500).json({error:'Unexpected server error'});});

app.listen(PORT,'0.0.0.0',()=>{
  console.log(`ORBIT ${VERSION} listening on 0.0.0.0:${PORT}`);
  console.log(`Critical path: uploaded image bytes -> Base64 -> eBay image -> deterministic identity -> SerpApi sold when healthy -> Trawl 90-day sold fallback (1 page max) -> eBay active`);
  console.log(`Generative AI critical path: OFF`);
  console.log(`SerpApi configured: ${!!SERP_KEY}`);
  console.log(`eBay credentials configured: ${!!(EBAY_ID&&EBAY_SECRET)}`);
  console.log(`Trawl configured: ${!!TRAWL_KEY}; sold fallback enabled: ${TRAWL_FALLBACK}; max_pages=1; sold cache=${Math.round(TTL.sold/86400000)}d`);
  console.log(`Access protection: ${!!ACCESS_CODE}`);
  refreshEbayToken(true).catch(()=>{});
});
