'use strict';

require('dotenv').config();
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const multer = require('multer');

const app = express();
const PORT = Number(process.env.PORT || 4173);
const HOST = process.env.HOST || '0.0.0.0';
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 14 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => cb(null, /^image\//.test(file.mimetype || ''))
});

// Keep local-development file:// access working; production uses same-origin HTTPS.
app.use((req,res,next)=>{
  const origin=String(req.headers.origin||'');
  const allowed=!origin || origin==='null' || /^https?:\/\/(?:localhost|127\.0\.0\.1)(?::\d+)?$/i.test(origin);
  if(allowed){
    res.setHeader('Access-Control-Allow-Origin',origin||'*');
    res.setHeader('Vary','Origin');
    res.setHeader('Access-Control-Allow-Methods','GET,POST,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers','Content-Type, X-ProfitQueue-Access');
  }
  if(req.method==='OPTIONS') return res.sendStatus(204);
  next();
});
app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use((req,res,next)=>{
  res.setHeader('X-Content-Type-Options','nosniff');
  res.setHeader('Referrer-Policy','same-origin');
  res.setHeader('Permissions-Policy','camera=(self)');
  if (req.path.startsWith('/api/')) res.setHeader('Cache-Control','no-store');
  next();
});
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public'), {
  maxAge: process.env.NODE_ENV==='production' ? '1h' : 0,
  setHeaders(res,file){ if(file.endsWith('index.html')||file.endsWith('sw.js')||file.endsWith('manifest.webmanifest')) res.setHeader('Cache-Control','no-cache'); }
}));

function cleanTextEnv(v='') { return String(v).trim(); }

const GEMINI_MODEL = process.env.GEMINI_VISION_MODEL || 'gemini-3.8-flash';
const COMP_MODEL = process.env.GEMINI_COMP_MODEL || 'gemini-3.8-flash';
const SERPAPI_KEY = process.env.SERPAPI_KEY || '';
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || '';
const APP_ACCESS_CODE = cleanTextEnv(process.env.APP_ACCESS_CODE || '');
// Free-mode defaults: one sold page + one active page for one search formulation.
// This is about 2 SerpApi searches/item, so the 250-search free plan goes much further.
const MARKET_SAMPLE_PAGES = Math.max(1, Math.min(3, Number(process.env.MARKET_SAMPLE_PAGES || 1)));
const MARKET_QUERY_ATTEMPTS = Math.max(1, Math.min(3, Number(process.env.MARKET_QUERY_ATTEMPTS || 1)));

const STOP = new Set('a an and the of for with without to from by on in at is are was were this that these those vintage rare new used genuine authentic original oem nice great'.split(' '));
const ACCESSORY_WORDS = new Set('case cover manual instructions box packaging charger cable cord adapter replacement part parts shell skin mount stand holder remote strap bag pouch dock cradle battery lens cap'.split(' '));
const LOT_RE = /\b(lot of|bundle of|set of \d+|\d+[- ]?(?:pc|pcs|piece|pack)|pair of|lot\b|bundle\b)/i;
const PARTS_RE = /\b(for parts|parts only|not working|broken|repair|as[- ]?is)\b/i;
const OFFER_RE = /best offer accepted|offer accepted/i;

function cleanText(v='') { return String(v).replace(/\s+/g, ' ').trim(); }
function norm(v='') { return cleanText(v).toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim(); }
function tokens(v='') { return norm(v).split(' ').filter(t => t && !STOP.has(t) && t.length > 1); }
function clamp(n, a, b) { return Math.max(a, Math.min(b, n)); }
function uniq(arr) { return [...new Set(arr.filter(Boolean).map(cleanText))]; }
function mean(arr) {
  const a = arr.filter(Number.isFinite);
  return a.length ? a.reduce((s,v)=>s+v,0)/a.length : 0;
}
function median(arr) {
  const a = arr.filter(Number.isFinite).slice().sort((x,y)=>x-y);
  if (!a.length) return 0;
  const i = Math.floor(a.length/2);
  return a.length % 2 ? a[i] : (a[i-1]+a[i])/2;
}
function percentile(arr, p) {
  const a = arr.filter(Number.isFinite).slice().sort((x,y)=>x-y);
  if (!a.length) return 0;
  const x = (a.length - 1) * p;
  const lo = Math.floor(x), hi = Math.ceil(x);
  return lo === hi ? a[lo] : a[lo] + (a[hi]-a[lo])*(x-lo);
}
function trimmedMean(arr, trim=.10) {
  const a = arr.filter(Number.isFinite).slice().sort((x,y)=>x-y);
  if (!a.length) return 0;
  if (a.length < 10) return mean(a);
  const cut = Math.floor(a.length * trim);
  return mean(a.slice(cut, a.length-cut));
}
function robustPrices(values) {
  const vals = values.filter(v => Number.isFinite(v) && v > 0);
  if (vals.length < 5) return vals;
  const med = median(vals);
  const deviations = vals.map(v=>Math.abs(v-med));
  const mad = median(deviations);
  let filtered = vals;
  if (mad > 0) {
    // 3.5 modified-z cutoff. More stable than ordinary mean/SD for collectible outliers.
    filtered = vals.filter(v => (0.6745 * Math.abs(v-med) / mad) <= 3.5);
  }
  if (filtered.length < Math.max(4, Math.floor(vals.length*.6))) {
    const q1 = percentile(vals,.25), q3 = percentile(vals,.75), iqr = Math.max(.01,q3-q1);
    filtered = vals.filter(v => v >= Math.max(0,q1-1.5*iqr) && v <= q3+1.5*iqr);
  }
  return filtered.length >= 3 ? filtered : vals;
}
function parseMoney(v) {
  if (typeof v === 'number') return Number.isFinite(v) ? v : null;
  if (v && typeof v === 'object') {
    for (const k of ['extracted','extracted_value','value','amount','price']) {
      const n = parseMoney(v[k]); if (n != null) return n;
    }
    if (v.from || v.to) {
      const lo = parseMoney(v.from), hi = parseMoney(v.to);
      if (lo != null && hi != null) return (lo+hi)/2;
      return lo ?? hi;
    }
  }
  const s = String(v ?? '');
  if (/free shipping/i.test(s)) return 0;
  const m = s.replace(/,/g,'').match(/-?\d+(?:\.\d{1,2})?/);
  return m ? Number(m[0]) : null;
}
function safeJson(text) {
  let s = String(text || '').trim();
  s = s.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
  const first = s.indexOf('{'), last = s.lastIndexOf('}');
  if (first >= 0 && last > first) s = s.slice(first, last+1);
  return JSON.parse(s);
}

function geminiResponseText(payload) {
  const parts = payload?.candidates?.[0]?.content?.parts || [];
  return parts.map(p => typeof p?.text === 'string' ? p.text : '').join('').trim();
}

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
function uniqueModels(list=[]) {
  return [...new Set(list.map(v=>String(v||'').trim()).filter(Boolean))];
}
const VISION_FALLBACK_MODELS = uniqueModels([
  ...(process.env.GEMINI_VISION_FALLBACKS || '').split(','),
  'gemini-3.7-flash',
  'gemini-3.5-flash',
  'gemini-3.1-flash-lite',
  'gemini-3-flash-preview'
]);
const COMP_FALLBACK_MODELS = uniqueModels([
  ...(process.env.GEMINI_COMP_FALLBACKS || '').split(','),
  'gemini-3.1-flash-lite',
  'gemini-3.5-flash-lite',
  'gemini-3.5-flash',
  'gemini-3.7-flash'
]);

async function geminiGenerate({ model=GEMINI_MODEL, fallbackModels=[], prompt='', imageBuffer=null, imageMime='image/jpeg', jsonMode=true }={}) {
  if (!GEMINI_API_KEY) throw new Error('GEMINI_API_KEY is not configured');
  const parts = [{ text: String(prompt || '') }];
  if (imageBuffer) {
    parts.push({
      inline_data: {
        mime_type: imageMime || 'image/jpeg',
        data: imageBuffer.toString('base64')
      }
    });
  }
  const body = {
    contents: [{ role: 'user', parts }],
    generationConfig: jsonMode ? { response_mime_type: 'application/json' } : {}
  };
  const models = uniqueModels([model, ...fallbackModels]);
  let lastErr = null;

  for (let modelIndex=0; modelIndex<models.length; modelIndex++) {
    const candidateModel = models[modelIndex];
    for (let attempt=1; attempt<=2; attempt++) {
      try {
        const response = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(candidateModel)}:generateContent`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'x-goog-api-key': GEMINI_API_KEY },
            body: JSON.stringify(body)
          }
        );
        const payload = await response.json().catch(() => ({}));
        if (!response.ok) {
          const msg = payload?.error?.message || `Gemini API HTTP ${response.status}`;
          const err = new Error(msg);
          err.status = response.status;
          err.code = payload?.error?.status || 'GEMINI_API_ERROR';
          throw err;
        }
        const text = geminiResponseText(payload);
        if (!text) {
          const reason = payload?.promptFeedback?.blockReason || payload?.candidates?.[0]?.finishReason || 'empty response';
          const err = new Error(`Gemini returned no text (${reason})`);
          err.status = 502;
          err.code = 'EMPTY_RESPONSE';
          throw err;
        }
        if (candidateModel !== model) console.warn(`Gemini fallback succeeded: ${model} -> ${candidateModel}`);
        return text;
      } catch (err) {
        lastErr = err;
        const status = Number(err?.status || 0);
        const transient = status === 408 || status === 429 || status >= 500;
        const unavailableModel = status === 404 || /no longer available|not found|unsupported model/i.test(String(err?.message||''));
        console.warn(`Gemini ${candidateModel} attempt ${attempt} failed: ${err.message}`);
        if (transient && attempt < 2) {
          const base = 700 * (2 ** (attempt - 1));
          const jitter = Math.floor(Math.random() * 350);
          await sleep(base + jitter);
          continue;
        }
        if (unavailableModel || transient) break; // move to the next model
        throw err; // auth/bad request errors should not be hidden by fallback
      }
    }
  }
  const err = new Error(`Gemini capacity unavailable across ${models.length} supported model${models.length===1?'':'s'}: ${lastErr?.message || 'unknown error'}`);
  err.status = lastErr?.status || 503;
  err.code = lastErr?.code || 'GEMINI_FALLBACK_EXHAUSTED';
  throw err;
}
function parseDate(v) {
  if (!v) return null;
  const cleaned=cleanText(v).replace(/^(sold|ended|completed)\s*(on)?\s*/i,'');
  const d = new Date(cleaned);
  return Number.isFinite(d.getTime()) ? d : null;
}
function daysAgo(date, now=new Date()) {
  if (!(date instanceof Date) || !Number.isFinite(date.getTime())) return null;
  return Math.floor((now.getTime()-date.getTime()) / 86400000);
}
function itemIdFromResult(r) {
  if (r.product_id) return String(r.product_id);
  const link = String(r.link || '');
  const m = link.match(/\/itm\/(?:[^/]+\/)?(\d{9,15})/i);
  return m ? m[1] : null;
}
function dedupeRows(rows) {
  const seen = new Set();
  return rows.filter(r=>{
    const key = r.itemId || `${norm(r.title)}|${r.price}|${r.sold_date||''}`;
    if (seen.has(key)) return false;
    seen.add(key); return true;
  });
}
function wilson(successes, n, z=1.96) {
  if (!n) return {p:0,low:0,high:1};
  const p = clamp(successes/n,0,1), z2=z*z, den=1+z2/n;
  const center=(p+z2/(2*n))/den;
  const spread=(z*Math.sqrt((p*(1-p)+z2/(4*n))/n))/den;
  return {p,low:clamp(center-spread,0,1),high:clamp(center+spread,0,1)};
}

function conditionCompatible(target, text='') {
  const t=norm(text);
  if (!target || target==='unknown' || !t) return true;
  if (target==='for_parts') return PARTS_RE.test(t);
  if (PARTS_RE.test(t)) return false;
  if (target==='new') return /\bnew\b|sealed|new with tags|new in box/.test(t) && !/open box/.test(t);
  if (target==='open_box') return /open box|new other|unused/.test(t) || /\bnew\b/.test(t);
  if (target==='used') return !/brand new|new with|new in|sealed/.test(t);
  return true;
}

function itemQueryCandidates(item) {
  const brand = cleanText(item.brand), model = cleanText(item.model), mpn = cleanText(item.mpn), type = cleanText(item.item_type || item.title);
  const barcode = cleanText(item.barcode || '');
  const supplied = Array.isArray(item.query_candidates) ? item.query_candidates : [];
  const identityTerms = Array.isArray(item.identity_terms) ? item.identity_terms : [];
  const modelQuoted = model ? `"${model}"` : '';
  const mpnQuoted = mpn ? `"${mpn}"` : '';
  return uniq([
    barcode,
    [brand, mpnQuoted, modelQuoted, type].filter(Boolean).join(' '),
    [brand, modelQuoted, type].filter(Boolean).join(' '),
    [brand, model, ...identityTerms.slice(0,2)].filter(Boolean).join(' '),
    [brand, model].filter(Boolean).join(' '),
    ...supplied
  ]).filter(q => q.length >= 3).slice(0, 6);
}

async function identifyImage(buffer, mime, mode='single') {
  if (!GEMINI_API_KEY) throw new Error('GEMINI_API_KEY is not configured');
  const group = mode === 'group';
  const prompt = `You are the visual identification engine for ProfitQueue, a professional reseller sourcing tool.
Analyze this photo and identify ${group ? 'each distinct sellable item visible (maximum 12)' : 'the single primary sellable item'}.

Critical rules:
- Never invent a brand, model, maker, edition, material, size, UPC, MPN, or price tag. Use null when not supported by visible evidence.
- Read all visible labels, model numbers, signatures, stamps, logos, tags and price stickers carefully.
- Exact model/part/edition matters more than generic object class.
- identity_terms are the minimum words/numbers a true comp should normally contain. Put model numbers, capacities, edition names, sizes, product lines, and distinctive identifiers here.
- exclude_terms are words that usually indicate the wrong product for this exact item (accessories, neighboring model numbers, incompatible sizes, etc.).
- Distinguish the main product from accessories, packaging, manuals and unrelated background objects.
- If identity is uncertain, give the strongest candidate but lower identity_confidence and list alternatives.
- price_tag is the acquisition/store price visibly attached to the item, never an estimated resale value.
- query_candidates must be concise eBay searches, most specific first, no hype words.
- Estimate listing labor and packing supplies conservatively. shipping_estimate is likely outbound postage if the seller offers free shipping.

Return ONLY valid JSON:
{
  "items": [{
    "title": "specific factual identity",
    "item_type": "object type",
    "category": "resale category",
    "brand": null,
    "model": null,
    "mpn": null,
    "barcode": null,
    "visible_text": ["..."],
    "identity_terms": ["must-match identifier"],
    "exclude_terms": ["wrong-model/accessory clue"],
    "condition": "new|open_box|used|for_parts|unknown",
    "price_tag": null,
    "identity_confidence": 0.0,
    "alternative_identities": ["..."],
    "query_candidates": ["..."],
    "is_bundle": false,
    "bulky": false,
    "fragile": false,
    "labor_min": 12,
    "supplies_estimate": 1.0,
    "shipping_estimate": 6.0,
    "bbox": {"x":0,"y":0,"w":1000,"h":1000}
  }]
}`;

  const outputText = await geminiGenerate({
    model: GEMINI_MODEL,
    fallbackModels: VISION_FALLBACK_MODELS,
    prompt,
    imageBuffer: buffer,
    imageMime: mime || 'image/jpeg',
    jsonMode: true
  });
  const parsed = safeJson(outputText);
  if (!Array.isArray(parsed.items) || !parsed.items.length) throw new Error('Vision model returned no identifiable items');
  return parsed.items.slice(0, group ? 12 : 1).map(x => ({
    ...x,
    title: cleanText(x.title || x.item_type || 'Unidentified item'),
    identity_confidence: clamp(Number(x.identity_confidence) || 0, 0, 1),
    price_tag: Number.isFinite(Number(x.price_tag)) ? Number(x.price_tag) : null,
    labor_min: clamp(Number(x.labor_min) || 12, 3, 120),
    supplies_estimate: clamp(Number(x.supplies_estimate) || 1, 0, 30),
    shipping_estimate: clamp(Number(x.shipping_estimate) || 0, 0, 150),
    identity_terms: uniq(Array.isArray(x.identity_terms) ? x.identity_terms : []),
    exclude_terms: uniq(Array.isArray(x.exclude_terms) ? x.exclude_terms : []),
    is_bundle: !!x.is_bundle
  }));
}

function conditionParam(condition) {
  if (condition === 'new') return '1000';
  if (condition === 'open_box') return '1500';
  if (condition === 'used') return '3000';
  if (condition === 'for_parts') return '7000';
  return null;
}

async function serpEbaySearch(query, {sold=false,page=1,condition='unknown'}={}) {
  if (!SERPAPI_KEY) throw new Error('SERPAPI_KEY is not configured');

  // Keep the provider request intentionally minimal. eBay/SerpApi has changed how some
  // optional filters are accepted over time; exactness + condition checks are already
  // performed later inside ProfitQueue, so optional provider-side filters are not required.
  const u = new URL('https://serpapi.com/search');
  u.searchParams.set('engine', 'ebay');
  u.searchParams.set('_nkw', query.slice(0,120));
  u.searchParams.set('_ipg', '100');
  u.searchParams.set('_pgn', String(page));
  if (sold) u.searchParams.set('show_only', 'Sold');
  u.searchParams.set('api_key', SERPAPI_KEY);

  let lastErr=null;
  const maxAttempts = sold ? 1 : 2;
  const timeoutMs = sold ? 18000 : 22000;
  for (let attempt=1;attempt<=maxAttempts;attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const r = await fetch(u, { signal: controller.signal, headers: { 'User-Agent': 'ProfitQueue/0.4' }});
      const bodyText = await r.text();
      let data = {};
      try { data = bodyText ? JSON.parse(bodyText) : {}; } catch {}
      if (!r.ok) {
        const providerMessage = cleanText(data?.error || bodyText || '').slice(0,280);
        throw new Error(`SerpApi eBay ${r.status}${providerMessage ? `: ${providerMessage}` : ''}`);
      }
      if (data.error) throw new Error(`SerpApi eBay: ${cleanText(data.error).slice(0,280)}`);
      if (Number(data.search_information?.total_results)>0 && !(data.organic_results||[]).length) throw new Error('eBay result page returned no parseable listings');
      return data;
    } catch(err) {
      lastErr=err;
      if (attempt<maxAttempts) await new Promise(r=>setTimeout(r,450));
    } finally { clearTimeout(timer); }
  }
  throw lastErr||new Error('eBay search failed');
}

function accessoryPenalty(title, identity) {
  const tt = new Set(tokens(title));
  const it = new Set(tokens(`${identity.title} ${identity.item_type || ''}`));
  let p = 0;
  for (const w of ACCESSORY_WORDS) if (tt.has(w) && !it.has(w)) p += .09;
  return Math.min(.45, p);
}
function titleMatchScore(title, item) {
  const titleN = norm(title), titleSet = new Set(tokens(title));
  const baseTokens = tokens(`${item.brand || ''} ${item.model || ''} ${item.mpn || ''} ${item.item_type || ''}`);
  const querySet = new Set(baseTokens);
  let inter = 0; for (const t of querySet) if (titleSet.has(t)) inter++;
  const union = new Set([...querySet, ...titleSet]).size || 1;
  let score = (inter / Math.max(1, querySet.size)) * .45 + (inter / union) * .12;
  const brand = norm(item.brand || ''), model = norm(item.model || ''), mpn = norm(item.mpn || '');
  if (brand) score += titleN.includes(brand) ? .10 : -.04;
  if (model) score += titleN.includes(model) ? .27 : -.22;
  if (mpn) score += titleN.includes(mpn) ? .25 : -.18;
  const must = (item.identity_terms || []).map(norm).filter(Boolean);
  if (must.length) {
    const hits = must.filter(t=>titleN.includes(t)).length;
    score += (hits/must.length)*.18;
    if (hits===0 && !model && !mpn) score -= .10;
  }
  const excludes=(item.exclude_terms||[]).map(norm).filter(Boolean);
  if (excludes.some(t=>titleN.includes(t))) score -= .35;
  score -= accessoryPenalty(title, item);
  if (LOT_RE.test(title) && !item.is_bundle) score -= .24;
  if (PARTS_RE.test(title) && item.condition !== 'for_parts') score -= .24;
  return clamp(score, 0, 1);
}
function normalizeResult(r, sold=false) {
  const soldDate = r.sold_date || null;
  const condition = cleanText(r.condition);
  const extensions = Array.isArray(r.extensions) ? r.extensions.join(' ') : cleanText(r.extensions || '');
  const shipping = parseMoney(r.shipping);
  return {
    itemId: itemIdFromResult(r),
    title: cleanText(r.title),
    price: parseMoney(r.price),
    shipping: shipping == null ? 0 : Math.max(0,shipping),
    condition,
    sold_date: soldDate,
    soldDateParsed: parseDate(soldDate),
    link: r.link || null,
    sponsored: !!r.sponsored,
    extensions,
    bestOfferUnknown: OFFER_RE.test(`${extensions} ${r.subtitle||''} ${r.returns||''}`),
    soldCount: Number(r.extracted_sold_count || 0) || 0,
    sourceSoldSearch: sold
  };
}
function evaluatePage(data, item, sold=false) {
  const rows = (data.organic_results || []).map(r=>normalizeResult(r,sold)).filter(r => r.title && r.price != null && r.price > 0);
  const scored = rows.map(r => ({...r, lexicalMatch: titleMatchScore(r.title, item)}));
  const totalRaw = Number(data.search_information?.total_results);
  return {
    rows: scored,
    total: Number.isFinite(totalRaw) ? totalRaw : scored.length,
    exactState: data.search_information?.organic_results_state || '',
    categories: data.categories || []
  };
}

async function sampleSearch(query, item, sold=false) {
  const run=async condition=>{
    const pages=[];
    const firstRaw=await serpEbaySearch(query,{sold,page:1,condition});
    const first=evaluatePage(firstRaw,item,sold); pages.push(first);
    const wantedPages = first.total > 200 ? MARKET_SAMPLE_PAGES : 1;
    for (let p=2;p<=wantedPages;p++) {
      const raw=await serpEbaySearch(query,{sold,page:p,condition});
      const ev=evaluatePage(raw,item,sold); pages.push(ev);
      if (!ev.rows.length) break;
    }
    return {total:first.total,exactState:first.exactState,categories:first.categories,rows:dedupeRows(pages.flatMap(p=>p.rows)),conditionApplied:condition};
  };
  let result=await run(item.condition);
  // eBay condition IDs are category-dependent. If a condition-filtered query unexpectedly returns nothing, retry unfiltered rather than reporting false scarcity.
  if (!result.rows.length && item.condition && item.condition!=='unknown') result=await run('unknown');
  return result;
}

function prefilterRows(rows,item,{sold=false}={}) {
  const now=new Date();
  return rows.filter(r=>{
    if (r.lexicalMatch < .20) return false;
    if (!conditionCompatible(item.condition,r.condition)) return false;
    if (LOT_RE.test(r.title) && !item.is_bundle) return false;
    if (PARTS_RE.test(r.title) && item.condition!=='for_parts') return false;
    if (sold) {
      // Sponsored cards can appear inside sold-result pages. A sold date is our proof that the row is an actual sold result.
      if (!r.soldDateParsed) return false;
      const age=daysAgo(r.soldDateParsed,now);
      if (age == null || age < -2 || age > 90) return false;
    }
    return true;
  }).sort((a,b)=>b.lexicalMatch-a.lexicalMatch);
}

async function classifyCompRows(item, soldRows, activeRows) {
  const sold = soldRows.slice(0,400), active=activeRows.slice(0,400);
  if (!GEMINI_API_KEY) return {sold:sold.map((r,i)=>({i,match:r.lexicalMatch>=.52?'exact':'wrong',confidence:r.lexicalMatch})),active:active.map((r,i)=>({i,match:r.lexicalMatch>=.52?'exact':'wrong',confidence:r.lexicalMatch}))};
  const identity = {
    title:item.title, brand:item.brand||null, model:item.model||null, mpn:item.mpn||null,
    item_type:item.item_type||null, condition:item.condition||'unknown',
    identity_terms:item.identity_terms||[], exclude_terms:item.exclude_terms||[], is_bundle:!!item.is_bundle
  };
  const compact = rows=>rows.map((r,i)=>({i,title:r.title,condition:r.condition,price:r.price}));
  const prompt=`You are a strict resale-comps classifier. Determine whether each eBay result is genuinely comparable to the photographed target.
Target: ${JSON.stringify(identity)}

Rules:
- exact = same product/model/edition/size/capacity/configuration, or an indistinguishable listing of the same generic/vintage object when no model exists.
- variant = same product family but a materially different size/capacity/edition/color only when that difference could affect price.
- accessory = case/manual/charger/part/replacement component instead of the target.
- lot = multiple units/bundle when target is one unit, unless target itself is a bundle.
- parts = broken/for-parts when target is not for-parts.
- wrong = different model/product or insufficient title evidence.
- Do NOT stretch matches to increase sample size. Precision matters more than recall.
Return only JSON: {"sold":[{"i":0,"match":"exact|variant|accessory|lot|parts|wrong","confidence":0.0}],"active":[...]}
Classify every provided index exactly once.
Sold rows: ${JSON.stringify(compact(sold))}
Active rows: ${JSON.stringify(compact(active))}`;
  try {
    const outputText=await geminiGenerate({model:COMP_MODEL,fallbackModels:COMP_FALLBACK_MODELS,prompt,jsonMode:true});
    const parsed=safeJson(outputText);
    return {sold:Array.isArray(parsed.sold)?parsed.sold:[],active:Array.isArray(parsed.active)?parsed.active:[]};
  } catch (err) {
    console.warn('Comp classifier fallback:',err.message);
    return {sold:sold.map((r,i)=>({i,match:r.lexicalMatch>=.52?'exact':'wrong',confidence:r.lexicalMatch})),active:active.map((r,i)=>({i,match:r.lexicalMatch>=.52?'exact':'wrong',confidence:r.lexicalMatch}))};
  }
}

function applyClassification(rows, classes) {
  const byIndex=new Map((classes||[]).map(c=>[Number(c.i),c]));
  return rows.slice(0,400).map((r,i)=>{
    const c=byIndex.get(i)||{};
    const label=String(c.match||'wrong');
    const aiConfidence=clamp(Number(c.confidence)||0,0,1);
    return {...r,compClass:label,compConfidence:aiConfidence,match:clamp(r.lexicalMatch*.35+aiConfidence*.65,0,1)};
  });
}

function searchQuality(sampleRows, matchedRows, total) {
  const n=Math.max(0,sampleRows.length), k=Math.max(0,matchedRows.length);
  const ci=wilson(k,n);
  const complete = total <= n + 2;
  const estimate = complete ? k : Math.round(total*ci.p);
  const low = complete ? k : Math.floor(total*ci.low);
  const high = complete ? k : Math.ceil(total*ci.high);
  return {sampleN:n,matchedN:k,precision:ci.p,precisionLow:ci.low,precisionHigh:ci.high,complete,estimate,low,high,total};
}

async function analyzeMarketAttempt(query,item) {
  // Keep active-market evidence even when eBay/SerpApi's Sold filter is degraded.
  const [soldResult,activeResult]=await Promise.allSettled([sampleSearch(query,item,true),sampleSearch(query,item,false)]);
  if (soldResult.status==='rejected' && activeResult.status==='rejected') {
    throw new Error(`eBay market provider failed — sold: ${soldResult.reason?.message||'unknown error'}; active: ${activeResult.reason?.message||'unknown error'}`);
  }
  const emptySearch=(error)=>({total:0,exactState:'',categories:[],rows:[],conditionApplied:'unknown',providerError:error||null});
  const soldSearch=soldResult.status==='fulfilled'?soldResult.value:emptySearch(soldResult.reason?.message||'sold search unavailable');
  const activeSearch=activeResult.status==='fulfilled'?activeResult.value:emptySearch(activeResult.reason?.message||'active search unavailable');
  const soldDataAvailable=soldResult.status==='fulfilled';
  const activeDataAvailable=activeResult.status==='fulfilled';
  const providerErrors=[];
  if (!soldDataAvailable) providerErrors.push(`sold comps unavailable: ${soldSearch.providerError}`);
  if (!activeDataAvailable) providerErrors.push(`active listings unavailable: ${activeSearch.providerError}`);
  const soldPre=prefilterRows(soldSearch.rows,item,{sold:true});
  const activePre=prefilterRows(activeSearch.rows,item,{sold:false});
  const classes=await classifyCompRows(item,soldPre,activePre);
  const soldClassified=applyClassification(soldPre,classes.sold);
  const activeClassified=applyClassification(activePre,classes.active);
  const soldExact=soldClassified.filter(r=>r.compClass==='exact' && r.compConfidence>=.55);
  const activeExact=activeClassified.filter(r=>r.compClass==='exact' && r.compConfidence>=.55);
  // Price accuracy: accepted-offer listings can hide the actual transaction price. Count them for velocity, but exclude them from price average.
  const priceRows=soldExact.filter(r=>!r.bestOfferUnknown);
  const robust=robustPrices(priceRows.map(r=>r.price));
  const soldQ=searchQuality(soldSearch.rows.slice(0,400),soldExact,soldSearch.total);
  const activeQ=searchQuality(activeSearch.rows.slice(0,400),activeExact,activeSearch.total);
  const priceMedian=median(robust), priceAverage=trimmedMean(robust,.10);
  const activePrices=robustPrices(activeExact.map(r=>r.price));
  const askingPriceMedian=median(activePrices);
  const dispersion=priceMedian>0?(percentile(robust,.75)-percentile(robust,.25))/priceMedian:1;
  let score = (soldQ.precisionLow*.34 + activeQ.precisionLow*.20 + clamp(robust.length/15,0,1)*.26 + (1-clamp(dispersion,0,1))*.12 + item.identity_confidence*.08);
  if (!soldDataAvailable) score*=.45;
  if (!activeDataAvailable) score*=.60;
  return {query,soldSearch,activeSearch,soldPre,activePre,soldExact,activeExact,priceRows,prices:robust,activePrices,askingPriceMedian,soldQ,activeQ,score,soldDataAvailable,activeDataAvailable,providerErrors};
}

async function bestMarketSearch(item) {
  const candidates=itemQueryCandidates(item);
  if (!candidates.length) throw new Error('Not enough visible identity to build a market query');
  const attempts=[];
  for (const query of candidates.slice(0,MARKET_QUERY_ATTEMPTS)) {
    try { attempts.push(await analyzeMarketAttempt(query,item)); }
    catch (err) { attempts.push({query,error:err.message,score:-1}); }
  }
  const valid=attempts.filter(a=>!a.error).sort((a,b)=>b.score-a.score);
  if (!valid.length) throw new Error(attempts[0]?.error||'No market data returned');
  const best=valid[0];
  const second=valid[1]||null;
  // Agreement between independent query formulations is an important defense against a deceptively clean wrong search.
  let agreement=1;
  if (second && best.prices.length>=3 && second.prices.length>=3) {
    const a=trimmedMean(best.prices), b=trimmedMean(second.prices);
    if (a>0&&b>0) agreement=Math.min(a,b)/Math.max(a,b);
    const s1=best.activeQ.estimate>0?best.soldQ.estimate/best.activeQ.estimate:0;
    const s2=second.activeQ.estimate>0?second.soldQ.estimate/second.activeQ.estimate:0;
    if (s1>0&&s2>0) agreement=Math.min(agreement,Math.min(s1,s2)/Math.max(s1,s2));
  }
  return {...best,agreement,attempts:attempts.map(a=>a.error?{query:a.query,error:a.error}:{query:a.query,score:a.score,soldSample:a.soldQ.sampleN,soldExact:a.soldQ.matchedN,activeSample:a.activeQ.sampleN,activeExact:a.activeQ.matchedN,soldPrecision:a.soldQ.precision,activePrecision:a.activeQ.precision})};
}

function marketToItem(identity, market, settings={}) {
  const soldPrices=market.prices;
  const soldDataAvailable=market.soldDataAvailable!==false;
  const activeDataAvailable=market.activeDataAvailable!==false;
  const saleAverage=trimmedMean(soldPrices,.10);
  const saleMedian=median(soldPrices);
  const q1=percentile(soldPrices,.25), q3=percentile(soldPrices,.75);
  const sold90=market.soldQ.estimate;
  const activeListings=market.activeQ.estimate;
  const soldLow=market.soldQ.low, soldHigh=market.soldQ.high;
  const activeLow=market.activeQ.low, activeHigh=market.activeQ.high;
  const rawStr=(soldDataAvailable&&activeDataAvailable)?(activeListings>0?sold90/activeListings:sold90>0?2:0):null;
  const strLow=(soldDataAvailable&&activeDataAvailable&&activeHigh>0)?soldLow/activeHigh*100:0;
  const strHigh=(soldDataAvailable&&activeDataAvailable)?(activeLow>0?soldHigh/activeLow*100:(soldHigh>0?200:0)):0;
  const daysToSell=rawStr>0?clamp(Math.round(90/rawStr),2,365):365;
  const dispersion=saleMedian>0?(q3-q1)/saleMedian:1;
  const priceSampleConfidence=clamp(soldPrices.length/15,0,1);
  const soldPrecisionConfidence=market.soldQ.precisionLow;
  const activePrecisionConfidence=market.activeQ.precisionLow;
  const countCertainty=clamp(1-((market.soldQ.high-market.soldQ.low)/Math.max(1,market.soldQ.estimate+market.soldQ.high)),0,1);
  let marketConfidence=clamp(
    priceSampleConfidence*.22 + soldPrecisionConfidence*.20 + activePrecisionConfidence*.16 +
    countCertainty*.12 + (1-clamp(dispersion,0,1))*.10 + market.agreement*.10 + identity.identity_confidence*.10,
    0,1
  );
  if (!soldDataAvailable) marketConfidence=Math.min(marketConfidence,.28);
  if (!activeDataAvailable) marketConfidence=Math.min(marketConfidence,.32);
  const tagCost=Number.isFinite(identity.price_tag)?identity.price_tag:null;
  const feesPct=Number(settings.defaultFeesPct??15);
  const shipping=Number(identity.shipping_estimate||0);
  const supplies=Number(identity.supplies_estimate||1);
  const targetProfit=Number(settings.minProfit??25);
  const maxBuyPrice=Math.max(0,saleAverage-saleAverage*(feesPct/100)-shipping-supplies-targetProfit);
  const reviewReasons=[];
  if (identity.identity_confidence<.62) reviewReasons.push('item identity uncertain');
  if (soldDataAvailable && soldPrices.length<4) reviewReasons.push('fewer than 4 exact-price comps');
  if (soldDataAvailable && market.soldQ.precisionLow<.35) reviewReasons.push('sold search contains many non-matches');
  if (activeDataAvailable && market.activeQ.precisionLow<.30) reviewReasons.push('active search contains many non-matches');
  if (market.agreement<.70) reviewReasons.push('independent search queries disagree');
  if (saleMedian>0 && (q3-q1)/saleMedian>.75) reviewReasons.push('sold prices are widely dispersed');
  return {
    title:identity.title,
    category:identity.category||identity.item_type||'Uncategorized',
    brand:identity.brand||null, model:identity.model||null, mpn:identity.mpn||null,
    condition:identity.condition||'unknown',
    cost:tagCost??0, costKnown:tagCost!=null, costSource:tagCost!=null?'visible price tag':'not visible',
    maxBuyPrice:Number(maxBuyPrice.toFixed(2)),
    // salePrice remains the field used by the scoring engine. It is now a robust average of verified exact sold comps.
    salePrice:Number(saleAverage.toFixed(2)),
    averageSalePrice:Number(saleAverage.toFixed(2)),
    medianSalePrice:Number(saleMedian.toFixed(2)),
    salePriceLow:Number(q1.toFixed(2)), salePriceHigh:Number(q3.toFixed(2)),
    feesPct, shipping, supplies, laborMin:Number(identity.labor_min||12),
    sold90, activeListings,
    sellThrough90:rawStr==null?null:Number((rawStr*100).toFixed(1)),
    sellThroughLow:Number(strLow.toFixed(1)), sellThroughHigh:Number(Math.min(strHigh,999).toFixed(1)),
    soldCountLow:soldLow, soldCountHigh:soldHigh, activeCountLow:activeLow, activeCountHigh:activeHigh,
    soldSample:soldPrices.length,
    soldSearchSample:market.soldQ.sampleN,
    activeSearchSample:market.activeQ.sampleN,
    soldMatchPrecision:Number(market.soldQ.precision.toFixed(3)),
    activeMatchPrecision:Number(market.activeQ.precision.toFixed(3)),
    queryAgreement:Number(market.agreement.toFixed(3)),
    daysToSell, quantity:1, bulky:!!identity.bulky, fragile:!!identity.fragile,
    confidence:marketConfidence, identityConfidence:identity.identity_confidence, marketConfidence,
    marketQuery:market.query,
    soldDataAvailable,activeDataAvailable,askingPriceMedian:Number((market.askingPriceMedian||0).toFixed(2)),providerErrors:market.providerErrors||[],
    marketSource:soldDataAvailable?'eBay sold + active via SerpApi; AI exact-comp verification':'eBay active via SerpApi; sold-data provider unavailable',
    visibleText:identity.visible_text||[], alternativeIdentities:identity.alternative_identities||[],
    compExamples:market.soldExact.slice(0,8).map(x=>({title:x.title,price:x.price,shipping:x.shipping,soldDate:x.sold_date,match:Number(x.match.toFixed(2)),link:x.link})),
    reviewRequired:reviewReasons.length>0 || marketConfidence<.64,
    reviewReasons,
    bbox:identity.bbox||null
  };
}

const AUTH_FAILURES=new Map();
function accessMatches(candidate='') {
  if (!APP_ACCESS_CODE) return true;
  const a=Buffer.from(String(candidate));
  const b=Buffer.from(APP_ACCESS_CODE);
  return a.length===b.length && crypto.timingSafeEqual(a,b);
}
function requireAccess(req,res,next) {
  if (!APP_ACCESS_CODE) return next();
  const key=String(req.ip||req.socket?.remoteAddress||'unknown');
  const now=Date.now();
  const state=AUTH_FAILURES.get(key)||{count:0,since:now};
  if(now-state.since>10*60*1000){state.count=0;state.since=now;}
  if(state.count>=10)return res.status(429).json({error:'Too many access-code attempts. Try again later.',code:'ACCESS_RATE_LIMIT'});
  const candidate=req.get('X-ProfitQueue-Access') || '';
  if (!accessMatches(candidate)) { state.count++;AUTH_FAILURES.set(key,state);return res.status(401).json({error:'ProfitQueue access code required',code:'ACCESS_REQUIRED'}); }
  AUTH_FAILURES.delete(key);next();
}

app.post('/api/access/check', requireAccess, (_req,res)=>res.json({ok:true}));

app.get('/api/health', (_req,res) => {
  res.json({
    ok:true, configured:Boolean(GEMINI_API_KEY&&SERPAPI_KEY), openai:Boolean(GEMINI_API_KEY), soldMarketData:Boolean(SERPAPI_KEY),
    model:GEMINI_MODEL, compModel:COMP_MODEL, visionFallbacks:VISION_FALLBACK_MODELS, compFallbacks:COMP_FALLBACK_MODELS, marketProvider:'SerpApi eBay + AI comp verification',
    samplePages:MARKET_SAMPLE_PAGES, queryAttempts:MARKET_QUERY_ATTEMPTS, accessProtected:Boolean(APP_ACCESS_CODE), deployment:process.env.RENDER?'render':'node', port:PORT
  });
});

app.post('/api/analyze', requireAccess, upload.single('image'), async (req,res) => {
  const started=Date.now();
  try {
    if (!req.file) return res.status(400).json({error:'No image uploaded'});
    if (!GEMINI_API_KEY||!SERPAPI_KEY) return res.status(503).json({error:'Backend needs GEMINI_API_KEY and SERPAPI_KEY in .env',code:'NOT_CONFIGURED'});
    let settings={}; try{settings=req.body.settings?JSON.parse(req.body.settings):{};}catch{}
    const mode=req.body.mode==='group'?'group':'single';
    const barcode=cleanText(req.body.barcode||'');
    const identities=await identifyImage(req.file.buffer,req.file.mimetype,mode);
    if (barcode&&identities[0]) {
      identities[0].barcode=barcode;
      identities[0].query_candidates=uniq([barcode,...(identities[0].query_candidates||[])]);
      identities[0].visible_text=uniq([...(identities[0].visible_text||[]),`Barcode ${barcode}`]);
      identities[0].identity_confidence=Math.max(.90,identities[0].identity_confidence||0);
    }
    const analyzeOne=async identity=>{
      try { return marketToItem(identity,await bestMarketSearch(identity),settings); }
      catch(err) {
        console.warn(`Market verification failed for ${identity.title}: ${err.message}`);
        return {
          title:identity.title,category:identity.category||identity.item_type||'Uncategorized',cost:identity.price_tag??0,costKnown:identity.price_tag!=null,
          salePrice:0,averageSalePrice:0,medianSalePrice:0,feesPct:Number(settings.defaultFeesPct??15),shipping:Number(identity.shipping_estimate||0),
          supplies:Number(identity.supplies_estimate||1),laborMin:Number(identity.labor_min||12),sold90:0,activeListings:0,sellThrough90:0,
          daysToSell:365,quantity:1,bulky:!!identity.bulky,fragile:!!identity.fragile,confidence:identity.identity_confidence*.25,
          identityConfidence:identity.identity_confidence,marketConfidence:0,reviewRequired:true,reviewReasons:[`market verification failed: ${err.message}`],analysisError:err.message,
          marketSource:'No verified comps',visibleText:identity.visible_text||[],alternativeIdentities:identity.alternative_identities||[],bbox:identity.bbox||null
        };
      }
    };
    const items=[];
    // Limit external search concurrency so rapid/group scanning does not create noisy provider failures.
    for (let i=0;i<identities.length;i+=2) items.push(...await Promise.all(identities.slice(i,i+2).map(analyzeOne)));
    res.json({items,meta:{elapsedMs:Date.now()-started,mode,model:GEMINI_MODEL,compModel:COMP_MODEL,provider:'SerpApi eBay + AI comp verification'}});
  } catch(err) {
    console.error(err); res.status(500).json({error:err.message||'Analysis failed'});
  }
});

app.use((err,_req,res,_next)=>{
  console.error(err);
  if (err?.code==='LIMIT_FILE_SIZE') return res.status(413).json({error:'Image is too large (14 MB max)'});
  res.status(500).json({error:err.message||'Server error'});
});

if (require.main === module) {
  app.listen(PORT,HOST,()=>{
    console.log(`\nProfitQueue AI listening on ${HOST}:${PORT}`);
    console.log(`Vision model: ${GEMINI_MODEL}`);
    console.log(`Comp classifier: ${COMP_MODEL}`);
    console.log(`Vision fallbacks: ${VISION_FALLBACK_MODELS.join(', ')}`);
    console.log(`Comp fallbacks: ${COMP_FALLBACK_MODELS.join(', ')}`);
    console.log(`Market sampling: up to ${MARKET_SAMPLE_PAGES} page(s) x ${MARKET_QUERY_ATTEMPTS} query formulation(s)`);
    console.log(`Gemini configured: ${Boolean(GEMINI_API_KEY)}`);
    console.log(`SerpApi configured: ${Boolean(SERPAPI_KEY)}`);
    console.log(`Access protection: ${Boolean(APP_ACCESS_CODE)}\n`);
  });
}

module.exports={app,mean,median,trimmedMean,robustPrices,parseMoney,parseDate,daysAgo,wilson,titleMatchScore,conditionCompatible,dedupeRows,searchQuality,marketToItem};
