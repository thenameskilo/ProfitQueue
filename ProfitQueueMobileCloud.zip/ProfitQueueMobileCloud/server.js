'use strict';
require('dotenv').config();
const express=require('express');
const multer=require('multer');
const crypto=require('crypto');
const fs=require('fs');
const fsp=require('fs/promises');
const path=require('path');
const core=require('./core');

const VERSION='1.7.0-marketplace-title-distillation';
const PORT=Number(process.env.PORT||10000);
const app=express();
const upload=multer({storage:multer.memoryStorage(),limits:{fileSize:10*1024*1024,files:4}});

const env=(...names)=>{for(const n of names){const v=process.env[n];if(v&&String(v).trim())return String(v).trim();}return '';};
const SERP_KEY=env('SERPAPI_API_KEY','SERP_API_KEY','SERPAPI_KEY');
const EBAY_ID=env('EBAY_CLIENT_ID','EBAY_APP_ID','EBAY_CLIENTID');
const EBAY_SECRET=env('EBAY_CLIENT_SECRET','EBAY_CERT_ID','EBAY_CLIENTSECRET');
const ACCESS_CODE=env('ORBIT_ACCESS_CODE','PROFITQUEUE_ACCESS_CODE','APP_ACCESS_CODE','ACCESS_CODE');
const TRAWL_KEY=env('TRAWL_API_KEY','TRAWL_KEY');
const TRAWL_FALLBACK=!!TRAWL_KEY; // 1.4.3 uses Trawl only for sold comps when SerpApi is unavailable/exhausted.

const counters={serp:0,ebay:0,trawl:0,trawlCredits:0,cacheHits:0,paidSoldCalls:0,paidSoldBudgetBlocks:0,analyses:0,startedAt:new Date().toISOString()};
const cache=new Map();
function cached(key){const x=cache.get(key);if(!x)return null;if(x.exp<Date.now()){cache.delete(key);return null;}counters.cacheHits++;return x.v;}
function putCache(key,v,ttlMs){cache.set(key,{v,exp:Date.now()+ttlMs});if(cache.size>1200){const keys=[...cache.keys()].slice(0,200);keys.forEach(k=>cache.delete(k));}return v;}
const TTL={lens:7*24*3600e3,market:3*24*3600e3,sold:5*24*3600e3,emptySold:24*3600e3};
let serpDisabledUntil=0; let serpLastError=''; let trawlDisabledUntil=0; let trawlLastError='';

async function fetchJson(url,opts={},timeoutMs=5000){
  const c=new AbortController(); const t=setTimeout(()=>c.abort(),timeoutMs);
  try{
    const r=await fetch(url,{...opts,signal:c.signal});
    const txt=await r.text(); let data={};
    try{data=txt?JSON.parse(txt):{};}catch{data={raw:txt};}
    if(!r.ok){const e=new Error(data?.error?.message||data?.error||data?.message||`${r.status} ${r.statusText}`);e.status=r.status;e.body=data;throw e;}
    return data;
  } finally {clearTimeout(t);}
}
function qs(obj){const p=new URLSearchParams();for(const [k,v] of Object.entries(obj)){if(v!==undefined&&v!==null&&v!=='')p.set(k,String(v));}return p.toString();}
function hashBuffer(b){return crypto.createHash('sha256').update(b).digest('hex');}
function canonicalQueryKey(query=''){
  // Trawl/eBay keyword order is not semantically meaningful for our searches.
  // Canonicalizing lets rescans/title variants reuse the same sold response instead of spending another credit.
  return [...new Set(core.queryTokens(String(query).toLowerCase()))].sort().join(' ');
}

let ebay={token:'',exp:0,ready:false,lastError:'not checked',disabledUntil:0};
async function refreshEbayToken(force=false){
  if(!EBAY_ID||!EBAY_SECRET){ebay={...ebay,ready:false,lastError:'credentials missing'};return false;}
  if(!force&&ebay.ready&&ebay.exp>Date.now()+60_000)return true;
  if(!force&&ebay.disabledUntil>Date.now())return false;
  try{
    counters.ebay++;
    const body=new URLSearchParams({grant_type:'client_credentials',scope:'https://api.ebay.com/oauth/api_scope'}).toString();
    const data=await fetchJson('https://api.ebay.com/identity/v1/oauth2/token',{method:'POST',headers:{Authorization:`Basic ${Buffer.from(`${EBAY_ID}:${EBAY_SECRET}`).toString('base64')}`,'Content-Type':'application/x-www-form-urlencoded'},body},2200);
    ebay={token:data.access_token||'',exp:Date.now()+Math.max(300,Number(data.expires_in)||7200)*1000,ready:!!data.access_token,lastError:'',disabledUntil:0};
    console.log('ORBIT eBay OAuth preflight: READY');
    return ebay.ready;
  }catch(e){
    const pause=e.status===401?30*60e3:5*60e3;
    ebay={...ebay,token:'',ready:false,lastError:`${e.status||''} ${e.message}`.trim(),disabledUntil:Date.now()+pause};
    console.log(`ORBIT eBay OAuth preflight: FAILED | ${ebay.lastError}`);
    return false;
  }
}
async function ebayHeaders(){if(!(await refreshEbayToken(false)))return null;return {'Authorization':`Bearer ${ebay.token}`,'X-EBAY-C-MARKETPLACE-ID':'EBAY_US','Content-Type':'application/json'};}
function ebayImageBase64(input){
  const buffer=Buffer.isBuffer(input)?input:input?.buffer;
  if(!Buffer.isBuffer(buffer)||!buffer.length)throw Object.assign(new Error('Uploaded image buffer is empty'),{status:400});
  return buffer.toString('base64');
}
async function ebayImageMatches(file){
  const h=await ebayHeaders(); if(!h)return [];
  try{
    counters.ebay++;
    const image=ebayImageBase64(file);
    const data=await fetchJson('https://api.ebay.com/buy/browse/v1/item_summary/search_by_image?limit=20',{method:'POST',headers:{...h,'Accept':'application/json'},body:JSON.stringify({image})},7000);
    return (data.itemSummaries||[]).slice(0,20).map(x=>({title:x.title||'',source:'eBay',link:x.itemWebUrl||'',thumbnail:x.image?.imageUrl||'',price:x.price?.value?{extracted:Number(x.price.value)}:null,condition:x.condition||''}));
  }catch(e){
    if(e.status===401){ebay.ready=false;ebay.disabledUntil=Date.now()+30*60e3;ebay.lastError='401 during image search';}
    console.log(`eBay image search unavailable: ${e.message}${e.body?` | ${JSON.stringify(e.body).slice(0,800)}`:''}`); return [];
  }
}
async function ebayActive(query,condition=''){
  const h=await ebayHeaders(); if(!h)return null;
  try{
    counters.ebay++;
    const filter=condition==='new'?'conditions:{NEW}':condition==='used'?'conditions:{USED}':'';
    const url='https://api.ebay.com/buy/browse/v1/item_summary/search?'+qs({q:query,limit:30,filter});
    const data=await fetchJson(url,{headers:{...h,'Accept':'application/json'}},5000);
    const organic=(data.itemSummaries||[]).map(x=>({title:x.title||'',link:x.itemWebUrl||'',condition:x.condition||'',price:{extracted:Number(x.price?.value)},shipping:Array.isArray(x.shippingOptions)&&x.shippingOptions[0]?.shippingCost?{extracted:Number(x.shippingOptions[0].shippingCost.value)}:'',thumbnail:x.image?.imageUrl||'',product_id:x.itemId||''}));
    return core.normalizeMarketResults({organic_results:organic,search_information:{total_results:Number(data.total)}},query,'active');
  }catch(e){
    if(e.status===401){ebay.ready=false;ebay.disabledUntil=Date.now()+30*60e3;ebay.lastError='401 during active search';}
    console.log(`eBay active search unavailable: ${e.message}${e.body?` | ${JSON.stringify(e.body).slice(0,800)}`:''}`); return null;
  }
}

async function serpSearch(params,ttlMs=TTL.market){
  if(!SERP_KEY)throw new Error('SerpApi key is not configured');
  if(serpDisabledUntil>Date.now())throw new Error(`SerpApi temporarily disabled: ${serpLastError||'quota unavailable'}`);
  const key='serp:'+JSON.stringify(params);
  const hit=cached(key); if(hit)return hit;
  counters.serp++;
  try{
    const data=await fetchJson('https://serpapi.com/search.json?'+qs({...params,api_key:SERP_KEY}),{},5000);
    if(data?.error)throw new Error(data.error);
    return putCache(key,data,ttlMs);
  }catch(e){
    const msg=String(e.message||'');
    if(/run out of searches|quota|credits|plan limit/i.test(msg)){
      serpLastError=msg; serpDisabledUntil=Date.now()+6*3600e3;
      console.log(`SerpApi quota cooldown enabled for 6h: ${msg}`);
    }
    throw e;
  }
}
async function serpUploadImage(file){
  if(!SERP_KEY)throw new Error('SerpApi key is not configured');
  const fd=new FormData();
  fd.append('api_key',SERP_KEY);
  fd.append('image',new Blob([file.buffer],{type:file.mimetype||'image/jpeg'}),file.originalname||'scan.jpg');
  counters.serp++;
  return fetchJson('https://serpapi.com/image',{method:'POST',body:fd},4500);
}
const TMP_DIR='/tmp/orbit-images';
try{fs.mkdirSync(TMP_DIR,{recursive:true});}catch{}
const tmpImages=new Map();
async function lensMatches(file,keywords='',req){
  const digest=hashBuffer(file.buffer); const ck=`lens:${digest}:${String(keywords).trim().toLowerCase()}`;
  const hit=cached(ck);if(hit)return hit;
  if(!SERP_KEY)return [];
  let params={engine:'google_lens',type:'visual_matches',hl:'en',country:'us'};
  if(keywords)params.q=keywords;
  try{
    if(file.buffer.length<=490*1024){
      const up=await serpUploadImage(file); if(up.image_id)params.image_id=up.image_id; else throw new Error(up.error||'Serp image upload failed');
    } else {
      const id=crypto.randomUUID()+'.jpg'; const p=path.join(TMP_DIR,id); await fsp.writeFile(p,file.buffer); tmpImages.set(id,Date.now()+10*60e3);
      params.url=`${req.protocol}://${req.get('host')}/tmp-images/${id}`;
    }
    const data=await serpSearch(params,TTL.lens);
    const matches=(data.visual_matches||[]).slice(0,20).map(x=>({title:x.title||'',source:x.source||'',link:x.link||'',thumbnail:x.thumbnail||x.image||'',price:x.price||null}));
    return putCache(ck,matches,TTL.lens);
  }catch(e){console.log(`SerpApi Lens unavailable: ${e.message}`);return [];}
}
async function serpMarket(query,mode){
  const params={engine:'ebay',ebay_domain:'ebay.com',_nkw:query,_ipg:100,_blrs:'spell_auto_correct'};
  if(mode==='sold')params.show_only='Sold';
  const data=await serpSearch(params,TTL.market);
  return core.normalizeMarketResults(data,query,mode);
}
async function trawlSold(query,condition='',budget=null,maxPages=2){
  if(!TRAWL_KEY)throw new Error('Trawl key is not configured');
  if(trawlDisabledUntil>Date.now())throw new Error(`Trawl temporarily disabled: ${trawlLastError||'quota unavailable'}`);
  const dateFrom=new Date(Date.now()-90*24*3600e3).toISOString().slice(0,10);
  maxPages=Math.max(1,Math.min(2,Number(maxPages)||1));
  const ck=`trawl:sold90:p${maxPages}:${condition||'any'}:${dateFrom}:${canonicalQueryKey(query)}`;
  const hit=cached(ck); if(hit)return hit;
  if(budget && budget.remaining<maxPages){counters.paidSoldBudgetBlocks++;throw new Error('Paid sold-search credit ceiling reached for this scan');}
  if(budget)budget.remaining-=maxPages; // reserve the maximum; unused page capacity is refunded below.
  counters.paidSoldCalls++;
  counters.trawl++;
  try{
    // Trawl charges only for pages actually returned. Asking for two pages still costs one credit
    // when fewer than 101 sold results exist, but avoids a second/repeated request when page 1 fills.
    const url='https://api.trawl.dev/ebay/v1/sold?'+qs({query,site:'EBAY_US',max_pages:maxPages,date_from:dateFrom,condition:condition||undefined});
    const data=await fetchJson(url,{headers:{'x-api-key':TRAWL_KEY,'Accept':'application/json'}},6500);
    const charged=Number(data?.credits_charged||0);
    if(budget)budget.remaining+=Math.max(0,maxPages-charged);
    const normalized=core.normalizeTrawlSold(data,query);
    counters.trawlCredits += charged;
    normalized.provider='Trawl';
    normalized.maxPagesRequested=maxPages;
    return putCache(ck,normalized,normalized.count>0?TTL.sold:TTL.emptySold);
  }catch(e){
    if(budget)budget.remaining+=maxPages; // failed requests are not billed by Trawl.
    const msg=String(e.message||'');
    if(e.status===429 || /monthly|credits|allowance|quota|limit/i.test(msg)){
      trawlLastError=msg; trawlDisabledUntil=Date.now()+6*3600e3;
      console.log(`Trawl quota cooldown enabled for 6h: ${msg}`);
    }
    throw e;
  }
}
async function soldMarket(query,condition='',budget=null,maxPages=1){
  // Prefer SerpApi while healthy. Trawl page depth is selected before the paid call from the user's STR threshold and active denominator.
  if(SERP_KEY && serpDisabledUntil<=Date.now()){
    try{ const r=await serpMarket(query,'sold'); r.provider='SerpApi'; return r; }catch(e){ console.log(`SerpApi sold unavailable: ${e.message}`); }
  }
  if(TRAWL_FALLBACK){
    try{ return await trawlSold(query,condition,budget,maxPages); }catch(e){ console.log(`Trawl sold unavailable: ${e.message}`); }
  }
  return {query,mode:'sold',count:0,sampleCount:0,items:[],error:serpLastError||trawlLastError||'No sold-data provider available',provider:'none'};
}
async function activeMarket(query,condition=''){
  const official=await ebayActive(query,condition);
  if(official){official.provider='eBay Browse';return official;}
  if(SERP_KEY && serpDisabledUntil<=Date.now()){
    try{const r=await serpMarket(query,'active');r.provider='SerpApi';return r;}catch(e){console.log(`SerpApi active unavailable: ${e.message}`);}
  }
  return {query,mode:'active',count:0,sampleCount:0,items:[],error:'No active-data provider available',provider:'none'};
}
function slimPool(p){return {query:p.query,pool:p.pool,provider:p.provider||'',count:p.count,sampleCount:p.sampleCount,closeSampleCount:Number(p.closeSampleCount||0),checked:p.checked,ratio:p.ratio,titlePurity:p.titlePurity,titleSimilarity:p.titleSimilarity,anchorCoverage:p.anchorCoverage,estimatedFromSample:!!p.estimatedFromSample,matchedToTitle:!!p.matchedToTitle,totalTrusted:!!p.totalTrusted,totalRaw:p.totalRaw,capped:!!p.capped,creditsCharged:Number(p.creditsCharged||0),error:p.error||'',items:(p.items||[]).slice(0,8),closeItems:(p.closeItems||[]).slice(0,5)};}
function inferredCondition(matches=[]){
  let n=0,u=0;
  for(const m of matches.slice(0,12)){
    const c=String(m?.condition||'').toLowerCase();
    if(!c)continue;
    if(/new|unused|sealed|open box/.test(c))n++;
    else if(/used|pre.?owned|very good|good|acceptable|refurb|parts/.test(c))u++;
  }
  const total=n+u;
  if(total<2)return {value:'',confidence:'low',newVotes:n,usedVotes:u};
  if(n/total>=.6)return {value:'new',confidence:total>=5?'high':'medium',newVotes:n,usedVotes:u};
  if(u/total>=.6)return {value:'used',confidence:total>=5?'high':'medium',newVotes:n,usedVotes:u};
  return {value:'',confidence:'low',newVotes:n,usedVotes:u};
}
function stripSearchNoise(text=''){
  return String(text)
    .replace(/\$\s*\d+(?:[.,]\d+)?/g,' ')
    .replace(/\b(?:msrp|retail|value|price)\s*[:$]?\s*\d+(?:[.,]\d+)?\b/ig,' ')
    .replace(/\b\d{1,3}\s*[x×]\s*\d{1,3}\b/ig,' ') // apparel/dimension pairs like 38x32
    .replace(/\b\d+(?:\.\d+)?\s*(?:inches?|inch|in|cm|mm)\b/ig,' ')
    .replace(/\b(?:size|sz|mens?|womens?|men's|women's)\s*[:#-]?\s*\d+(?:\.\d+)?\b/ig,' ')
    .replace(/\b\d{1,2}\.\d+\b/g,' ')
    .replace(/\b(?:nwt|nwot|nib|bnwt|new|used|pre[- ]?owned|sealed|open box|rare|authentic|genuine|oem|real|original|free shipping|fast shipping|choose)\b/ig,' ')
    .replace(/\s+/g,' ').trim();
}
function semanticTokens(text=''){
  const raw=core.tokenize(stripSearchNoise(text));
  const junk=new Set(`a an and are as at be by for from in is it of on or the to with without sale sold listing ebay mercari poshmark etsy amazon walmart target black white blue red green brown gray grey dark light wash stretch denim jean jeans size sz mens men womens women unisex made england casual lounge choose up wide long side snip toe`.split(/\s+/));
  return raw.filter(t=>!junk.has(t) && !/^\d{1,2}\.\d+$/.test(t));
}
function brandPrefix(tokens){
  if(tokens[0]==='dr'&&tokens[1]==='martens') return ['dr','martens'];
  if(tokens[0]==='old'&&tokens[1]==='west') return ['old','west'];
  if(tokens[0]==='hoka'&&tokens[1]==='one'&&tokens[2]==='one') return ['hoka'];
  if(tokens[0]==='levis'||tokens[0]==='levi') return ['levis'];
  return tokens[0]?[tokens[0]]:[];
}
const CATEGORY_WORDS=new Set(`shoe shoes sneaker sneakers boot boots running hiking leather lace chunky western embroidered sandal sandals shorts short pants pant shirt shirts hoodie jacket coat headphones headphone wireless neckband noise cancelling canceling water gun cover beach blanket towel ties striped hood fly leg utility work washed cartridge valve handle single pressure constant`.split(/\s+/));
function productCategory(tokens){
  const out=[];
  for(const t of tokens){if(CATEGORY_WORDS.has(t)&&!out.includes(t))out.push(t);}
  const pairs=[['water','gun'],['running','shoes'],['cowgirl','boots'],['western','boots'],['beach','cover']];
  for(const pair of pairs){if(pair.every(x=>tokens.includes(x))) return pair.join(' ');}
  return out.slice(0,2).join(' ');
}
function queryProfiles(title,keywords=''){
  let toks=semanticTokens(`${keywords} ${title}`);
  if(!toks.length)return {exact:'',style:'',family:''};
  // De-duplicate while keeping title order. HOKA's former "One One" branding is noise for marketplace matching.
  const seen=new Set(); toks=toks.filter(t=>{if(t==='one'&&toks[0]==='hoka')return false;if(seen.has(t))return false;seen.add(t);return true;});
  const brand=brandPrefix(toks);
  const brandSet=new Set(brand);
  const modelTokens=toks.filter(t=>!brandSet.has(t) && ((/[a-z]/.test(t)&&/\d/.test(t)) || /^\d{3,8}$/.test(t)) && !/^(?:19\d\d|20\d\d)$/.test(t));
  const shortModel=toks.filter(t=>/^\d{1,2}$/.test(t));
  const descriptors=toks.filter(t=>!brandSet.has(t)&&!modelTokens.includes(t)&&!shortModel.includes(t)&&!CATEGORY_WORDS.has(t)&&!/^(?:vintage|pair|lot)$/.test(t));
  const cat=productCategory(toks);
  const addUnique=(arr,x)=>{if(x&&!arr.includes(x))arr.push(x)};

  const exact=[...brand];
  // Named line/style first, then hard model/SKU identifiers. This prevents HOKA Clifton 8 from collapsing to generic "Hoka running shoes".
  if(descriptors[0])addUnique(exact,descriptors[0]);
  modelTokens.slice(0,2).forEach(x=>addUnique(exact,x));
  if(shortModel.length && descriptors.length) addUnique(exact,shortModel[0]);
  if(!modelTokens.length && descriptors[1])addUnique(exact,descriptors[1]);
  if(exact.length<3 && cat) cat.split(' ').forEach(x=>addUnique(exact,x));

  const style=[...brand];
  if(descriptors[0])addUnique(style,descriptors[0]);
  const humanModel=modelTokens.find(t=>t.length<=6) || shortModel[0];
  if(humanModel)addUnique(style,humanModel);
  if(!humanModel && descriptors[1])addUnique(style,descriptors[1]);
  if(style.length<3 && cat)cat.split(' ').forEach(x=>addUnique(style,x));

  const family=[...brand];
  // Keep a named style whenever possible; family fallback must not become a brand-wide category dump.
  if(descriptors[0])addUnique(family,descriptors[0]);
  else if(humanModel)addUnique(family,humanModel);
  if(family.length<2 && cat)cat.split(' ').slice(0,2).forEach(x=>addUnique(family,x));
  return {exact:exact.slice(0,5).join(' '),style:style.slice(0,4).join(' '),family:family.slice(0,4).join(' ')};
}
function poolUsable(p,minSample=3){
  if(!p||p.error)return false;
  const sample=Number(p.sampleCount)||0;
  const ratio=Number(p.ratio)||0;
  return sample>=minSample && (sample<8 || ratio>=.45);
}
function activeStrength(p){
  if(!p)return -1;
  const sample=Number(p.sampleCount)||0, ratio=Number(p.ratio)||0, count=Number(p.count)||0;
  return sample*(.55+.45*ratio) + (p.totalTrusted?Math.min(count,80)/10:0);
}
function selectSpecificActive(levels){
  // Scarcity is not a reason to throw away identity. A specific exact/style query with even
  // one validated active comp is preferable to a broad family pool that changes the product.
  const exact=levels.find(x=>x.level==='exact');
  if(exact?.query && Number(exact.active?.sampleCount)>=1) return exact;
  const style=levels.find(x=>x.level==='style');
  if(style?.query && Number(style.active?.sampleCount)>=1) return style;
  for(const x of levels){if(x.query && poolUsable(x.active,3))return x;}
  return levels.filter(x=>x.query&&x.active).sort((a,b)=>activeStrength(b.active)-activeStrength(a.active))[0]||levels[0];
}
function strAssessment(str,sold,active,level){
  const soldN=Number(sold?.sampleCount)||0, activeN=Number(active?.sampleCount)||0, ratio=Number(active?.ratio)||0;
  let quality='low', note='Limited marketplace evidence';
  if(str?.providerUnavailable || sold?.error || sold?.provider==='none') return {...str,available:false,value:null,label:'Unavailable',typeLabel:'STR unavailable',quality:'none',level,note:'Sold data unavailable — provider quota or service limit reached. This is not a 0% sell-through result.'};
  if(!str.available){
    const note=str?.denominatorUncertain?'Active listings were only a sample, not a trustworthy market total. ORBIT withheld STR rather than divide sold count by a misleading denominator.':'Insufficient matched sold/active evidence';
    return {...str,typeLabel:'STR unavailable',quality:'none',level,note};
  }
  if(str?.unstableEstimate&&str?.velocity?.available){
    quality='medium';
    note=`Very high sell-through signal. Observed floor ${str.observedLabel}; velocity projection exceeds 200%, so ORBIT suppresses the exact extrapolated percentage as unstable.`;
  }else if(str?.estimated&&str?.velocity?.available){
    quality=str.velocity.confidence==='high'?'high':'medium';
    note=`Velocity estimate from ${str.velocity.datedCount} dated sold comps spanning ${Math.round(str.velocity.spanDays)} days. Observed floor ${str.observedLabel}; projected 90-day sold count ~${str.velocity.estimatedSold}.`;
  }else if(str?.estimatedValue!=null&&str?.velocity?.confidence==='low'){
    quality='low';
    note=`Sold page is capped. Observed floor ${str.label}; velocity suggests ${str.estimatedLabel}, but the ${Math.round(str.velocity.spanDays)}-day date span is too short to let that estimate drive Buy/Pass.`;
  }else if(/^title-/.test(String(level||''))&&soldN>=3&&activeN>=3){
    const purity=Math.min(Number(sold?.titlePurity??1),Number(active?.titlePurity??1));
    quality=purity>=.72&&!sold?.capped?'high':'medium';
    note=`Direct title-matched sold and active comps${active?.estimatedFromSample?' with an active denominator estimated from a high-purity eBay sample':''}.`;
  }else if(level==='exact'&&soldN>=3&&activeN>=3&&ratio>=.55){quality=sold?.capped?'medium':'high';note=sold?.capped?`Exact-model sold results filled the Trawl page cap; displayed STR is a lower bound.`:'Exact/model matched sold and active evidence.';}
  else if(level==='style'&&soldN>=3&&activeN>=3){quality='medium';note='Style-level estimate; size/color and listing fluff are excluded.';}
  else if(level==='family'){quality='low';note='Estimated family STR from a broader same-brand/style pool.';}
  if(sold?.capped&&active?.count>1200&&level!=='exact'&&!str?.estimated) return {available:false,value:null,label:'Unavailable',typeLabel:'STR unavailable',confidence:'low',quality:'none',level,note:'Sold results capped while active pool is too broad for a defensible STR.'};
  const titleMode=/^title-/.test(String(level||''));
  const typeLabel=str?.estimated?'Velocity-estimated STR':(sold?.capped?'Lower-bound STR':(titleMode?(active?.estimatedFromSample?'Title-matched STR estimate':'Title-matched STR'):(level==='exact'&&quality==='high'?'Exact STR':'Estimated STR')));
  return {...str,typeLabel,quality,level,note};
}
async function analyzeOne(file,fields,req){
  const started=Date.now();
  const keywords=String(fields.keywords||'').trim().slice(0,120);
  let imageMatches=[]; let idProvider='';
  if(ebay.ready || (EBAY_ID&&EBAY_SECRET&&ebay.disabledUntil<Date.now())){
    imageMatches=await ebayImageMatches(file);
    if(imageMatches.length>=3)idProvider='eBay image';
  }
  // SerpApi Lens costs a search. Skip it when eBay image evidence already produces a confident identity.
  const preliminaryIdentity=core.inferIdentity(imageMatches,keywords);
  const needLens=imageMatches.length===0 || (imageMatches.length<3 && preliminaryIdentity.confidence<.72 && !keywords);
  if(needLens){
    const lens=await lensMatches(file,keywords,req);
    if(lens.length){imageMatches=[...imageMatches,...lens];idProvider=imageMatches.length>lens.length?'eBay image + Google Lens':'Google Lens';}
  }
  const identity=core.inferIdentity(imageMatches,keywords);
  if(!imageMatches.length&&keywords){identity.title=keywords;identity.familyQuery=keywords;identity.confidence=.58;idProvider='user keywords';}
  const condition=inferredCondition(imageMatches);
  const profiles=core.queryProfiles(identity.title,keywords,imageMatches);
  if(!profiles.exact)throw Object.assign(new Error('Could not identify the item. Add one or two identifying keywords and rescan.'),{status:422});

  // 1.7: the chosen listing title is the primary evidence. Build progressively reduced
  // title queries, validate every one against FREE active eBay titles, and keep the
  // broadest query that still returns a highly consistent same-item cluster.
  const queryPlan=core.titleDistillationQueries(identity.title,keywords);
  if(!queryPlan.length)throw Object.assign(new Error('Could not distill a marketplace query from the identified listing title.'),{status:422});
  const activeResults=await Promise.all(queryPlan.map(x=>activeMarket(x.query,condition.value)));
  const candidates=queryPlan.map((x,i)=>({level:x.id,id:x.id,intent:x.intent||'',query:x.query,active:activeResults[i]}));
  const ranked=core.rankTitleDistillationCandidates(candidates,identity.title);
  let selected=ranked.find(x=>x.active&&!x.active.error&&Number(x.active.checked||0)>0) || ranked[0];
  if(!selected)throw Object.assign(new Error('Could not validate a marketplace query for this item.'),{status:422});
  let queryValidation=selected.validation||core.scoreTitleDistillationCandidate(identity.title,selected.active,selected);
  if(queryValidation.checked>=8 && queryValidation.productPurity<.40){
    console.log(`ORBIT title query rejected | title=${JSON.stringify(identity.title)} | query=${JSON.stringify(selected.query)} | score=${queryValidation.score} | purity=${queryValidation.productPurity} | coverage=${queryValidation.anchorCoverage}`);
    throw Object.assign(new Error('Marketplace results are too mixed to calculate reliable comps. Add a model/style/character keyword or another photo and rescan.'),{status:422});
  }
  const directActive=core.filterMarketPoolAgainstTitle(selected.active,identity.title);
  console.log(`ORBIT title distillation | title=${JSON.stringify(identity.title)} | selected=${JSON.stringify(selected.query)} | confidence=${queryValidation.confidence} | score=${queryValidation.score} | purity=${Math.round((queryValidation.productPurity||0)*100)}% | similarity=${Math.round((queryValidation.titleSimilarity||0)*100)}% | anchors=${Math.round((queryValidation.anchorCoverage||0)*100)}% | matchedActive=${directActive.count}/${directActive.sampleCount} | candidates=${ranked.map(x=>`${x.id}:${x.validation?.score||0}/P${Math.round((x.validation?.productPurity||0)*100)}%/S${Math.round((x.validation?.titleSimilarity||0)*100)}%/A${Math.round((x.validation?.anchorCoverage||0)*100)}%:${x.query}`).join(' || ')}`);
  // Decision-aware paging: because Trawl cannot fetch page 2 separately, decide page depth BEFORE the single paid request.
  // If 100 sold comps would already clear the user's minimum STR against the current active denominator, one page is enough.
  // Otherwise allow a second page so the scan can resolve borderline/high-volume items without spending that extra credit on every item.
  const minStr=Math.max(0,Number(fields.minStr||20));
  const paging=core.recommendedSoldPages(directActive?.count,minStr,2);
  const paidBudget={remaining:paging.pages};
  let soldPoolRaw=await soldMarket(selected.query,condition.value,paidBudget,paging.pages);
  const finalSelected=selected;
  // Crucially, sold and active listings are now filtered with the SAME matcher against
  // the original chosen listing title. Raw search totals never become the numerator or
  // denominator unless the sampled marketplace cluster proves that they are same-item results.
  const soldPool={...core.filterMarketPoolAgainstTitle(soldPoolRaw,identity.title),pool:finalSelected.level};
  const activePool={...directActive,pool:finalSelected.level};
  let str=strAssessment(core.computeSellThrough(soldPool,activePool),soldPool,activePool,finalSelected.level);
  if(soldPool.provider==='Trawl'&&soldPool.capped){
    if(str.estimated){
      str={...str,thresholdResolved:Number(str.value)>=minStr,note:`${str.note} ORBIT used sold-date velocity instead of treating the page cap as the final sold count.`};
    }else if(str.available&&Number(str.value)>=minStr){
      str={...str,thresholdResolved:true,note:`${str.note} The observed lower bound already clears your ${minStr}% minimum.`};
    }else if(str.available){
      str={...str,thresholdResolved:false,note:`${str.note} Actual STR may be higher than the observed floor.`};
    }
  }
  const pricing=core.pricingFromSold(soldPool);
  const bool=v=>/^(1|true|yes|on)$/i.test(String(v||''));
  const cost=core.acquisitionCost({manualPrice:fields.purchasePrice,visiblePrice:fields.visiblePrice,binsMode:bool(fields.binsMode),pricePerLb:fields.pricePerLb,title:identity.title});
  const decision=core.decision({title:identity.title,pricing,str,cost,soldCount:soldPool.count||0,activeCount:activePool.count||0,minValue:Number(fields.minValue||15),minStr:Number(fields.minStr||20),minProfit:Number(fields.minProfit||10),feeRate:Number(fields.feeRate||14)/100,shipCost:Number(fields.shipCost||8),supplies:Number(fields.supplies||1)});
  const result={
    version:VERSION,title:identity.title,identityConfidence:Math.round(identity.confidence*100),identityProvider:idProvider||'unverified',identityEvidence:identity.evidence,
    query:{exact:profiles.exact,style:profiles.style||null,family:profiles.family||null,selected:finalSelected.query,selectedMode:finalSelected.level,structured:profiles.structured||{},validation:finalSelected.validation||queryValidation,candidates:ranked.map(x=>({id:x.id,query:x.query,intent:x.intent,score:x.validation?.score||0,precision:x.validation?.precision||0,productPurity:x.validation?.productPurity??x.validation?.precision??0,lexicalPrecision:x.validation?.productPurity??0,titleSimilarity:x.validation?.titleSimilarity||0,anchorCoverage:x.validation?.anchorCoverage||0,confidence:x.validation?.confidence||'none',checked:x.validation?.checked||0,matched:x.validation?.matched||0})),diagnostics:{...(profiles.diagnostics||{}),engine:'marketplace-title-distillation',sourceTitle:identity.title}},condition,pricing,str,cost,decision,
    market:{sold:slimPool(soldPool),active:slimPool(activePool)},
    diagnostics:{ms:Date.now()-started,serpCalls:counters.serp,ebayCalls:counters.ebay,trawlCalls:counters.trawl,trawlCredits:counters.trawlCredits,cacheHits:counters.cacheHits,trawlUsed:(soldPool.provider==='Trawl'),soldProvider:soldPool.provider||'none',activeProvider:activePool.provider||'none',pairedMarketPools:true,paidSoldBudgetPerScan:paging.pages,paidSoldBudgetRemaining:paidBudget.remaining,pagingStrategy:paging.reason,onePageLowerBound:paging.onePageLowerBound,minStrThreshold:minStr,aiUsed:false}
  };
  console.log(`ORBIT analysis | title=${JSON.stringify(result.title)} | condition=${condition.value||'any'}(${condition.newVotes}/${condition.usedVotes}) | mode=${finalSelected.level} | query=${JSON.stringify(finalSelected.query)} | qscore=${queryValidation.score}/P${Math.round((queryValidation.productPurity||0)*100)}%/S${Math.round((queryValidation.titleSimilarity||0)*100)}%/A${Math.round((queryValidation.anchorCoverage||0)*100)}% | paging=${paging.pages}p:${paging.reason} | sold=${soldPool.provider||'none'}:${soldPool.count||0}/${soldPool.sampleCount||0}${soldPool.capped?'+':''} | active=${activePool.provider||'none'}:${activePool.count||0}/${activePool.sampleCount||0}${activePool.estimatedFromSample?'~':''} | ASP=${pricing.available?pricing.asp:'NA'} | prices=${pricing.tiers?.available?`${pricing.tiers.quick}/${pricing.tiers.market}/${pricing.tiers.highAsk}`:'limited'} | STR=${str.available?str.label:'NA'} | ${Date.now()-started}ms`);
  return result;
}

app.disable('x-powered-by');
app.set('trust proxy',1);
app.use(express.json({limit:'1mb'}));
app.use(express.urlencoded({extended:true}));
app.get('/tmp-images/:id',async(req,res)=>{const exp=tmpImages.get(req.params.id);if(!exp||exp<Date.now())return res.sendStatus(404);res.set('Cache-Control','public,max-age=600');res.type('jpg').sendFile(path.join(TMP_DIR,req.params.id));});
setInterval(async()=>{for(const [id,exp] of tmpImages){if(exp<Date.now()){tmpImages.delete(id);fsp.unlink(path.join(TMP_DIR,id)).catch(()=>{});}}},5*60e3).unref();

function auth(req,res,next){if(!ACCESS_CODE)return next();const got=req.get('x-orbit-code')||req.body?.accessCode||'';if(crypto.timingSafeEqual(Buffer.from(String(got).padEnd(Math.max(String(got).length,ACCESS_CODE.length),'\0')),Buffer.from(ACCESS_CODE.padEnd(Math.max(String(got).length,ACCESS_CODE.length),'\0'))))return next();return res.status(401).json({error:'Access code required'});}
app.get('/api/status',(req,res)=>res.json({ok:true,version:VERSION,protected:!!ACCESS_CODE,providers:{serpApi:!!SERP_KEY,serpCoolingDown:serpDisabledUntil>Date.now(),serpError:serpLastError,ebayConfigured:!!(EBAY_ID&&EBAY_SECRET),ebayReady:ebay.ready,ebayError:ebay.lastError,trawlConfigured:!!TRAWL_KEY,trawlAutomaticFallback:TRAWL_FALLBACK,trawlCoolingDown:trawlDisabledUntil>Date.now(),trawlError:trawlLastError,generativeAiCriticalPath:false},usage:counters,cacheEntries:cache.size}));
app.post('/api/analyze',auth,upload.array('images',4),async(req,res)=>{
  try{
    counters.analyses++;
    const files=req.files||[];if(!files.length)return res.status(400).json({error:'Add at least one photo.'});
    // Multiple photos are treated as views of the same item; use the first for visual search to conserve quota.
    const result=await analyzeOne(files[0],req.body||{},req);
    result.photoCount=files.length;
    res.json(result);
  }catch(e){console.error('Analyze error:',e);res.status(e.status||503).json({error:e.message||'Analysis failed',version:VERSION});}
});

app.use(express.static(path.join(__dirname,'public'),{maxAge:'10m',etag:true}));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.use((err,req,res,next)=>{if(err?.code==='LIMIT_FILE_SIZE')return res.status(413).json({error:'Photo is too large. Use a photo under 10 MB.'});console.error(err);res.status(500).json({error:'Unexpected server error'});});

app.listen(PORT,'0.0.0.0',()=>{
  console.log(`ORBIT ${VERSION} listening on 0.0.0.0:${PORT}`);
  console.log(`Critical path: image -> chosen listing title -> title distillation ladder -> free active-market anchor validation -> direct title-matched active denominator -> one paid sold query -> direct title-matched sold comps -> STR/pricing -> scarcity-aware decision`);
  console.log(`Generative AI critical path: OFF`);
  console.log(`SerpApi configured: ${!!SERP_KEY}`);
  console.log(`eBay credentials configured: ${!!(EBAY_ID&&EBAY_SECRET)}`);
  console.log(`Trawl configured: ${!!TRAWL_KEY}; sold fallback enabled: ${TRAWL_FALLBACK}; decision-aware sold depth=1-2 pages/scan; sold cache=${Math.round(TTL.sold/86400000)}d`);
  console.log(`Access protection: ${!!ACCESS_CODE}`);
  refreshEbayToken(true).catch(()=>{});
});
