# ORBIT 1.7.2 — Minimum-Sufficient Title Query

This release keeps query-defined STR while making title-derived query selection materially stricter and less brittle.

## Core changes
- STR still uses the exact same selected query for active and sold counts. No title matching is applied to the STR numerator or denominator.
- Added critical-anchor extraction for model/style numbers, named line/generation phrases, object type, and early title identity.
- Added explicit generation handling such as `Slide 2` and `Gen 2`.
- Added anchor-core and anchor-plus search candidates so ORBIT can broaden without throwing away the terms that define the item.
- Candidate ranking now accounts for active-result sample size. 1/1 and 2/2 result sets cannot masquerade as high-confidence markets.
- Added minimum-sufficient-query preference: once anchors and purity are supported, shorter defensible queries beat redundant long queries.
- Added stronger metadata cleanup for sizes, widths, country/origin language, condition words, colors, and seller fluff.
- Added phrase normalization for owners manuals, user guides, Gore-Tex, Ray-Ban, Fisher-Price, Toy Biz, etc.
- Added two-digit automotive year normalization in manual titles (for example `09 Nissan Cube` -> `2009 Nissan Cube`).
- Added mixed-bundle/auction-lot detection so ORBIT refuses to manufacture a misleading single-item STR for titles that clearly contain multiple products or junk-lot language.
- Rejection logs now include every attempted query, sample size, purity, and critical-anchor coverage.

## Regression targets
- Hoka Ora Recovery Slide 2 keeps `Slide 2`.
- Ray-Ban Meta Gen 2 produces `ray ban meta gen 2 smart glasses` as an explicit fallback.
- Nissan Cube manual produces `2009 nissan cube owners manual`.
- Danner Acadia 21210 strips width/size/country metadata but keeps model identity.
- Frye Duke Roper no longer trusts a 2-result exact query over a supported broader market.
- Mixed MSR stove + pot-set and auction junk-lot titles are blocked from single-item STR.

## Test status
109/109 local tests passing with 0 external API calls.
