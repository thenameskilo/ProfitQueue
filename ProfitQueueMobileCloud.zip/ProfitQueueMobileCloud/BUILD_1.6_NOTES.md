# ORBIT 1.6.0 — Constraint Identity Graph

- Replaces token-first query selection with role extraction: manufacturer/brand, named entity/product line, subject, model/SKU, object type, variant, and condition.
- Discovers multi-word entities dynamically from image-marketplace evidence rather than relying on an ever-growing phrase list.
- Extracts normalized model chains including spaced/hyphenated IDs.
- Separates condition language from product identity queries.
- Synthesizes multiple minimal identity hypotheses and validates them against free eBay active results.
- Adds object-cluster consistency to query scoring.
- Adds one adaptive active-market refinement pass before Trawl; active results can restore missing canonical tokens from the original evidence.
- Paid sold lookup remains blocked when identity confidence is inadequate.
- STR/pricing logic is intentionally unchanged.
